import express from 'express';
import http from 'http';
import path from 'path';
import fs from 'fs';
import { execSync } from 'child_process';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import { botManagerInstance } from './server/bot-manager';

dotenv.config();

async function startServer() {
  const app = express();
  const server = http.createServer(app);
  const PORT = 3000;

  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ extended: true, limit: '50mb' }));

  const dataDir = path.join(process.cwd(), 'data');
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  // --- API Endpoints ---

  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', service: 'ryze-discord-bot-host' });
  });

  // Upload and extract ZIP archive
  app.post('/api/upload/zip', async (req, res) => {
    try {
      const { base64, filename } = req.body || {};
      if (!base64) {
        return res.status(400).json({ error: 'Nenhum dado base64 enviado.' });
      }

      const buffer = Buffer.from(base64, 'base64');
      const tempZipPath = path.join(process.cwd(), 'temp_upload.zip');
      fs.writeFileSync(tempZipPath, buffer);

      // Run Python script to inspect and safely extract zip contents
      const extractScript = `
import zipfile, os, json

zip_path = 'temp_upload.zip'
extracted_files = []
has_rules = False

try:
    with zipfile.ZipFile(zip_path, 'r') as z:
        for member in z.infolist():
            # Prevent path traversal
            target_path = os.path.abspath(os.path.join('.', member.filename))
            if not target_path.startswith(os.path.abspath('.')):
                continue
            z.extract(member, '.')
            extracted_files.append({
                'filename': member.filename,
                'size': member.file_size,
                'isDir': member.is_dir()
            })
            if 'regra' in member.filename.lower():
                has_rules = True

    print(json.dumps({'success': True, 'count': len(extracted_files), 'files': extracted_files, 'hasRules': has_rules}))
except Exception as e:
    print(json.dumps({'success': False, 'error': str(e)}))
`;

      const pyRes = execSync(`python3 -c "${extractScript.replace(/"/g, '\\"')}"`, { stdio: 'pipe' }).toString();
      try {
        if (fs.existsSync(tempZipPath)) fs.unlinkSync(tempZipPath);
      } catch (_) {}

      const parsed = JSON.parse(pyRes.trim());
      if (parsed.success) {
        botManagerInstance.addLog('system', `Upload de ZIP (${filename || 'arquivo.zip'}) processado com sucesso! ${parsed.count} arquivos extraídos.`);
        return res.json({
          success: true,
          message: `ZIP extraído com sucesso! ${parsed.count} itens sincronizados.`,
          files: parsed.files,
          hasRules: parsed.hasRules,
        });
      } else {
        return res.status(400).json({ error: 'Falha ao extrair ZIP: ' + parsed.error });
      }
    } catch (err: any) {
      return res.status(500).json({ error: 'Erro ao processar upload de ZIP: ' + err.message });
    }
  });

  // Upload single file (text or binary/base64)
  app.post('/api/upload/file', (req, res) => {
    try {
      const { filename, content, isBase64, targetFolder } = req.body || {};
      if (!filename) {
        return res.status(400).json({ error: 'Nome do arquivo não especificado.' });
      }

      const safeFilename = path.basename(filename);
      let targetDir = process.cwd();
      if (targetFolder) {
        const candidateDir = path.resolve(process.cwd(), targetFolder);
        if (candidateDir.startsWith(process.cwd())) {
          targetDir = candidateDir;
        }
      }

      if (!fs.existsSync(targetDir)) {
        fs.mkdirSync(targetDir, { recursive: true });
      }

      const destPath = path.join(targetDir, safeFilename);

      if (isBase64) {
        const buffer = Buffer.from(content || '', 'base64');
        fs.writeFileSync(destPath, buffer);
      } else {
        fs.writeFileSync(destPath, content || '', 'utf8');
      }

      botManagerInstance.addLog('system', `Arquivo recebido via painel: ${path.relative(process.cwd(), destPath)}`);
      res.json({
        success: true,
        message: `Arquivo ${safeFilename} enviado com sucesso!`,
        path: path.relative(process.cwd(), destPath),
      });
    } catch (err: any) {
      res.status(500).json({ error: 'Erro ao salvar arquivo: ' + err.message });
    }
  });

  // Get project files tree
  app.get('/api/project/files-tree', (req, res) => {
    try {
      const walk = (dir: string, baseDir: string = dir): any[] => {
        const list = fs.readdirSync(dir);
        const result: any[] = [];
        for (const file of list) {
          if (file === 'node_modules' || file === '.git' || file === 'dist' || file === '.cache' || file === 'bun.lock') continue;
          const fullPath = path.join(dir, file);
          const stat = fs.statSync(fullPath);
          const relPath = path.relative(process.cwd(), fullPath);
          if (stat.isDirectory()) {
            result.push({
              name: file,
              path: relPath,
              type: 'directory',
              children: walk(fullPath, baseDir),
            });
          } else {
            result.push({
              name: file,
              path: relPath,
              type: 'file',
              size: stat.size,
              updatedAt: stat.mtimeMs,
            });
          }
        }
        return result;
      };

      const files = walk(process.cwd());
      const hasRegras = fs.existsSync(path.join(process.cwd(), 'regras.md'));
      res.json({ files, hasRegras });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Read any file raw text
  app.get('/api/project/file-content', (req, res) => {
    try {
      const filePathParam = (req.query.path as string) || '';
      if (!filePathParam) return res.status(400).json({ error: 'Caminho não fornecido' });
      
      const fullPath = path.resolve(process.cwd(), filePathParam);
      if (!fullPath.startsWith(process.cwd())) {
        return res.status(403).json({ error: 'Acesso negado fora da pasta do projeto' });
      }

      if (!fs.existsSync(fullPath)) {
        return res.status(404).json({ error: 'Arquivo não encontrado: ' + filePathParam });
      }

      const content = fs.readFileSync(fullPath, 'utf8');
      res.json({ path: filePathParam, content });
    } catch (err: any) {
      res.status(500).json({ error: 'Erro ao ler arquivo: ' + err.message });
    }
  });

  // Save any raw file
  app.post('/api/project/save-raw-file', (req, res) => {
    try {
      const { path: filePathParam, content } = req.body || {};
      if (!filePathParam) return res.status(400).json({ error: 'Caminho não fornecido' });

      const fullPath = path.resolve(process.cwd(), filePathParam);
      if (!fullPath.startsWith(process.cwd())) {
        return res.status(403).json({ error: 'Acesso negado' });
      }

      const dir = path.dirname(fullPath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }

      fs.writeFileSync(fullPath, content || '', 'utf8');
      botManagerInstance.addLog('system', `Arquivo ${filePathParam} modificado/criado.`);
      res.json({ success: true, message: `Arquivo ${filePathParam} salvo com sucesso!` });
    } catch (err: any) {
      res.status(500).json({ error: 'Erro ao salvar arquivo: ' + err.message });
    }
  });

  // Bot Status
  app.get('/api/bot/status', (req, res) => {
    const state = botManagerInstance.getState();
    const hasEnvToken = Boolean(process.env.DISCORD_BOT_TOKEN || process.env.DISCORD_TOKEN);
    res.json({
      ...state,
      hasEnvToken,
      ownerRoleId: process.env.BOT_OWNER_ROLE_ID || '',
      hasSessionSecret: Boolean(process.env.SESSION_SECRET),
      hasMercadoPago: Boolean(process.env.MERCADOPAGO_ACCESS_TOKEN),
    });
  });

  // Start Bot
  app.post('/api/bot/start', async (req, res) => {
    const { token, guildId, ownerRoleId, sessionSecret, mercadoPagoToken } = req.body || {};
    if (token) process.env.DISCORD_BOT_TOKEN = token.trim();
    if (guildId) process.env.DISCORD_GUILD_ID = guildId.trim();
    if (ownerRoleId) process.env.BOT_OWNER_ROLE_ID = ownerRoleId.trim();
    if (sessionSecret) process.env.SESSION_SECRET = sessionSecret.trim();
    if (mercadoPagoToken) process.env.MERCADOPAGO_ACCESS_TOKEN = mercadoPagoToken.trim();

    botManagerInstance.saveAppConfig({
      token: token ? token.trim() : undefined,
      guildId: guildId ? guildId.trim() : undefined,
      ownerRoleId: ownerRoleId ? ownerRoleId.trim() : undefined,
      sessionSecret: sessionSecret ? sessionSecret.trim() : undefined,
      mercadoPagoToken: mercadoPagoToken ? mercadoPagoToken.trim() : undefined,
    });

    const result = await botManagerInstance.start(token);
    res.json(result);
  });

  // Stop Bot
  app.post('/api/bot/stop', async (req, res) => {
    const result = await botManagerInstance.stop();
    res.json(result);
  });

  // Restart Bot
  app.post('/api/bot/restart', async (req, res) => {
    const { token, guildId } = req.body || {};
    if (token) {
      process.env.DISCORD_BOT_TOKEN = token.trim();
      botManagerInstance.saveAppConfig({ token: token.trim() });
    }
    if (guildId) {
      process.env.DISCORD_GUILD_ID = guildId.trim();
      botManagerInstance.saveAppConfig({ guildId: guildId.trim() });
    }
    const result = await botManagerInstance.restart(token);
    res.json(result);
  });

  // Get Logs
  app.get('/api/bot/logs', (req, res) => {
    res.json({ logs: botManagerInstance.getLogs() });
  });

  // Clear Logs
  app.post('/api/bot/logs/clear', (req, res) => {
    botManagerInstance.clearLogs();
    res.json({ success: true });
  });

  // Get Config
  app.get('/api/bot/config', (req, res) => {
    let ownerRoleId = process.env.BOT_OWNER_ROLE_ID || process.env.CARGO_OWNER_ID || '';
    try {
      const appConfigPath = path.join(dataDir, 'app_config.json');
      if (fs.existsSync(appConfigPath)) {
        const raw = fs.readFileSync(appConfigPath, 'utf8').trim();
        if (raw) {
          const cfg = JSON.parse(raw);
          if (cfg.ownerRoleId) ownerRoleId = cfg.ownerRoleId;
        }
      }
    } catch (_) {}

    const token = process.env.DISCORD_BOT_TOKEN || process.env.DISCORD_TOKEN || '';
    const maskedToken = token
      ? `${token.slice(0, 8)}...${token.slice(-6)}`
      : '';
    res.json({
      hasToken: Boolean(token),
      maskedToken,
      guildId: process.env.DISCORD_GUILD_ID || process.env.GUILD_ID || '',
      ownerRoleId,
      sessionSecretConfigured: Boolean(process.env.SESSION_SECRET),
      mercadoPagoConfigured: Boolean(process.env.MERCADOPAGO_ACCESS_TOKEN),
    });
  });

  // Save Config
  app.post('/api/bot/config', (req, res) => {
    const { token, guildId, ownerRoleId, sessionSecret, mercadoPagoToken } = req.body || {};
    if (token !== undefined) {
      if (token.trim()) process.env.DISCORD_BOT_TOKEN = token.trim();
      else delete process.env.DISCORD_BOT_TOKEN;
    }
    if (guildId !== undefined) {
      process.env.DISCORD_GUILD_ID = guildId.trim();
      process.env.GUILD_ID = guildId.trim();
    }
    if (ownerRoleId !== undefined) {
      process.env.BOT_OWNER_ROLE_ID = ownerRoleId.trim();
      process.env.CARGO_OWNER_ID = ownerRoleId.trim();
    }
    if (sessionSecret !== undefined && sessionSecret.trim()) {
      process.env.SESSION_SECRET = sessionSecret.trim();
    }
    if (mercadoPagoToken !== undefined) {
      process.env.MERCADOPAGO_ACCESS_TOKEN = mercadoPagoToken.trim();
    }

    botManagerInstance.saveAppConfig({
      token: token !== undefined ? (token.trim() || '') : undefined,
      guildId: guildId !== undefined ? guildId.trim() : undefined,
      ownerRoleId: ownerRoleId !== undefined ? ownerRoleId.trim() : undefined,
      sessionSecret: sessionSecret !== undefined ? sessionSecret.trim() : undefined,
      mercadoPagoToken: mercadoPagoToken !== undefined ? mercadoPagoToken.trim() : undefined,
    });

    botManagerInstance.addLog('system', 'Configurações persistidas com sucesso.');
    res.json({ success: true, message: 'Configurações salvas.' });
  });

  // List Data Files
  app.get('/api/bot/data-files', (req, res) => {
    try {
      const files = fs.readdirSync(dataDir).filter((f) => f.endsWith('.json'));
      const list = files.map((name) => {
        const stats = fs.statSync(path.join(dataDir, name));
        return {
          name,
          size: stats.size,
          updatedAt: stats.mtimeMs,
        };
      });
      res.json({ files: list });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Get specific JSON data file
  app.get('/api/bot/data-file/:filename', (req, res) => {
    const filename = path.basename(req.params.filename);
    if (!filename.endsWith('.json')) {
      return res.status(400).json({ error: 'Apenas arquivos .json são permitidos' });
    }
    const filePath = path.join(dataDir, filename);
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ error: 'Arquivo não encontrado' });
    }
    try {
      const content = fs.readFileSync(filePath, 'utf8');
      const parsed = JSON.parse(content);
      res.json({ filename, data: parsed, raw: content });
    } catch (err: any) {
      res.status(500).json({ error: 'Arquivo JSON inválido ou erro de leitura: ' + err.message });
    }
  });

  // Update specific JSON data file
  app.post('/api/bot/data-file/:filename', (req, res) => {
    const filename = path.basename(req.params.filename);
    if (!filename.endsWith('.json')) {
      return res.status(400).json({ error: 'Apenas arquivos .json são permitidos' });
    }
    const filePath = path.join(dataDir, filename);
    const { data, raw } = req.body || {};
    try {
      let contentToWrite = '';
      if (raw !== undefined) {
        JSON.parse(raw); // validate JSON syntax
        contentToWrite = raw;
      } else if (data !== undefined) {
        contentToWrite = JSON.stringify(data, null, 2);
      } else {
        return res.status(400).json({ error: 'Conteúdo não fornecido' });
      }

      fs.writeFileSync(filePath, contentToWrite, 'utf8');
      botManagerInstance.addLog('system', `Arquivo de dados "${filename}" salvo com sucesso.`);
      res.json({ success: true, message: `Arquivo ${filename} atualizado.` });
    } catch (err: any) {
      res.status(400).json({ error: 'Falha ao salvar JSON: ' + err.message });
    }
  });

  // Helper to generate fresh project ZIP (includes configured credentials)
  const generateFreshZip = () => {
    const zipPath = path.join(process.cwd(), 'projeto-completo.zip');
    try {
      if (fs.existsSync(zipPath)) {
        fs.unlinkSync(zipPath);
      }
    } catch (_) {}

    execSync(`python3 -c "
import zipfile, os, json, re

zip_filename = 'projeto-completo.zip'
excluded_dirs = {'node_modules', '.git', 'dist', '.cache', '__pycache__', '.temp', 'coverage', '.vercel', '.next'}
excluded_files = {'projeto-completo.zip', 'ryze-discord-bot.zip', 'projeto.zip', '.DS_Store', '.env.local', '.env.production', 'temp_upload.zip'}

with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as z:
    for root, dirs, files in os.walk('.'):
        dirs[:] = [d for d in dirs if d not in excluded_dirs]
        for file in files:
            if file in excluded_files or file.endswith('.pyc') or file.startswith('temp_') or file == zip_filename:
                continue
            filepath = os.path.join(root, file)
            relpath = os.path.relpath(filepath, '.')
            
            # Write file directly, preserving configured credentials in data/app_config.json
            z.write(filepath, relpath)
"`, { stdio: 'pipe' });
    return zipPath;
  };

  // ── Remote Sync & Auto-Update API ──────────────────────────────────────────

  // Helper to get all project files for direct remote sync payload
  const getProjectSyncFiles = () => {
    const excludedDirs = new Set(['node_modules', '.git', 'dist', '.cache', '__pycache__', '.temp', 'coverage', '.vercel', '.next']);
    const excludedFiles = new Set(['projeto-completo.zip', 'ryze-discord-bot.zip', 'projeto.zip', '.DS_Store', '.env.local', '.env.production', 'temp_upload.zip']);
    const binaryExtensions = new Set(['.png', '.jpg', '.jpeg', '.gif', '.webp', '.ico', '.pdf', '.zip', '.tar', '.gz', '.mp3', '.wav', '.woff', '.woff2', '.ttf', '.eot']);

    const files: Array<{ path: string; content: string; isBase64: boolean; size: number; mtime: number }> = [];

    const walk = (dir: string) => {
      const list = fs.readdirSync(dir);
      for (const item of list) {
        if (excludedDirs.has(item)) continue;
        const fullPath = path.join(dir, item);
        const stat = fs.statSync(fullPath);
        if (stat.isDirectory()) {
          walk(fullPath);
        } else {
          if (excludedFiles.has(item) || item.endsWith('.pyc') || item.startsWith('temp_')) continue;
          const relPath = path.relative(process.cwd(), fullPath).replace(/\\/g, '/');
          const ext = path.extname(item).toLowerCase();
          const isBinary = binaryExtensions.has(ext);

          if (isBinary) {
            const buf = fs.readFileSync(fullPath);
            files.push({
              path: relPath,
              content: buf.toString('base64'),
              isBase64: true,
              size: stat.size,
              mtime: stat.mtimeMs,
            });
          } else {
            const text = fs.readFileSync(fullPath, 'utf8');
            files.push({
              path: relPath,
              content: text,
              isBase64: false,
              size: stat.size,
              mtime: stat.mtimeMs,
            });
          }
        }
      }
    };

    walk(process.cwd());
    return files;
  };

  // Sync Info endpoint
  app.get(['/api/sync/info', '/api/sync/status'], (req, res) => {
    try {
      const proto = req.headers['x-forwarded-proto'] || req.protocol || 'http';
      const host = req.headers['x-forwarded-host'] || req.headers.host || `localhost:${PORT}`;
      const baseUrl = `${proto}://${host}`;
      const now = new Date().toISOString();

      res.json({
        success: true,
        service: 'Ryze Discord Bot Remote Sync Master',
        timestamp: now,
        version: Date.now().toString(36),
        endpoints: {
          info: `${baseUrl}/api/sync/info`,
          payload: `${baseUrl}/api/sync/payload`,
          bundleZip: `${baseUrl}/api/sync/bundle.zip`,
          downloadZip: `${baseUrl}/api/project/download-zip`,
        },
        quickCommands: {
          nodeSync: 'node sync.js',
          npmSync: 'npm run sync',
          discordCommand: '.atualizar',
        },
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Sync Payload (JSON containing all files for zero-dependency remote auto-update)
  app.get('/api/sync/payload', (req, res) => {
    try {
      const files = getProjectSyncFiles();
      const timestamp = new Date().toISOString();
      const version = Date.now().toString(36);

      res.json({
        success: true,
        version,
        timestamp,
        count: files.length,
        files,
      });
    } catch (err: any) {
      res.status(500).json({ error: 'Erro ao gerar payload de sincronização: ' + err.message });
    }
  });

  // Sync Bundle ZIP stream
  app.get(['/api/sync/bundle.zip', '/api/sync/download'], (req, res) => {
    try {
      const zipPath = generateFreshZip();
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', 'attachment; filename="ryze-bot-sync.zip"');
      res.sendFile(zipPath);
    } catch (err: any) {
      res.status(500).json({ error: 'Erro ao gerar ZIP de sincronização: ' + err.message });
    }
  });

  // Download Complete Project Code as ZIP (always fresh)
  app.get(['/api/bot/download-zip', '/api/project/download-zip', '/download/projeto.zip'], (req, res) => {
    try {
      const zipPath = generateFreshZip();
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', 'attachment; filename="projeto-completo.zip"');
      res.sendFile(zipPath);
    } catch (err: any) {
      res.status(500).json({ error: 'Erro ao gerar arquivo zip: ' + err.message });
    }
  });

  // Base64 Download endpoint for sandboxed iframe environments (always fresh)
  app.get('/api/project/download-base64', (req, res) => {
    try {
      const zipPath = generateFreshZip();
      const fileBuffer = fs.readFileSync(zipPath);
      const base64Data = fileBuffer.toString('base64');
      res.json({
        filename: 'projeto-completo.zip',
        size: fileBuffer.length,
        base64: base64Data,
      });
    } catch (err: any) {
      res.status(500).json({ error: 'Erro ao converter zip: ' + err.message });
    }
  });

  // Auto-start bot if token is already present
  const initialToken = process.env.DISCORD_BOT_TOKEN || process.env.DISCORD_TOKEN;
  if (initialToken) {
    botManagerInstance.addLog('system', 'DISCORD_BOT_TOKEN detectado no ambiente. Iniciando bot...');
    botManagerInstance.start();
  } else {
    botManagerInstance.addLog('system', 'Pronto para execução. Insira o Token do Discord no painel para iniciar.');
  }

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`[RYZE-BOT-DASHBOARD] Servidor web rodando na porta ${PORT}`);
  });
}

startServer();
