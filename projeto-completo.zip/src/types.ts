export interface LogEntry {
  id: string;
  timestamp: string;
  type: 'stdout' | 'stderr' | 'system' | 'error' | 'ready';
  message: string;
}

export interface BotState {
  status: 'offline' | 'starting' | 'online' | 'error';
  tag?: string;
  id?: string;
  avatar?: string;
  guildCount: number;
  uptimeSeconds: number;
  startedAt?: number;
  lastError?: string;
  hasEnvToken: boolean;
  ownerRoleId?: string;
  hasSessionSecret: boolean;
  hasMercadoPago: boolean;
  workers?: Array<{ slot: number; state: string; tag?: string; id?: string }>;
  memoryUsageMb?: number;
}

export interface BotConfig {
  hasToken: boolean;
  maskedToken: string;
  guildId?: string;
  ownerRoleId: string;
  sessionSecretConfigured: boolean;
  mercadoPagoConfigured: boolean;
}

export interface DataFileInfo {
  name: string;
  size: number;
  updatedAt: number;
}

