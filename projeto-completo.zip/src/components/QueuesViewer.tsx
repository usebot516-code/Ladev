import React, { useState, useEffect } from 'react';
import { Radio, Users, Shield, Tv, Sparkles, RefreshCw, Trophy, Swords, CheckCircle } from 'lucide-react';

export const QueuesViewer: React.FC = () => {
  const [filasData, setFilasData] = useState<any>(null);
  const [mediadoresData, setMediadoresData] = useState<any>(null);
  const [analistasData, setAnalistasData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);

  const fetchData = async () => {
    setIsLoading(true);
    try {
      const [fRes, mRes, aRes] = await Promise.all([
        fetch('/api/bot/data-file/filas_data.json').catch(() => null),
        fetch('/api/bot/data-file/mediadores_data.json').catch(() => null),
        fetch('/api/bot/data-file/analistas_data.json').catch(() => null),
      ]);

      if (fRes && fRes.ok && (fRes.headers.get('content-type') || '').includes('application/json')) {
        const d = await fRes.json();
        setFilasData(d.data);
      }
      if (mRes && mRes.ok && (mRes.headers.get('content-type') || '').includes('application/json')) {
        const d = await mRes.json();
        setMediadoresData(d.data);
      }
      if (aRes && aRes.ok && (aRes.headers.get('content-type') || '').includes('application/json')) {
        const d = await aRes.json();
        setAnalistasData(d.data);
      }
    } catch (e) {
      console.warn('Could not fetch queue files:', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-amber-900/40 bg-stone-900/60 p-5 backdrop-blur-sm">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-400">
            <Radio className="h-6 w-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-stone-100">
              Filas Free Fire & Mediadores
            </h2>
            <p className="text-xs text-stone-400">
              Painéis interativos de apostas, conferência Pix e gerenciamento de filas Free Fire.
            </p>
          </div>
        </div>

        <button
          onClick={fetchData}
          disabled={isLoading}
          className="flex items-center gap-1.5 rounded-xl border border-stone-700 bg-stone-950 px-3.5 py-2 text-xs font-semibold text-stone-300 hover:text-white"
        >
          <RefreshCw className={`h-3.5 w-3.5 ${isLoading ? 'animate-spin' : ''}`} />
          <span>Atualizar Dados</span>
        </button>
      </div>

      {/* Queue Types Cards */}
      <div className="grid grid-cols-1 gap-5 md:grid-cols-3">
        {/* Fila Mediador */}
        <div className="rounded-2xl border border-amber-900/40 bg-stone-950 p-5 space-y-3">
          <div className="flex items-center gap-2.5 text-amber-400">
            <Shield className="h-5 w-5" />
            <h3 className="font-bold text-stone-100">Fila Mediador</h3>
          </div>
          <p className="text-xs text-stone-400">
            Mediadores escolhem o método de recebimento (Asaas, Mercado Pago, PagBank, Inter, Efí, Pix). Valida o valor da aposta e cria a sala no Free Fire automaticamente via Nixff.
          </p>
          <div className="rounded-xl border border-stone-800 bg-stone-900/80 p-3 text-xs font-mono space-y-1">
            <div className="text-stone-400">Comando: <span className="text-amber-300 font-bold">/fila mediador</span></div>
            <div className="text-stone-400">Canal padrão: <span className="text-stone-200">🗂️・filas-med</span></div>
          </div>
        </div>

        {/* Fila Analista */}
        <div className="rounded-2xl border border-cyan-900/40 bg-stone-950 p-5 space-y-3">
          <div className="flex items-center gap-2.5 text-cyan-400">
            <Users className="h-5 w-5" />
            <h3 className="font-bold text-stone-100">Fila Analista (SS)</h3>
          </div>
          <p className="text-xs text-stone-400">
            Fila para membros solicitarem telagem e análise de partidas suspeitas com equipe dedicada de analistas.
          </p>
          <div className="rounded-xl border border-stone-800 bg-stone-900/80 p-3 text-xs font-mono space-y-1">
            <div className="text-stone-400">Comando: <span className="text-cyan-300 font-bold">/fila analista</span></div>
            <div className="text-stone-400">Canal padrão: <span className="text-stone-200">💬・chat-analista</span></div>
          </div>
        </div>

        {/* Fila Streamer */}
        <div className="rounded-2xl border border-purple-900/40 bg-stone-950 p-5 space-y-3">
          <div className="flex items-center gap-2.5 text-purple-400">
            <Tv className="h-5 w-5" />
            <h3 className="font-bold text-stone-100">Fila Streamer</h3>
          </div>
          <p className="text-xs text-stone-400">
            Filas exclusivas para criadores de conteúdo e transmissões com sorteio e gerenciamento de espectadores.
          </p>
          <div className="rounded-xl border border-stone-800 bg-stone-900/80 p-3 text-xs font-mono space-y-1">
            <div className="text-stone-400">Comando: <span className="text-purple-300 font-bold">/fila streamer</span></div>
            <div className="text-stone-400">Canal padrão: <span className="text-stone-200">🎥・fila-streamer</span></div>
          </div>
        </div>
      </div>

      {/* Partida Workflow Card */}
      <div className="rounded-2xl border border-stone-800 bg-stone-900/60 p-5 space-y-3">
        <h3 className="text-sm font-bold text-stone-100 flex items-center gap-2">
          <Swords className="h-4 w-4 text-amber-400" />
          <span>Fluxo de Confirmação e Criação de Sala Free Fire</span>
        </h3>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-4">
          <div className="rounded-xl border border-stone-800 bg-stone-950 p-3">
            <span className="text-[10px] font-bold text-amber-400 block mb-1">PASSO 1</span>
            <h4 className="text-xs font-bold text-stone-200">Jogadores entram</h4>
            <p className="text-[11px] text-stone-400 mt-1">2 jogadores selecionam valor e subtipo da partida (Gelo Infinito, Padrão, etc).</p>
          </div>
          <div className="rounded-xl border border-stone-800 bg-stone-950 p-3">
            <span className="text-[10px] font-bold text-amber-400 block mb-1">PASSO 2</span>
            <h4 className="text-xs font-bold text-stone-200">Pagamento Pix</h4>
            <p className="text-[11px] text-stone-400 mt-1">Os jogadores enviam <code>pg Nome Sobrenome</code> no tópico da partida.</p>
          </div>
          <div className="rounded-xl border border-stone-800 bg-stone-950 p-3">
            <span className="text-[10px] font-bold text-amber-400 block mb-1">PASSO 3</span>
            <h4 className="text-xs font-bold text-stone-200">Validação Automática</h4>
            <p className="text-[11px] text-stone-400 mt-1">O bot valida o comprovante com a API do banco do mediador.</p>
          </div>
          <div className="rounded-xl border border-stone-800 bg-stone-950 p-3">
            <span className="text-[10px] font-bold text-emerald-400 block mb-1">PASSO 4</span>
            <h4 className="text-xs font-bold text-stone-200">Sala Criada</h4>
            <p className="text-[11px] text-stone-400 mt-1">Gera ID e Senha da sala Nixff.vip com botões de cópia direta.</p>
          </div>
        </div>
      </div>
    </div>
  );
};
