import React, { useState } from 'react';
import {
  Bot,
  Play,
  Square,
  RotateCcw,
  RefreshCw,
  Terminal,
  Server,
  Layers,
  Settings,
  Database,
  ExternalLink,
  ShieldAlert,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Download,
  Loader2,
  Upload,
  FileText,
} from 'lucide-react';
import { BotState } from '../types';
import { downloadProjectZip } from '../utils/downloadZip';

interface HeaderProps {
  activeTab: 'overview' | 'console' | 'multibot' | 'queues' | 'data' | 'files' | 'guide' | 'rules';
  onTabChange: (tab: 'overview' | 'console' | 'multibot' | 'queues' | 'data' | 'files' | 'guide' | 'rules') => void;
  botState: BotState | null;
  onStartBot: () => void;
  onStopBot: () => void;
  onRestartBot: () => void;
  isActionLoading: boolean;
  onOpenConfigModal: () => void;
  onOpenSyncModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onTabChange,
  botState,
  onStartBot,
  onStopBot,
  onRestartBot,
  isActionLoading,
  onOpenConfigModal,
  onOpenSyncModal,
}) => {
  const [isDownloading, setIsDownloading] = useState(false);
  const isOnline = botState?.status === 'online';
  const isStarting = botState?.status === 'starting';
  const isError = botState?.status === 'error';

  const handleDownload = async () => {
    setIsDownloading(true);
    await downloadProjectZip();
    setIsDownloading(false);
  };

  const formatUptime = (seconds: number) => {
    if (!seconds) return '0s';
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    if (hrs > 0) return `${hrs}h ${mins}m ${secs}s`;
    if (mins > 0) return `${mins}m ${secs}s`;
    return `${secs}s`;
  };

  return (
    <header className="sticky top-0 z-50 border-b border-indigo-950/60 bg-stone-950/90 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4 px-4 py-3 sm:px-6">
        {/* Brand & Bot Identity */}
        <div className="flex items-center gap-3">
          <div className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-600 to-violet-700 shadow-md shadow-indigo-950/60 text-white">
            <Bot className="h-6 w-6" />
            <span
              className={`absolute -bottom-0.5 -right-0.5 h-3.5 w-3.5 rounded-full border-2 border-stone-950 ${
                isOnline
                  ? 'bg-emerald-500 shadow-[0_0_8px_#10b981]'
                  : isStarting
                  ? 'bg-amber-400 animate-pulse'
                  : isError
                  ? 'bg-rose-500'
                  : 'bg-stone-600'
              }`}
            />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-bold tracking-tight text-stone-100 sm:text-lg">
                Ryze Discord Bot
              </h1>
              <span
                className={`rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider ${
                  isOnline
                    ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-500/40'
                    : isStarting
                    ? 'bg-amber-950/80 text-amber-300 border border-amber-500/40'
                    : isError
                    ? 'bg-rose-950/80 text-rose-300 border border-rose-500/40'
                    : 'bg-stone-900 text-stone-400 border border-stone-800'
                }`}
              >
                {isOnline ? 'Online' : isStarting ? 'Iniciando' : isError ? 'Erro' : 'Parado'}
              </span>
            </div>
            <p className="text-xs text-stone-400 font-mono">
              {botState?.tag ? `@${botState.tag}` : 'Host Ativo • Node.js v18+'}
              {isOnline && botState?.uptimeSeconds ? ` • Uptime: ${formatUptime(botState.uptimeSeconds)}` : ''}
            </p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="flex items-center gap-1 overflow-x-auto rounded-xl border border-stone-800 bg-stone-900/80 p-1">
          {[
            { id: 'overview', label: 'Painel Geral', icon: Server },
            { id: 'console', label: 'Console & Logs', icon: Terminal },
            { id: 'multibot', label: 'Multi-Bots (.bots)', icon: Layers },
            { id: 'queues', label: 'Filas & Partidas', icon: Layers },
            { id: 'data', label: 'Arquivos JSON', icon: Database },
            { id: 'files', label: 'Anexos & ZIPs', icon: Upload },
            { id: 'guide', label: 'Comandos & Guia', icon: HelpCircle },
            { id: 'rules', label: 'Regras (regras.md)', icon: FileText },
          ].map((tab) => {
            const Icon = tab.icon;
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id as any)}
                className={`flex items-center gap-1.5 whitespace-nowrap rounded-lg px-3 py-1.5 text-xs font-medium transition-all ${
                  active
                    ? 'bg-indigo-600 text-white shadow-sm font-semibold'
                    : 'text-stone-400 hover:text-stone-200 hover:bg-stone-800/60'
                }`}
              >
                <Icon className="h-3.5 w-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Actions (Start/Stop/Restart/Config) */}
        <div className="flex items-center gap-2">
          {isOnline ? (
            <>
              <button
                onClick={onStopBot}
                disabled={isActionLoading}
                className="flex items-center gap-1.5 rounded-xl border border-rose-700/60 bg-rose-950/60 px-3 py-1.5 text-xs font-semibold text-rose-200 shadow hover:bg-rose-900/80 disabled:opacity-50"
                title="Desligar Bot"
              >
                <Square className="h-3.5 w-3.5 fill-current" />
                <span>Parar</span>
              </button>
              <button
                onClick={onRestartBot}
                disabled={isActionLoading}
                className="flex items-center gap-1.5 rounded-xl border border-stone-700 bg-stone-900 px-3 py-1.5 text-xs font-semibold text-stone-200 shadow hover:bg-stone-800 disabled:opacity-50"
                title="Reiniciar Bot"
              >
                <RotateCcw className="h-3.5 w-3.5" />
                <span>Reiniciar</span>
              </button>
            </>
          ) : (
            <button
              onClick={onStartBot}
              disabled={isActionLoading || isStarting}
              className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 px-4 py-1.5 text-xs font-bold text-white shadow-lg shadow-emerald-950/50 hover:from-emerald-500 hover:to-teal-500 disabled:opacity-50"
              title="Ligar Bot"
            >
              <Play className="h-3.5 w-3.5 fill-current" />
              <span>{isStarting ? 'Iniciando...' : 'Ligar Bot'}</span>
            </button>
          )}

          <button
            onClick={onOpenSyncModal}
            className="flex items-center gap-1.5 rounded-xl border border-cyan-500/40 bg-cyan-950/40 px-3 py-1.5 text-xs font-semibold text-cyan-200 hover:bg-cyan-900/60 hover:text-white transition-all shadow-sm"
            title="Conectar e sincronizar código com hospedagem externa (Auto-Update)"
          >
            <RefreshCw className="h-3.5 w-3.5 text-cyan-400" />
            <span className="hidden sm:inline">Auto-Update</span>
          </button>

          <button
            onClick={onOpenConfigModal}
            className="flex items-center gap-1.5 rounded-xl border border-stone-800 bg-stone-900 px-3 py-1.5 text-xs font-medium text-stone-300 hover:border-stone-700 hover:text-white"
            title="Configurar Token e Credenciais"
          >
            <Settings className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Credenciais</span>
          </button>

          <button
            onClick={handleDownload}
            disabled={isDownloading}
            className="flex items-center gap-1.5 rounded-xl border border-indigo-500/40 bg-indigo-950/50 px-3 py-1.5 text-xs font-medium text-indigo-200 hover:bg-indigo-900/60 hover:text-white transition-colors disabled:opacity-50"
            title="Baixar projeto completo em formato .ZIP"
          >
            {isDownloading ? (
              <Loader2 className="h-3.5 w-3.5 animate-spin text-indigo-400" />
            ) : (
              <Download className="h-3.5 w-3.5" />
            )}
            <span className="hidden sm:inline">{isDownloading ? 'Baixando...' : 'Baixar .ZIP'}</span>
          </button>
        </div>
      </div>
    </header>
  );
};
