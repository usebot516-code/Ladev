import React, { useState, useEffect, useRef } from 'react';
import { Terminal, Trash2, Copy, Check, ArrowDown, Search, Filter, RefreshCw } from 'lucide-react';
import { LogEntry } from '../types';

interface LiveConsoleProps {
  logs: LogEntry[];
  onClearLogs: () => void;
  onRefreshLogs: () => void;
  isLoading: boolean;
}

export const LiveConsole: React.FC<LiveConsoleProps> = ({
  logs,
  onClearLogs,
  onRefreshLogs,
  isLoading,
}) => {
  const [filterType, setFilterType] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [autoScroll, setAutoScroll] = useState<boolean>(true);
  const [copied, setCopied] = useState<boolean>(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (autoScroll && scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs, autoScroll]);

  const filteredLogs = logs.filter((log) => {
    if (filterType === 'error' && log.type !== 'error' && log.type !== 'stderr' && !log.message.includes('[ERRO]')) {
      return false;
    }
    if (filterType === 'ready' && log.type !== 'ready' && !log.message.includes('Online')) {
      return false;
    }
    if (filterType === 'system' && log.type !== 'system') {
      return false;
    }
    if (searchTerm) {
      return log.message.toLowerCase().includes(searchTerm.toLowerCase());
    }
    return true;
  });

  const handleCopyLogs = () => {
    const text = logs.map((l) => `[${l.timestamp}] [${l.type.toUpperCase()}] ${l.message}`).join('\n');
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const getLogColor = (log: LogEntry) => {
    if (log.type === 'error' || log.type === 'stderr' || log.message.includes('[ERRO]') || log.message.includes('[FATAL]')) {
      return 'text-rose-400 bg-rose-950/20';
    }
    if (log.type === 'ready' || log.message.includes('Online como') || log.message.includes('autenticado')) {
      return 'text-emerald-300 font-semibold bg-emerald-950/20';
    }
    if (log.message.includes('[AVISO]')) {
      return 'text-amber-300';
    }
    if (log.type === 'system') {
      return 'text-cyan-300';
    }
    if (log.message.includes('[BOTS]')) {
      return 'text-violet-300';
    }
    if (log.message.includes('[LOJA]')) {
      return 'text-yellow-300';
    }
    return 'text-stone-300';
  };

  return (
    <div className="flex flex-col rounded-2xl border border-stone-800 bg-stone-950 shadow-2xl overflow-hidden min-h-[580px]">
      {/* Console Top Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-stone-800 bg-stone-900/90 px-4 py-3">
        <div className="flex items-center gap-3">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-stone-800 text-indigo-400">
            <Terminal className="h-4 w-4" />
          </div>
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-stone-200">
              Terminal de Logs & Eventos Discord
            </h3>
            <p className="text-[11px] text-stone-400 font-mono">
              {filteredLogs.length} linhas filtradas ({logs.length} total)
            </p>
          </div>
        </div>

        {/* Filters & Search */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Search Input */}
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-stone-500" />
            <input
              type="text"
              placeholder="Buscar logs..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="rounded-lg border border-stone-800 bg-stone-950 pl-8 pr-3 py-1 text-xs text-stone-200 placeholder:text-stone-500 focus:border-indigo-500 focus:outline-none w-36 sm:w-48"
            />
          </div>

          {/* Level Filter */}
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="rounded-lg border border-stone-800 bg-stone-950 px-2.5 py-1 text-xs text-stone-300 focus:border-indigo-500 focus:outline-none"
          >
            <option value="all">Todos os tipos</option>
            <option value="error">Erros & Avisos</option>
            <option value="ready">Conexões / Ready</option>
            <option value="system">Sistema Interno</option>
          </select>

          {/* Auto Scroll */}
          <button
            onClick={() => setAutoScroll(!autoScroll)}
            className={`flex items-center gap-1 rounded-lg px-2.5 py-1 text-xs font-medium transition-colors ${
              autoScroll
                ? 'bg-indigo-950 text-indigo-300 border border-indigo-700/50'
                : 'bg-stone-800 text-stone-400 border border-stone-700'
            }`}
            title="Rolar automaticamente para a última linha"
          >
            <ArrowDown className="h-3 w-3" />
            <span>Auto-scroll</span>
          </button>

          {/* Copy */}
          <button
            onClick={handleCopyLogs}
            disabled={logs.length === 0}
            className="flex items-center gap-1 rounded-lg border border-stone-800 bg-stone-950 px-2.5 py-1 text-xs text-stone-300 hover:bg-stone-800 hover:text-white disabled:opacity-40"
            title="Copiar todos os logs"
          >
            {copied ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
            <span>{copied ? 'Copiado!' : 'Copiar'}</span>
          </button>

          {/* Refresh */}
          <button
            onClick={onRefreshLogs}
            disabled={isLoading}
            className="flex items-center gap-1 rounded-lg border border-stone-800 bg-stone-950 px-2.5 py-1 text-xs text-stone-300 hover:bg-stone-800 hover:text-white"
            title="Atualizar logs"
          >
            <RefreshCw className={`h-3 w-3 ${isLoading ? 'animate-spin' : ''}`} />
          </button>

          {/* Clear */}
          <button
            onClick={onClearLogs}
            disabled={logs.length === 0}
            className="flex items-center gap-1 rounded-lg border border-stone-800 bg-stone-950 px-2.5 py-1 text-xs text-stone-400 hover:bg-rose-950/60 hover:text-rose-300 hover:border-rose-800/60 disabled:opacity-40"
            title="Limpar buffer de logs"
          >
            <Trash2 className="h-3 w-3" />
            <span>Limpar</span>
          </button>
        </div>
      </div>

      {/* Logs Output Window */}
      <div
        ref={scrollRef}
        className="flex-1 overflow-y-auto bg-stone-950 p-4 font-mono text-[12px] leading-relaxed select-text space-y-1 min-h-[460px] max-h-[640px]"
      >
        {filteredLogs.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full py-16 text-center text-stone-500">
            <Terminal className="h-10 w-10 mb-2 stroke-[1.5] text-stone-600" />
            <p className="text-xs">Nenhum log registrado no momento.</p>
            <p className="text-[11px] text-stone-600 mt-0.5">
              Inicie o bot com seu Token do Discord para visualizar os eventos em tempo real.
            </p>
          </div>
        ) : (
          filteredLogs.map((log) => (
            <div
              key={log.id}
              className={`flex items-start gap-2 rounded px-2 py-0.5 hover:bg-stone-900/60 transition-colors ${getLogColor(
                log
              )}`}
            >
              <span className="text-stone-600 select-none text-[11px] shrink-0 font-mono">
                [{log.timestamp}]
              </span>
              <span
                className={`text-[10px] uppercase font-bold shrink-0 px-1 py-0.2 rounded border ${
                  log.type === 'error' || log.type === 'stderr'
                    ? 'border-rose-800 text-rose-300 bg-rose-950/60'
                    : log.type === 'ready'
                    ? 'border-emerald-800 text-emerald-300 bg-emerald-950/60'
                    : log.type === 'system'
                    ? 'border-cyan-800 text-cyan-300 bg-cyan-950/60'
                    : 'border-stone-800 text-stone-400 bg-stone-900'
                }`}
              >
                {log.type}
              </span>
              <span className="break-all whitespace-pre-wrap flex-1">{log.message}</span>
            </div>
          ))
        )}
      </div>

      {/* Console Status Bar */}
      <div className="flex items-center justify-between border-t border-stone-800/80 bg-stone-900/40 px-4 py-2 text-[11px] text-stone-400 font-mono">
        <div className="flex items-center gap-2">
          <span className="inline-block h-2 w-2 rounded-full bg-emerald-400 animate-ping" />
          <span>Monitoramento ao vivo de saída STDIO & Eventos Discord</span>
        </div>
        <div>
          <span>Codificação: UTF-8</span>
        </div>
      </div>
    </div>
  );
};
