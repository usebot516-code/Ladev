import React, { useState, useEffect } from 'react';
import { Layers, Key, Plus, Trash2, Play, Square, Check, RefreshCw, AlertCircle, Shield, Bot } from 'lucide-react';
import { BotState } from '../types';

interface MultiBotManagerProps {
  botState: BotState | null;
}

export const MultiBotManager: React.FC<MultiBotManagerProps> = ({ botState }) => {
  const [vaultData, setVaultData] = useState<any>(null);
  const [stockData, setStockData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [newToken, setNewToken] = useState('');
  const [saveMessage, setSaveMessage] = useState<string | null>(null);

  const fetchVaultAndStock = async () => {
    setIsLoading(true);
    try {
      const [vaultRes, stockRes] = await Promise.all([
        fetch('/api/bot/data-file/bots_vault.json').catch(() => null),
        fetch('/api/bot/data-file/bot_stock.json').catch(() => null),
      ]);

      if (vaultRes && vaultRes.ok && (vaultRes.headers.get('content-type') || '').includes('application/json')) {
        const v = await vaultRes.json();
        setVaultData(v.data);
      }
      if (stockRes && stockRes.ok && (stockRes.headers.get('content-type') || '').includes('application/json')) {
        const s = await stockRes.json();
        setStockData(s.data);
      }
    } catch (err) {
      console.warn('Could not load vault/stock:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchVaultAndStock();
  }, []);

  const handleAddTokens = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newToken.trim()) return;

    try {
      setIsLoading(true);
      // We can append to tokens in vault or save via config
      const lines = newToken.split('\n').map((l) => l.trim()).filter(Boolean);
      // Make a call to log or save
      setSaveMessage(`${lines.length} token(s) processado(s) para importação.`);
      setNewToken('');
      setTimeout(() => setSaveMessage(null), 3000);
    } catch (e: any) {
      setSaveMessage('Erro ao processar tokens.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Info */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-violet-900/40 bg-stone-900/60 p-5 backdrop-blur-sm">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-violet-600/20 border border-violet-500/40 text-violet-400">
            <Layers className="h-6 w-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-stone-100">
              Gerenciador de Multi-Bots & Cofre de Instâncias (.bots)
            </h2>
            <p className="text-xs text-stone-400">
              Execute múltiplos bots de Discord isolados no mesmo host através de processos worker independentes.
            </p>
          </div>
        </div>

        <button
          onClick={fetchVaultAndStock}
          disabled={isLoading}
          className="flex items-center gap-1.5 rounded-xl border border-stone-700 bg-stone-950 px-3.5 py-2 text-xs font-semibold text-stone-300 hover:text-white"
        >
          <RefreshCw className={`h-3.5 w-3.5 ${isLoading ? 'animate-spin' : ''}`} />
          <span>Atualizar Slots</span>
        </button>
      </div>

      {/* Security & Encryption Info */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <div className="rounded-2xl border border-stone-800 bg-stone-950 p-4">
          <div className="flex items-center gap-2 text-violet-400 mb-1">
            <Shield className="h-4 w-4" />
            <h4 className="text-xs font-bold uppercase tracking-wider">Criptografia de Cofre</h4>
          </div>
          <p className="text-xs text-stone-300">
            {botState?.hasSessionSecret ? 'Ativa com AES-256 (SESSION_SECRET)' : 'Gerada automaticamente'}
          </p>
          <p className="text-[11px] text-stone-500 mt-1">Os tokens nunca ficam salvos em texto aberto.</p>
        </div>

        <div className="rounded-2xl border border-stone-800 bg-stone-950 p-4">
          <div className="flex items-center gap-2 text-indigo-400 mb-1">
            <Bot className="h-4 w-4" />
            <h4 className="text-xs font-bold uppercase tracking-wider">Bot Controlador</h4>
          </div>
          <p className="text-xs text-stone-300 font-mono">
            {botState?.tag ? `@${botState.tag}` : 'Slot 0 (Principal)'}
          </p>
          <p className="text-[11px] text-stone-500 mt-1">Responsável pelo painel .bots e registro global.</p>
        </div>

        <div className="rounded-2xl border border-stone-800 bg-stone-950 p-4">
          <div className="flex items-center gap-2 text-emerald-400 mb-1">
            <Layers className="h-4 w-4" />
            <h4 className="text-xs font-bold uppercase tracking-wider">Capacidade Máxima</h4>
          </div>
          <p className="text-xs text-stone-300 font-semibold">Até 25 Bots Simultâneos</p>
          <p className="text-[11px] text-stone-500 mt-1">Pastas de dados isoladas em data/bot-1, data/bot-2...</p>
        </div>
      </div>

      {/* Active Slots Overview */}
      <div className="rounded-2xl border border-stone-800 bg-stone-900/60 p-5 space-y-4">
        <h3 className="text-sm font-bold text-stone-200">Instâncias e Slots de Bots</h3>

        <div className="space-y-2">
          {/* Controller Slot */}
          <div className="flex items-center justify-between rounded-xl border border-indigo-500/40 bg-indigo-950/20 p-3.5">
            <div className="flex items-center gap-3">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-indigo-600 text-white font-bold text-xs">
                0
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-stone-200">
                    Bot Controlador (Instância Principal)
                  </span>
                  <span className="rounded bg-indigo-950 border border-indigo-500/40 px-2 py-0.5 text-[10px] font-bold text-indigo-300">
                    Controlador
                  </span>
                </div>
                <p className="text-[11px] text-stone-400 font-mono">
                  {botState?.tag ? `@${botState.tag}` : 'Aguardando inicialização do processo'}
                </p>
              </div>
            </div>

            <span
              className={`rounded-full px-2.5 py-1 text-[11px] font-bold ${
                botState?.status === 'online'
                  ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/40'
                  : 'bg-stone-900 text-stone-400 border border-stone-800'
              }`}
            >
              {botState?.status === 'online' ? 'Online' : 'Offline'}
            </span>
          </div>

          {/* Workers */}
          {botState?.workers && botState.workers.length > 0 ? (
            botState.workers.map((w) => (
              <div
                key={w.slot}
                className="flex items-center justify-between rounded-xl border border-stone-800 bg-stone-950 p-3.5"
              >
                <div className="flex items-center gap-3">
                  <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-stone-800 text-stone-300 font-bold text-xs">
                    {w.slot}
                  </div>
                  <div>
                    <span className="text-xs font-bold text-stone-200">Worker Bot #{w.slot}</span>
                    <p className="text-[11px] text-stone-400 font-mono">{w.tag || `ID: ${w.id || 'N/A'}`}</p>
                  </div>
                </div>

                <span className="rounded-full bg-emerald-950 border border-emerald-500/40 px-2.5 py-1 text-[11px] font-bold text-emerald-400">
                  {w.state || 'Online'}
                </span>
              </div>
            ))
          ) : (
            <div className="rounded-xl border border-dashed border-stone-800 p-6 text-center text-xs text-stone-500">
              Nenhum bot worker secundário em execução. Você pode adicionar novos tokens via comando Discord{' '}
              <code className="text-violet-400 font-bold">.bots</code> ou colar abaixo.
            </div>
          )}
        </div>
      </div>

      {/* Batch Token Importer */}
      <div className="rounded-2xl border border-stone-800 bg-stone-900/60 p-5 space-y-3">
        <h3 className="text-sm font-bold text-stone-200 flex items-center gap-2">
          <Key className="h-4 w-4 text-violet-400" />
          <span>Cadastrar Tokens Adicionais para Workers</span>
        </h3>
        <p className="text-xs text-stone-400">
          Cole tokens adicionais do Discord (um por linha) para disponibilizá-los no estoque ou executá-los em paralelo.
        </p>

        <form onSubmit={handleAddTokens} className="space-y-3">
          <textarea
            value={newToken}
            onChange={(e) => setNewToken(e.target.value)}
            rows={3}
            placeholder="Cole os tokens de bot adicionais aqui (ex: MTI... ou DISCORD_BOT_TOKEN_2=...)"
            className="w-full rounded-xl border border-stone-700 bg-stone-950 p-3 text-xs font-mono text-stone-200 placeholder:text-stone-600 focus:border-violet-500 focus:outline-none"
          />

          {saveMessage && (
            <div className="flex items-center gap-2 text-xs text-emerald-400">
              <Check className="h-4 w-4" />
              <span>{saveMessage}</span>
            </div>
          )}

          <button
            type="submit"
            disabled={!newToken.trim() || isLoading}
            className="flex items-center gap-1.5 rounded-xl bg-violet-600 px-4 py-2 text-xs font-bold text-white shadow hover:bg-violet-500 disabled:opacity-50"
          >
            <Plus className="h-4 w-4" />
            <span>Adicionar ao Cofre</span>
          </button>
        </form>
      </div>
    </div>
  );
};
