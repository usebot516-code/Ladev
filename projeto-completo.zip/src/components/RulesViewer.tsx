import React, { useState, useEffect } from 'react';
import {
  FileText,
  CheckCircle2,
  Copy,
  Check,
  Download,
  AlertTriangle,
  Layers,
  Sparkles,
  Loader2,
} from 'lucide-react';
import { downloadProjectZip } from '../utils/downloadZip';

export const RulesViewer: React.FC = () => {
  const [rulesContent, setRulesContent] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [copied, setCopied] = useState<boolean>(false);
  const [isDownloading, setIsDownloading] = useState<boolean>(false);

  useEffect(() => {
    fetch('/api/project/file-content?path=regras.md')
      .then((res) => res.json())
      .then((data) => {
        if (data.content) {
          setRulesContent(data.content);
        }
      })
      .catch((err) => console.error('Erro ao carregar regras:', err))
      .finally(() => setIsLoading(false));
  }, []);

  const handleCopy = () => {
    navigator.clipboard.writeText(rulesContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = async () => {
    setIsDownloading(true);
    await downloadProjectZip();
    setIsDownloading(false);
  };

  const rulesSummary = [
    {
      id: '1',
      title: 'API & Tecnologia Recente',
      desc: 'Utilizar sempre a versão mais recente e estável da API do Discord. Discord Components V2 em todos os painéis, botões, modais e sistemas.',
    },
    {
      id: '2',
      title: 'Auto-Refresh Obrigatório',
      desc: 'Todos os painéis devem possuir atualização in-place automática e controlada sempre que houver alteração de estado.',
    },
    {
      id: '3',
      title: 'Proibição Total de Emojis',
      desc: 'Estritamente sem emojis em títulos, descrições, campos, botões, select menus, modais ou mensagens de resposta.',
    },
    {
      id: '4',
      title: 'Proibição Total de Rodapés (Footer)',
      desc: 'Zero footer em painéis, embeds ou mensagens.',
    },
    {
      id: '5',
      title: 'Select Menus & Botões no Container',
      desc: 'Componentes e menus obrigatoriamente dentro do Container V2 do painel, com labels e placeholders claros e sem emojis.',
    },
    {
      id: '6',
      title: 'Exportação ZIP Limpa & Sincronizada',
      desc: 'Download do projeto em .ZIP limpo (sem node_modules, .git, .cache ou arquivos temporários), sempre atualizado.',
    },
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header Banner */}
      <div className="rounded-2xl border border-indigo-900/60 bg-gradient-to-br from-stone-950 via-stone-900 to-indigo-950/40 p-6 shadow-xl">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-indigo-600/20 border border-indigo-500/40 text-indigo-400">
              <FileText className="h-6 w-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold tracking-tight text-white">Regras Oficiais do Projeto (regras.md)</h2>
              <p className="text-xs text-stone-400 font-mono">
                Diretrizes estritas de arquitetura, componentes V2, ausência de emojis e padronização.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 rounded-xl border border-stone-800 bg-stone-900 px-3.5 py-2 text-xs font-medium text-stone-300 hover:border-stone-700 hover:text-white transition-colors"
            >
              {copied ? <Check className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4" />}
              <span>{copied ? 'Copiado!' : 'Copiar regras.md'}</span>
            </button>
            <button
              onClick={handleDownload}
              disabled={isDownloading}
              className="flex items-center gap-1.5 rounded-xl border border-indigo-500/40 bg-indigo-950/60 px-3.5 py-2 text-xs font-semibold text-indigo-200 hover:bg-indigo-900/80 transition-colors disabled:opacity-50"
            >
              {isDownloading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Download className="h-4 w-4" />}
              <span>{isDownloading ? 'Gerando ZIP...' : 'Baixar ZIP Conforme Regra 6'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Checklist Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {rulesSummary.map((item) => (
          <div
            key={item.id}
            className="rounded-xl border border-stone-800 bg-stone-900/70 p-4 space-y-2 hover:border-stone-700 transition-colors"
          >
            <div className="flex items-center gap-2 text-indigo-400 font-semibold text-sm">
              <span className="flex h-5 w-5 items-center justify-center rounded-full bg-indigo-950 border border-indigo-800 text-[10px]">
                {item.id}
              </span>
              <span>{item.title}</span>
            </div>
            <p className="text-xs text-stone-300 leading-relaxed">{item.desc}</p>
          </div>
        ))}
      </div>

      {/* Raw Markdown / Content View */}
      <div className="rounded-2xl border border-stone-800 bg-stone-900/90 overflow-hidden shadow-xl">
        <div className="flex items-center justify-between border-b border-stone-800 bg-stone-950 px-5 py-3">
          <div className="flex items-center gap-2">
            <span className="h-2 w-2 rounded-full bg-indigo-500" />
            <span className="text-xs font-mono font-semibold text-stone-300">regras.md (Arquivo Original)</span>
          </div>
          <span className="text-[11px] font-mono text-stone-500">61 linhas • UTF-8</span>
        </div>

        <div className="p-6 font-mono text-xs text-stone-200 leading-relaxed bg-stone-950/60 overflow-x-auto max-h-[550px] overflow-y-auto whitespace-pre-wrap selection:bg-indigo-900 selection:text-white">
          {isLoading ? (
            <div className="flex items-center justify-center py-12 text-stone-400 gap-2">
              <Loader2 className="h-5 w-5 animate-spin" />
              <span>Carregando arquivo regras.md...</span>
            </div>
          ) : (
            rulesContent || 'Não foi possível carregar o arquivo regras.md'
          )}
        </div>
      </div>
    </div>
  );
};
