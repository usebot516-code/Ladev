import React, { useState, useEffect } from 'react';
import { X, Key, Shield, CreditCard, Lock, Check, Server, Save } from 'lucide-react';
import { BotConfig } from '../types';

interface CredentialsModalProps {
  isOpen: boolean;
  onClose: () => void;
  botConfig: BotConfig | null;
  onSaveConfig: (data: {
    token?: string;
    guildId?: string;
    ownerRoleId?: string;
    sessionSecret?: string;
    mercadoPagoToken?: string;
  }) => Promise<void>;
}

export const CredentialsModal: React.FC<CredentialsModalProps> = ({
  isOpen,
  onClose,
  botConfig,
  onSaveConfig,
}) => {
  const [token, setToken] = useState('');
  const [guildId, setGuildId] = useState('');
  const [ownerRoleId, setOwnerRoleId] = useState('');
  const [sessionSecret, setSessionSecret] = useState('');
  const [mercadoPagoToken, setMercadoPagoToken] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  useEffect(() => {
    if (botConfig) {
      setGuildId(botConfig.guildId || '');
      setOwnerRoleId(botConfig.ownerRoleId || '');
    }
  }, [botConfig]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setStatusMessage(null);
    try {
      await onSaveConfig({
        token: token.trim() || undefined,
        guildId: guildId.trim() || undefined,
        ownerRoleId: ownerRoleId.trim() || undefined,
        sessionSecret: sessionSecret.trim() || undefined,
        mercadoPagoToken: mercadoPagoToken.trim() || undefined,
      });
      setStatusMessage('Credenciais salvas com sucesso!');
      setToken('');
      setTimeout(() => {
        setStatusMessage(null);
        onClose();
      }, 1500);
    } catch (err: any) {
      setStatusMessage('Erro ao salvar credenciais.');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/80 p-4 backdrop-blur-sm">
      <div className="relative w-full max-w-lg rounded-2xl border border-stone-800 bg-stone-900 p-6 shadow-2xl space-y-5">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-stone-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-indigo-600/20 text-indigo-400 border border-indigo-500/30">
              <Key className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-stone-100">Configuração de Credenciais</h3>
              <p className="text-[11px] text-stone-400">Gerencie os tokens, ID do servidor e chaves secretas</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="rounded-lg p-1 text-stone-400 hover:bg-stone-800 hover:text-stone-200"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          {/* Discord Bot Token */}
          <div className="space-y-1.5">
            <label className="flex items-center justify-between font-semibold text-stone-200">
              <span className="flex items-center gap-1.5">
                <Key className="h-3.5 w-3.5 text-indigo-400" />
                DISCORD_BOT_TOKEN
              </span>
              {botConfig?.hasToken && (
                <span className="text-[10px] text-emerald-400 font-mono">
                  {botConfig.maskedToken}
                </span>
              )}
            </label>
            <input
              type="password"
              value={token}
              onChange={(e) => setToken(e.target.value)}
              placeholder={
                botConfig?.hasToken
                  ? 'Deixe em branco para manter o token atual'
                  : 'Cole o Token do Discord (Developer Portal)'
              }
              className="w-full rounded-xl border border-stone-700 bg-stone-950 p-2.5 font-mono text-xs text-stone-100 placeholder:text-stone-600 focus:border-indigo-500 focus:outline-none"
            />
          </div>

          {/* Guild ID (Servidor) */}
          <div className="space-y-1.5">
            <label className="flex items-center gap-1.5 font-semibold text-stone-200">
              <Server className="h-3.5 w-3.5 text-cyan-400" />
              GUILD_ID (ID do Servidor para Comandos Instantâneos)
            </label>
            <input
              type="text"
              value={guildId}
              onChange={(e) => setGuildId(e.target.value)}
              placeholder="Ex: 1534517665526317126"
              className="w-full rounded-xl border border-stone-700 bg-stone-950 p-2.5 font-mono text-xs text-stone-100 placeholder:text-stone-600 focus:border-indigo-500 focus:outline-none"
            />
          </div>

          {/* Owner Role ID */}
          <div className="space-y-1.5">
            <label className="flex items-center gap-1.5 font-semibold text-stone-200">
              <Shield className="h-3.5 w-3.5 text-violet-400" />
              BOT_OWNER_ROLE_ID (Cargo do Dono do Bot)
            </label>
            <input
              type="text"
              value={ownerRoleId}
              onChange={(e) => setOwnerRoleId(e.target.value)}
              placeholder="Ex: 123456789012345678"
              className="w-full rounded-xl border border-stone-700 bg-stone-950 p-2.5 font-mono text-xs text-stone-100 placeholder:text-stone-600 focus:border-indigo-500 focus:outline-none"
            />
          </div>

          {/* Session Secret */}
          <div className="space-y-1.5">
            <label className="flex items-center gap-1.5 font-semibold text-stone-200">
              <Lock className="h-3.5 w-3.5 text-emerald-400" />
              SESSION_SECRET (Chave do Cofre Criptografado)
            </label>
            <input
              type="password"
              value={sessionSecret}
              onChange={(e) => setSessionSecret(e.target.value)}
              placeholder="Chave secreta de criptografia (opcional)"
              className="w-full rounded-xl border border-stone-700 bg-stone-950 p-2.5 font-mono text-xs text-stone-100 placeholder:text-stone-600 focus:border-indigo-500 focus:outline-none"
            />
          </div>

          {/* MercadoPago Token */}
          <div className="space-y-1.5">
            <label className="flex items-center gap-1.5 font-semibold text-stone-200">
              <CreditCard className="h-3.5 w-3.5 text-yellow-400" />
              MERCADOPAGO_ACCESS_TOKEN (Pix Automático da Loja)
            </label>
            <input
              type="password"
              value={mercadoPagoToken}
              onChange={(e) => setMercadoPagoToken(e.target.value)}
              placeholder="Ex: APP_USR-..."
              className="w-full rounded-xl border border-stone-700 bg-stone-950 p-2.5 font-mono text-xs text-stone-100 placeholder:text-stone-600 focus:border-indigo-500 focus:outline-none"
            />
          </div>

          {statusMessage && (
            <div className="flex items-center gap-2 rounded-xl bg-emerald-950/60 border border-emerald-500/40 p-2.5 text-emerald-300 text-xs">
              <Check className="h-4 w-4 shrink-0" />
              <span>{statusMessage}</span>
            </div>
          )}

          {/* Footer Buttons */}
          <div className="flex items-center justify-end gap-2 border-t border-stone-800 pt-3">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl border border-stone-700 bg-stone-950 px-4 py-2 text-xs font-semibold text-stone-300 hover:text-white"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="flex items-center gap-1.5 rounded-xl bg-indigo-600 px-5 py-2 text-xs font-bold text-white shadow hover:bg-indigo-500 disabled:opacity-50"
            >
              <Save className="h-3.5 w-3.5" />
              <span>{isSaving ? 'Salvando...' : 'Salvar Configurações'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
