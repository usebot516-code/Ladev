import React, { useState, useEffect, useRef } from 'react';
import {
  Upload,
  FileArchive,
  FileText,
  FolderPlus,
  RefreshCw,
  CheckCircle2,
  AlertCircle,
  FileCode,
  Save,
  Folder,
  Eye,
  Trash2,
  Download,
  FileCheck,
  Edit3,
  Loader2,
  BookOpen,
} from 'lucide-react';

interface FileItem {
  name: string;
  path: string;
  type: 'file' | 'directory';
  size?: number;
  updatedAt?: number;
  children?: FileItem[];
}

export const FileManagerAndUpload: React.FC = () => {
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadStatus, setUploadStatus] = useState<{
    type: 'success' | 'error' | 'info';
    message: string;
    files?: Array<{ filename: string; size: number }>;
  } | null>(null);

  const [filesTree, setFilesTree] = useState<FileItem[]>([]);
  const [hasRegras, setHasRegras] = useState(false);
  const [isLoadingTree, setIsLoadingTree] = useState(false);

  // Quick Regras.md Editor / Viewer
  const [regrasContent, setRegrasContent] = useState('');
  const [isSavingRegras, setIsSavingRegras] = useState(false);
  const [regrasSaveStatus, setRegrasSaveStatus] = useState<string | null>(null);

  // Selected file modal / viewer
  const [viewingFile, setViewingFile] = useState<{ path: string; content: string } | null>(null);
  const [isViewingLoading, setIsViewingLoading] = useState(false);

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const loadFilesTree = async () => {
    setIsLoadingTree(true);
    try {
      const res = await fetch('/api/project/files-tree');
      if (res.ok) {
        const data = await res.json();
        setFilesTree(data.files || []);
        setHasRegras(Boolean(data.hasRegras));
      }
    } catch (err) {
      console.error('Falha ao listar arquivos:', err);
    } finally {
      setIsLoadingTree(false);
    }
  };

  const loadRegrasMd = async () => {
    try {
      const res = await fetch('/api/project/file-content?path=regras.md');
      if (res.ok) {
        const data = await res.json();
        setRegrasContent(data.content || '');
      }
    } catch (_) {}
  };

  useEffect(() => {
    loadFilesTree();
    loadRegrasMd();
  }, []);

  const handleSaveRegras = async () => {
    setIsSavingRegras(true);
    setRegrasSaveStatus(null);
    try {
      const res = await fetch('/api/project/save-raw-file', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ path: 'regras.md', content: regrasContent }),
      });
      if (res.ok) {
        setRegrasSaveStatus('regras.md salvo com sucesso no projeto!');
        setHasRegras(true);
        loadFilesTree();
        setTimeout(() => setRegrasSaveStatus(null), 4000);
      } else {
        setRegrasSaveStatus('Erro ao salvar regras.md');
      }
    } catch (err: any) {
      setRegrasSaveStatus('Erro de conexão: ' + err.message);
    } finally {
      setIsSavingRegras(false);
    }
  };

  const processFile = async (file: File) => {
    setIsUploading(true);
    setUploadStatus({ type: 'info', message: `Processando upload de "${file.name}"...` });

    try {
      if (file.name.toLowerCase().endsWith('.zip')) {
        // Read as Base64 and send to extract endpoint
        const reader = new FileReader();
        reader.onload = async () => {
          try {
            const base64String = (reader.result as string).split(',')[1];
            const res = await fetch('/api/upload/zip', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ base64: base64String, filename: file.name }),
            });
            const data = await res.json();
            if (res.ok && data.success) {
              setUploadStatus({
                type: 'success',
                message: data.message,
                files: data.files,
              });
              loadFilesTree();
              loadRegrasMd();
            } else {
              setUploadStatus({
                type: 'error',
                message: data.error || 'Falha ao extrair arquivo ZIP.',
              });
            }
          } catch (err: any) {
            setUploadStatus({ type: 'error', message: 'Erro ao enviar ZIP: ' + err.message });
          } finally {
            setIsUploading(false);
          }
        };
        reader.readAsDataURL(file);
      } else {
        // Single file (Markdown, text, json, etc.)
        const isText = file.type.startsWith('text') || file.name.endsWith('.md') || file.name.endsWith('.json') || file.name.endsWith('.js') || file.name.endsWith('.txt');
        
        if (isText) {
          const text = await file.text();
          const res = await fetch('/api/upload/file', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ filename: file.name, content: text, isBase64: false }),
          });
          const data = await res.json();
          if (res.ok && data.success) {
            setUploadStatus({ type: 'success', message: data.message });
            loadFilesTree();
            if (file.name.toLowerCase() === 'regras.md') {
              setRegrasContent(text);
              setHasRegras(true);
            }
          } else {
            setUploadStatus({ type: 'error', message: data.error || 'Erro ao enviar arquivo.' });
          }
          setIsUploading(false);
        } else {
          // Binary file as base64
          const reader = new FileReader();
          reader.onload = async () => {
            const base64String = (reader.result as string).split(',')[1];
            const res = await fetch('/api/upload/file', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ filename: file.name, content: base64String, isBase64: true }),
            });
            const data = await res.json();
            if (res.ok && data.success) {
              setUploadStatus({ type: 'success', message: data.message });
              loadFilesTree();
            } else {
              setUploadStatus({ type: 'error', message: data.error || 'Erro ao salvar arquivo binário.' });
            }
            setIsUploading(false);
          };
          reader.readAsDataURL(file);
        }
      }
    } catch (err: any) {
      setUploadStatus({ type: 'error', message: 'Falha durante o upload: ' + err.message });
      setIsUploading(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      processFile(e.target.files[0]);
    }
  };

  const handleViewFile = async (filePath: string) => {
    setIsViewingLoading(true);
    try {
      const res = await fetch(`/api/project/file-content?path=${encodeURIComponent(filePath)}`);
      if (res.ok) {
        const data = await res.json();
        setViewingFile({ path: filePath, content: data.content });
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsViewingLoading(false);
    }
  };

  const formatSize = (bytes?: number) => {
    if (!bytes) return '0 B';
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <div className="space-y-6">
      {/* Top Banner / Explainer */}
      <div className="rounded-2xl border border-indigo-900/60 bg-gradient-to-br from-indigo-950/40 via-stone-900/80 to-stone-950 p-6 shadow-xl backdrop-blur-md">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-indigo-600/30 text-indigo-400 border border-indigo-500/30">
                <Upload className="h-4 w-4" />
              </span>
              <h2 className="text-xl font-bold tracking-tight text-white">
                Importador de Arquivos & ZIPs
              </h2>
            </div>
            <p className="mt-1 text-sm text-stone-300">
              Envie arquivos compactados (<code className="rounded bg-stone-800 px-1 py-0.5 text-xs text-amber-300">.zip</code>) ou arquivos avulsos (<code className="rounded bg-stone-800 px-1 py-0.5 text-xs text-indigo-300">regras.md</code>, <code className="rounded bg-stone-800 px-1 py-0.5 text-xs text-stone-300">.json</code>, <code className="rounded bg-stone-800 px-1 py-0.5 text-xs text-stone-300">.js</code>). Os ZIPs são descompactados e integrados automaticamente na estrutura do bot!
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className={`flex items-center gap-2 rounded-xl px-3.5 py-2 text-xs font-semibold border ${
              hasRegras
                ? 'bg-emerald-950/60 text-emerald-300 border-emerald-500/40'
                : 'bg-amber-950/60 text-amber-300 border-amber-500/40'
            }`}>
              {hasRegras ? (
                <>
                  <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                  <span>regras.md: Presente</span>
                </>
              ) : (
                <>
                  <AlertCircle className="h-4 w-4 text-amber-400" />
                  <span>regras.md: Não Encontrado</span>
                </>
              )}
            </div>

            <button
              onClick={() => {
                loadFilesTree();
                loadRegrasMd();
              }}
              disabled={isLoadingTree}
              className="flex items-center gap-1.5 rounded-xl border border-stone-700 bg-stone-800 px-3.5 py-2 text-xs font-semibold text-stone-200 hover:bg-stone-700 transition"
              title="Atualizar lista de arquivos"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${isLoadingTree ? 'animate-spin' : ''}`} />
              <span>Atualizar</span>
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Left Column: Drag & Drop Zone + Regras Editor (7 cols) */}
        <div className="space-y-6 lg:col-span-7">
          {/* Drag & Drop Upload Card */}
          <div className="rounded-2xl border border-stone-800 bg-stone-900/90 p-5 shadow-lg">
            <h3 className="text-sm font-bold uppercase tracking-wider text-stone-300 flex items-center gap-2 mb-3">
              <FileArchive className="h-4 w-4 text-indigo-400" />
              Upload Rápido de ZIP ou Arquivo
            </h3>

            <div
              onDrop={handleDrop}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onClick={() => fileInputRef.current?.click()}
              className={`relative flex flex-col items-center justify-center rounded-xl border-2 border-dashed p-8 text-center transition cursor-pointer ${
                isDragging
                  ? 'border-indigo-500 bg-indigo-950/40 text-white shadow-lg'
                  : 'border-stone-700 hover:border-indigo-500/70 bg-stone-950/60 hover:bg-stone-900/60 text-stone-300'
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                className="hidden"
                accept=".zip,.md,.json,.js,.ts,.txt,.png,.jpg"
                onChange={handleFileSelect}
              />

              {isUploading ? (
                <div className="flex flex-col items-center gap-2 py-3">
                  <Loader2 className="h-8 w-8 animate-spin text-indigo-400" />
                  <p className="text-sm font-semibold text-stone-200">Enviando e extraindo arquivos...</p>
                  <p className="text-xs text-stone-400">Aguarde a finalização automática do processo.</p>
                </div>
              ) : (
                <>
                  <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-2xl bg-indigo-600/20 text-indigo-400 border border-indigo-500/30">
                    <Upload className="h-6 w-6" />
                  </div>
                  <p className="text-sm font-bold text-stone-200">
                    Arraste e solte o arquivo ZIP ou regras.md aqui
                  </p>
                  <p className="mt-1 text-xs text-stone-400">
                    Ou clique para selecionar direto do seu computador
                  </p>
                  <div className="mt-4 flex flex-wrap justify-center gap-1.5">
                    <span className="rounded-md bg-stone-800 px-2 py-0.5 text-[11px] font-mono text-stone-300 border border-stone-700">.ZIP</span>
                    <span className="rounded-md bg-indigo-950/80 px-2 py-0.5 text-[11px] font-mono text-indigo-300 border border-indigo-700/50">regras.md</span>
                    <span className="rounded-md bg-stone-800 px-2 py-0.5 text-[11px] font-mono text-stone-300 border border-stone-700">.JSON</span>
                    <span className="rounded-md bg-stone-800 px-2 py-0.5 text-[11px] font-mono text-stone-300 border border-stone-700">.JS</span>
                  </div>
                </>
              )}
            </div>

            {/* Upload Feedback Status */}
            {uploadStatus && (
              <div
                className={`mt-4 rounded-xl p-4 text-xs border ${
                  uploadStatus.type === 'success'
                    ? 'bg-emerald-950/70 border-emerald-500/50 text-emerald-200'
                    : uploadStatus.type === 'error'
                    ? 'bg-rose-950/70 border-rose-500/50 text-rose-200'
                    : 'bg-indigo-950/70 border-indigo-500/50 text-indigo-200'
                }`}
              >
                <div className="flex items-center gap-2 font-bold text-sm">
                  {uploadStatus.type === 'success' ? (
                    <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
                  ) : uploadStatus.type === 'error' ? (
                    <AlertCircle className="h-4 w-4 text-rose-400 shrink-0" />
                  ) : (
                    <Loader2 className="h-4 w-4 animate-spin text-indigo-400 shrink-0" />
                  )}
                  <span>{uploadStatus.message}</span>
                </div>

                {uploadStatus.files && uploadStatus.files.length > 0 && (
                  <div className="mt-3 max-h-36 overflow-y-auto rounded-lg bg-black/40 p-2 font-mono text-[11px] space-y-1">
                    <p className="text-[10px] uppercase font-bold text-stone-400 mb-1">Arquivos Extraídos ({uploadStatus.files.length}):</p>
                    {uploadStatus.files.map((f, idx) => (
                      <div key={idx} className="flex justify-between text-stone-300">
                        <span className="truncate pr-2">{f.filename}</span>
                        <span className="text-stone-500 shrink-0">{formatSize(f.size)}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Quick regras.md Editor / Viewer */}
          <div className="rounded-2xl border border-stone-800 bg-stone-900/90 p-5 shadow-lg">
            <div className="flex items-center justify-between gap-3 mb-3">
              <div className="flex items-center gap-2">
                <BookOpen className="h-4 w-4 text-amber-400" />
                <h3 className="text-sm font-bold uppercase tracking-wider text-stone-300">
                  Editor Direto de <code className="text-amber-300 font-mono">regras.md</code>
                </h3>
              </div>

              <div className="flex items-center gap-2">
                {regrasSaveStatus && (
                  <span className="text-xs text-emerald-400 font-semibold">{regrasSaveStatus}</span>
                )}
                <button
                  onClick={handleSaveRegras}
                  disabled={isSavingRegras}
                  className="flex items-center gap-1.5 rounded-xl bg-indigo-600 px-3.5 py-1.5 text-xs font-bold text-white shadow-md hover:bg-indigo-500 disabled:opacity-50 transition"
                >
                  {isSavingRegras ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
                  <span>Salvar regras.md</span>
                </button>
              </div>
            </div>

            <p className="text-xs text-stone-400 mb-3">
              Você pode colar o texto das suas regras aqui e clicar em "Salvar regras.md" para criar ou atualizar o arquivo diretamente no projeto.
            </p>

            <textarea
              value={regrasContent}
              onChange={(e) => setRegrasContent(e.target.value)}
              placeholder="# Regras do Bot Ryze&#10;&#10;Cole aqui o conteúdo do seu regras.md..."
              rows={12}
              className="w-full rounded-xl border border-stone-800 bg-stone-950 p-3.5 font-mono text-xs text-stone-200 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 resize-y leading-relaxed"
            />
          </div>
        </div>

        {/* Right Column: Project Files Tree & Explorer (5 cols) */}
        <div className="space-y-6 lg:col-span-5">
          <div className="rounded-2xl border border-stone-800 bg-stone-900/90 p-5 shadow-lg">
            <div className="flex items-center justify-between gap-3 mb-3">
              <div className="flex items-center gap-2">
                <Folder className="h-4 w-4 text-indigo-400" />
                <h3 className="text-sm font-bold uppercase tracking-wider text-stone-300">
                  Explorador do Projeto
                </h3>
              </div>
              <span className="text-[11px] font-mono text-stone-400">
                {filesTree.length} itens raiz
              </span>
            </div>

            {isLoadingTree ? (
              <div className="flex items-center justify-center py-12 text-stone-400">
                <Loader2 className="h-6 w-6 animate-spin text-indigo-400" />
              </div>
            ) : (
              <div className="max-h-[600px] overflow-y-auto rounded-xl border border-stone-800/80 bg-stone-950/80 p-2 font-mono text-xs divide-y divide-stone-900">
                {filesTree.map((item, idx) => (
                  <FileTreeNode
                    key={idx}
                    item={item}
                    onView={handleViewFile}
                    isRegras={item.name.toLowerCase() === 'regras.md'}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* File Content Preview Modal */}
      {viewingFile && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm">
          <div className="relative flex max-h-[85vh] w-full max-w-4xl flex-col rounded-2xl border border-stone-700 bg-stone-900 p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-stone-800">
              <div className="flex items-center gap-2">
                <FileCode className="h-5 w-5 text-indigo-400" />
                <h4 className="font-bold text-stone-100 font-mono text-sm">{viewingFile.path}</h4>
              </div>
              <button
                onClick={() => setViewingFile(null)}
                className="rounded-lg p-1 text-stone-400 hover:bg-stone-800 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="mt-4 flex-1 overflow-y-auto rounded-xl bg-stone-950 p-4 font-mono text-xs text-stone-300 leading-relaxed whitespace-pre-wrap">
              {viewingFile.content}
            </div>

            <div className="mt-4 flex justify-end">
              <button
                onClick={() => setViewingFile(null)}
                className="rounded-xl bg-stone-800 px-4 py-2 text-xs font-semibold text-stone-200 hover:bg-stone-700"
              >
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

interface FileTreeNodeProps {
  item: FileItem;
  onView: (path: string) => void;
  isRegras?: boolean;
}

const FileTreeNode: React.FC<FileTreeNodeProps> = ({ item, onView, isRegras }) => {
  const [isOpen, setIsOpen] = useState(false);

  if (item.type === 'directory') {
    return (
      <div className="py-1">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="flex w-full items-center gap-2 rounded-lg px-2 py-1 text-left text-stone-300 hover:bg-stone-900 transition"
        >
          <Folder className="h-3.5 w-3.5 text-amber-400 shrink-0" />
          <span className="font-semibold text-stone-200 truncate">{item.name}/</span>
          <span className="text-[10px] text-stone-500 ml-auto">({item.children?.length || 0})</span>
        </button>
        {isOpen && item.children && (
          <div className="ml-4 pl-2 border-l border-stone-800 mt-1 space-y-0.5">
            {item.children.map((child, idx) => (
              <FileTreeNode key={idx} item={child} onView={onView} isRegras={child.name.toLowerCase() === 'regras.md'} />
            ))}
          </div>
        )}
      </div>
    );
  }

  return (
    <div
      className={`flex items-center justify-between rounded-lg px-2 py-1 transition ${
        isRegras ? 'bg-amber-950/40 border border-amber-500/30' : 'hover:bg-stone-900'
      }`}
    >
      <div className="flex items-center gap-2 truncate pr-2">
        {isRegras ? (
          <BookOpen className="h-3.5 w-3.5 text-amber-400 shrink-0" />
        ) : item.name.endsWith('.json') ? (
          <FileText className="h-3.5 w-3.5 text-emerald-400 shrink-0" />
        ) : item.name.endsWith('.js') || item.name.endsWith('.ts') ? (
          <FileCode className="h-3.5 w-3.5 text-indigo-400 shrink-0" />
        ) : (
          <FileCheck className="h-3.5 w-3.5 text-stone-400 shrink-0" />
        )}
        <span className={`truncate text-xs ${isRegras ? 'font-bold text-amber-300' : 'text-stone-300'}`}>
          {item.name}
        </span>
      </div>

      <div className="flex items-center gap-2 shrink-0">
        <span className="text-[10px] text-stone-500">
          {item.size ? (item.size < 1024 ? `${item.size}B` : `${(item.size / 1024).toFixed(0)}KB`) : ''}
        </span>
        <button
          onClick={() => onView(item.path)}
          className="rounded p-1 text-stone-400 hover:bg-stone-800 hover:text-white"
          title="Ver Conteúdo"
        >
          <Eye className="h-3.5 w-3.5" />
        </button>
      </div>
    </div>
  );
};
