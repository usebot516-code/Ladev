import React from 'react';
import { HelpCircle, Terminal, Shield, Sparkles, Zap, Key, CreditCard } from 'lucide-react';

export const CommandGuide: React.FC = () => {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3 rounded-2xl border border-indigo-900/40 bg-stone-900/60 p-5 backdrop-blur-sm">
        <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-indigo-500/20 border border-indigo-500/40 text-indigo-400">
          <HelpCircle className="h-6 w-6" />
        </div>
        <div>
          <h2 className="text-lg font-bold text-stone-100">Guia e Documentação dos Comandos</h2>
          <p className="text-xs text-stone-400">
            Lista completa de comandos slash e prefixados disponíveis no Ryze Discord Bot.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
        {/* Section 1: Administrador */}
        <div className="rounded-2xl border border-stone-800 bg-stone-950 p-5 space-y-4">
          <h3 className="text-sm font-bold text-stone-100 flex items-center gap-2 border-b border-stone-800 pb-2">
            <Shield className="h-4 w-4 text-indigo-400" />
            <span>Comandos Slash de Administração</span>
          </h3>

          <div className="space-y-3 text-xs">
            <div className="rounded-xl border border-emerald-800/60 bg-emerald-950/40 p-3">
              <span className="font-mono font-bold text-emerald-300">/ping ou .ping</span>
              <span className="ml-2 rounded bg-emerald-900/80 px-1.5 py-0.5 text-[10px] font-bold text-emerald-300">
                Geral / Monitoramento
              </span>
              <p className="text-stone-300 mt-1">
                Exibe um painel completo em tempo real com a latência da API Discord, WebSocket ping, uptime, uso de memória RAM e status do bot com botão de atualização instantânea.
              </p>
            </div>

            <div className="rounded-xl border border-stone-800 bg-stone-900/50 p-3">
              <span className="font-mono font-bold text-indigo-300">/iniciar</span>
              <p className="text-stone-300 mt-1">
                Configura as filas, os valores, a taxa e os canais do sistema (Aparência, Valores/Taxa e Canais).
              </p>
            </div>

            <div className="rounded-xl border border-stone-800 bg-stone-900/50 p-3">
              <span className="font-mono font-bold text-indigo-300">/limpar</span>
              <p className="text-stone-300 mt-1">
                Apaga uma quantidade específica de mensagens do canal atual (de 1 a 1000 mensagens).
              </p>
            </div>

            <div className="rounded-xl border border-stone-800 bg-stone-900/50 p-3">
              <span className="font-mono font-bold text-indigo-300">/ajuda</span>
              <p className="text-stone-300 mt-1">
                Abre a Central de Ajuda com lista interativa de comandos slash e de prefixo.
              </p>
            </div>

            <div className="rounded-xl border border-stone-800 bg-stone-900/50 p-3">
              <span className="font-mono font-bold text-indigo-300">/avisos</span>
              <p className="text-stone-300 mt-1">
                Abre o painel de gerenciamento e envio de avisos automáticos do servidor.
              </p>
            </div>

            <div className="rounded-xl border border-stone-800 bg-stone-900/50 p-3">
              <span className="font-mono font-bold text-indigo-300">/aux</span>
              <p className="text-stone-300 mt-1">
                Painel auxiliar de finalização rápida para mediadores (vitória normal, W.O e finalização).
              </p>
            </div>

            <div className="rounded-xl border border-stone-800 bg-stone-900/50 p-3">
              <span className="font-mono font-bold text-indigo-300">/blacklist painel</span>
              <p className="text-stone-300 mt-1">
                Abre o painel público de consulta da blacklist Free Fire no canal.
              </p>
            </div>

            <div className="rounded-xl border border-stone-800 bg-stone-900/50 p-3">
              <span className="font-mono font-bold text-indigo-300">/blacklist adicionar</span>
              <p className="text-stone-300 mt-1">
                Adiciona um jogador ou ID Free Fire à blacklist do servidor.
              </p>
            </div>

            <div className="rounded-xl border border-stone-800 bg-stone-900/50 p-3">
              <span className="font-mono font-bold text-indigo-300">/blacklist remover</span>
              <p className="text-stone-300 mt-1">
                Abre menu de seleção para remover um jogador da blacklist do servidor.
              </p>
            </div>

            <div className="rounded-xl border border-stone-800 bg-stone-900/50 p-3">
              <span className="font-mono font-bold text-indigo-300">/configurar</span>
              <p className="text-stone-300 mt-1">
                Central de configurações do servidor dividida em três categorias principais: <strong>Filas</strong> (cargos, canais, taxa, QR Code, mediação), <strong>Tickets</strong> (tópicos e logs) e <strong>Loja Coins</strong> (cargos de atendimento, canal de tópicos, recompensas e catálogo).
              </p>
            </div>

            <div className="rounded-xl border border-stone-800 bg-stone-900/50 p-3">
              <span className="font-mono font-bold text-indigo-300">/config bot</span>
              <p className="text-stone-300 mt-1">
                Painel para gerenciar Nome, Bio, Avatar, Banner e Status de presença do bot.
              </p>
            </div>

            <div className="rounded-xl border border-stone-800 bg-stone-900/50 p-3">
              <span className="font-mono font-bold text-indigo-300">/coins gerenciar</span>
              <p className="text-stone-300 mt-1">
                Adiciona ou remove saldo de Coins de um membro específico do servidor.
              </p>
            </div>

            <div className="rounded-xl border border-amber-900/40 bg-amber-950/20 p-3">
              <span className="font-mono font-bold text-amber-300">/loja coins</span>
              <p className="text-stone-300 mt-1">
                Abre o painel completo de configuração e publicação da Loja de Coins (criação de produtos de cargo e atendimento personalizado, compra com Coins, entrega automática e transcripts em HTML).
              </p>
            </div>

            <div className="rounded-xl border border-stone-800 bg-stone-900/50 p-3">
              <span className="font-mono font-bold text-indigo-300">/exposed registrar</span>
              <p className="text-stone-300 mt-1">
                Registra exposed com ID Free Fire, motivo, prints/provas e bane o jogador suspeito.
              </p>
            </div>

            <div className="rounded-xl border border-stone-800 bg-stone-900/50 p-3">
              <span className="font-mono font-bold text-indigo-300">/exposed historico</span>
              <p className="text-stone-300 mt-1">
                Exibe o histórico de exposeds com paginação e filtro por analista.
              </p>
            </div>

            <div className="rounded-xl border border-stone-800 bg-stone-900/50 p-3">
              <span className="font-mono font-bold text-indigo-300">/filas gerenciar</span>
              <p className="text-stone-300 mt-1">
                Abre o painel de configuração e envio de filas Free Fire no canal selecionado.
              </p>
            </div>

            <div className="rounded-xl border border-stone-800 bg-stone-900/50 p-3">
              <span className="font-mono font-bold text-indigo-300">/fila mediador</span>
              <p className="text-stone-300 mt-1">
                Abre o painel de fila exclusiva de mediadores.
              </p>
            </div>

            <div className="rounded-xl border border-stone-800 bg-stone-900/50 p-3">
              <span className="font-mono font-bold text-indigo-300">/fila analista</span>
              <p className="text-stone-300 mt-1">
                Abre o painel público de fila de analistas.
              </p>
            </div>

            <div className="rounded-xl border border-stone-800 bg-stone-900/50 p-3">
              <span className="font-mono font-bold text-indigo-300">/fila streamer</span>
              <p className="text-stone-300 mt-1">
                Abre o painel de configuração e envio de filas de streamers.
              </p>
            </div>

            <div className="rounded-xl border border-stone-800 bg-stone-900/50 p-3">
              <span className="font-mono font-bold text-indigo-300">/ranking painel</span>
              <p className="text-stone-300 mt-1">
                Abre o painel de configuração e exibição de ranking de vitórias.
              </p>
            </div>

            <div className="rounded-xl border border-stone-800 bg-stone-900/50 p-3">
              <span className="font-mono font-bold text-indigo-300">/sorteio painel</span>
              <p className="text-stone-300 mt-1">
                Abre o painel principal de configuração e publicação de sorteios.
              </p>
            </div>

            <div className="rounded-xl border border-stone-800 bg-stone-900/50 p-3">
              <span className="font-mono font-bold text-indigo-300">/sorteio reiniciar</span>
              <p className="text-stone-300 mt-1">
                Abre o painel para reiniciar ou re-sortear um sorteio finalizado ou ativo.
              </p>
            </div>

            <div className="rounded-xl border border-stone-800 bg-stone-900/50 p-3">
              <span className="font-mono font-bold text-indigo-300">/sorteio revogar</span>
              <p className="text-stone-300 mt-1">
                Abre o painel para revogar ou cancelar um sorteio ativo.
              </p>
            </div>

            <div className="rounded-xl border border-stone-800 bg-stone-900/50 p-3">
              <span className="font-mono font-bold text-indigo-300">/tickets painel</span>
              <p className="text-stone-300 mt-1">
                Abre o painel de configuração e publicação de tickets de atendimento.
              </p>
            </div>

            <div className="rounded-xl border border-stone-800 bg-stone-900/50 p-3">
              <span className="font-mono font-bold text-indigo-300">/tickets fechar</span>
              <p className="text-stone-300 mt-1">
                Fecha o ticket atual ou abre o painel para fechar tickets abertos.
              </p>
            </div>
          </div>
        </div>

        {/* Section 2: Owner & Loja */}
        <div className="rounded-2xl border border-stone-800 bg-stone-950 p-5 space-y-4">
          <h3 className="text-sm font-bold text-stone-100 flex items-center gap-2 border-b border-stone-800 pb-2">
            <Key className="h-4 w-4 text-violet-400" />
            <span>Comandos com Prefixo do Dono (Owner)</span>
          </h3>

          <div className="space-y-3 text-xs">
            <div className="rounded-xl border border-cyan-800/60 bg-cyan-950/40 p-3">
              <span className="font-mono font-bold text-cyan-300">.atualizar ou .dev sync</span>
              <span className="ml-2 rounded bg-cyan-900/80 px-1.5 py-0.5 text-[10px] font-bold text-cyan-300">
                Auto-Update Remoto
              </span>
              <p className="text-stone-300 mt-1">
                Conecta à API do Google AI Studio, baixa automaticamente todos os arquivos modificados/atualizados e reinicia o bot na sua hospedagem externa em 3 segundos.
              </p>
            </div>

            <div className="rounded-xl border border-stone-800 bg-stone-900/50 p-3">
              <span className="font-mono font-bold text-violet-300">.dev central</span>
              <p className="text-stone-300 mt-1">
                Abre a Central de Desenvolvedor e Gerenciador da Loja de Planos com personalização de aparência, preços, duração, termos e integração Pix Mercado Pago.
              </p>
            </div>

            <div className="rounded-xl border border-stone-800 bg-stone-900/50 p-3">
              <span className="font-mono font-bold text-yellow-300">.p ou .p @membro</span>
              <p className="text-stone-300 mt-1">
                Exibe o perfil do jogador com saldo de coins, vitórias, estatísticas e link de convite.
              </p>
            </div>

            <div className="rounded-xl border border-stone-800 bg-stone-900/50 p-3">
              <span className="font-mono font-bold text-cyan-300">pg Nome Sobrenome</span>
              <p className="text-stone-300 mt-1">
                Enviado no chat de uma partida para acionar a validação instantânea de pagamento Pix configurada pelo mediador.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Section 3: Regras Gerais Obrigatórias */}
      <div className="rounded-2xl border border-indigo-900/50 bg-stone-950 p-6 space-y-4 shadow-xl">
        <div className="flex items-center gap-2 border-b border-stone-800 pb-3">
          <Terminal className="h-5 w-5 text-amber-400" />
          <h3 className="text-sm font-bold uppercase tracking-wider text-stone-100">
            Regras Gerais Obrigatórias do Projeto (regras.md)
          </h3>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4 text-xs">
          <div className="rounded-xl border border-rose-900/40 bg-rose-950/20 p-4 space-y-1">
            <span className="font-bold text-rose-300 text-sm block">1. Zero Emojis em Painéis</span>
            <p className="text-stone-300 leading-relaxed">
              Todos os tipos de painéis, botões, modais e menus Select são feitos <strong>estritamente sem uso de emojis</strong>.
            </p>
          </div>

          <div className="rounded-xl border border-emerald-900/40 bg-emerald-950/20 p-4 space-y-1">
            <span className="font-bold text-emerald-300 text-sm block">2. Auto-Refresh Obrigatório</span>
            <p className="text-stone-300 leading-relaxed">
              Toda inclusão, exclusão ou alteração atualiza a mensagem original no canal automaticamente (in-place).
            </p>
          </div>

          <div className="rounded-xl border border-indigo-900/40 bg-indigo-950/20 p-4 space-y-1">
            <span className="font-bold text-indigo-300 text-sm block">3. Components V2 & Menus</span>
            <p className="text-stone-300 leading-relaxed">
              Select Menus e botões são alocados <strong>rigorosamente dentro do container</strong> V2 do painel, nunca soltos.
            </p>
          </div>

          <div className="rounded-xl border border-amber-900/40 bg-amber-950/20 p-4 space-y-1">
            <span className="font-bold text-amber-300 text-sm block">4. Zero Rodapés (Sem Footer)</span>
            <p className="text-stone-300 leading-relaxed">
              Proibido uso de qualquer rodapé (footer) em painéis, embeds ou mensagens para manter visual limpo.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
