import React, { useState, useEffect } from 'react';
import {
  RefreshCw,
  Copy,
  Check,
  Zap,
  Terminal,
  Globe,
  Server,
  Cloud,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Code,
  X,
  Radio,
  FileCode,
} from 'lucide-react';

interface RemoteSyncModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const RemoteSyncModal: React.FC<RemoteSyncModalProps> = ({ isOpen, onClose }) => {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [syncInfo, setSyncInfo] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [testResult, setTestResult] = useState<{ ok: boolean; message: string } | null>(null);

  const currentHost = typeof window !== 'undefined' ? window.location.origin : '';
  const syncEndpointUrl = `${currentHost}/api/sync/payload`;
  const zipEndpointUrl = `${currentHost}/api/sync/bundle.zip`;

  useEffect(() => {
    if (isOpen) {
      loadSyncInfo();
    }
  }, [isOpen]);

  const loadSyncInfo = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/sync/info');
      const data = await res.json();
      setSyncInfo(data);
    } catch (e: any) {
      console.warn('Erro ao obter status do sync:', e.message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleTestConnection = async () => {
    setIsLoading(true);
    setTestResult(null);
    try {
      const res = await fetch('/api/sync/payload');
      const data = await res.json();
      if (data.success && Array.isArray(data.files)) {
        setTestResult({
          ok: true,
          message: `API Conectada! ${data.count || data.files.length} arquivos prontos para transmissão em tempo real (Versão: ${data.version}).`,
        });
      } else {
        setTestResult({
          ok: false,
          message: data.error || 'A API respondeu mas o formato foi inesperado.',
        });
      }
    } catch (e: any) {
      setTestResult({
        ok: false,
        message: 'Falha ao testar conexão com o servidor local: ' + e.message,
      });
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="relative w-full max-w-3xl rounded-2xl border border-indigo-900/60 bg-stone-950 p-6 shadow-2xl text-stone-100 my-8">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-stone-800 pb-4 mb-6">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-600 to-cyan-600 text-white shadow-lg shadow-indigo-950/60">
              <RefreshCw className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                Sincronização & Auto-Update Remoto (Live Sync)
                <span className="rounded-full bg-emerald-950/80 px-2 py-0.5 text-[10px] font-bold text-emerald-400 border border-emerald-500/30">
                  ATIVO
                </span>
              </h2>
              <p className="text-xs text-stone-400">
                Atualize o bot na sua outra hospedagem instantaneamente sem precisar baixar ou upar arquivos manualmente.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-stone-400 hover:bg-stone-800 hover:text-white transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Live Status & Test Banner */}
        <div className="mb-6 rounded-xl border border-indigo-950 bg-indigo-950/30 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-indigo-300">
              <Radio className="h-4 w-4 text-emerald-400 animate-pulse" />
              <span>Servidor Master de Sincronização Pronto</span>
            </div>
            <p className="text-xs text-stone-400 mt-1 font-mono break-all">
              Endpoint: {syncEndpointUrl}
            </p>
          </div>
          <button
            onClick={handleTestConnection}
            disabled={isLoading}
            className="flex items-center justify-center gap-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 px-4 py-2 text-xs font-bold text-white shadow transition-all whitespace-nowrap disabled:opacity-50"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${isLoading ? 'animate-spin' : ''}`} />
            <span>Testar API</span>
          </button>
        </div>

        {testResult && (
          <div
            className={`mb-6 flex items-start gap-2 rounded-xl p-3 text-xs ${
              testResult.ok
                ? 'border border-emerald-500/40 bg-emerald-950/50 text-emerald-300'
                : 'border border-rose-500/40 bg-rose-950/50 text-rose-300'
            }`}
          >
            {testResult.ok ? (
              <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-400 mt-0.5" />
            ) : (
              <AlertCircle className="h-4 w-4 shrink-0 text-rose-400 mt-0.5" />
            )}
            <div>
              <p className="font-semibold">{testResult.ok ? 'Sucesso na Conexão' : 'Erro no Teste'}</p>
              <p className="mt-0.5 opacity-90">{testResult.message}</p>
            </div>
          </div>
        )}

        {/* Methods */}
        <div className="space-y-4 mb-6">
          {/* Method 1: Discord Command */}
          <div className="rounded-xl border border-stone-800 bg-stone-900/60 p-4 transition-all hover:border-stone-700">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <span className="flex h-6 w-6 items-center justify-center rounded-lg bg-indigo-600/30 text-indigo-400 text-xs font-bold border border-indigo-500/30">
                  1
                </span>
                <h3 className="text-sm font-bold text-stone-200">
                  Pelo Discord (Método Mais Fácil)
                </h3>
              </div>
              <span className="text-[10px] font-semibold text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2 py-0.5 rounded-md">
                1 Clique
              </span>
            </div>
            <p className="text-xs text-stone-400 mb-3">
              Quando você pedir qualquer alteração aqui no chat, basta você ir no seu Discord e digitar:
            </p>
            <div className="flex items-center justify-between rounded-lg bg-stone-950 border border-stone-800 p-2.5 font-mono text-xs text-indigo-300">
              <code>.atualizar</code>
              <button
                onClick={() => copyToClipboard('.atualizar', 'discord_cmd')}
                className="flex items-center gap-1 rounded bg-stone-800 px-2 py-1 text-[11px] text-stone-300 hover:bg-stone-700 hover:text-white"
              >
                {copiedKey === 'discord_cmd' ? (
                  <Check className="h-3.5 w-3.5 text-emerald-400" />
                ) : (
                  <Copy className="h-3.5 w-3.5" />
                )}
                <span>Copiar</span>
              </button>
            </div>
            <p className="text-[11px] text-stone-500 mt-2">
              * O bot irá conectar diretamente aqui, baixar o código atualizado, sobrescrever os arquivos e reiniciar sozinho.
            </p>
          </div>

          {/* Method 2: Terminal / Node Command */}
          <div className="rounded-xl border border-stone-800 bg-stone-900/60 p-4 transition-all hover:border-stone-700">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <span className="flex h-6 w-6 items-center justify-center rounded-lg bg-cyan-600/30 text-cyan-400 text-xs font-bold border border-cyan-500/30">
                  2
                </span>
                <h3 className="text-sm font-bold text-stone-200">
                  Pelo Terminal da sua Hospedagem (VPS / SSH)
                </h3>
              </div>
              <span className="text-[10px] font-semibold text-cyan-400 bg-cyan-950/60 border border-cyan-500/30 px-2 py-0.5 rounded-md">
                CLI
              </span>
            </div>
            <p className="text-xs text-stone-400 mb-3">
              No console ou terminal da sua hospedagem externa, execute o script de sincronização:
            </p>
            <div className="flex items-center justify-between rounded-lg bg-stone-950 border border-stone-800 p-2.5 font-mono text-xs text-cyan-300">
              <code>npm run sync</code>
              <button
                onClick={() => copyToClipboard('npm run sync', 'npm_sync')}
                className="flex items-center gap-1 rounded bg-stone-800 px-2 py-1 text-[11px] text-stone-300 hover:bg-stone-700 hover:text-white"
              >
                {copiedKey === 'npm_sync' ? (
                  <Check className="h-3.5 w-3.5 text-emerald-400" />
                ) : (
                  <Copy className="h-3.5 w-3.5" />
                )}
                <span>Copiar</span>
              </button>
            </div>
            <p className="text-[11px] text-stone-500 mt-2">
              Ou comando direto: <code className="text-stone-300">node sync.js</code>
            </p>
          </div>

          {/* Method 3: Direct ZIP URL */}
          <div className="rounded-xl border border-stone-800 bg-stone-900/60 p-4 transition-all hover:border-stone-700">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <span className="flex h-6 w-6 items-center justify-center rounded-lg bg-amber-600/30 text-amber-400 text-xs font-bold border border-amber-500/30">
                  3
                </span>
                <h3 className="text-sm font-bold text-stone-200">
                  Link Direto do Pacote ZIP (Sempre Atualizado)
                </h3>
              </div>
              <span className="text-[10px] font-semibold text-amber-400 bg-amber-950/60 border border-amber-500/30 px-2 py-0.5 rounded-md">
                Download Direto
              </span>
            </div>
            <p className="text-xs text-stone-400 mb-3">
              URL que sempre gera e entrega o código compilado mais recente:
            </p>
            <div className="flex items-center justify-between rounded-lg bg-stone-950 border border-stone-800 p-2.5 font-mono text-xs text-amber-300">
              <span className="truncate mr-2">{zipEndpointUrl}</span>
              <button
                onClick={() => copyToClipboard(zipEndpointUrl, 'zip_url')}
                className="flex items-center gap-1 rounded bg-stone-800 px-2 py-1 text-[11px] text-stone-300 hover:bg-stone-700 hover:text-white shrink-0"
              >
                {copiedKey === 'zip_url' ? (
                  <Check className="h-3.5 w-3.5 text-emerald-400" />
                ) : (
                  <Copy className="h-3.5 w-3.5" />
                )}
                <span>Copiar URL</span>
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-3 border-t border-stone-800 pt-4">
          <button
            onClick={onClose}
            className="rounded-xl bg-stone-800 hover:bg-stone-700 px-5 py-2 text-xs font-bold text-white transition-colors"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
};
