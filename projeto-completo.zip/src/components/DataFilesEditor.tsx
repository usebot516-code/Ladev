import React, { useState, useEffect } from 'react';
import { Database, FileCode, Save, RefreshCw, Check, AlertTriangle, Search } from 'lucide-react';
import { DataFileInfo } from '../types';

export const DataFilesEditor: React.FC = () => {
  const [files, setFiles] = useState<DataFileInfo[]>([]);
  const [selectedFile, setSelectedFile] = useState<string>('guild_configs.json');
  const [fileContent, setFileContent] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [saveStatus, setSaveStatus] = useState<{ success?: boolean; message?: string } | null>(null);

  const fetchFileList = async () => {
    try {
      const res = await fetch('/api/bot/data-files');
      const contentType = res.headers.get('content-type') || '';
      if (res.ok && contentType.includes('application/json')) {
        const d = await res.json();
        setFiles(d.files || []);
      }
    } catch (e) {
      console.warn('Could not load data-files:', e);
    }
  };

  const loadFileContent = async (fileName: string) => {
    setIsLoading(true);
    setSaveStatus(null);
    try {
      const res = await fetch(`/api/bot/data-file/${fileName}`);
      const contentType = res.headers.get('content-type') || '';
      if (res.ok && contentType.includes('application/json')) {
        const d = await res.json();
        setFileContent(d.raw || JSON.stringify(d.data, null, 2));
      }
    } catch (e) {
      console.warn('Could not load file content:', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchFileList();
    loadFileContent(selectedFile);
  }, []);

  const handleSelectFile = (name: string) => {
    setSelectedFile(name);
    loadFileContent(name);
  };

  const handleSave = async () => {
    try {
      // Validate JSON
      JSON.parse(fileContent);
    } catch (e: any) {
      setSaveStatus({ success: false, message: 'JSON inválido: ' + e.message });
      return;
    }

    setIsSaving(true);
    setSaveStatus(null);
    try {
      const res = await fetch(`/api/bot/data-file/${selectedFile}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ raw: fileContent }),
      });

      if (res.ok) {
        setSaveStatus({ success: true, message: 'Arquivo salvo com sucesso!' });
        fetchFileList();
        setTimeout(() => setSaveStatus(null), 3000);
      } else {
        const err = await res.json();
        setSaveStatus({ success: false, message: err.error || 'Falha ao salvar' });
      }
    } catch (e: any) {
      setSaveStatus({ success: false, message: e.message });
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-emerald-900/40 bg-stone-900/60 p-5 backdrop-blur-sm">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400">
            <Database className="h-6 w-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-stone-100">
              Banco de Dados & Arquivos JSON (/data)
            </h2>
            <p className="text-xs text-stone-400">
              Visualize e edite as configurações de servidores, filas, ranking, tickets e blacklist.
            </p>
          </div>
        </div>

        <button
          onClick={() => {
            fetchFileList();
            loadFileContent(selectedFile);
          }}
          disabled={isLoading}
          className="flex items-center gap-1.5 rounded-xl border border-stone-700 bg-stone-950 px-3.5 py-2 text-xs font-semibold text-stone-300 hover:text-white"
        >
          <RefreshCw className={`h-3.5 w-3.5 ${isLoading ? 'animate-spin' : ''}`} />
          <span>Recarregar</span>
        </button>
      </div>

      {/* Main 2-Column Layout */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Left: Files List */}
        <div className="lg:col-span-4 rounded-2xl border border-stone-800 bg-stone-900/60 p-4 space-y-2">
          <h3 className="text-xs font-bold uppercase tracking-wider text-stone-400 mb-3 flex items-center gap-2">
            <FileCode className="h-4 w-4 text-emerald-400" />
            <span>Arquivos Disponíveis ({files.length})</span>
          </h3>

          <div className="space-y-1">
            {files.map((file) => {
              const active = selectedFile === file.name;
              return (
                <button
                  key={file.name}
                  onClick={() => handleSelectFile(file.name)}
                  className={`w-full flex items-center justify-between rounded-xl px-3.5 py-2.5 text-left text-xs font-mono transition-all ${
                    active
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/50 shadow font-bold'
                      : 'text-stone-400 hover:bg-stone-800 hover:text-stone-200 border border-transparent'
                  }`}
                >
                  <span className="truncate">{file.name}</span>
                  <span className="text-[10px] text-stone-500 font-sans">
                    {(file.size / 1024).toFixed(1)} KB
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right: Code/JSON Editor */}
        <div className="lg:col-span-8 flex flex-col rounded-2xl border border-stone-800 bg-stone-950 p-4 space-y-3 shadow-2xl">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-stone-800 pb-3">
            <div className="flex items-center gap-2 font-mono text-xs text-stone-200">
              <span className="text-emerald-400 font-bold">Arquivo Ativo:</span>
              <span className="rounded bg-stone-900 px-2 py-0.5 border border-stone-800">
                data/{selectedFile}
              </span>
            </div>

            <div className="flex items-center gap-2">
              {saveStatus && (
                <span
                  className={`text-xs flex items-center gap-1 font-semibold ${
                    saveStatus.success ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {saveStatus.success ? <Check className="h-3.5 w-3.5" /> : <AlertTriangle className="h-3.5 w-3.5" />}
                  <span>{saveStatus.message}</span>
                </span>
              )}

              <button
                onClick={handleSave}
                disabled={isSaving || isLoading}
                className="flex items-center gap-1.5 rounded-xl bg-emerald-600 px-4 py-1.5 text-xs font-bold text-white shadow hover:bg-emerald-500 disabled:opacity-50"
              >
                <Save className="h-3.5 w-3.5" />
                <span>{isSaving ? 'Salvando...' : 'Salvar Alterações'}</span>
              </button>
            </div>
          </div>

          <textarea
            value={fileContent}
            onChange={(e) => setFileContent(e.target.value)}
            disabled={isLoading}
            rows={18}
            className="w-full flex-1 rounded-xl border border-stone-800 bg-stone-900/90 p-4 font-mono text-xs leading-relaxed text-stone-200 placeholder:text-stone-600 focus:border-emerald-500 focus:outline-none select-text"
          />
        </div>
      </div>
    </div>
  );
};
