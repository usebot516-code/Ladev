import React, { useState } from 'react';
import {
  Bot,
  Play,
  Square,
  RotateCcw,
  Key,
  Shield,
  Layers,
  Copy,
  Check,
  ExternalLink,
  Users,
  Server,
  Zap,
  Terminal,
  Activity,
  Award,
  CreditCard,
  MessageSquare,
  Clock,
  Sparkles,
  ChevronRight,
  FolderOpen,
  RefreshCw,
  Download,
  Loader2,
  FileArchive,
  Upload,
  FileText,
} from 'lucide-react';
import { BotState, BotConfig } from '../types';
import { downloadProjectZip } from '../utils/downloadZip';

interface BotControlPanelProps {
  botState: BotState | null;
  botConfig: BotConfig | null;
  onStartBot: (token?: string) => void;
  onStopBot: () => void;
  onRestartBot: (token?: string) => void;
  isActionLoading: boolean;
  onOpenConfigModal: () => void;
  onOpenSyncModal?: () => void;
  onNavigateTab: (tab: any) => void;
}

export const BotControlPanel: React.FC<BotControlPanelProps> = ({
  botState,
  botConfig,
  onStartBot,
  onStopBot,
  onRestartBot,
  isActionLoading,
  onOpenConfigModal,
  onOpenSyncModal,
  onNavigateTab,
}) => {
  const [copiedInvite, setCopiedInvite] = useState(false);
  const [quickToken, setQuickToken] = useState('');
  const [isDownloadingZip, setIsDownloadingZip] = useState(false);
  const [zipStatusText, setZipStatusText] = useState<string | null>(null);
  const isOnline = botState?.status === 'online';
  const isStarting = botState?.status === 'starting';

  const handleDownloadZip = async () => {
    setIsDownloadingZip(true);
    setZipStatusText('Gerando e baixando pacote .ZIP...');
    await downloadProjectZip((status) => setZipStatusText(status));
    setIsDownloadingZip(false);
    setTimeout(() => setZipStatusText(null), 3000);
  };

  // Discord Bot Invite Link Generator
  // Permissions: 8 (Administrator) with bot and applications.commands scopes
  const botId = botState?.id || 'SEU_CLIENT_ID';
  const inviteUrl = `https://discord.com/api/oauth2/authorize?client_id=${botId}&permissions=8&scope=bot%20applications.commands`;

  const handleCopyInvite = () => {
    navigator.clipboard.writeText(inviteUrl);
    setCopiedInvite(true);
    setTimeout(() => setCopiedInvite(false), 2000);
  };

  const handleQuickStart = (e: React.FormEvent) => {
    e.preventDefault();
    if (quickToken.trim()) {
      onStartBot(quickToken.trim());
      setQuickToken('');
    } else {
      onStartBot();
    }
  };

  return (
    <div className="space-y-6">
      {/* Bot Hero Status Card */}
      <div className="relative overflow-hidden rounded-2xl border border-indigo-900/50 bg-gradient-to-br from-stone-950 via-stone-900 to-indigo-950/40 p-6 shadow-2xl">
        {/* Glow effect */}
        <div className="pointer-events-none absolute -right-20 -top-20 h-64 w-64 rounded-full bg-indigo-500/10 blur-3xl" />

        <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
          {/* Bot Profile Details */}
          <div className="flex items-center gap-4">
            <div className="relative flex h-20 w-20 items-center justify-center rounded-2xl border-2 border-indigo-500/40 bg-stone-900 shadow-xl">
              {botState?.avatar ? (
                <img
                  src={botState.avatar}
                  alt="Bot Avatar"
                  className="h-full w-full rounded-2xl object-cover"
                />
              ) : (
                <Bot className="h-10 w-10 text-indigo-400" />
              )}
              <span
                className={`absolute -bottom-1 -right-1 h-5 w-5 rounded-full border-4 border-stone-950 ${
                  isOnline
                    ? 'bg-emerald-500 shadow-[0_0_10px_#10b981]'
                    : isStarting
                    ? 'bg-amber-400 animate-ping'
                    : 'bg-stone-600'
                }`}
              />
            </div>

            <div>
              <div className="flex items-center gap-2.5">
                <h2 className="text-xl font-extrabold text-stone-100 sm:text-2xl">
                  {botState?.tag ? botState.tag : 'Ryze Discord Bot'}
                </h2>
                <span className="rounded bg-indigo-950 border border-indigo-500/40 px-2 py-0.5 text-[10px] font-bold text-indigo-300 uppercase">
                  v2.1.2 Oficial
                </span>
              </div>
              <p className="mt-1 text-xs text-stone-400 font-mono">
                {botState?.id ? `Client ID: ${botState.id}` : 'Sistema de Filas, Mediadores, Tickets e Multi-Bots'}
              </p>
              <div className="mt-2 flex flex-wrap items-center gap-2 text-xs">
                <span
                  className={`inline-flex items-center gap-1 rounded-md px-2.5 py-1 text-xs font-semibold ${
                    isOnline
                      ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-500/30'
                      : isStarting
                      ? 'bg-amber-950/80 text-amber-300 border border-amber-500/30'
                      : 'bg-stone-800 text-stone-300'
                  }`}
                >
                  <Zap className="h-3.5 w-3.5" />
                  <span>Status: {isOnline ? 'ONLINE & CONECTADO' : isStarting ? 'INICIANDO SESSÃO...' : 'OFFLINE'}</span>
                </span>
                {botConfig?.maskedToken && (
                  <span className="rounded-md border border-stone-800 bg-stone-900 px-2.5 py-1 text-[11px] font-mono text-stone-400">
                    Token: {botConfig.maskedToken}
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Quick Action Button Box */}
          <div className="flex flex-col gap-2.5 sm:flex-row">
            {isOnline ? (
              <>
                <button
                  onClick={onStopBot}
                  disabled={isActionLoading}
                  className="flex items-center justify-center gap-2 rounded-xl border border-rose-600/50 bg-rose-950/80 px-5 py-2.5 text-xs font-bold text-rose-200 shadow-lg hover:bg-rose-900 disabled:opacity-50"
                >
                  <Square className="h-4 w-4 fill-current" />
                  <span>Parar Bot</span>
                </button>
                <button
                  onClick={() => onRestartBot()}
                  disabled={isActionLoading}
                  className="flex items-center justify-center gap-2 rounded-xl border border-stone-700 bg-stone-900 px-4 py-2.5 text-xs font-bold text-stone-200 shadow hover:bg-stone-800 disabled:opacity-50"
                >
                  <RotateCcw className="h-4 w-4" />
                  <span>Reiniciar</span>
                </button>
              </>
            ) : (
              <button
                onClick={() => onStartBot()}
                disabled={isActionLoading || isStarting}
                className="flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-emerald-500 via-emerald-600 to-teal-600 px-6 py-3 text-xs font-bold text-white shadow-xl shadow-emerald-950/60 hover:from-emerald-400 hover:to-teal-500 disabled:opacity-50"
              >
                <Play className="h-4 w-4 fill-current" />
                <span>{isStarting ? 'Conectando ao Discord...' : 'Iniciar Discord Bot'}</span>
              </button>
            )}

            <button
              onClick={handleCopyInvite}
              className="flex items-center justify-center gap-2 rounded-xl border border-indigo-700/60 bg-indigo-950/60 px-4 py-2.5 text-xs font-semibold text-indigo-200 shadow hover:bg-indigo-900/80"
              title="Copiar Link de Convite para o Servidor"
            >
              {copiedInvite ? <Check className="h-4 w-4 text-emerald-400" /> : <ExternalLink className="h-4 w-4" />}
              <span>{copiedInvite ? 'Convite Copiado!' : 'Convidar p/ Servidor'}</span>
            </button>
          </div>
        </div>

        {/* Quick Token Start Input if offline and no token */}
        {!isOnline && !botConfig?.hasToken && (
          <form onSubmit={handleQuickStart} className="mt-6 border-t border-stone-800/80 pt-4">
            <label className="block text-xs font-semibold text-stone-300 mb-1.5 flex items-center gap-2">
              <Key className="h-3.5 w-3.5 text-indigo-400" />
              <span>Inserir Token do Discord para Iniciar Imediatamente:</span>
            </label>
            <div className="flex gap-2">
              <input
                type="password"
                value={quickToken}
                onChange={(e) => setQuickToken(e.target.value)}
                placeholder="Cole o DISCORD_BOT_TOKEN aqui (ex: MTI...)"
                className="flex-1 rounded-xl border border-stone-700 bg-stone-950 px-4 py-2 text-xs text-stone-100 placeholder:text-stone-500 focus:border-indigo-500 focus:outline-none"
              />
              <button
                type="submit"
                disabled={!quickToken.trim() || isActionLoading}
                className="flex items-center gap-1.5 rounded-xl bg-indigo-600 px-5 py-2 text-xs font-bold text-white hover:bg-indigo-500 disabled:opacity-50"
              >
                <Play className="h-3.5 w-3.5 fill-current" />
                <span>Iniciar</span>
              </button>
            </div>
          </form>
        )}
      </div>

      {/* Direct ZIP Download Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 rounded-2xl border border-indigo-500/30 bg-gradient-to-r from-indigo-950/70 via-stone-900/80 to-purple-950/50 p-4 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border border-indigo-500/40 bg-indigo-900/40 text-indigo-300 shadow-inner">
            <FileArchive className="h-6 w-6" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <span>Código-Fonte Completo do Projeto (.ZIP)</span>
              <span className="rounded-full bg-indigo-500/20 px-2 py-0.5 text-[10px] font-semibold text-indigo-300 border border-indigo-500/30">
                Limpo & Seguro
              </span>
            </h4>
            <p className="text-xs text-stone-400">
              Inclui <code className="text-stone-300">bot_src/</code>, <code className="text-stone-300">data/</code>, painel web e configurações. Tokens do Discord são omitidos do .ZIP por segurança.
            </p>
            {zipStatusText && (
              <p className="text-[11px] font-medium text-emerald-400 mt-1 animate-pulse">
                {zipStatusText}
              </p>
            )}
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {onOpenSyncModal && (
            <button
              onClick={onOpenSyncModal}
              className="flex shrink-0 items-center gap-2 rounded-xl border border-cyan-500/50 bg-cyan-950/70 px-4 py-2.5 text-xs font-bold text-cyan-200 hover:bg-cyan-900/80 hover:text-white transition-all shadow-md"
            >
              <RefreshCw className="h-4 w-4 text-cyan-400" />
              <span>Auto-Update Remoto</span>
            </button>
          )}

          <button
            onClick={() => onNavigateTab('files')}
            className="flex shrink-0 items-center gap-2 rounded-xl border border-indigo-500/50 bg-indigo-950/70 px-4 py-2.5 text-xs font-bold text-indigo-200 hover:bg-indigo-900/80 hover:text-white transition-all shadow-md"
          >
            <Upload className="h-4 w-4" />
            <span>Anexar / Enviar ZIPs</span>
          </button>

          <button
            onClick={handleDownloadZip}
            disabled={isDownloadingZip}
            className="flex shrink-0 items-center gap-2 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 px-4 py-2.5 text-xs font-bold text-white shadow-lg shadow-indigo-950/60 hover:from-indigo-500 hover:to-purple-500 transition-all disabled:opacity-50"
          >
            {isDownloadingZip ? (
              <Loader2 className="h-4 w-4 animate-spin text-white" />
            ) : (
              <Download className="h-4 w-4" />
            )}
            <span>{isDownloadingZip ? 'Preparando...' : 'Baixar .ZIP'}</span>
          </button>
        </div>
      </div>

      {/* Metric Cards Grid */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {/* Metric 1: Servidores */}
        <div className="rounded-2xl border border-stone-800 bg-stone-900/60 p-4 backdrop-blur-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-stone-400">Servidores Ativos</span>
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-indigo-950/60 border border-indigo-800/40 text-indigo-400">
              <Server className="h-4 w-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-black text-stone-100">{botState?.guildCount || 0}</span>
            <span className="text-[11px] text-stone-400">guilds conectadas</span>
          </div>
        </div>

        {/* Metric 2: Multi-Bots Vault */}
        <div
          onClick={() => onNavigateTab('multibot')}
          className="group cursor-pointer rounded-2xl border border-stone-800 bg-stone-900/60 p-4 backdrop-blur-sm hover:border-indigo-500/50 transition-colors"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-stone-400 group-hover:text-indigo-300">
              Multi-Bots (.bots)
            </span>
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-violet-950/60 border border-violet-800/40 text-violet-400">
              <Layers className="h-4 w-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-black text-stone-100">
              {botState?.workers ? botState.workers.length : 'Ativo'}
            </span>
            <span className="text-[11px] text-stone-400">instâncias gerenciadas</span>
          </div>
        </div>

        {/* Metric 3: Loja & MercadoPago */}
        <div className="rounded-2xl border border-stone-800 bg-stone-900/60 p-4 backdrop-blur-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-stone-400">Mercado Pago Pix</span>
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-yellow-950/60 border border-yellow-800/40 text-yellow-400">
              <CreditCard className="h-4 w-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-sm font-bold text-stone-200">
              {botConfig?.mercadoPagoConfigured ? 'Ativado (Pix)' : 'Não Configurado'}
            </span>
          </div>
          <p className="text-[10px] text-stone-500 mt-1">Comando .loja e pagamentos automáticos</p>
        </div>

        {/* Metric 4: Arquivos de Dados */}
        <div
          onClick={() => onNavigateTab('data')}
          className="group cursor-pointer rounded-2xl border border-stone-800 bg-stone-900/60 p-4 backdrop-blur-sm hover:border-indigo-500/50 transition-colors"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-stone-400 group-hover:text-indigo-300">
              Banco de Dados JSON
            </span>
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-950/60 border border-emerald-800/40 text-emerald-400">
              <FolderOpen className="h-4 w-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-black text-stone-100">9</span>
            <span className="text-[11px] text-stone-400">arquivos em /data</span>
          </div>
        </div>
      </div>

      {/* Feature Modules Cards Grid */}
      <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
        {/* Module 1: Filas e Mediadores Free Fire */}
        <div className="rounded-2xl border border-stone-800 bg-stone-900/60 p-5 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5 text-amber-400">
              <Zap className="h-5 w-5" />
              <h3 className="font-bold text-stone-100">Filas & Mediadores Free Fire</h3>
            </div>
            <button
              onClick={() => onNavigateTab('queues')}
              className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1 font-medium"
            >
              <span>Ver detalhes</span>
              <ChevronRight className="h-3.5 w-3.5" />
            </button>
          </div>
          <p className="text-xs text-stone-400 leading-relaxed">
            Painéis interativos com Components V2 para <strong>Fila Mediador</strong>, <strong>Fila Analista</strong> e{' '}
            <strong>Fila Streamer</strong> com painéis dinâmicos e controle de partidas.
          </p>
          <div className="flex flex-wrap gap-2 pt-1">
            <span className="rounded-lg bg-stone-800 px-2.5 py-1 text-[11px] font-mono text-stone-300">
              /filas
            </span>
            <span className="rounded-lg bg-stone-800 px-2.5 py-1 text-[11px] font-mono text-stone-300">
              /fila mediador
            </span>
            <span className="rounded-lg bg-stone-800 px-2.5 py-1 text-[11px] font-mono text-stone-300">
              /fila analista
            </span>
            <span className="rounded-lg bg-stone-800 px-2.5 py-1 text-[11px] font-mono text-stone-300">
              API Nixff.vip
            </span>
          </div>
        </div>

        {/* Module 2: Multi-Bots Vault & Loja */}
        <div className="rounded-2xl border border-stone-800 bg-stone-900/60 p-5 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5 text-violet-400">
              <Layers className="h-5 w-5" />
              <h3 className="font-bold text-stone-100">Multi-Bots & Loja de Planos</h3>
            </div>
            <button
              onClick={() => onNavigateTab('multibot')}
              className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1 font-medium"
            >
              <span>Gerenciar cofre</span>
              <ChevronRight className="h-3.5 w-3.5" />
            </button>
          </div>
          <p className="text-xs text-stone-400 leading-relaxed">
            Execute até 25 bots simultâneos no mesmo host através do cofre criptografado com <code>SESSION_SECRET</code>. Cada instância opera com dados e filas isoladas.
          </p>
          <div className="flex flex-wrap gap-2 pt-1">
            <span className="rounded-lg bg-stone-800 px-2.5 py-1 text-[11px] font-mono text-stone-300">
              .dev central
            </span>
            <span className="rounded-lg bg-stone-800 px-2.5 py-1 text-[11px] font-mono text-stone-300">
              .p
            </span>
            <span className="rounded-lg bg-stone-800 px-2.5 py-1 text-[11px] font-mono text-stone-300">
              /tickets
            </span>
            <span className="rounded-lg bg-stone-800 px-2.5 py-1 text-[11px] font-mono text-stone-300">
              /ranking
            </span>
          </div>
        </div>
      </div>

      {/* Regras do Projeto (regras.md) Quick Card */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 rounded-2xl border border-indigo-900/60 bg-gradient-to-r from-stone-900 via-indigo-950/40 to-stone-900 p-4 shadow-lg">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-indigo-500/40 bg-indigo-900/30 text-indigo-400">
            <FileText className="h-5 w-5" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-stone-200">Regras Oficiais do Projeto (regras.md)</h4>
            <p className="text-[11px] text-stone-400">
              Painéis sem emojis • Discord Components V2 • Auto-Refresh Obrigatório • Zero Rodapés • Exportação ZIP limpa
            </p>
          </div>
        </div>
        <button
          onClick={() => onNavigateTab('rules')}
          className="flex shrink-0 items-center gap-1.5 rounded-xl border border-indigo-500/40 bg-indigo-950/60 px-3.5 py-1.5 text-xs font-semibold text-indigo-200 hover:bg-indigo-900/80 hover:text-white transition-colors"
        >
          <span>Ler regras.md</span>
          <ChevronRight className="h-3.5 w-3.5" />
        </button>
      </div>

      {/* Quick Slash Commands Table */}
      <div className="rounded-2xl border border-stone-800 bg-stone-900/60 p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Terminal className="h-4 w-4 text-indigo-400" />
            <h3 className="font-bold text-stone-200 text-sm">Comandos Principais do Ryze Bot</h3>
          </div>
          <button
            onClick={() => onNavigateTab('guide')}
            className="text-xs text-indigo-400 hover:text-indigo-300 font-medium"
          >
            Ver manual completo &rarr;
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="border-b border-stone-800 text-stone-400">
              <tr>
                <th className="pb-2 font-semibold">Comando</th>
                <th className="pb-2 font-semibold">Permissão</th>
                <th className="pb-2 font-semibold">Descrição</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-800/60 text-stone-300 font-mono">
              <tr>
                <td className="py-2.5 text-indigo-400 font-bold">/config_bot</td>
                <td className="py-2.5 text-stone-400">Administrador</td>
                <td className="py-2.5 font-sans text-stone-300">Abre o painel de perfil do bot (Nome, Bio, Avatar, Banner, Status)</td>
              </tr>
              <tr>
                <td className="py-2.5 text-indigo-400 font-bold">/configurar</td>
                <td className="py-2.5 text-stone-400">Administrador</td>
                <td className="py-2.5 font-sans text-stone-300">Configura cargos de mediador, analista, canais de logs e taxas</td>
              </tr>
              <tr>
                <td className="py-2.5 text-indigo-400 font-bold">/filas</td>
                <td className="py-2.5 text-stone-400">Administrador</td>
                <td className="py-2.5 font-sans text-stone-300">Envia painéis de filas (Normal, Mediador, Analista, Streamer)</td>
              </tr>
              <tr>
                <td className="py-2.5 text-indigo-400 font-bold">/aux</td>
                <td className="py-2.5 text-stone-400">Mediador</td>
                <td className="py-2.5 font-sans text-stone-300">Finalização rápida de partidas confirmadas (Vitória normal, W.O, Vencedor)</td>
              </tr>
              <tr>
                <td className="py-2.5 text-indigo-400 font-bold">/blacklist</td>
                <td className="py-2.5 text-stone-400">Administrador</td>
                <td className="py-2.5 font-sans text-stone-300">Comandos: /blacklist painel, /blacklist adicionar, /blacklist remover</td>
              </tr>
              <tr>
                <td className="py-2.5 text-violet-400 font-bold">.dev central</td>
                <td className="py-2.5 text-stone-400">Administrador / Dev</td>
                <td className="py-2.5 font-sans text-stone-300">Central de desenvolvedor: Gerencia e publica a Loja de Planos com Pix Mercado Pago</td>
              </tr>
              <tr>
                <td className="py-2.5 text-yellow-400 font-bold">.p</td>
                <td className="py-2.5 text-stone-400">Público</td>
                <td className="py-2.5 font-sans text-stone-300">Exibe o perfil com saldo de coins, estatísticas e link de convite</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
