/**
 * Utility to download the project ZIP cleanly in any browser or iframe environment
 */
export async function downloadProjectZip(onProgress?: (status: string) => void): Promise<boolean> {
  try {
    if (onProgress) onProgress('Preparando download do ZIP...');

    // Try primary blob stream download
    const res = await fetch('/api/project/download-zip');
    if (res.ok) {
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'projeto-completo.zip';
      document.body.appendChild(a);
      a.click();
      setTimeout(() => {
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
      }, 1000);
      if (onProgress) onProgress('Download concluído!');
      return true;
    }

    // Fallback: Base64 data URI method
    if (onProgress) onProgress('Tentando método alternativo base64...');
    const b64Res = await fetch('/api/project/download-base64');
    if (!b64Res.ok) throw new Error('Falha ao obter pacote ZIP');
    const data = await b64Res.json();
    if (!data.base64) throw new Error('Dados do ZIP vazios');

    const byteCharacters = atob(data.base64);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    const fallbackBlob = new Blob([byteArray], { type: 'application/zip' });

    const fallbackUrl = window.URL.createObjectURL(fallbackBlob);
    const a = document.createElement('a');
    a.href = fallbackUrl;
    a.download = data.filename || 'projeto-completo.zip';
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      window.URL.revokeObjectURL(fallbackUrl);
      document.body.removeChild(a);
    }, 1000);

    if (onProgress) onProgress('Download concluído!');
    return true;
  } catch (error: any) {
    console.error('[DOWNLOAD] Falha no download do ZIP:', error);
    if (onProgress) onProgress('Erro ao baixar: ' + error.message);
    // Ultimate fallback: open url directly in new window
    window.open('/api/project/download-zip', '_blank');
    return false;
  }
}
