import React, { useState, useEffect, useCallback } from 'react';
import { Header } from './components/Header';
import { BotControlPanel } from './components/BotControlPanel';
import { LiveConsole } from './components/LiveConsole';
import { MultiBotManager } from './components/MultiBotManager';
import { QueuesViewer } from './components/QueuesViewer';
import { DataFilesEditor } from './components/DataFilesEditor';
import { FileManagerAndUpload } from './components/FileManagerAndUpload';
import { CommandGuide } from './components/CommandGuide';
import { RulesViewer } from './components/RulesViewer';
import { CredentialsModal } from './components/CredentialsModal';
import { RemoteSyncModal } from './components/RemoteSyncModal';
import { BotState, BotConfig, LogEntry } from './types';
import { AlertCircle, CheckCircle2, Info, X } from 'lucide-react';

type TabType = 'overview' | 'console' | 'multibot' | 'queues' | 'data' | 'files' | 'guide' | 'rules';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('overview');
  const [botState, setBotState] = useState<BotState | null>(null);
  const [botConfig, setBotConfig] = useState<BotConfig | null>(null);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [isConfigModalOpen, setIsConfigModalOpen] = useState(false);
  const [isSyncModalOpen, setIsSyncModalOpen] = useState(false);
  const [isActionLoading, setIsActionLoading] = useState(false);
  const [isLogsLoading, setIsLogsLoading] = useState(false);
  const [toast, setToast] = useState<{ type: 'success' | 'error' | 'info'; message: string } | null>(null);

  const showToast = (type: 'success' | 'error' | 'info', message: string) => {
    setToast({ type, message });
    setTimeout(() => {
      setToast((prev) => (prev?.message === message ? null : prev));
    }, 4000);
  };

  const fetchBotStatus = useCallback(async () => {
    try {
      const res = await fetch('/api/bot/status');
      const contentType = res.headers.get('content-type') || '';
      if (res.ok && contentType.includes('application/json')) {
        const data = await res.json();
        setBotState(data);
      }
    } catch (_) {}
  }, []);

  const fetchBotConfig = useCallback(async () => {
    try {
      const res = await fetch('/api/bot/config');
      const contentType = res.headers.get('content-type') || '';
      if (res.ok && contentType.includes('application/json')) {
        const data = await res.json();
        setBotConfig(data);
      }
    } catch (_) {}
  }, []);

  const fetchLogs = useCallback(async () => {
    try {
      setIsLogsLoading(true);
      const res = await fetch('/api/bot/logs');
      const contentType = res.headers.get('content-type') || '';
      if (res.ok && contentType.includes('application/json')) {
        const data = await res.json();
        if (Array.isArray(data.logs)) {
          setLogs(data.logs);
        }
      }
    } catch (_) {
    } finally {
      setIsLogsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchBotStatus();
    fetchBotConfig();
    fetchLogs();

    const statusInterval = setInterval(fetchBotStatus, 3000);
    const logsInterval = setInterval(fetchLogs, 2500);

    return () => {
      clearInterval(statusInterval);
      clearInterval(logsInterval);
    };
  }, [fetchBotStatus, fetchBotConfig, fetchLogs]);

  const handleStartBot = async (customToken?: string) => {
    setIsActionLoading(true);
    try {
      const payload: Record<string, string> = {};
      if (customToken) payload.token = customToken;

      const res = await fetch('/api/bot/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (data.success) {
        showToast('success', data.message || 'Bot iniciado com sucesso!');
        await fetchBotStatus();
        await fetchLogs();
      } else {
        showToast('error', data.error || 'Erro ao iniciar o bot.');
      }
    } catch (err: any) {
      showToast('error', 'Falha na requisição: ' + err.message);
    } finally {
      setIsActionLoading(false);
    }
  };

  const handleStopBot = async () => {
    setIsActionLoading(true);
    try {
      const res = await fetch('/api/bot/stop', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        showToast('info', data.message || 'Bot parado com sucesso.');
        await fetchBotStatus();
        await fetchLogs();
      } else {
        showToast('error', data.error || 'Erro ao parar o bot.');
      }
    } catch (err: any) {
      showToast('error', 'Falha na requisição: ' + err.message);
    } finally {
      setIsActionLoading(false);
    }
  };

  const handleRestartBot = async (customToken?: string) => {
    setIsActionLoading(true);
    try {
      const payload: Record<string, string> = {};
      if (customToken) payload.token = customToken;

      const res = await fetch('/api/bot/restart', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (data.success) {
        showToast('success', data.message || 'Bot reiniciado com sucesso!');
        await fetchBotStatus();
        await fetchLogs();
      } else {
        showToast('error', data.error || 'Erro ao reiniciar o bot.');
      }
    } catch (err: any) {
      showToast('error', 'Falha na requisição: ' + err.message);
    } finally {
      setIsActionLoading(false);
    }
  };

  const handleSaveConfig = async (data: {
    token?: string;
    guildId?: string;
    ownerRoleId?: string;
    sessionSecret?: string;
    mercadoPagoToken?: string;
  }) => {
    try {
      const res = await fetch('/api/bot/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      const result = await res.json();
      if (result.success) {
        showToast('success', 'Configurações atualizadas com sucesso!');
        await fetchBotConfig();
        await fetchBotStatus();
      } else {
        showToast('error', result.error || 'Erro ao salvar configurações.');
      }
    } catch (err: any) {
      showToast('error', 'Falha ao salvar: ' + err.message);
    }
  };

  const handleClearLogs = async () => {
    try {
      const res = await fetch('/api/bot/logs/clear', { method: 'POST' });
      if (res.ok) {
        setLogs([]);
        showToast('info', 'Console de logs limpo.');
      }
    } catch (err: any) {
      showToast('error', 'Erro ao limpar logs: ' + err.message);
    }
  };

  return (
    <div className="min-h-screen bg-stone-950 text-stone-100 font-sans antialiased selection:bg-indigo-500 selection:text-white">
      {/* Toast Notification */}
      {toast && (
        <div className="fixed bottom-5 right-5 z-50 flex items-center gap-3 rounded-2xl border border-stone-800 bg-stone-900/95 p-4 shadow-2xl backdrop-blur-md transition-all animate-in fade-in slide-in-from-bottom-5">
          {toast.type === 'success' && <CheckCircle2 className="h-5 w-5 text-emerald-400 shrink-0" />}
          {toast.type === 'error' && <AlertCircle className="h-5 w-5 text-rose-400 shrink-0" />}
          {toast.type === 'info' && <Info className="h-5 w-5 text-indigo-400 shrink-0" />}
          <p className="text-xs font-medium text-stone-200">{toast.message}</p>
          <button
            onClick={() => setToast(null)}
            className="ml-2 rounded-lg p-1 text-stone-400 hover:bg-stone-800 hover:text-stone-200"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      )}

      {/* Top Header & Navigation */}
      <Header
        activeTab={activeTab}
        onTabChange={setActiveTab}
        botState={botState}
        onStartBot={() => handleStartBot()}
        onStopBot={handleStopBot}
        onRestartBot={() => handleRestartBot()}
        isActionLoading={isActionLoading}
        onOpenConfigModal={() => setIsConfigModalOpen(true)}
        onOpenSyncModal={() => setIsSyncModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="mx-auto max-w-7xl px-4 py-6 sm:px-6">
        {activeTab === 'overview' && (
          <BotControlPanel
            botState={botState}
            botConfig={botConfig}
            onStartBot={handleStartBot}
            onStopBot={handleStopBot}
            onRestartBot={handleRestartBot}
            isActionLoading={isActionLoading}
            onOpenConfigModal={() => setIsConfigModalOpen(true)}
            onOpenSyncModal={() => setIsSyncModalOpen(true)}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'console' && (
          <LiveConsole
            logs={logs}
            onClearLogs={handleClearLogs}
            onRefreshLogs={fetchLogs}
            isLoading={isLogsLoading}
          />
        )}

        {activeTab === 'multibot' && <MultiBotManager botState={botState} />}

        {activeTab === 'queues' && <QueuesViewer />}

        {activeTab === 'data' && <DataFilesEditor />}

        {activeTab === 'files' && <FileManagerAndUpload />}

        {activeTab === 'guide' && <CommandGuide />}

        {activeTab === 'rules' && <RulesViewer />}
      </main>

      {/* Credentials Modal */}
      <CredentialsModal
        isOpen={isConfigModalOpen}
        onClose={() => setIsConfigModalOpen(false)}
        botConfig={botConfig}
        onSaveConfig={handleSaveConfig}
      />

      {/* Remote Sync & Auto-Update Modal */}
      <RemoteSyncModal
        isOpen={isSyncModalOpen}
        onClose={() => setIsSyncModalOpen(false)}
      />
    </div>
  );
}
