'use strict';

/**
 * Ryze Discord Bot - Remote Sync & Auto-Update Engine
 * 
 * Este script conecta a sua hospedagem externa ao painel de desenvolvimento
 * do Google AI Studio, baixando e aplicando as atualizações de código instantaneamente.
 * 
 * Como usar:
 *   node sync.js               -> Sincroniza o código com o painel remoto
 *   npm run sync               -> Atalho no package.json
 *   npm run sync -- --restart  -> Sincroniza e reinicia o processo
 */

const fs = require('fs');
const path = require('path');
const http = require('http');
const https = require('https');

// Carregar variáveis de ambiente se disponível
try { require('dotenv').config(); } catch (_) {}

// URL padrão do ambiente de desenvolvimento no AI Studio
const DEFAULT_STUDIO_URL = process.env.STUDIO_SYNC_URL 
  || process.env.DEV_URL 
  || 'https://ais-dev-zm5u62otboazwljbd6o6x7-459637973365.us-west1.run.app';

function getSyncUrl() {
  let url = DEFAULT_STUDIO_URL;
  try {
    const configPath = path.join(__dirname, 'data', 'app_config.json');
    if (fs.existsSync(configPath)) {
      const cfg = JSON.parse(fs.readFileSync(configPath, 'utf8'));
      if (cfg.studioSyncUrl) url = cfg.studioSyncUrl;
    }
  } catch (_) {}
  return url.replace(/\/+$/, '');
}

function fetchJson(url, headers = {}) {
  return new Promise((resolve, reject) => {
    const isHttps = url.startsWith('https://');
    const client = isHttps ? https : http;

    const req = client.get(url, { headers: { 'User-Agent': 'RyzeBot-SyncClient/1.0', ...headers } }, (res) => {
      // Seguir redirecionamentos (301, 302, 307, 308)
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        let redirectUrl = res.headers.location;
        if (!redirectUrl.startsWith('http://') && !redirectUrl.startsWith('https://')) {
          const origin = new URL(url).origin;
          redirectUrl = origin + (redirectUrl.startsWith('/') ? '' : '/') + redirectUrl;
        }
        return resolve(fetchJson(redirectUrl, headers));
      }

      if (res.statusCode !== 200) {
        return reject(new Error(`Servidor remoto respondeu com status HTTP ${res.statusCode}`));
      }

      let rawData = '';
      res.setEncoding('utf8');
      res.on('data', (chunk) => { rawData += chunk; });
      res.on('end', () => {
        try {
          const parsed = JSON.parse(rawData);
          resolve(parsed);
        } catch (e) {
          reject(new Error(`Falha ao decodificar resposta JSON da API de sincronização: ${e.message}`));
        }
      });
    });

    req.on('error', (err) => reject(err));
    req.setTimeout(30000, () => {
      req.destroy();
      reject(new Error('Tempo limite de conexão excedido ao conectar ao painel remoto'));
    });
  });
}

/**
 * Executa a sincronização completa baixando arquivos do payload JSON.
 * Preserva arquivos de dados essenciais locais se especificado.
 */
async function executeSync(options = {}) {
  const targetDir = options.targetDir || process.cwd();
  const baseUrl = options.url || getSyncUrl();
  const preserveData = options.preserveData !== false; // por padrão preserva dados locais em data/
  const onProgress = typeof options.onProgress === 'function' ? options.onProgress : console.log;

  onProgress(`🌐 Conectando a ${baseUrl}...`);

  const syncEndpoint = `${baseUrl}/api/sync/payload`;
  const result = await fetchJson(syncEndpoint);

  if (!result.success || !Array.isArray(result.files)) {
    throw new Error(result.error || 'Resposta inválida recebida da API de sincronização');
  }

  onProgress(`📦 Recebidos ${result.files.length} arquivos do servidor. Aplicando alterações...`);

  let updatedCount = 0;
  let skippedCount = 0;

  for (const fileObj of result.files) {
    const relPath = fileObj.path;
    if (!relPath) continue;

    // Se estiver em data/ e já existir localmente, podemos preservar configurações de guilds/bancos se preserveData for true
    // exceto arquivos de estrutura padrão
    const isDataFile = relPath.startsWith('data/') || relPath.startsWith('data\\');
    const fullDestPath = path.join(targetDir, relPath);

    if (isDataFile && preserveData && fs.existsSync(fullDestPath)) {
      // Preserva bancos já existentes em execução local (ex: partidas, tickets, filas ativas)
      // mas permite atualizar app_config se solicitado
      if (!relPath.endsWith('app_config.json')) {
        skippedCount++;
        continue;
      }
    }

    const dirName = path.dirname(fullDestPath);
    if (!fs.existsSync(dirName)) {
      fs.mkdirSync(dirName, { recursive: true });
    }

    if (fileObj.isBase64) {
      const buffer = Buffer.from(fileObj.content, 'base64');
      fs.writeFileSync(fullDestPath, buffer);
    } else {
      fs.writeFileSync(fullDestPath, fileObj.content, 'utf8');
    }

    updatedCount++;
  }

  // Grava marcador de versão local de sincronização
  try {
    const syncState = {
      lastSyncTime: new Date().toISOString(),
      serverTimestamp: result.timestamp,
      version: result.version,
      updatedFilesCount: updatedCount,
      sourceUrl: baseUrl,
    };
    fs.writeFileSync(path.join(targetDir, 'data', 'last_sync.json'), JSON.stringify(syncState, null, 2), 'utf8');
  } catch (_) {}

  onProgress(`✅ Sincronização concluída com sucesso! ${updatedCount} arquivos atualizados (${skippedCount} arquivos locais de dados preservados).`);

  return {
    success: true,
    updatedCount,
    skippedCount,
    totalFiles: result.files.length,
    timestamp: result.timestamp,
    version: result.version,
  };
}

// Se executado diretamente via CLI (node sync.js)
if (require.main === module) {
  (async () => {
    try {
      console.log('──────────────────────────────────────────────────');
      console.log(' 🚀 RYZE BOT - AUTO-SYNC / ATUALIZADOR REMOTO');
      console.log('──────────────────────────────────────────────────');
      const syncResult = await executeSync({
        onProgress: (msg) => console.log(msg),
      });
      console.log('──────────────────────────────────────────────────');
      console.log(`✨ Código 100% atualizado! Versão: ${syncResult.version || syncResult.timestamp}`);
      console.log('👉 Você pode reiniciar o bot agora para aplicar as mudanças.');
      console.log('──────────────────────────────────────────────────');

      if (process.argv.includes('--restart') || process.argv.includes('-r')) {
        console.log('🔄 Reiniciando bot...');
        process.exit(0);
      }
    } catch (err) {
      console.error('❌ Erro durante a sincronização:', err.message);
      process.exit(1);
    }
  })();
}

module.exports = {
  executeSync,
  getSyncUrl,
};
