'use strict';

const fs = require('fs');
const { dataPath } = require('./data-path');
const { getConfig } = require('./configurar');

const DATA_FILE = dataPath('coins_data.json');
let state = {};

function loadData() {
  try {
    if (fs.existsSync(DATA_FILE)) {
      state = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    }
  } catch (err) {
    console.error('[COINS] Erro ao carregar moedas:', err.message);
    state = {};
  }
}

function saveData() {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(state, null, 2), 'utf8');
  } catch (err) {
    console.error('[COINS] Erro ao salvar moedas:', err.message);
  }
}

loadData();

function guildState(guildId) {
  if (!state[guildId]) {
    state[guildId] = { balances: {}, history: [] };
  }
  return state[guildId];
}

function coins(guildId, userId) {
  return Number(guildState(guildId).balances[userId] ?? 0);
}

function changeCoins(guildId, userId, amount, reason = '', metadata = {}) {
  const data = guildState(guildId);
  const before = coins(guildId, userId);
  const after = before + Math.floor(Number(amount) || 0);
  if (after < 0) return { ok: false, before, after };
  data.balances[userId] = after;
  data.history.push({
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    userId,
    amount: Math.floor(Number(amount) || 0),
    before,
    after,
    reason: String(reason || 'Movimentação de Coins').slice(0, 200),
    metadata,
    date: new Date().toISOString(),
  });
  saveData();
  return { ok: true, before, after };
}

function registrarRecompensas(guildId, vencedorId, perdedores, partidaId) {
  const cfg = getConfig(guildId);
  const winnerCoins = Math.max(0, Math.floor(Number(cfg.coins?.winner) || 0));
  const loserCoins = Math.max(0, Math.floor(Number(cfg.coins?.loser) || 0));
  if (vencedorId) changeCoins(guildId, vencedorId, winnerCoins, 'Recompensa por vitória', { partidaId });
  for (const userId of [...new Set((perdedores ?? []).filter((id) => id && id !== vencedorId))]) {
    changeCoins(guildId, userId, loserCoins, 'Recompensa por derrota', { partidaId });
  }
  if (winnerCoins || loserCoins) {
    console.log(`[COINS] Recompensas registradas — guild=${guildId} vencedor=${winnerCoins} perdedor=${loserCoins} partida=${partidaId}`);
  }
}

const { EmbedBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const { getEmbedColor, painelV2FromEmbed } = require('./visual');

async function handleCoins(interaction) {
  if (!interaction.isChatInputCommand() || interaction.commandName !== 'coins') return false;

  const isAdministrator = interaction.memberPermissions?.has(PermissionFlagsBits.Administrator) ||
    interaction.member?.permissions?.has(PermissionFlagsBits.ManageGuild);

  if (!isAdministrator) {
    await interaction.reply({
      content: 'Apenas administradores podem gerenciar Coins.',
      flags: MessageFlags.Ephemeral,
    });
    return true;
  }

  const sub = interaction.options.getSubcommand(false);
  if (sub && sub !== 'gerenciar') return false;

  const acao = interaction.options.getString('acao', true);
  const targetUser = interaction.options.getUser('membro', true);
  const quantidade = interaction.options.getInteger('quantidade', true);
  const guildId = interaction.guildId;

  if (!targetUser || !quantidade || quantidade <= 0) {
    await interaction.reply({
      content: 'Parametros invalidos fornecidos para o comando.',
      flags: MessageFlags.Ephemeral,
    });
    return true;
  }

  const delta = acao === 'adicionar' ? quantidade : -quantidade;
  const result = changeCoins(
    guildId,
    targetUser.id,
    delta,
    `${acao === 'adicionar' ? 'Adicionado' : 'Removido'} por ${interaction.user.tag}`
  );

  if (!result.ok && acao === 'remover') {
    await interaction.reply({
      content: `Nao foi possivel remover essa quantidade. O saldo atual de <@${targetUser.id}> e de **${result.before} Coins**.`,
      flags: MessageFlags.Ephemeral,
    });
    return true;
  }

  const color = getEmbedColor(guildId);
  const embed = new EmbedBuilder()
    .setColor(color)
    .setTitle(acao === 'adicionar' ? 'Coins Adicionados' : 'Coins Removidos')
    .setDescription(
      `**Membro:** <@${targetUser.id}> (\`${targetUser.tag}\`)\n` +
      `**Operacao:** ${acao === 'adicionar' ? `+${quantidade} Coins` : `-${quantidade} Coins`}\n` +
      `**Saldo Anterior:** ${result.before} Coins\n` +
      `**Saldo Atual:** **${result.after} Coins**\n` +
      `**Moderador:** <@${interaction.user.id}>`
    );

  const payload = painelV2FromEmbed(embed);
  await interaction.reply({
    ...payload,
    flags: (payload.flags || MessageFlags.IsComponentsV2) | MessageFlags.Ephemeral,
  });
  return true;
}

module.exports = {
  coins,
  changeCoins,
  registrarRecompensas,
  handleCoins,
};

