'use strict';

const fs = require('fs');
const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  ModalBuilder,
  MessageFlags,
  StringSelectMenuBuilder,
  TextInputBuilder,
  TextInputStyle,
} = require('discord.js');
const { painelV2FromEmbed, avatarDoServidor } = require('./visual');
const { getConfig } = require('./configurar');
const { coins } = require('./loja');
const { obterEstatisticas, obterRankingVitorias } = require('./perfil');
const { dataPath } = require('./data-path');

const PAGE_SIZE = 20;
const DATA_FILE = dataPath('ranking_data.json');
const PERIODS = {
  '1': 'Último 1 dia',
  '7': 'Últimos 7 dias',
  '30': 'Últimos 30 dias',
};
const paineisConfigOrigem = new Map();

function lerDados() {
  try {
    return fs.existsSync(DATA_FILE)
      ? JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'))
      : {};
  } catch (error) {
    console.error('[RANKING] Falha ao ler dados:', error.message);
    return {};
  }
}

const dados = lerDados();

let _saving = false;
let _savePending = false;
function salvarDados() {
  if (_saving) {
    _savePending = true;
    return;
  }
  _saving = true;
  try {
    const temp = `${DATA_FILE}.tmp`;
    fs.writeFile(temp, JSON.stringify(dados, null, 2), 'utf8', (err) => {
      if (!err) {
        fs.rename(temp, DATA_FILE, () => {
          _saving = false;
          if (_savePending) {
            _savePending = false;
            salvarDados();
          }
        });
      } else {
        _saving = false;
      }
    });
  } catch (error) {
    _saving = false;
  }
}

function dadosGuild(guildId) {
  if (!dados[guildId]) {
    dados[guildId] = {
      panelMsgId: null,
      panelChanId: null,
      titulo: 'PAINEL DE RANKING',
      descricao:
        'Consulte suas estatísticas ou acompanhe os jogadores com mais vitórias do servidor.\n\n' +
        '**Navegação privada:** ao clicar, somente você verá a tela escolhida. O painel público continuará igual para os demais membros.',
      thumbnail: null,
      banner: null,
    };
  }
  const defaults = {
    titulo: 'PAINEL DE RANKING',
    descricao:
      'Consulte suas estatísticas ou acompanhe os jogadores com mais vitórias do servidor.\n\n' +
      '**Navegação privada:** ao clicar, somente você verá a tela escolhida. O painel público continuará igual para os demais membros.',
    thumbnail: null,
    banner: null,
  };
  for (const [key, value] of Object.entries(defaults)) {
    if (!Object.prototype.hasOwnProperty.call(dados[guildId], key)) dados[guildId][key] = value;
  }
  return dados[guildId];
}

function color(guildId) {
  return getConfig(guildId)?.embedColor ?? 0x5865f2;
}

function button(customId, label, style = ButtonStyle.Secondary, disabled = false) {
  return new ButtonBuilder()
    .setCustomId(customId)
    .setLabel(label)
    .setStyle(style)
    .setDisabled(disabled);
}

function principalPanel(guildId, guild) {
  const panel = dadosGuild(guildId);
  return painelV2FromEmbed(
    new EmbedBuilder()
      .setColor(color(guildId))
      .setTitle(panel.titulo)
      .setDescription(panel.descricao)
      .addFields(
        { name: 'Perfil', value: 'Veja seu saldo de Coins, vitórias, derrotas, partidas disputadas e taxa de vitória.', inline: false },
        { name: 'Ranking', value: 'Confira a classificação de vitórias dos jogadores nos últimos 1, 7 ou 30 dias.', inline: false },
      ),
    [
      new ActionRowBuilder().addComponents(
        button('ranking:perfil', 'Perfil', ButtonStyle.Primary),
        button('ranking:periodos', 'Ranking', ButtonStyle.Success),
      ),
    ],
    { thumbnail: panel.thumbnail || avatarDoServidor(guild), image: panel.banner },
  );
}

function textoConfiguracao(guildId) {
  const panel = dadosGuild(guildId);
  return [
    `Título: **${panel.titulo || 'Não configurado'}**`,
    `Descrição: **${panel.descricao || 'Não configurada'}**`,
    `Thumbnail: **${panel.thumbnail ? 'Configurada' : 'Usando o ícone do servidor'}**`,
    `Banner: **${panel.banner ? 'Configurado' : 'Nenhum'}**`,
  ].join('\n');
}

function painelConfiguracaoRanking(guildId, notice = null, guild = null) {
  const panel = dadosGuild(guildId);
  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle('CONFIGURAÇÃO DO PAINEL DE RANKING')
    .setDescription(
      'Configure a aparência do painel antes de publicá-lo no canal atual.\n\n' +
      textoConfiguracao(guildId) +
      (notice ? `\n\n**Resultado da última ação**\n${notice}` : ''),
    );
  if (panel.thumbnail) embed.setThumbnail(panel.thumbnail);
  if (panel.banner) embed.setImage(panel.banner);

  return {
    ...painelV2FromEmbed(
      embed,
      [
        new ActionRowBuilder().addComponents(
          new StringSelectMenuBuilder()
            .setCustomId('ranking:config:opcoes')
            .setPlaceholder('Selecione o que deseja configurar')
            .addOptions(
              { label: 'Título', value: 'titulo', description: 'Alterar o título do painel público' },
              { label: 'Descrição', value: 'descricao', description: 'Alterar o texto do painel público' },
              { label: 'Thumbnail', value: 'thumbnail', description: 'Alterar ou remover a imagem pequena' },
              { label: 'Banner', value: 'banner', description: 'Alterar ou remover a imagem principal' },
            ),
        ),
        new ActionRowBuilder().addComponents(
          button('ranking:config:enviar', 'Enviar', ButtonStyle.Success),
        ),
      ],
      { thumbnail: panel.thumbnail || avatarDoServidor(guild), image: panel.banner },
    ),
    flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
  };
}

function modalConfiguracaoRanking(tipo, panel) {
  const campos = {
    titulo: {
      customId: 'ranking:config_modal:titulo',
      title: 'Alterar título do painel',
      label: 'Título do painel',
      placeholder: 'PAINEL DE RANKING',
      maxLength: 256,
      value: panel.titulo,
    },
    descricao: {
      customId: 'ranking:config_modal:descricao',
      title: 'Alterar descrição do painel',
      label: 'Descrição do painel',
      placeholder: 'Texto exibido no painel público',
      maxLength: 4000,
      value: panel.descricao,
    },
    thumbnail: {
      customId: 'ranking:config_modal:thumbnail',
      title: 'Alterar thumbnail do painel',
      label: 'URL da thumbnail',
      placeholder: 'URL pública direta da imagem; vazio remove',
      maxLength: 1000,
      value: panel.thumbnail || '',
      required: false,
    },
    banner: {
      customId: 'ranking:config_modal:banner',
      title: 'Alterar banner do painel',
      label: 'URL do banner',
      placeholder: 'URL pública direta da imagem; vazio remove',
      maxLength: 1000,
      value: panel.banner || '',
      required: false,
    },
  }[tipo];

  if (!campos) return null;
  const campo = new TextInputBuilder()
    .setCustomId('valor')
    .setLabel(campos.label)
    .setPlaceholder(campos.placeholder)
    .setStyle(tipo === 'descricao' ? TextInputStyle.Paragraph : TextInputStyle.Short)
    .setMaxLength(campos.maxLength)
    .setRequired(campos.required !== false);
  if (campos.value) campo.setValue(campos.value);

  return new ModalBuilder()
    .setCustomId(campos.customId)
    .setTitle(campos.title)
    .addComponents(new ActionRowBuilder().addComponents(campo));
}

async function publicarPainelRanking(guild, channel) {
  const guildId = guild.id;
  const registro = dadosGuild(guildId);
  if (registro.panelChanId && registro.panelChanId !== channel.id && registro.panelMsgId) {
    const canalAnterior = await guild.client?.channels.fetch(registro.panelChanId).catch(() => null);
    const mensagemAnterior = await canalAnterior?.messages.fetch(registro.panelMsgId).catch(() => null);
    if (mensagemAnterior?.author?.id === guild.client?.user?.id) {
      await mensagemAnterior.delete().catch(() => {});
      console.log(`[RANKING] Painel antigo removido de #${canalAnterior.name} antes da migração.`);
    }
  }
  const payload = {
    ...principalPanel(guildId, guild),
    allowedMentions: { parse: [] },
  };

  let message = null;
  if (registro.panelChanId === channel.id && registro.panelMsgId) {
    message = await channel.messages.fetch(registro.panelMsgId).catch(() => null);
  }
  if (message) await message.edit(payload);
  else message = await channel.send(payload);

  registro.panelMsgId = message.id;
  registro.panelChanId = channel.id;
  salvarDados();
  return message;
}

async function restaurarPainelRanking(client) {
  for (const [guildId, registro] of Object.entries(dados)) {
    if (!registro.panelMsgId || !registro.panelChanId) continue;
    const channel = await client.channels.fetch(registro.panelChanId).catch(() => null);
    if (!channel) continue;
    const message = await channel.messages.fetch(registro.panelMsgId).catch(() => null);
    if (!message) continue;
    const guild = client.guilds.cache.get(guildId) ?? channel.guild;
    if (!guild) continue;
    await message.edit({
      ...principalPanel(guildId, guild),
      allowedMentions: { parse: [] },
    }).catch((error) => {
      console.error('[RANKING] Falha ao restaurar painel:', error.message);
    });
  }
}

function profilePanel(guildId, userId, guild) {
  const stats = obterEstatisticas(guildId, userId);
  return painelV2FromEmbed(
    new EmbedBuilder()
      .setColor(color(guildId))
      .setTitle('PERFIL')
      .setDescription(`Resumo estatístico de <@${userId}>.\n\nOs dados são registrados automaticamente quando uma partida é finalizada e permanecem salvos mesmo após reinícios do bot.`)
      .addFields(
        { name: 'Saldo de Coins', value: `${coins(guildId, userId)} Coins`, inline: true },
        { name: 'Vitórias', value: `${stats.vitorias} partida(s) vencida(s)`, inline: true },
        { name: 'Derrotas', value: `${stats.derrotas} partida(s) perdida(s)`, inline: true },
        { name: 'Partidas disputadas', value: `${stats.partidas} partida(s) registrada(s)`, inline: true },
        { name: 'Taxa de vitória', value: `${stats.taxa}% das partidas`, inline: true },
      ),
    [],
    { thumbnail: avatarDoServidor(guild) },
  );
}

function periodPanel(guildId, guild) {
  return painelV2FromEmbed(
    new EmbedBuilder()
      .setColor(color(guildId))
      .setTitle('PERÍODO DO RANKING')
      .setDescription('Escolha o intervalo de tempo para consultar a classificação.\n\nO resultado será ordenado automaticamente da maior quantidade de vitórias para a menor. Quando necessário, o ranking será dividido em páginas.'),
    [
      new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
          .setCustomId('ranking:periodo')
          .setPlaceholder('Selecione um período')
          .addOptions(
            { label: 'Último 1 dia', value: '1', description: 'Vitórias nas últimas 24 horas' },
            { label: 'Últimos 7 dias', value: '7', description: 'Vitórias na última semana' },
            { label: 'Últimos 30 dias', value: '30', description: 'Vitórias no último mês' },
          ),
      ),
    ],
    { thumbnail: avatarDoServidor(guild) },
  );
}

async function rankingPanel(interaction, dias, pagina = 0) {
  const entries = obterRankingVitorias(interaction.guildId, dias);
  const totalPaginas = Math.max(1, Math.ceil(entries.length / PAGE_SIZE));
  const paginaSegura = Math.min(Math.max(Number(pagina) || 0, 0), totalPaginas - 1);
  const inicio = paginaSegura * PAGE_SIZE;
  const atual = entries.slice(inicio, inicio + PAGE_SIZE);
  const linhas = [];
  for (const [index, entry] of atual.entries()) {
    const member = interaction.guild.members.cache.get(entry.userId)
      || await interaction.guild.members.fetch(entry.userId).catch(() => null);
    const nome = member?.displayName ?? `<@${entry.userId}>`;
    linhas.push(`**${inicio + index + 1}.** ${nome} — **${entry.vitorias} ${entry.vitorias === 1 ? 'vitória' : 'vitórias'}**`);
  }

  const descricao = linhas.length
    ? linhas.join('\n')
    : 'Nenhuma vitória foi registrada neste período.';
  return painelV2FromEmbed(
    new EmbedBuilder()
      .setColor(color(interaction.guildId))
      .setTitle(`RANKING DE VITÓRIAS — ${PERIODS[String(dias)]}`)
      .setDescription(`Classificação de jogadores pelas vitórias registradas nos **${PERIODS[String(dias)]?.toLowerCase() ?? 'período selecionado'}**.\n\n${descricao}`),
    [
      new ActionRowBuilder().addComponents(
        button(`ranking:pagina:${dias}:${paginaSegura - 1}`, 'Anterior', ButtonStyle.Secondary, paginaSegura === 0),
        button(`ranking:pagina:${dias}:${paginaSegura + 1}`, 'Próximo', ButtonStyle.Secondary, paginaSegura >= totalPaginas - 1),
      ),
    ],
    { thumbnail: avatarDoServidor(interaction.guild) },
  );
}

async function handleRanking(interaction) {
  if (interaction.isChatInputCommand() && interaction.commandName === 'ranking') {
    paineisConfigOrigem.set(`${interaction.guildId}:${interaction.user.id}`, interaction);
    await interaction.reply(painelConfiguracaoRanking(interaction.guildId, null, interaction.guild));
    return true;
  }

  const id = interaction.customId ?? '';
  if (!id.startsWith('ranking:')) return false;
  const guildId = interaction.guildId;

  if (interaction.isStringSelectMenu() && id === 'ranking:config:opcoes') {
    const modal = modalConfiguracaoRanking(interaction.values[0], dadosGuild(guildId));
    if (modal) await interaction.showModal(modal);
    return true;
  }

  if (interaction.isButton() && id === 'ranking:config:enviar') {
    await interaction.deferUpdate();
    const message = await publicarPainelRanking(interaction.guild, interaction.channel);
    paineisConfigOrigem.delete(`${guildId}:${interaction.user.id}`);
    await interaction.editReply(
      painelConfiguracaoRanking(
        guildId,
        message ? `Painel enviado em <#${message.channelId}>.` : 'Não foi possível enviar o painel.',
        interaction.guild,
      ),
    );
    return true;
  }

  if (interaction.isModalSubmit() && id.startsWith('ranking:config_modal:')) {
    const tipo = id.split(':').pop();
    const panel = dadosGuild(guildId);
    const valor = interaction.fields.getTextInputValue('valor').trim();
    if (tipo === 'titulo') panel.titulo = valor || 'PAINEL DE RANKING';
    if (tipo === 'descricao') {
      panel.descricao = valor ||
        'Consulte suas estatísticas ou acompanhe os jogadores com mais vitórias do servidor.\n\n' +
        '**Navegação privada:** ao clicar, somente você verá a tela escolhida. O painel público continuará igual para os demais membros.';
    }
    if (tipo === 'thumbnail') panel.thumbnail = valor || null;
    if (tipo === 'banner') panel.banner = valor || null;
    salvarDados();

    await interaction.deferReply({ flags: MessageFlags.Ephemeral });
    const origem = paineisConfigOrigem.get(`${guildId}:${interaction.user.id}`);
    if (origem) {
      try {
        await origem.editReply(painelConfiguracaoRanking(guildId, 'Configuração atualizada automaticamente.', interaction.guild));
      } catch (error) {
        console.error('[RANKING] Falha ao atualizar painel de configuração:', error.message);
      }
    }
    await interaction.editReply({ content: '✅ Configuração atualizada.' });
    return true;
  }

  const parts = id.split(':');
  const action = parts.length >= 4 && /^\d+$/.test(parts[1]) ? parts[2] : parts[1];
  const value = parts.length >= 4 && /^\d+$/.test(parts[1]) ? parts[3] : parts[2];
  const page = parts.length >= 4 && /^\d+$/.test(parts[1]) ? parts[4] : parts[3];
  const viewerId = interaction.user.id;
  const mensagemPrivada = Boolean(
    interaction.message?.flags?.has?.(MessageFlags.Ephemeral)
      || ((interaction.message?.flags?.bitfield ?? 0) & MessageFlags.Ephemeral),
  );

  async function responder(payload) {
    if (mensagemPrivada) {
      await interaction.update({ ...payload, flags: MessageFlags.IsComponentsV2 });
    } else {
      await interaction.reply({
        ...payload,
        flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
      });
    }
  }

  if (action === 'inicio' && interaction.isButton()) {
    await responder(principalPanel(interaction.guildId, interaction.guild));
    return true;
  }
  if (action === 'perfil' && interaction.isButton()) {
    await responder(profilePanel(interaction.guildId, viewerId, interaction.guild));
    return true;
  }
  if (action === 'periodos' && interaction.isButton()) {
    await responder(periodPanel(interaction.guildId, interaction.guild));
    return true;
  }
  if (action === 'periodo' && interaction.isStringSelectMenu()) {
    await responder(await rankingPanel(interaction, interaction.values[0], 0));
    return true;
  }
  if (action === 'pagina' && interaction.isButton()) {
    await responder(await rankingPanel(interaction, value, page));
    return true;
  }
  return false;
}

module.exports = {
  handleRanking,
  publicarPainelRanking,
  restaurarPainelRanking,
};