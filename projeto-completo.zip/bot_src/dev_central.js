'use strict';

const fs = require('fs');
const path = require('path');
const https = require('https');
const {
  Client: DiscordClient,
  GatewayIntentBits,
  EmbedBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ChannelSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ChannelType,
  MessageFlags,
  PermissionFlagsBits,
  AttachmentBuilder,
} = require('discord.js');
const QRCode = require('qrcode');

const { painelV2FromEmbed } = require('./visual');
const { getConfig, updateConfig } = require('./configurar');
const { dataPath } = require('./data-path');
const { isBotOwnerUser } = require('./plano_check');
const { salvarJSON, lerJSON } = require('./storage');
const {
  painelCategoriasBotoes,
  painelBotoesDaCategoria,
  modalConfigurarBotao,
  definirConfigBotao,
  MAPA_TODOS_BOTOES,
} = require('./botoes_config');

const DATA_FILE = dataPath('dev_central_data.json');
let state = readData();

const activeChecks = new Map();
const activeBotClients = new Map(); // Mapa de instâncias ativas de bots gerenciados

function findPurchaseById(purchaseId) {
  if (!purchaseId) return { purchase: null, guildId: null };
  if (!state || typeof state !== 'object') state = readData();
  for (const gId of Object.keys(state)) {
    const d = state[gId];
    if (d && Array.isArray(d.purchases)) {
      const p = d.purchases.find((item) => item && item.id === purchaseId);
      if (p) return { purchase: p, guildId: gId };
    }
  }
  return { purchase: null, guildId: null };
}

function findTestClaimById(claimId) {
  if (!claimId) return { claim: null, guildId: null };
  if (!state || typeof state !== 'object') state = readData();
  for (const gId of Object.keys(state)) {
    const d = state[gId];
    if (d && Array.isArray(d.testClaims)) {
      const c = d.testClaims.find((item) => item && item.id === claimId);
      if (c) return { claim: c, guildId: gId };
    }
  }
  return { claim: null, guildId: null };
}

function readData() {
  try {
    const loaded = lerJSON(DATA_FILE, null);
    if (loaded && typeof loaded === 'object') {
      return loaded;
    }
  } catch (error) {
    console.error('[DEV CENTRAL] Falha ao ler dados:', error.message);
  }
  return {};
}

function saveData(guildId = null) {
  try {
    if (!state || typeof state !== 'object') state = {};
    salvarJSON(DATA_FILE, state);
    try {
      const { agendarSincronizacao } = require('./sincronizar_paineis');
      agendarSincronizacao(null, guildId);
    } catch (_) {}
  } catch (error) {
    console.error('[DEV CENTRAL] Erro ao salvar dados:', error.message);
  }
}

function guildData(guildId) {
  if (!state || typeof state !== 'object') {
    state = readData();
  }

  if (!state[guildId]) {
    state[guildId] = {
      appearance: {
        title: 'Loja Oficial',
        description: 'Adquira seu plano de acesso com ativação imediata.',
        banner: null,
        thumbnail: null,
        footer: null,
      },
      config: {
        price: 29.90,
        durationDays: 30, // 0 = vitalício / infinito
        mercadoPagoToken: process.env.MERCADOPAGO_ACCESS_TOKEN || '',
        terms: '1. O acesso concedido é de uso individual e intransferível.\n2. O suporte será fornecido durante o período contratado.\n3. Não é permitido o compartilhamento de credenciais.',
        topicsChannelId: null,
      },
      panels: [],
      purchases: [],
      managedBots: [],
      testConfig: {
        appearance: {
          title: 'Teste Grátis - Acesso VIP',
          description: 'Resgate seu teste gratuito convidando amigos para o servidor!',
          banner: null,
          thumbnail: null,
          footer: null,
        },
        config: {
          requiredInvites: 3,
          minAccountAgeDays: 7,
          durationText: '24h',
          globalLimit: 0,
          perUserLimit: 1,
        },
      },
      tests: [],
      testClaims: [],
    };
    saveData();
  }

  const d = state[guildId];
  if (!d.appearance) d.appearance = {};
  if (d.appearance.title === undefined || d.appearance.title === null) {
    d.appearance.title = 'Loja Oficial';
  }
  if (d.appearance.description === undefined || d.appearance.description === null) {
    d.appearance.description = 'Adquira seu plano de acesso com ativação imediata.';
  }
  if (d.appearance.footer === undefined) {
    d.appearance.footer = null;
  }
  if (!d.config) d.config = {};
  if (typeof d.config.price !== 'number') d.config.price = 29.90;
  if (typeof d.config.durationDays !== 'number') d.config.durationDays = 30;
  if (d.config.mercadoPagoToken === undefined || d.config.mercadoPagoToken === null) {
    d.config.mercadoPagoToken = process.env.MERCADOPAGO_ACCESS_TOKEN || '';
  }
  if (d.config.terms === undefined || d.config.terms === null) {
    d.config.terms = '1. O acesso concedido é de uso individual e intransferível.\n2. O suporte será fornecido durante o período contratado.\n3. Não é permitido o compartilhamento de credenciais.';
  }
  if (d.config.topicsChannelId === undefined) {
    d.config.topicsChannelId = null;
  }
  if (!Array.isArray(d.panels)) d.panels = [];
  if (!Array.isArray(d.purchases)) d.purchases = [];
  if (!Array.isArray(d.managedBots)) d.managedBots = [];

  if (!d.testConfig) d.testConfig = {};
  if (!d.testConfig.appearance) d.testConfig.appearance = {};
  if (d.testConfig.appearance.title === undefined || d.testConfig.appearance.title === null) {
    d.testConfig.appearance.title = 'Teste Grátis - Acesso VIP';
  }
  if (d.testConfig.appearance.description === undefined || d.testConfig.appearance.description === null) {
    d.testConfig.appearance.description = 'Resgate seu teste gratuito convidando amigos para o servidor!';
  }
  if (d.testConfig.appearance.footer === undefined) {
    d.testConfig.appearance.footer = null;
  }
  if (!d.testConfig.config) d.testConfig.config = {};
  if (typeof d.testConfig.config.requiredInvites !== 'number') d.testConfig.config.requiredInvites = 3;
  if (typeof d.testConfig.config.minAccountAgeDays !== 'number') d.testConfig.config.minAccountAgeDays = 7;
  if (!d.testConfig.config.durationText) d.testConfig.config.durationText = '24h';
  if (typeof d.testConfig.config.globalLimit !== 'number') d.testConfig.config.globalLimit = 0;
  if (typeof d.testConfig.config.perUserLimit !== 'number') d.testConfig.config.perUserLimit = 1;

  if (!Array.isArray(d.tests)) d.tests = [];
  if (!Array.isArray(d.testClaims)) d.testClaims = [];

  return d;
}

function maskToken(token) {
  if (!token || typeof token !== 'string') return 'N/A';
  if (token.length <= 16) return '****';
  return `${token.slice(0, 8)}...${token.slice(-6)}`;
}

function getBotIdFromToken(token) {
  if (!token || typeof token !== 'string') return null;
  try {
    const part = token.split('.')[0];
    if (!part) return null;
    const decoded = Buffer.from(part, 'base64').toString('utf-8');
    if (/^\d{16,25}$/.test(decoded)) {
      return decoded;
    }
  } catch (_) {}
  return null;
}

function getBotInviteUrl(botId) {
  if (!botId) return null;
  return `https://discord.com/api/oauth2/authorize?client_id=${botId}&permissions=8&scope=bot%20applications.commands`;
}

// Cor padrão fixa vermelha para todos os painéis administrativos de dono do bot
const COR_PAINEL_DONO = 0xED4245;

function color(_guildId) {
  return COR_PAINEL_DONO;
}

function truncate(value, max = 4000) {
  const text = String(value ?? '');
  return text.length > max ? `${text.slice(0, max - 3)}...` : text;
}

function isValidHttpUrl(str) {
  if (!str || typeof str !== 'string') return false;
  try {
    const u = new URL(str.trim());
    return u.protocol === 'http:' || u.protocol === 'https:';
  } catch (_) {
    return false;
  }
}

async function getUserValidInvites(guild, userId, minAccountAgeDays = 0) {
  if (!guild || !userId) return 0;
  try {
    const invites = await guild.invites.fetch().catch(() => null);
    if (!invites) return 0;

    let totalCount = 0;
    for (const [, inv] of invites) {
      if (inv && inv.inviter && inv.inviter.id === userId) {
        totalCount += (inv.uses || 0);
      }
    }
    return totalCount;
  } catch (_) {
    return 0;
  }
}

function isDevAdmin(member) {
  return isBotOwnerUser(member);
}

// ── HTTP Request Helper ────────────────────────────────────────────────────────
function requestJson(url, options = {}, bodyData = null) {
  return new Promise((resolve, reject) => {
    try {
      const parsed = new URL(url);
      const reqOptions = {
        hostname: parsed.hostname,
        port: parsed.port || 443,
        path: `${parsed.pathname}${parsed.search}`,
        method: options.method || 'GET',
        headers: {
          'Content-Type': 'application/json',
          'User-Agent': 'DevCentral/1.0',
          ...(options.headers || {}),
        },
      };

      const req = https.request(reqOptions, (res) => {
        let data = '';
        res.on('data', (chunk) => { data += chunk; });
        res.on('end', () => {
          try {
            const json = data ? JSON.parse(data) : {};
            resolve({ statusCode: res.statusCode, body: json });
          } catch (e) {
            resolve({ statusCode: res.statusCode, body: { raw: data } });
          }
        });
      });

      req.on('error', (err) => reject(err));
      if (bodyData) {
        req.write(typeof bodyData === 'string' ? bodyData : JSON.stringify(bodyData));
      }
      req.end();
    } catch (e) {
      reject(e);
    }
  });
}

// ── Mercado Pago Helpers ───────────────────────────────────────────────────────
async function createPixPayment(token, amount, description, payerEmail = 'cliente@loja.com') {
  try {
    const idempotencyKey = `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
    const body = {
      transaction_amount: Number(Number(amount).toFixed(2)),
      description: description.slice(0, 60),
      payment_method_id: 'pix',
      payer: {
        email: payerEmail,
      },
    };

    const res = await requestJson('https://api.mercadopago.com/v1/payments', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token.trim()}`,
        'X-Idempotency-Key': idempotencyKey,
      },
    }, body);

    if (res.statusCode === 201 || res.statusCode === 200) {
      const data = res.body;
      return {
        ok: true,
        id: String(data.id),
        status: data.status,
        qrCode: data.point_of_interaction?.transaction_data?.qr_code || '',
        qrCodeBase64: data.point_of_interaction?.transaction_data?.qr_code_base64 || '',
        ticketUrl: data.point_of_interaction?.transaction_data?.ticket_url || '',
      };
    }

    return {
      ok: false,
      message: res.body?.message || 'Falha ao gerar cobrança Pix no Mercado Pago.',
    };
  } catch (err) {
    return {
      ok: false,
      message: err.message || 'Erro de conexão com o Mercado Pago.',
    };
  }
}

async function checkPixPayment(token, paymentId) {
  try {
    const res = await requestJson(`https://api.mercadopago.com/v1/payments/${paymentId}`, {
      headers: {
        Authorization: `Bearer ${token.trim()}`,
      },
    });

    if (res.statusCode === 200) {
      const data = res.body;
      return {
        ok: true,
        status: data.status,
        approved: data.status === 'approved',
        paidAmount: data.transaction_amount,
      };
    }
  } catch (_) {}

  return { ok: false, status: 'unknown' };
}

// ── Modais ─────────────────────────────────────────────────────────────────────

function descriptionModal(currentDescription) {
  const modal = new ModalBuilder()
    .setCustomId('dev:loja:appearance:modal:description')
    .setTitle('Descrição do Painel');

  const text = String(currentDescription || '');
  const part1 = text.slice(0, 4000);
  const part2 = text.slice(4000, 8000);
  const part3 = text.slice(8000, 12000);

  const input1 = new TextInputBuilder()
    .setCustomId('desc_part1')
    .setLabel('Descrição - Parte 1')
    .setStyle(TextInputStyle.Paragraph)
    .setMaxLength(4000)
    .setRequired(false);
  if (part1) input1.setValue(part1);

  const input2 = new TextInputBuilder()
    .setCustomId('desc_part2')
    .setLabel('Descrição - Parte 2 (Opcional)')
    .setStyle(TextInputStyle.Paragraph)
    .setMaxLength(4000)
    .setRequired(false);
  if (part2) input2.setValue(part2);

  const input3 = new TextInputBuilder()
    .setCustomId('desc_part3')
    .setLabel('Descrição - Parte 3 (Opcional)')
    .setStyle(TextInputStyle.Paragraph)
    .setMaxLength(4000)
    .setRequired(false);
  if (part3) input3.setValue(part3);

  modal.addComponents(
    new ActionRowBuilder().addComponents(input1),
    new ActionRowBuilder().addComponents(input2),
    new ActionRowBuilder().addComponents(input3),
  );

  return modal;
}

function singleTextModal(customId, title, label, value, style = TextInputStyle.Short, maxLength = 256) {
  const safeTitle = String(title || 'Configuração').trim().slice(0, 45) || 'Configuração';
  const safeLabel = String(label || 'Valor').trim().slice(0, 45) || 'Valor';
  const safeMax = Math.max(1, Math.min(maxLength || 256, 4000));

  const modal = new ModalBuilder()
    .setCustomId(customId)
    .setTitle(safeTitle);

  const input = new TextInputBuilder()
    .setCustomId('value')
    .setLabel(safeLabel)
    .setStyle(style)
    .setMaxLength(safeMax)
    .setRequired(false);

  if (value !== undefined && value !== null) {
    const strVal = String(value);
    if (strVal.length > 0) {
      input.setValue(strVal.slice(0, safeMax));
    }
  }

  modal.addComponents(new ActionRowBuilder().addComponents(input));
  return modal;
}

function registerBotsModal() {
  const modal = new ModalBuilder()
    .setCustomId('dev:bots:modal:register')
    .setTitle('Cadastrar Tokens de Bots');

  const input = new TextInputBuilder()
    .setCustomId('tokens')
    .setLabel('Tokens dos Bots (um por linha)')
    .setStyle(TextInputStyle.Paragraph)
    .setPlaceholder('Cole aqui os tokens dos bots (um por linha)...')
    .setMaxLength(4000)
    .setRequired(true);

  modal.addComponents(new ActionRowBuilder().addComponents(input));
  return modal;
}

function testesInvitesModal(currentInvites = 3, currentMinAgeDays = 7) {
  const modal = new ModalBuilder()
    .setCustomId('dev:testes:config:modal:invites')
    .setTitle('Configurar Invites do Teste');

  const input1 = new TextInputBuilder()
    .setCustomId('invites_count')
    .setLabel('Quantidade de Invites Necessários')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('Ex: 3 (ou 0 para liberar sem invites)')
    .setValue(String(currentInvites ?? 3))
    .setMaxLength(10)
    .setRequired(true);

  const input2 = new TextInputBuilder()
    .setCustomId('min_age_days')
    .setLabel('Idade Mínima da Conta (em dias)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('Ex: 7 (tempo mín. que a conta deve ter)')
    .setValue(String(currentMinAgeDays ?? 7))
    .setMaxLength(10)
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(input1),
    new ActionRowBuilder().addComponents(input2),
  );
  return modal;
}

function testesDurationModal(currentDuration = '24h') {
  const modal = new ModalBuilder()
    .setCustomId('dev:testes:config:modal:duration')
    .setTitle('Tempo de Duração do Teste');

  const input = new TextInputBuilder()
    .setCustomId('duration_text')
    .setLabel('Duração do Teste (após resgatar)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('Ex: 24h, 3 dias, 7 dias, 30 dias')
    .setValue(String(currentDuration ?? '24h'))
    .setMaxLength(64)
    .setRequired(true);

  modal.addComponents(new ActionRowBuilder().addComponents(input));
  return modal;
}

function testesLimitsModal(currentGlobal = 0, currentPerUser = 1) {
  const modal = new ModalBuilder()
    .setCustomId('dev:testes:config:modal:limits')
    .setTitle('Limites de Resgate');

  const input1 = new TextInputBuilder()
    .setCustomId('global_limit')
    .setLabel('Limite Geral de Resgates (0 = sem limite)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('Ex: 50 (ou 0 para ilimitado)')
    .setValue(String(currentGlobal ?? 0))
    .setMaxLength(10)
    .setRequired(true);

  const input2 = new TextInputBuilder()
    .setCustomId('per_user_limit')
    .setLabel('Limite de Resgate por Pessoa')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('Ex: 1 (quantas vezes cada pessoa resgata)')
    .setValue(String(currentPerUser ?? 1))
    .setMaxLength(10)
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(input1),
    new ActionRowBuilder().addComponents(input2),
  );
  return modal;
}

// ── Painéis Administrativos ────────────────────────────────────────────────────

function mainDevPanel(guildId) {
  const d = guildData(guildId);
  const totalBots = (d.managedBots || []).length;
  const runningBots = (d.managedBots || []).filter((b) => b.status === 'online' && activeBotClients.has(b.id)).length;
  const totalTests = (d.tests || []).length;

  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle('PAINEL DEV CENTRAL')
    .setDescription(
      'Painel de controle central de serviços e sistemas.\n\n' +
      'Selecione uma das opções abaixo para gerenciar os módulos do sistema.'
    )
    .addFields([
      { name: 'Módulo Loja', value: 'Planos e Acessos', inline: true },
      { name: 'Gestão de Bots', value: `${runningBots}/${totalBots} online`, inline: true },
      { name: 'Config Testes', value: `${totalTests} painel(is)`, inline: true },
      { name: 'Personalização', value: 'Config Botões', inline: true },
    ]);

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('dev:loja:menu')
      .setLabel('Loja config')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('dev:bots:menu')
      .setLabel('Gestão bots')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('dev:testes:menu')
      .setLabel('Config testes')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('dev:buttons:menu')
      .setLabel('Config botões')
      .setStyle(ButtonStyle.Secondary),
  );

  return painelV2FromEmbed(embed, [row]);
}

function gestaoBotsPanel(guildId, aviso = null) {
  const d = guildData(guildId);
  const bots = d.managedBots || [];
  const onlineCount = bots.filter((b) => b.status === 'online' && activeBotClients.has(b.id)).length;
  const offlineCount = bots.filter((b) => b.status !== 'online' || !activeBotClients.has(b.id)).length;

  let desc =
    'Gerencie instâncias e tokens de bots secundários cadastrados.\n\n' +
    '• **Cadastrar tokens:** Registre novos tokens para inicialização.\n' +
    '• **Remover tokens:** Exclua tokens cadastrados do sistema.\n' +
    '• **Iniciar:** Inicializa e conecta todas as instâncias cadastradas de um por um.\n' +
    '• **Parar:** Escolha uma instância em execução para desconectar.';

  if (aviso) {
    desc += `\n\n**Status:** ${aviso}`;
  }

  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle('PAINEL DE GESTÃO DE BOTS')
    .setDescription(desc)
    .addFields([
      { name: 'Total de Bots', value: `${bots.length} cadastrado(s)`, inline: true },
      { name: 'Online', value: `🟢 ${onlineCount}`, inline: true },
      { name: 'Offline / Erro', value: `🔴 ${offlineCount}`, inline: true },
    ]);

  if (bots.length > 0) {
    const listText = bots
      .slice(0, 10)
      .map((b, i) => {
        const isOnline = b.status === 'online' && activeBotClients.has(b.id);
        const icon = isOnline ? '🟢' : b.status === 'error' ? '⚠️' : '🔴';
        const name = b.tag ? `**${b.tag}**` : `Bot #${i + 1}`;
        const errorInfo = b.lastError ? ` *(Erro: ${truncate(b.lastError, 40)})*` : '';
        return `${icon} ${name} — \`${maskToken(b.token)}\`${errorInfo}`;
      })
      .join('\n');

    embed.addFields([
      { name: `Instâncias Cadastradas (${Math.min(bots.length, 10)}/${bots.length})`, value: listText || 'Nenhum', inline: false },
    ]);
  }

  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('dev:bots:start_all').setLabel('Iniciar').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId('dev:bots:stop_panel').setLabel('Parar').setStyle(ButtonStyle.Danger),
  );

  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('dev:bots:register_tokens').setLabel('Cadastrar tokens').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('dev:bots:remove_tokens_panel').setLabel('Remover tokens').setStyle(ButtonStyle.Secondary),
  );

  const row3 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('dev:main:back').setLabel('Voltar').setStyle(ButtonStyle.Secondary),
  );

  return painelV2FromEmbed(embed, [row1, row2, row3]);
}

function gestaoBotsRemoveTokensPanel(guildId) {
  const d = guildData(guildId);
  const bots = d.managedBots || [];

  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle('REMOVER TOKENS DE BOTS')
    .setDescription(
      'Selecione no menu de opções abaixo o bot/token que você deseja remover do sistema.'
    )
    .addFields([
      { name: 'Total Cadastrados', value: `${bots.length} bot(s)`, inline: true },
    ]);

  const components = [];

  if (bots.length > 0) {
    const options = bots.slice(0, 25).map((b, i) => {
      const isOnline = b.status === 'online' && activeBotClients.has(b.id);
      const statusLabel = isOnline ? 'Online' : b.status === 'error' ? 'Erro' : 'Offline';
      return {
        label: truncate(`${b.tag || `Bot #${i + 1}`} (${maskToken(b.token)})`, 100),
        description: truncate(`Status: ${statusLabel} | ID: ${b.botId || 'Não registrado'}`, 100),
        value: b.id,
      };
    });

    const selectRow = new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId('dev:bots:select_remove')
        .setPlaceholder('Escolha o bot que deseja remover')
        .addOptions(options)
    );
    components.push(selectRow);
  } else {
    embed.setDescription('Nenhum bot cadastrado no sistema para ser removido.');
  }

  const buttonRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('dev:bots:menu:back')
      .setLabel('Voltar')
      .setStyle(ButtonStyle.Secondary),
  );
  components.push(buttonRow);

  return painelV2FromEmbed(embed, components);
}

function gestaoBotsStopPanel(guildId) {
  const d = guildData(guildId);
  const bots = d.managedBots || [];
  const runningBots = bots.filter((b) => b.status === 'online' || activeBotClients.has(b.id));

  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle('PARAR INSTÂNCIA DE BOT')
    .setDescription(
      'Selecione no menu de opções abaixo a instância de bot em execução que você deseja parar.'
    )
    .addFields([
      { name: 'Bots Online', value: `${runningBots.length} ativo(s)`, inline: true },
    ]);

  const components = [];

  if (runningBots.length > 0) {
    const options = runningBots.slice(0, 25).map((b, i) => {
      return {
        label: truncate(`${b.tag || `Bot #${i + 1}`} (${maskToken(b.token)})`, 100),
        description: truncate(`ID: ${b.botId || 'N/A'} | Em execução`, 100),
        value: b.id,
      };
    });

    const selectRow = new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId('dev:bots:select_stop')
        .setPlaceholder('Escolha o bot que deseja parar')
        .addOptions(options)
    );
    components.push(selectRow);
  } else {
    embed.setDescription('Nenhum bot está em execução no momento.');
  }

  const buttonRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('dev:bots:menu:back')
      .setLabel('Voltar')
      .setStyle(ButtonStyle.Secondary),
  );
  components.push(buttonRow);

  return painelV2FromEmbed(embed, components);
}

function lojaMenuPanel(guildId, aviso = null) {
  const d = guildData(guildId);
  const priceDisplay = d.config.price > 0 ? `R$ ${d.config.price.toFixed(2)}` : 'Gratuito';
  const durationDisplay = d.config.durationDays > 0 ? `${d.config.durationDays} dias` : 'Vitalício (Infinito)';
  const tokenDisplay = d.config.mercadoPagoToken ? 'Configurado' : 'Não configurado';

  let desc =
    'Configure os parâmetros visuais e de pagamento do painel público da loja.\n\n' +
    'Utilize o menu de seleção abaixo para acessar a seção desejada.';
  if (aviso) {
    desc += `\n\n**Aviso:** ${aviso}`;
  }

  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle('GERENCIADOR DA LOJA')
    .setDescription(desc)
    .addFields([
      { name: 'Preço Atual', value: priceDisplay, inline: true },
      { name: 'Duração do Plano', value: durationDisplay, inline: true },
      { name: 'Mercado Pago', value: tokenDisplay, inline: true },
      { name: 'Título do Painel', value: truncate(d.appearance.title, 100), inline: false },
    ]);

  const selectRow = new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId('dev:loja:select_section')
      .setPlaceholder('Selecione uma seção para gerenciar')
      .addOptions([
        {
          label: 'Aparência',
          value: 'appearance',
          description: 'Título, descrição, banner e thumbnail do painel público',
        },
        {
          label: 'Configurar',
          value: 'config',
          description: 'Preço, duração, pagamento e termos de uso',
        },
      ]),
  );

  const buttonRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('dev:main:back')
      .setLabel('Voltar')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('dev:loja:send_prompt')
      .setLabel('Enviar')
      .setStyle(ButtonStyle.Success),
  );

  return painelV2FromEmbed(embed, [selectRow, buttonRow]);
}

function lojaSendPanel(guildId) {
  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle('PUBLICAR PAINEL DA LOJA')
    .setDescription(
      'Selecione o canal onde a mensagem pública da loja deverá ser enviada.\n\n' +
      'O painel contará com atualização automática em tempo real sempre que houver alterações.'
    );

  const channelRow = new ActionRowBuilder().addComponents(
    new ChannelSelectMenuBuilder()
      .setCustomId('dev:loja:send_channel')
      .setPlaceholder('Selecione o canal de texto')
      .setChannelTypes([ChannelType.GuildText, ChannelType.GuildAnnouncement]),
  );

  const buttonRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('dev:loja:menu:back')
      .setLabel('Voltar')
      .setStyle(ButtonStyle.Secondary),
  );

  return painelV2FromEmbed(embed, [channelRow, buttonRow]);
}

function lojaAppearancePanel(guildId) {
  const d = guildData(guildId);
  const app = d.appearance;

  const bannerValid = isValidHttpUrl(app.banner) ? app.banner : null;
  const thumbValid = isValidHttpUrl(app.thumbnail) ? app.thumbnail : null;

  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle('APARÊNCIA DA LOJA')
    .setDescription('Configure a identidade visual exibida no painel público.')
    .addFields([
      { name: 'Título', value: truncate(app.title, 256) || 'Não definido', inline: false },
      { name: 'Descrição', value: truncate(app.description, 1024) || 'Não definida', inline: false },
      { name: 'Rodapé', value: truncate(app.footer, 256) || 'Nenhum', inline: false },
      { name: 'Banner', value: bannerValid ? truncate(bannerValid, 120) : 'Nenhum', inline: true },
      { name: 'Thumbnail', value: thumbValid ? truncate(thumbValid, 120) : 'Nenhuma', inline: true },
    ]);

  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('dev:loja:appearance:title').setLabel('Título').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('dev:loja:appearance:description').setLabel('Descrição').setStyle(ButtonStyle.Secondary),
  );

  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('dev:loja:appearance:banner').setLabel('Banner').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('dev:loja:appearance:thumbnail').setLabel('Thumbnail').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('dev:loja:appearance:footer').setLabel('Rodapé').setStyle(ButtonStyle.Secondary),
  );

  const row3 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('dev:loja:menu:back').setLabel('Voltar').setStyle(ButtonStyle.Secondary),
  );

  return painelV2FromEmbed(embed, [row1, row2, row3], {
    image: bannerValid || undefined,
    thumbnail: thumbValid || undefined,
  });
}

function lojaConfigPanel(guildId) {
  const d = guildData(guildId);
  const cfg = d.config;

  const priceDisplay = cfg.price > 0 ? `R$ ${cfg.price.toFixed(2)}` : 'Gratuito';
  const durationDisplay = cfg.durationDays > 0 ? `${cfg.durationDays} dias` : 'Vitalício (Infinito)';
  const tokenDisplay = cfg.mercadoPagoToken
    ? `${cfg.mercadoPagoToken.slice(0, 10)}...${cfg.mercadoPagoToken.slice(-6)} (Configurado)`
    : 'Não configurado';
  const topicsDisplay = cfg.topicsChannelId ? `<#${cfg.topicsChannelId}>` : 'Canal do painel (Padrão)';

  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle('CONFIGURAÇÃO DA LOJA')
    .setDescription('Defina os parâmetros operacionais, valores e termos da loja.')
    .addFields([
      { name: 'Preço do Bot', value: priceDisplay, inline: true },
      { name: 'Duração do Plano', value: durationDisplay, inline: true },
      { name: 'Mercado Pago Token', value: tokenDisplay, inline: false },
      { name: 'Canal de Tópicos', value: topicsDisplay, inline: false },
      { name: 'Termos de Uso', value: truncate(cfg.terms, 1024) || 'Nenhum termo cadastrado.', inline: false },
    ]);

  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('dev:loja:config:price').setLabel('Preço').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('dev:loja:config:duration').setLabel('Duração').setStyle(ButtonStyle.Secondary),
  );

  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('dev:loja:config:payment').setLabel('Pagamento').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('dev:loja:config:terms').setLabel('Termos').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('dev:loja:config:topics_channel').setLabel('Canal Tópicos').setStyle(ButtonStyle.Secondary),
  );

  const row3 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('dev:loja:menu:back').setLabel('Voltar').setStyle(ButtonStyle.Secondary),
  );

  return painelV2FromEmbed(embed, [row1, row2, row3]);
}

function lojaTopicsChannelPanel(guildId) {
  const d = guildData(guildId);
  const cfg = d.config;
  const currentText = cfg.topicsChannelId ? `<#${cfg.topicsChannelId}>` : 'Canal onde o usuário clicar em comprar (Padrão)';

  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle('CANAL DE TÓPICOS DA LOJA')
    .setDescription(
      'Selecione o canal de texto onde os tópicos e atendimentos de compra serão criados automaticamente.\n\n' +
      'Caso não selecione nenhum canal ou resete para o padrão, os tópicos serão criados dentro do canal onde o painel público estiver publicado.'
    )
    .addFields([
      { name: 'Canal Atual dos Tópicos', value: currentText, inline: false },
    ]);

  const channelRow = new ActionRowBuilder().addComponents(
    new ChannelSelectMenuBuilder()
      .setCustomId('dev:loja:config:select_topics_channel')
      .setPlaceholder('Selecione o canal para criação dos tópicos')
      .setChannelTypes([ChannelType.GuildText, ChannelType.GuildAnnouncement]),
  );

  const buttonRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('dev:loja:config:back_to_config')
      .setLabel('Voltar')
      .setStyle(ButtonStyle.Secondary),
  );

  if (cfg.topicsChannelId) {
    buttonRow.addComponents(
      new ButtonBuilder()
        .setCustomId('dev:loja:config:clear_topics_channel')
        .setLabel('Resetar Padrão')
        .setStyle(ButtonStyle.Danger),
    );
  }

  return painelV2FromEmbed(embed, [channelRow, buttonRow]);
}

// ── Painéis do Módulo "Config Testes" ──────────────────────────────────────────

function testesMenuPanel(guildId, aviso = null) {
  const d = guildData(guildId);
  const totalTests = (d.tests || []).length;
  const totalClaims = (d.testClaims || []).length;

  let desc =
    'Painel central de configuração e gerenciamento de testes gratuitos.\n\n' +
    '• **Criar teste:** Configure a aparência e regras do teste e envie o painel para um canal.\n' +
    '• **Gerenciar testes:** Visualize e remova painéis de testes já criados.\n' +
    '• **Histórico de resgates:** Acompanhe o histórico de usuários que resgataram testes.';
  if (aviso) {
    desc += `\n\n**Aviso:** ${aviso}`;
  }

  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle('CONFIGURAÇÃO DE TESTES')
    .setDescription(desc)
    .addFields([
      { name: 'Painéis Criados', value: `${totalTests} ativo(s)`, inline: true },
      { name: 'Total de Resgates', value: `${totalClaims} resgate(s)`, inline: true },
      { name: 'Invites Padrão', value: `${d.testConfig.config.requiredInvites || 0} req.`, inline: true },
    ]);

  const selectRow = new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId('dev:testes:select_action')
      .setPlaceholder('Selecione uma opção...')
      .addOptions([
        {
          label: 'Criar teste',
          value: 'criar',
          description: 'Aparência, regras e publicação de novo painel de teste',
        },
        {
          label: 'Gerenciar testes',
          value: 'gerenciar',
          description: 'Visualizar e remover painéis de testes existentes',
        },
        {
          label: 'Histórico de resgates',
          value: 'historico',
          description: 'Consultar histórico de resgates de testes',
        },
      ]),
  );

  const buttonRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('dev:main:back')
      .setLabel('Voltar')
      .setStyle(ButtonStyle.Secondary),
  );

  return painelV2FromEmbed(embed, [selectRow, buttonRow]);
}

function testesCreatePanel(guildId, aviso = null) {
  const d = guildData(guildId);
  const app = d.testConfig.appearance;
  const cfg = d.testConfig.config;

  const bannerValid = isValidHttpUrl(app.banner) ? app.banner : null;
  const thumbValid = isValidHttpUrl(app.thumbnail) ? app.thumbnail : null;

  const invitesDisplay = cfg.requiredInvites > 0
    ? `${cfg.requiredInvites} invites (Conta mín. ${cfg.minAccountAgeDays || 0} dias)`
    : 'Sem requisitos de invites';
  const durationDisplay = cfg.durationText || '24h';
  const limitsDisplay = `Geral: ${cfg.globalLimit > 0 ? cfg.globalLimit : 'Ilimitado'} | Por pessoa: ${cfg.perUserLimit || 1}`;

  let desc =
    'Configure os parâmetros de aparência e regras do teste antes de publicar.\n\n' +
    'Selecione uma opção no menu para editar ou clique em **Enviar** para publicar no canal escolhido.';
  if (aviso) {
    desc += `\n\n**Aviso:** ${aviso}`;
  }

  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle('CRIAR / CONFIGURAR TESTE')
    .setDescription(desc)
    .addFields([
      { name: 'Título do Teste', value: truncate(app.title, 80), inline: true },
      { name: 'Duração', value: durationDisplay, inline: true },
      { name: 'Invites Necessários', value: invitesDisplay, inline: false },
      { name: 'Limites de Resgate', value: limitsDisplay, inline: false },
      { name: 'Mídias', value: `Banner: ${bannerValid ? '✅ Sim' : '❌ Não'} | Thumb: ${thumbValid ? '✅ Sim' : '❌ Não'}`, inline: false },
    ]);

  const selectRow = new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId('dev:testes:create:select_section')
      .setPlaceholder('Selecione para editar...')
      .addOptions([
        {
          label: 'Aparência',
          value: 'appearance',
          description: 'Editar título, descrição, banner e thumbnail',
        },
        {
          label: 'Configurar',
          value: 'config',
          description: 'Configurar invites, duração e limites de resgate',
        },
      ]),
  );

  const buttonRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('dev:testes:menu')
      .setLabel('Voltar')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('dev:testes:send_prompt')
      .setLabel('Enviar')
      .setStyle(ButtonStyle.Success),
  );

  return painelV2FromEmbed(embed, [selectRow, buttonRow], {
    image: bannerValid || undefined,
    thumbnail: thumbValid || undefined,
  });
}

function testesAppearancePanel(guildId, aviso = null) {
  const d = guildData(guildId);
  const app = d.testConfig.appearance;
  const bannerValid = isValidHttpUrl(app.banner) ? app.banner : null;
  const thumbValid = isValidHttpUrl(app.thumbnail) ? app.thumbnail : null;

  let desc = 'Personalize as informações visuais do painel de teste grátis.';
  if (aviso) {
    desc += `\n\n**Aviso:** ${aviso}`;
  }

  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle('APARÊNCIA DO PAINEL DE TESTE')
    .setDescription(desc)
    .addFields([
      { name: 'Título', value: truncate(app.title, 1024) || 'Não definido', inline: false },
      { name: 'Descrição', value: truncate(app.description, 1024) || 'Não definida', inline: false },
      { name: 'Banner URL', value: bannerValid ? truncate(app.banner, 100) : 'Nenhum banner cadastrado', inline: true },
      { name: 'Thumbnail URL', value: thumbValid ? truncate(app.thumbnail, 100) : 'Nenhuma thumbnail cadastrada', inline: true },
    ]);

  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('dev:testes:appearance:title').setLabel('Título').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('dev:testes:appearance:description').setLabel('Descrição').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('dev:testes:appearance:banner').setLabel('Banner').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('dev:testes:appearance:thumbnail').setLabel('Thumbnail').setStyle(ButtonStyle.Secondary),
  );

  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('dev:testes:create:menu').setLabel('Voltar').setStyle(ButtonStyle.Secondary),
  );

  return painelV2FromEmbed(embed, [row1, row2], {
    image: bannerValid || undefined,
    thumbnail: thumbValid || undefined,
  });
}

function testesConfigPanel(guildId, aviso = null) {
  const d = guildData(guildId);
  const cfg = d.testConfig.config;

  const invitesDisplay = cfg.requiredInvites > 0
    ? `${cfg.requiredInvites} invite(s) (Conta com no mín. ${cfg.minAccountAgeDays || 0} dia(s))`
    : 'Sem verificação de invites (Livre)';
  const durationDisplay = cfg.durationText || '24h';
  const limitsDisplay = `Limite Geral: ${cfg.globalLimit > 0 ? `${cfg.globalLimit} resgates` : 'Ilimitado'} | Por Pessoa: ${cfg.perUserLimit || 1} resgate(s)`;

  let desc = 'Configure os critérios de validação de invites, tempo de teste e limites de resgate.';
  if (aviso) {
    desc += `\n\n**Aviso:** ${aviso}`;
  }

  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle('CONFIGURAÇÃO DE REGRAS DO TESTE')
    .setDescription(desc)
    .addFields([
      { name: 'Invites Necessários', value: invitesDisplay, inline: false },
      { name: 'Tempo de Duração', value: durationDisplay, inline: false },
      { name: 'Limite de Resgate', value: limitsDisplay, inline: false },
    ]);

  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('dev:testes:config:invites').setLabel('Invites necessários').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('dev:testes:config:duration').setLabel('Tempo de duração').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('dev:testes:config:limits').setLabel('Limite de resgate').setStyle(ButtonStyle.Secondary),
  );

  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('dev:testes:create:menu').setLabel('Voltar').setStyle(ButtonStyle.Secondary),
  );

  return painelV2FromEmbed(embed, [row1, row2]);
}

function testesSendPanel(guildId) {
  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle('PUBLICAR PAINEL DE TESTES')
    .setDescription(
      'Selecione o canal onde o painel público de testes deverá ser enviado.\n\n' +
      'Os usuários poderão clicar nos botões para verificar seus invites e resgatar o teste diretamente.'
    );

  const channelRow = new ActionRowBuilder().addComponents(
    new ChannelSelectMenuBuilder()
      .setCustomId('dev:testes:send_channel')
      .setPlaceholder('Selecione o canal de texto')
      .setChannelTypes([ChannelType.GuildText, ChannelType.GuildAnnouncement]),
  );

  const buttonRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('dev:testes:create:menu')
      .setLabel('Voltar')
      .setStyle(ButtonStyle.Secondary),
  );

  return painelV2FromEmbed(embed, [channelRow, buttonRow]);
}

function testesManagePanel(guildId, aviso = null) {
  const d = guildData(guildId);
  const tests = d.tests || [];

  let desc =
    'Gerencie os painéis de testes publicados no servidor.\n\n' +
    'Selecione um painel de teste no menu abaixo para **editar aparência/regras** ou **remover**:';
  if (aviso) {
    desc += `\n\n**Aviso:** ${aviso}`;
  }

  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle('GERENCIAR TESTES')
    .setDescription(desc);

  const components = [];

  if (tests.length === 0) {
    embed.addFields([{ name: 'Status', value: 'Nenhum painel de teste publicado no momento.', inline: false }]);
  } else {
    const options = tests.slice(0, 25).map((t, idx) => {
      const label = `${idx + 1}. ${truncate(t.appearance?.title || 'Painel de Teste', 40)}`;
      const descOption = `Canal: ${t.channelId} | ${t.claimsCount || 0} resgates`;
      return {
        label,
        value: t.id,
        description: descOption.slice(0, 50),
      };
    });

    const selectRow = new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId('dev:testes:manage:select')
        .setPlaceholder('Selecione um painel de teste para gerenciar...')
        .addOptions(options),
    );
    components.push(selectRow);
  }

  const buttonRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('dev:testes:menu')
      .setLabel('Voltar')
      .setStyle(ButtonStyle.Secondary),
  );
  components.push(buttonRow);

  return painelV2FromEmbed(embed, components);
}

function testesEditPanel(guildId, testItem, aviso = null) {
  const app = testItem.appearance || {};
  const cfg = testItem.config || {};

  const bannerValid = isValidHttpUrl(app.banner) ? app.banner : null;
  const thumbValid = isValidHttpUrl(app.thumbnail) ? app.thumbnail : null;

  const invitesDisplay = cfg.requiredInvites > 0
    ? `${cfg.requiredInvites} invites (Conta mín. ${cfg.minAccountAgeDays || 0} dias)`
    : 'Sem requisitos de invites';
  const durationDisplay = cfg.durationText || '24h';
  const limitsDisplay = `Geral: ${cfg.globalLimit > 0 ? cfg.globalLimit : 'Ilimitado'} | Por pessoa: ${cfg.perUserLimit || 1}`;

  let desc =
    `Gerenciando o painel de teste em <#${testItem.channelId}>.\n\n` +
    `• **Resgates efetuados:** ${testItem.claimsCount || 0}\n` +
    'Selecione uma opção no menu para editar as propriedades deste painel:';
  if (aviso) {
    desc += `\n\n**Aviso:** ${aviso}`;
  }

  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle(`EDITAR TESTE: ${truncate(app.title || 'Painel de Teste', 50)}`)
    .setDescription(desc)
    .addFields([
      { name: 'Título do Teste', value: truncate(app.title, 80) || 'Não definido', inline: true },
      { name: 'Duração', value: durationDisplay, inline: true },
      { name: 'Invites Necessários', value: invitesDisplay, inline: false },
      { name: 'Limites de Resgate', value: limitsDisplay, inline: false },
      { name: 'Mídias', value: `Banner: ${bannerValid ? '✅ Sim' : '❌ Não'} | Thumb: ${thumbValid ? '✅ Sim' : '❌ Não'}`, inline: false },
    ]);

  const selectRow = new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId(`dev:testes:edit:select_section:${testItem.id}`)
      .setPlaceholder('Selecione para editar...')
      .addOptions([
        {
          label: 'Aparência',
          value: 'appearance',
          description: 'Editar título, descrição, banner e thumbnail',
        },
        {
          label: 'Configurar',
          value: 'config',
          description: 'Configurar invites, duração e limites de resgate',
        },
      ]),
  );

  const buttonRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('dev:testes:manage:menu')
      .setLabel('Voltar')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(`dev:testes:edit:delete:${testItem.id}`)
      .setLabel('Excluir Teste')
      .setStyle(ButtonStyle.Danger),
  );

  return painelV2FromEmbed(embed, [selectRow, buttonRow], {
    image: bannerValid || undefined,
    thumbnail: thumbValid || undefined,
  });
}

function testesEditAppearancePanel(guildId, testItem, aviso = null) {
  const app = testItem.appearance || {};
  const bannerValid = isValidHttpUrl(app.banner) ? app.banner : null;
  const thumbValid = isValidHttpUrl(app.thumbnail) ? app.thumbnail : null;

  let desc = `Personalize as informações visuais deste painel de teste em <#${testItem.channelId}>.`;
  if (aviso) {
    desc += `\n\n**Aviso:** ${aviso}`;
  }

  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle('EDITAR APARÊNCIA DO TESTE')
    .setDescription(desc)
    .addFields([
      { name: 'Título', value: truncate(app.title, 1024) || 'Não definido', inline: false },
      { name: 'Descrição', value: truncate(app.description, 1024) || 'Não definida', inline: false },
      { name: 'Banner URL', value: bannerValid ? truncate(app.banner, 100) : 'Nenhum banner cadastrado', inline: true },
      { name: 'Thumbnail URL', value: thumbValid ? truncate(app.thumbnail, 100) : 'Nenhuma thumbnail cadastrada', inline: true },
    ]);

  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`dev:testes:edit:app:title:${testItem.id}`).setLabel('Título').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`dev:testes:edit:app:description:${testItem.id}`).setLabel('Descrição').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`dev:testes:edit:app:banner:${testItem.id}`).setLabel('Banner').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`dev:testes:edit:app:thumbnail:${testItem.id}`).setLabel('Thumbnail').setStyle(ButtonStyle.Secondary),
  );

  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`dev:testes:edit:open:${testItem.id}`).setLabel('Voltar').setStyle(ButtonStyle.Secondary),
  );

  return painelV2FromEmbed(embed, [row1, row2], {
    image: bannerValid || undefined,
    thumbnail: thumbValid || undefined,
  });
}

function testesEditConfigPanel(guildId, testItem, aviso = null) {
  const cfg = testItem.config || {};

  const invitesDisplay = cfg.requiredInvites > 0
    ? `${cfg.requiredInvites} invite(s) (Conta com no mín. ${cfg.minAccountAgeDays || 0} dia(s))`
    : 'Sem verificação de invites (Livre)';
  const durationDisplay = cfg.durationText || '24h';
  const limitsDisplay = `Limite Geral: ${cfg.globalLimit > 0 ? `${cfg.globalLimit} resgates` : 'Ilimitado'} | Por Pessoa: ${cfg.perUserLimit || 1} resgate(s)`;

  let desc = `Configure as regras e validações deste painel de teste em <#${testItem.channelId}>.`;
  if (aviso) {
    desc += `\n\n**Aviso:** ${aviso}`;
  }

  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle('EDITAR REGRAS DO TESTE')
    .setDescription(desc)
    .addFields([
      { name: 'Invites Necessários', value: invitesDisplay, inline: false },
      { name: 'Tempo de Duração', value: durationDisplay, inline: false },
      { name: 'Limite de Resgate', value: limitsDisplay, inline: false },
    ]);

  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`dev:testes:edit:cfg:invites:${testItem.id}`).setLabel('Invites necessários').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`dev:testes:edit:cfg:duration:${testItem.id}`).setLabel('Tempo de duração').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`dev:testes:edit:cfg:limits:${testItem.id}`).setLabel('Limite de resgate').setStyle(ButtonStyle.Secondary),
  );

  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`dev:testes:edit:open:${testItem.id}`).setLabel('Voltar').setStyle(ButtonStyle.Secondary),
  );

  return painelV2FromEmbed(embed, [row1, row2]);
}

function testesHistoryPanel(guildId) {
  const d = guildData(guildId);
  const claims = d.testClaims || [];

  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle('HISTÓRICO DE RESGATES DE TESTES')
    .setDescription(
      claims.length === 0
        ? 'Nenhum teste foi resgatado ainda neste servidor.'
        : `Total de **${claims.length}** resgate(s) registrado(s) no sistema:`
    );

  if (claims.length > 0) {
    const recent = claims.slice(-10).reverse();
    for (const c of recent) {
      const dataStr = c.claimedAt ? new Date(c.claimedAt).toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' }) : 'N/D';
      embed.addFields([
        {
          name: `👤 ${c.userTag || c.userId} • ${dataStr}`,
          value: `🔑 Licença: \`${c.licenseKey || 'N/A'}\`\n⏱️ Duração: **${c.durationText || 'N/A'}** | 👥 Invites: **${c.verifiedInvites || 0}**\n📌 Painel: **${truncate(c.testTitle || 'Teste Grátis', 40)}**`,
          inline: false,
        },
      ]);
    }
  }

  const buttonRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('dev:testes:menu')
      .setLabel('Voltar')
      .setStyle(ButtonStyle.Secondary),
  );

  return painelV2FromEmbed(embed, [buttonRow]);
}

// ── Painel Público de Testes ───────────────────────────────────────────────────

function publicTestPayload(guildId, testItem) {
  const app = testItem.appearance || {};
  const cfg = testItem.config || {};

  const bannerValid = isValidHttpUrl(app.banner) ? app.banner : null;
  const thumbValid = isValidHttpUrl(app.thumbnail) ? app.thumbnail : null;

  const reqText = cfg.requiredInvites > 0
    ? `${cfg.requiredInvites} invites válidos (Conta mín. ${cfg.minAccountAgeDays || 0} dias)`
    : 'Nenhum requisito (Resgate Livre)';
  const durationText = cfg.durationText || '24h';
  const limitsText = cfg.globalLimit > 0
    ? `${testItem.claimsCount || 0}/${cfg.globalLimit} vagas resgatadas`
    : `${testItem.claimsCount || 0} resgatados (Sem limite geral)`;

  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle(app.title || 'Teste Grátis')
    .setDescription(app.description || 'Resgate seu teste gratuito agora convidando amigos!')
    .addFields([
      { name: 'Requisitos de Invites', value: reqText, inline: true },
      { name: 'Duração do Teste', value: durationText, inline: true },
      { name: 'Vagas & Resgates', value: limitsText, inline: false },
    ]);

  if (app.footer) {
    embed.setFooter({ text: truncate(app.footer, 2048) });
  }

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`dev:testes:public:claim:${testItem.id}`)
      .setLabel('Resgatar Teste')
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(`dev:testes:public:invites:${testItem.id}`)
      .setLabel('Meus Invites')
      .setStyle(ButtonStyle.Secondary),
  );

  return painelV2FromEmbed(embed, [row], {
    image: bannerValid || undefined,
    thumbnail: thumbValid || undefined,
  });
}

async function sendOrEditPublicTestPanel(channel, guildId, testItem) {
  const payload = publicTestPayload(guildId, testItem);
  try {
    return await channel.send(payload);
  } catch (err) {
    console.warn('[DEV TESTES] Falha ao enviar com componentes V2 completos, tentando sem mídias:', err.message);
    const app = testItem.appearance || {};
    const cfg = testItem.config || {};
    const reqText = cfg.requiredInvites > 0
      ? `${cfg.requiredInvites} invites válidos (Conta mín. ${cfg.minAccountAgeDays || 0} dias)`
      : 'Nenhum requisito (Resgate Livre)';
    const durationText = cfg.durationText || '24h';
    const limitsText = cfg.globalLimit > 0
      ? `${testItem.claimsCount || 0}/${cfg.globalLimit} vagas resgatadas`
      : `${testItem.claimsCount || 0} resgatados (Sem limite geral)`;

    const embed = new EmbedBuilder()
      .setColor(color(guildId))
      .setTitle(app.title || 'Teste Grátis')
      .setDescription(app.description || 'Resgate seu teste gratuito agora convidando amigos!')
      .addFields([
        { name: 'Requisitos de Invites', value: reqText, inline: true },
        { name: 'Duração do Teste', value: durationText, inline: true },
        { name: 'Vagas & Resgates', value: limitsText, inline: false },
      ]);

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`dev:testes:public:claim:${testItem.id}`)
        .setLabel('Resgatar Teste')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId(`dev:testes:public:invites:${testItem.id}`)
        .setLabel('Meus Invites')
        .setStyle(ButtonStyle.Secondary),
    );
    return await channel.send(painelV2FromEmbed(embed, [row])).catch((err2) => {
      console.error('[DEV TESTES] Erro definitivo ao enviar no canal:', err2.message);
      return null;
    });
  }
}

// ── Painel Público da Loja ─────────────────────────────────────────────────────

function publicShopPayload(guildId) {
  const d = guildData(guildId);
  const app = d.appearance;

  const bannerValid = isValidHttpUrl(app.banner) ? app.banner : null;
  const thumbValid = isValidHttpUrl(app.thumbnail) ? app.thumbnail : null;

  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle(app.title || 'Loja Oficial')
    .setDescription(app.description || 'Adquira seu plano de acesso com ativação imediata.');

  if (app.footer) {
    embed.setFooter({ text: truncate(app.footer, 2048) });
  }

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('dev:loja:public:buy')
      .setLabel('Comprar')
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId('dev:loja:public:terms')
      .setLabel('Ler Termos')
      .setStyle(ButtonStyle.Secondary),
  );

  return painelV2FromEmbed(embed, [row], {
    image: bannerValid || undefined,
    thumbnail: thumbValid || undefined,
  });
}

function termsPayload(guildId) {
  const d = guildData(guildId);
  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle('TERMOS DE USO')
    .setDescription(d.config.terms || 'Nenhum termo de uso cadastrado.');

  return painelV2FromEmbed(embed, []);
}

async function sendOrEditPublicPanel(channel, guildId) {
  const payload = publicShopPayload(guildId);
  try {
    return await channel.send(payload);
  } catch (err) {
    console.warn('[DEV LOJA] Falha ao enviar com componentes V2 completos, tentando sem mídias:', err.message);
    const d = guildData(guildId);
    const embed = new EmbedBuilder()
      .setColor(color(guildId))
      .setTitle(d.appearance.title || 'Loja Oficial')
      .setDescription(d.appearance.description || 'Adquira seu plano de acesso com ativação imediata.');

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('dev:loja:public:buy').setLabel('Comprar').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId('dev:loja:public:terms').setLabel('Ler Termos').setStyle(ButtonStyle.Secondary),
    );
    return await channel.send(painelV2FromEmbed(embed, [row])).catch((err2) => {
      console.error('[DEV LOJA] Erro definitivo ao enviar no canal:', err2.message);
      return null;
    });
  }
}

// ── Auto-Refresh dos Painéis Públicos ──────────────────────────────────────────

async function refreshAllPublishedPanels(client, guildId = null) {
  if (!guildId) {
    for (const gId of Object.keys(state)) {
      await refreshAllPublishedPanels(client, gId).catch(() => {});
    }
    return;
  }
  const d = guildData(guildId);

  // 1. Refresh Shop Panels
  if (d.panels && d.panels.length > 0) {
    const payload = publicShopPayload(guildId);
    const remaining = [];

    for (const item of d.panels) {
      try {
        const channel = await client.channels.fetch(item.channelId).catch(() => null);
        if (!channel) {
          remaining.push(item);
          continue;
        }
        let msg = null;
        try {
          msg = await channel.messages.fetch(item.messageId);
        } catch (err) {
          if (err?.code === 10008) {
            continue; // Message deleted permanently
          }
          remaining.push(item);
          continue;
        }

        if (msg) {
          await msg.edit(payload).catch(async () => {
            const embed = new EmbedBuilder()
              .setColor(color(guildId))
              .setTitle(d.appearance.title || 'Loja Oficial')
              .setDescription(d.appearance.description || 'Adquira seu plano de acesso com ativação imediata.');
            const row = new ActionRowBuilder().addComponents(
              new ButtonBuilder().setCustomId('dev:loja:public:buy').setLabel('Comprar').setStyle(ButtonStyle.Success),
              new ButtonBuilder().setCustomId('dev:loja:public:terms').setLabel('Ler Termos').setStyle(ButtonStyle.Secondary),
            );
            await msg.edit(painelV2FromEmbed(embed, [row])).catch(() => {});
          });
        }
        remaining.push(item);
      } catch (_) {
        remaining.push(item);
      }
    }

    d.panels = remaining;
  }

  // 2. Refresh Test Panels
  if (d.tests && d.tests.length > 0) {
    const remainingTests = [];
    for (const testItem of d.tests) {
      try {
        const channel = await client.channels.fetch(testItem.channelId).catch(() => null);
        if (!channel) {
          remainingTests.push(testItem);
          continue;
        }
        let msg = null;
        try {
          msg = await channel.messages.fetch(testItem.messageId);
        } catch (err) {
          if (err?.code === 10008) {
            continue; // Message deleted
          }
          remainingTests.push(testItem);
          continue;
        }

        if (msg) {
          const testPayload = publicTestPayload(guildId, testItem);
          await msg.edit(testPayload).catch(() => {});
        }
        remainingTests.push(testItem);
      } catch (_) {
        remainingTests.push(testItem);
      }
    }
    d.tests = remainingTests;
  }

  saveData();
}

async function restorePanels(client, targetGuildId = null) {
  for (const guildId of Object.keys(state)) {
    if (targetGuildId && guildId !== targetGuildId) continue;
    try {
      refreshAllPublishedPanels(client, guildId).catch(() => {});
    } catch (_) {}
  }
}

// ── Painel de Confirmação no Canal / Tópico ────────────────────────────────────

function confirmationChannelPayload(guildId, purchase) {
  const priceDisplay = purchase.price > 0 ? `R$ ${purchase.price.toFixed(2)}` : 'Gratuito';
  const durationDisplay = purchase.durationDays > 0 ? `${purchase.durationDays} dias` : 'Vitalício';

  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle('CONFIRMAÇÃO DE COMPRA')
    .setDescription(
      `Olá <@${purchase.userId}>, você iniciou o processo para aquisição do plano do bot!\n\n` +
      `📋 **Informações do Pedido:**\n` +
      `• **Produto:** Acesso Premium ao Bot\n` +
      `• **Valor:** ${priceDisplay}\n` +
      `• **Duração:** ${durationDisplay}\n\n` +
      `Clique em **Confirmar** para gerar o QR Code Pix e os dados para pagamento, ou em **Cancelar** para encerrar o pedido.`
    );

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`dev:loja:topic:confirm:${purchase.id}`)
      .setLabel('Confirmar')
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(`dev:loja:topic:cancel:${purchase.id}`)
      .setLabel('Cancelar')
      .setStyle(ButtonStyle.Danger),
  );

  return painelV2FromEmbed(embed, [row]);
}

// ── Painel de Pagamento com QR Code ────────────────────────────────────────────

async function purchasePaymentPayload(guildId, purchase) {
  const priceDisplay = purchase.price > 0 ? `R$ ${purchase.price.toFixed(2)}` : 'Gratuito';
  const durationDisplay = purchase.durationDays > 0 ? `${purchase.durationDays} dias` : 'Vitalício';

  let qrBuffer = null;
  if (purchase.qrCodeBase64) {
    try {
      qrBuffer = Buffer.from(purchase.qrCodeBase64, 'base64');
    } catch (_) {}
  }
  if (!qrBuffer && purchase.pixCode) {
    try {
      qrBuffer = await QRCode.toBuffer(purchase.pixCode, { width: 360, margin: 2, errorCorrectionLevel: 'M' });
    } catch (_) {}
  }
  if (!qrBuffer) {
    try {
      qrBuffer = await QRCode.toBuffer(`PIX-RYZE-${purchase.id}`, { width: 360, margin: 2, errorCorrectionLevel: 'M' });
    } catch (_) {}
  }

  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle('PAGAMENTO PIX')
    .setDescription(
      `Olá <@${purchase.userId}>, seu pagamento Pix foi gerado com sucesso!\n\n` +
      `📋 **Informações da Compra:**\n` +
      `• **Produto:** Plano de Acesso ao Bot\n` +
      `• **Valor:** ${priceDisplay}\n` +
      `• **Duração:** ${durationDisplay}\n` +
      `• **Status:** ⏳ Aguardando Pagamento (Detecção Automática)\n\n` +
      `📸 **QR Code Pix:** Escaneie o QR Code abaixo com o aplicativo do seu banco.\n` +
      `📋 **Copia e Cola:** Clique no botão abaixo para copiar o código Pix.`
    );

  const files = [];
  if (qrBuffer) {
    const attachment = new AttachmentBuilder(qrBuffer, { name: 'qrcode.png' });
    files.push(attachment);
    embed.setImage('attachment://qrcode.png');
  }

  const buttons = [
    new ButtonBuilder()
      .setCustomId(`dev:loja:topic:copypix:${purchase.id}`)
      .setLabel('Copia e cola')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId(`dev:loja:topic:cancel:${purchase.id}`)
      .setLabel('Cancelar')
      .setStyle(ButtonStyle.Danger),
  ];

  const row = new ActionRowBuilder().addComponents(buttons);
  return painelV2FromEmbed(embed, [row], { files, image: 'attachment://qrcode.png' });
}

// ── Painel de Compra Concluída no Tópico ───────────────────────────────────────

function purchaseApprovedChannelPayload(guildId, purchase) {
  const delivered = purchase.deliveredBot;
  const botName = delivered?.tag || 'Bot Exclusivo';
  const inviteUrl = delivered?.inviteUrl || getBotInviteUrl(delivered?.botId);

  const embed = new EmbedBuilder()
    .setColor(0x57f287)
    .setTitle('PAGAMENTO APROVADO & BOT ENTREGUE')
    .setDescription(
      `Olá <@${purchase.userId}>, seu pagamento foi confirmado pelo sistema!\n\n` +
      `✅ **Status:** Aprovado e Entregue\n` +
      `🤖 **Bot Vinculado:** **${botName}**\n` +
      (delivered?.botId ? `🆔 **ID da Aplicação:** \`${delivered.botId}\`\n` : '') +
      `🔑 **Chave de Licença:** \`${purchase.licenseKey}\`\n\n` +
      `📩 **Dados de Acesso Enviados na sua DM!**\n` +
      `Enviamos uma mensagem privada na sua DM com o **link de convite**, os dados de acesso e o botão para ativar no seu servidor.`
    );

  const row = new ActionRowBuilder();
  if (inviteUrl) {
    row.addComponents(
      new ButtonBuilder()
        .setLabel('Convidar bot')
        .setStyle(ButtonStyle.Link)
        .setURL(inviteUrl),
    );
  }
  row.addComponents(
    new ButtonBuilder()
      .setCustomId(`dev:loja:topic:close:${purchase.id}`)
      .setLabel('Fechar Tópico')
      .setStyle(ButtonStyle.Secondary),
  );

  return painelV2FromEmbed(embed, [row]);
}

// ── Painel de Entrega na DM do Comprador ───────────────────────────────────────

function dmDeliveryPayload(client, purchase) {
  const delivered = purchase.deliveredBot;
  const botId = delivered?.botId || client?.user?.id || '';
  const inviteUrl = delivered?.inviteUrl || getBotInviteUrl(botId);
  const durationDisplay = purchase.durationDays > 0 ? `${purchase.durationDays} dias` : 'Vitalício';
  const botName = delivered?.tag || client?.user?.tag || client?.user?.username || 'Bot Discord Oficial';

  const embed = new EmbedBuilder()
    .setColor(0x57f287)
    .setTitle('🎉 ACESSO LIBERADO COM SUCESSO!')
    .setDescription(
      `Olá <@${purchase.userId}>, seu pagamento foi aprovado e seu acesso foi liberado para você!\n\n` +
      `📦 **Informações da Compra:**\n` +
      `• **Bot:** **${botName}**\n` +
      `• **Duração do Plano:** ${durationDisplay}\n` +
      `• **Valor:** R$ ${Number(purchase.price || 0).toFixed(2)}\n` +
      `• **Chave de Licença:** \`${purchase.licenseKey}\`\n\n` +
      (delivered?.token ? `🔐 **Token de Acesso:**\n\`\`\`${delivered.token}\`\`\`\n` : '') +
      `📌 **Instruções para Ativação:**\n` +
      `1️⃣ Clique no botão **Convidar bot** abaixo para adicionar o bot ao seu servidor.\n` +
      `2️⃣ Após o bot entrar no seu servidor, clique no botão **Resgatar plano** e digite o ID do servidor para ativar o período contratado.`
    );

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setLabel('Convidar bot')
      .setStyle(ButtonStyle.Link)
      .setURL(inviteUrl),
    new ButtonBuilder()
      .setCustomId(`dev:loja:dm:redeem:${purchase.id}`)
      .setLabel('Resgatar plano')
      .setStyle(ButtonStyle.Success),
  );

  return painelV2FromEmbed(embed, [row]);
}

// ── Modal de Resgate de Plano ──────────────────────────────────────────────────

function redeemModal(purchaseId) {
  const modal = new ModalBuilder()
    .setCustomId(`dev:loja:dm:redeem_modal:${purchaseId}`)
    .setTitle('Resgatar Plano no Servidor');

  const input = new TextInputBuilder()
    .setCustomId('target_guild_id')
    .setLabel('ID do Servidor Discord')
    .setPlaceholder('Ex: 123456789012345678')
    .setStyle(TextInputStyle.Short)
    .setMinLength(16)
    .setMaxLength(25)
    .setRequired(true);

  modal.addComponents(new ActionRowBuilder().addComponents(input));
  return modal;
}

// ── Painel de Entrega Ephemeral de Teste Grátis ──────────────────────────────────

function testClaimEphemeralPayload(client, claimRecord, testItem = null) {
  const botId = client?.user?.id || '';
  const inviteUrl = getBotInviteUrl(botId);
  const botName = client?.user?.tag || client?.user?.username || 'Bot Discord Oficial';
  const durationDisplay = claimRecord.durationText || '24h';

  const embed = new EmbedBuilder()
    .setColor(0x57f287)
    .setTitle('🎉 TESTE GRÁTIS LIBERADO COM SUCESSO!')
    .setDescription(
      `Olá <@${claimRecord.userId}>, seus requisitos de teste foram validados e seu acesso de avaliação foi gerado com sucesso!\n\n` +
      `📦 **Informações do Teste Grátis:**\n` +
      `• **Bot:** **${botName}**\n` +
      `• **Duração do Teste:** ${durationDisplay}\n` +
      `• **Valor:** Gratuito (Versão de Teste)\n` +
      `• **Invites Validados:** ${claimRecord.verifiedInvites || 0}\n` +
      `• **Chave de Licença:** \`${claimRecord.licenseKey}\`\n\n` +
      `📌 **Instruções para Ativação:**\n` +
      `1️⃣ Clique no botão **Convidar bot** abaixo para adicionar o bot ao seu servidor.\n` +
      `2️⃣ Após o bot entrar no seu servidor, clique no botão **Resgatar teste** e digite o ID do servidor para ativar o período gratuito.`
    );

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setLabel('Convidar bot')
      .setStyle(ButtonStyle.Link)
      .setURL(inviteUrl),
    new ButtonBuilder()
      .setCustomId(`dev:testes:ephemeral:redeem:${claimRecord.id}`)
      .setLabel('Resgatar teste')
      .setStyle(ButtonStyle.Success),
  );

  return painelV2FromEmbed(embed, [row]);
}

function testRedeemModal(claimId) {
  const modal = new ModalBuilder()
    .setCustomId(`dev:testes:ephemeral:redeem_modal:${claimId}`)
    .setTitle('Resgatar Teste no Servidor');

  const input = new TextInputBuilder()
    .setCustomId('target_guild_id')
    .setLabel('ID do Servidor Discord')
    .setPlaceholder('Ex: 123456789012345678')
    .setStyle(TextInputStyle.Short)
    .setMinLength(16)
    .setMaxLength(25)
    .setRequired(true);

  modal.addComponents(new ActionRowBuilder().addComponents(input));
  return modal;
}

// ── Iniciar e Gerenciar Pedido de Compra ───────────────────────────────────────

async function handleStartPurchase(interaction, client) {
  const guildId = interaction.guildId;
  const d = guildData(guildId);
  const userId = interaction.user.id;

  // Verificar se já tem pedido aberto em andamento
  const existing = d.purchases.find((p) => p.userId === userId && (p.status === 'unconfirmed' || p.status === 'pending') && p.channelId);
  if (existing) {
    const ch = await interaction.guild.channels.fetch(existing.channelId).catch(() => null);
    if (ch) {
      await interaction.reply({
        content: `Você já possui um atendimento de compra aberto em <#${ch.id}>. Conclua ou cancele o pedido anterior.`,
        flags: MessageFlags.Ephemeral,
      });
      return;
    }
  }

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  const price = d.config.price;
  const durationDays = d.config.durationDays;
  const purchaseId = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

  // Criar canal/tópico de compra
  const cfg = getConfig(guildId);
  let channel = null;
  const channelName = `compra-${interaction.user.username.toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 20)}`;

  let hostChannel = interaction.channel;
  if (d.config.topicsChannelId) {
    const fetched = await interaction.guild.channels.fetch(d.config.topicsChannelId).catch(() => null);
    if (fetched && fetched.isTextBased()) {
      hostChannel = fetched;
    }
  }

  try {
    if (hostChannel?.threads) {
      channel = await hostChannel.threads.create({
        name: channelName,
        type: ChannelType.PrivateThread,
        autoArchiveDuration: 1440,
        reason: `Pedido de compra aberto por ${interaction.user.tag}`,
      });
      await channel.members.add(userId).catch(() => {});
    } else {
      channel = await interaction.guild.channels.create({
        name: channelName,
        type: ChannelType.GuildText,
        parent: hostChannel?.parentId || cfg.channels?.lojaTopicos || null,
        permissionOverwrites: [
          {
            id: interaction.guild.roles.everyone.id,
            deny: [PermissionFlagsBits.ViewChannel],
          },
          {
            id: userId,
            allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
          },
          {
            id: client.user.id,
            allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageChannels, PermissionFlagsBits.EmbedLinks],
          },
        ],
      });
    }
  } catch (err) {
    console.error('[DEV LOJA] Falha ao criar canal de compra:', err.message);
    await interaction.editReply({
      content: 'Não foi possível criar o canal de atendimento. Verifique as permissões de Gerenciar Canais do bot.',
    });
    return;
  }

  const purchaseRecord = {
    id: purchaseId,
    guildId,
    userId,
    channelId: channel.id,
    price,
    durationDays,
    status: 'unconfirmed',
    paymentId: null,
    pixCode: '',
    qrCodeBase64: '',
    licenseKey: `LIC-${Math.random().toString(36).substring(2, 7).toUpperCase()}-${Math.random().toString(36).substring(2, 7).toUpperCase()}`,
    createdAt: new Date().toISOString(),
  };

  d.purchases.push(purchaseRecord);
  saveData();

  // Enviar painel de confirmação inicial
  const msg = await channel.send(confirmationChannelPayload(guildId, purchaseRecord));
  purchaseRecord.messageId = msg.id;
  saveData();

  await interaction.editReply({
    content: `Seu canal de atendimento foi criado com sucesso: <#${channel.id}>`,
  });
}

function startPaymentWatcher(client, guildId, purchaseId) {
  if (activeChecks.has(purchaseId)) return;

  const timer = setInterval(async () => {
    const d = guildData(guildId);
    const purchase = d.purchases.find((p) => p.id === purchaseId);
    if (!purchase || purchase.status !== 'pending' || !purchase.paymentId) {
      clearInterval(timer);
      activeChecks.delete(purchaseId);
      return;
    }

    const token = d.config.mercadoPagoToken;
    if (!token) return;

    try {
      const check = await checkPixPayment(token, purchase.paymentId);
      if (check.ok && check.approved) {
        clearInterval(timer);
        activeChecks.delete(purchaseId);
        await completePurchase(client, guildId, purchaseId);
      }
    } catch (_) {}
  }, 10000);

  activeChecks.set(purchaseId, timer);
  setTimeout(() => {
    if (activeChecks.has(purchaseId)) {
      clearInterval(activeChecks.get(purchaseId));
      activeChecks.delete(purchaseId);
    }
  }, 30 * 60 * 1000);
}

async function completePurchase(client, guildId, purchaseId) {
  const d = guildData(guildId);
  const purchase = d.purchases.find((p) => p.id === purchaseId);
  if (!purchase || purchase.status === 'approved') return;

  // Se houver bot adicional em managedBots, pode utilizá-lo, caso contrário entrega o bot principal
  let deliveredBot = null;
  if (Array.isArray(d.managedBots) && d.managedBots.length > 0) {
    const rawBot = d.managedBots.shift();
    const botId = rawBot.botId || getBotIdFromToken(rawBot.token) || client?.user?.id || '';
    const inviteUrl = getBotInviteUrl(botId);

    deliveredBot = {
      id: rawBot.id,
      token: rawBot.token,
      tag: rawBot.tag || 'Bot Discord',
      botId: botId,
      inviteUrl: inviteUrl,
      deliveredAt: new Date().toISOString(),
    };
    purchase.deliveredBot = deliveredBot;
  } else if (!purchase.deliveredBot) {
    const botId = client?.user?.id || client?.application?.id || '';
    purchase.deliveredBot = {
      id: 'principal',
      token: null,
      tag: client?.user?.tag || client?.user?.username || 'Bot Oficial',
      botId: botId,
      inviteUrl: getBotInviteUrl(botId),
      deliveredAt: new Date().toISOString(),
    };
  }

  purchase.status = 'approved';
  purchase.approvedAt = new Date().toISOString();
  saveData();

  // Atualizar painel no canal/tópico de compra
  const channel = await client.channels.fetch(purchase.channelId).catch(() => null);
  if (channel) {
    const approvedPayload = purchaseApprovedChannelPayload(guildId, purchase);
    if (purchase.messageId) {
      const msg = await channel.messages.fetch(purchase.messageId).catch(() => null);
      if (msg) await msg.edit(approvedPayload).catch(() => {});
    } else {
      await channel.send(approvedPayload).catch(() => {});
    }
  }

  // Enviar painel de entrega na DM do comprador com os botões Convidar Bot e Resgatar Plano
  try {
    const user = await client.users.fetch(purchase.userId).catch(() => null);
    if (user) {
      const dmPayload = dmDeliveryPayload(client, purchase);
      await user.send(dmPayload).catch(() => {});
    }
  } catch (err) {
    console.error('[DEV LOJA] Erro ao enviar DM para o comprador:', err.message);
  }
}

// ── Helper de Resposta a Modais ────────────────────────────────────────────────
async function safeAckModal(interaction, payload) {
  try {
    await interaction.update(payload);
  } catch (err) {
    if (!interaction.replied && !interaction.deferred) {
      await interaction.reply({
        ...payload,
        flags: (payload.flags || MessageFlags.IsComponentsV2) | MessageFlags.Ephemeral,
      }).catch(() => {});
    }
  }
}

// ── Roteador de Interações do Dev Central ───────────────────────────────────────

async function handleDevCentral(interaction, client) {
  const id = interaction.customId || '';

  // ── Interações de DM / Resgate de Plano (Sem necessidade de guildId na interação) ──

  if (interaction.isButton() && id.startsWith('dev:loja:dm:redeem:')) {
    const purchaseId = id.replace('dev:loja:dm:redeem:', '');
    const { purchase } = findPurchaseById(purchaseId);

    if (!purchase) {
      await interaction.reply({
        content: 'Pedido de compra não localizado no sistema.',
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    if (purchase.redeemed) {
      await interaction.reply({
        content: `Este plano já foi resgatado e ativado no servidor **${purchase.redeemedGuildName || purchase.redeemedGuildId}** (\`${purchase.redeemedGuildId}\`).`,
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    await interaction.showModal(redeemModal(purchase.id));
    return true;
  }

  if (interaction.isModalSubmit() && id.startsWith('dev:loja:dm:redeem_modal:')) {
    const purchaseId = id.replace('dev:loja:dm:redeem_modal:', '');
    const { purchase, guildId: sourceGuildId } = findPurchaseById(purchaseId);

    if (!purchase) {
      await interaction.reply({
        content: 'Pedido de compra não localizado no sistema.',
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    if (purchase.redeemed) {
      await interaction.reply({
        content: `Este plano já foi resgatado anteriormente no servidor **${purchase.redeemedGuildName || purchase.redeemedGuildId}**.`,
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    const targetGuildId = interaction.fields.getTextInputValue('target_guild_id').trim();

    if (!/^\d{16,25}$/.test(targetGuildId)) {
      await interaction.reply({
        content: '❌ **ID de servidor inválido!** Certifique-se de digitar apenas os números do ID do servidor (17 a 22 dígitos).',
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    // Verificar se o bot está presente no servidor informado
    const targetGuild = await client.guilds.fetch(targetGuildId).catch(() => null);

    if (!targetGuild) {
      await interaction.reply({
        content:
          `❌ **O bot não está presente no servidor informado (\`${targetGuildId}\`)!**\n\n` +
          `O bot só consegue ativar o plano caso ele já tenha sido adicionado ao servidor.\n\n` +
          `👉 Clique no botão **Convidar bot** na mensagem da sua DM para adicionar o bot ao servidor primeiro, e em seguida tente resgatar o plano novamente.`,
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    // Ativar o plano no servidor de destino
    const durationDays = Number(purchase.durationDays) || 0;
    const expiresAt = durationDays > 0 ? new Date(Date.now() + durationDays * 86400000).toISOString() : null;

    purchase.redeemed = true;
    purchase.redeemedGuildId = targetGuild.id;
    purchase.redeemedGuildName = targetGuild.name;
    purchase.redeemedAt = new Date().toISOString();
    purchase.expiresAt = expiresAt;
    saveData();

    try {
      updateConfig(targetGuild.id, {
        plan: {
          active: true,
          status: 'active',
          planType: durationDays > 0 ? `${durationDays} dias` : 'vitalicio',
          durationDays,
          activatedAt: new Date().toISOString(),
          expiresAt,
          purchaseId: purchase.id,
          buyerId: interaction.user.id,
          licenseKey: purchase.licenseKey,
        },
      });
    } catch (err) {
      console.error('[DEV LOJA] Erro ao salvar plano na config do servidor:', err.message);
    }

    const duracaoTexto = durationDays > 0 ? `${durationDays} dias` : 'Vitalício';
    const validadeTexto = expiresAt ? new Date(expiresAt).toLocaleDateString('pt-BR') : 'Permanente / Vitalício';

    await interaction.reply({
      content:
        `✅ **Plano Ativado com Sucesso!**\n\n` +
        `O seu plano foi ativado no seguinte servidor:\n` +
        `🏰 **Servidor:** ${targetGuild.name} (\`${targetGuild.id}\`)\n` +
        `⏱️ **Duração:** ${duracaoTexto}\n` +
        `📅 **Validade:** ${validadeTexto}\n` +
        `🔑 **Chave de Licença:** \`${purchase.licenseKey}\`\n\n` +
        `Todos os recursos do bot já estão liberados e prontos para uso no seu servidor!`,
      flags: MessageFlags.Ephemeral,
    });
    return true;
  }

  // ── Interações de Resgate de Teste Grátis no Servidor (Ephemeral) ─────────────

  if (interaction.isButton() && id.startsWith('dev:testes:ephemeral:redeem:')) {
    const claimId = id.replace('dev:testes:ephemeral:redeem:', '');
    const { claim } = findTestClaimById(claimId);

    if (!claim) {
      await interaction.reply({
        content: 'Registro de teste gratuito não localizado no sistema.',
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    if (claim.redeemed) {
      await interaction.reply({
        content: `Este teste gratuito já foi resgatado e ativado no servidor **${claim.redeemedGuildName || claim.redeemedGuildId}** (\`${claim.redeemedGuildId}\`).`,
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    await interaction.showModal(testRedeemModal(claim.id));
    return true;
  }

  if (interaction.isModalSubmit() && id.startsWith('dev:testes:ephemeral:redeem_modal:')) {
    const claimId = id.replace('dev:testes:ephemeral:redeem_modal:', '');
    const { claim } = findTestClaimById(claimId);

    if (!claim) {
      await interaction.reply({
        content: 'Registro de teste gratuito não localizado no sistema.',
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    if (claim.redeemed) {
      await interaction.reply({
        content: `Este teste já foi ativado anteriormente no servidor **${claim.redeemedGuildName || claim.redeemedGuildId}**.`,
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    const targetGuildId = interaction.fields.getTextInputValue('target_guild_id').trim();

    if (!/^\d{16,25}$/.test(targetGuildId)) {
      await interaction.reply({
        content: '❌ **ID de servidor inválido!** Certifique-se de digitar apenas os números do ID do servidor (17 a 22 dígitos).',
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    const targetGuild = await client.guilds.fetch(targetGuildId).catch(() => null);

    if (!targetGuild) {
      await interaction.reply({
        content:
          `❌ **O bot não está presente no servidor informado (\`${targetGuildId}\`)!**\n\n` +
          `O bot só consegue ativar o teste caso ele já tenha sido adicionado ao servidor.\n\n` +
          `👉 Clique no botão **Convidar bot** no painel para adicionar o bot ao servidor primeiro, e em seguida clique em **Resgatar teste** novamente.`,
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    // Converter duração do teste para cálculo de expiração se aplicável
    const durRaw = String(claim.durationText || '24h').toLowerCase().trim();
    let durationMs = 24 * 3600000;
    if (durRaw.includes('dia') || durRaw.includes('d')) {
      const match = durRaw.match(/\d+/);
      const days = match ? parseInt(match[0], 10) : 1;
      durationMs = days * 86400000;
    } else if (durRaw.includes('h') || durRaw.includes('hora')) {
      const match = durRaw.match(/\d+/);
      const hours = match ? parseInt(match[0], 10) : 24;
      durationMs = hours * 3600000;
    }

    const expiresAt = new Date(Date.now() + durationMs).toISOString();

    claim.redeemed = true;
    claim.redeemedGuildId = targetGuild.id;
    claim.redeemedGuildName = targetGuild.name;
    claim.redeemedAt = new Date().toISOString();
    claim.expiresAt = expiresAt;
    saveData();

    try {
      updateConfig(targetGuild.id, {
        plan: {
          active: true,
          status: 'active',
          planType: `Teste (${claim.durationText || '24h'})`,
          durationDays: Math.ceil(durationMs / 86400000),
          activatedAt: new Date().toISOString(),
          expiresAt,
          claimId: claim.id,
          buyerId: interaction.user.id,
          licenseKey: claim.licenseKey,
        },
      });
    } catch (err) {
      console.error('[DEV TESTES] Erro ao salvar teste na config do servidor:', err.message);
    }

    await interaction.reply({
      content:
        `✅ **Teste Grátis Ativado com Sucesso!**\n\n` +
        `O período de teste do bot foi ativado no seguinte servidor:\n` +
        `🏰 **Servidor:** ${targetGuild.name} (\`${targetGuild.id}\`)\n` +
        `⏱️ **Duração do Teste:** ${claim.durationText || '24h'}\n` +
        `📅 **Válido até:** ${new Date(expiresAt).toLocaleString('pt-BR')}\n` +
        `🔑 **Chave de Licença:** \`${claim.licenseKey}\`\n\n` +
        `Todos os comandos e funcionalidades do bot já estão liberados para uso no servidor!`,
      flags: MessageFlags.Ephemeral,
    });
    return true;
  }

  const guildId = interaction.guildId;
  if (!guildId) return false;

  // Interações que exigem permissão de administrador
  const isAdminAction =
    (id.startsWith('dev:loja:') || id.startsWith('dev:bots:') || id.startsWith('dev:buttons:') || id.startsWith('dev:testes:')) &&
    !id.startsWith('dev:loja:public:') &&
    !id.startsWith('dev:loja:topic:') &&
    !id.startsWith('dev:testes:public:');
  if (isAdminAction || id === 'dev:main:back') {
    if (!isDevAdmin(interaction.member)) {
      await interaction.reply({
        content: 'Apenas administradores podem gerenciar a Central de Desenvolvedor e a Loja.',
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }
  }

  // ── Módulo Config Testes ───────────────────────────────────────────────────

  // 1. Abertura do menu de Config Testes
  if (interaction.isButton() && id === 'dev:testes:menu') {
    await interaction.update(testesMenuPanel(guildId));
    return true;
  }

  // 2. Select menu da central de testes (Criar teste / Gerenciar testes / Histórico de resgates)
  if (interaction.isStringSelectMenu() && id === 'dev:testes:select_action') {
    const val = interaction.values[0];
    if (val === 'criar') {
      await interaction.update(testesCreatePanel(guildId));
      return true;
    }
    if (val === 'gerenciar') {
      await interaction.update(testesManagePanel(guildId));
      return true;
    }
    if (val === 'historico') {
      await interaction.update(testesHistoryPanel(guildId));
      return true;
    }
    return true;
  }

  // 3. Voltar para o painel de Criar Teste
  if (interaction.isButton() && id === 'dev:testes:create:menu') {
    await interaction.update(testesCreatePanel(guildId));
    return true;
  }

  // 4. Select menu do painel Criar Teste (Aparência / Configurar)
  if (interaction.isStringSelectMenu() && id === 'dev:testes:create:select_section') {
    const val = interaction.values[0];
    if (val === 'appearance') {
      await interaction.update(testesAppearancePanel(guildId));
      return true;
    }
    if (val === 'config') {
      await interaction.update(testesConfigPanel(guildId));
      return true;
    }
    return true;
  }

  // 5. Botão "Enviar" no painel de Criar Teste
  if (interaction.isButton() && id === 'dev:testes:send_prompt') {
    await interaction.update(testesSendPanel(guildId));
    return true;
  }

  // 6. Seleção de canal para enviar painel público de teste
  if (interaction.isChannelSelectMenu() && id === 'dev:testes:send_channel') {
    await interaction.deferUpdate();
    const targetChannelId = interaction.values[0];
    const channel = await interaction.guild.channels.fetch(targetChannelId).catch(() => null);

    if (!channel || !channel.isTextBased()) {
      await interaction.editReply(testesCreatePanel(guildId, 'Canal inválido ou sem permissão para envio.'));
      return true;
    }

    const d = guildData(guildId);
    const testItem = {
      id: `test_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      channelId: channel.id,
      messageId: null,
      createdAt: new Date().toISOString(),
      claimsCount: 0,
      appearance: { ...d.testConfig.appearance },
      config: { ...d.testConfig.config },
    };

    const sentMsg = await sendOrEditPublicTestPanel(channel, guildId, testItem);

    if (!sentMsg) {
      await interaction.editReply(
        testesCreatePanel(
          guildId,
          'Não foi possível enviar a mensagem no canal selecionado. Verifique as permissões do bot (Ver Canal, Enviar Mensagens, Inserir Links).'
        )
      );
      return true;
    }

    testItem.messageId = sentMsg.id;
    d.tests.push(testItem);
    saveData();

    await interaction.editReply(
      testesCreatePanel(guildId, `Painel público de testes publicado com sucesso em <#${channel.id}>!`)
    );
    return true;
  }

  // 7. Botões da Aparência do Teste (Título, Descrição, Banner, Thumbnail)
  if (interaction.isButton() && id === 'dev:testes:appearance:title') {
    const current = guildData(guildId).testConfig.appearance.title;
    await interaction.showModal(
      singleTextModal('dev:testes:appearance:modal:title', 'Título do Painel de Testes', 'Título', current, TextInputStyle.Short, 256)
    );
    return true;
  }

  if (interaction.isButton() && id === 'dev:testes:appearance:description') {
    const current = guildData(guildId).testConfig.appearance.description;
    await interaction.showModal(
      singleTextModal('dev:testes:appearance:modal:description', 'Descrição do Teste', 'Descrição', current, TextInputStyle.Paragraph, 2000)
    );
    return true;
  }

  if (interaction.isButton() && id === 'dev:testes:appearance:banner') {
    const current = guildData(guildId).testConfig.appearance.banner;
    await interaction.showModal(
      singleTextModal('dev:testes:appearance:modal:banner', 'Banner do Painel', 'URL do Banner (https://...)', current, TextInputStyle.Short, 1000)
    );
    return true;
  }

  if (interaction.isButton() && id === 'dev:testes:appearance:thumbnail') {
    const current = guildData(guildId).testConfig.appearance.thumbnail;
    await interaction.showModal(
      singleTextModal('dev:testes:appearance:modal:thumbnail', 'Thumbnail do Painel', 'URL da Thumbnail (https://...)', current, TextInputStyle.Short, 1000)
    );
    return true;
  }

  // 8. Modais da Aparência do Teste
  if (interaction.isModalSubmit() && id === 'dev:testes:appearance:modal:title') {
    const val = interaction.fields.getTextInputValue('value').trim();
    guildData(guildId).testConfig.appearance.title = val || 'Teste Grátis - Acesso VIP';
    saveData();
    refreshAllPublishedPanels(client, guildId).catch(() => {});
    await safeAckModal(interaction, testesAppearancePanel(guildId));
    return true;
  }

  if (interaction.isModalSubmit() && id === 'dev:testes:appearance:modal:description') {
    const val = interaction.fields.getTextInputValue('value').trim();
    guildData(guildId).testConfig.appearance.description = val || 'Resgate seu teste gratuito convidando amigos para o servidor!';
    saveData();
    refreshAllPublishedPanels(client, guildId).catch(() => {});
    await safeAckModal(interaction, testesAppearancePanel(guildId));
    return true;
  }

  if (interaction.isModalSubmit() && id === 'dev:testes:appearance:modal:banner') {
    const val = interaction.fields.getTextInputValue('value').trim();
    guildData(guildId).testConfig.appearance.banner = isValidHttpUrl(val) ? val : null;
    saveData();
    refreshAllPublishedPanels(client, guildId).catch(() => {});
    await safeAckModal(interaction, testesAppearancePanel(guildId));
    return true;
  }

  if (interaction.isModalSubmit() && id === 'dev:testes:appearance:modal:thumbnail') {
    const val = interaction.fields.getTextInputValue('value').trim();
    guildData(guildId).testConfig.appearance.thumbnail = isValidHttpUrl(val) ? val : null;
    saveData();
    refreshAllPublishedPanels(client, guildId).catch(() => {});
    await safeAckModal(interaction, testesAppearancePanel(guildId));
    return true;
  }

  // 9. Botões de Configurar Regras do Teste (Invites necessários, Duração, Limite de resgate)
  if (interaction.isButton() && id === 'dev:testes:config:invites') {
    const cfg = guildData(guildId).testConfig.config;
    await interaction.showModal(testesInvitesModal(cfg.requiredInvites, cfg.minAccountAgeDays));
    return true;
  }

  if (interaction.isButton() && id === 'dev:testes:config:duration') {
    const cfg = guildData(guildId).testConfig.config;
    await interaction.showModal(testesDurationModal(cfg.durationText));
    return true;
  }

  if (interaction.isButton() && id === 'dev:testes:config:limits') {
    const cfg = guildData(guildId).testConfig.config;
    await interaction.showModal(testesLimitsModal(cfg.globalLimit, cfg.perUserLimit));
    return true;
  }

  // 10. Modais de Configurar Regras do Teste
  if (interaction.isModalSubmit() && id === 'dev:testes:config:modal:invites') {
    const invRaw = interaction.fields.getTextInputValue('invites_count').trim();
    const ageRaw = interaction.fields.getTextInputValue('min_age_days').trim();
    const invCount = parseInt(invRaw, 10);
    const ageDays = parseInt(ageRaw, 10);

    const cfg = guildData(guildId).testConfig.config;
    cfg.requiredInvites = isNaN(invCount) || invCount < 0 ? 0 : invCount;
    cfg.minAccountAgeDays = isNaN(ageDays) || ageDays < 0 ? 0 : ageDays;

    saveData();
    refreshAllPublishedPanels(client, guildId).catch(() => {});
    await safeAckModal(interaction, testesConfigPanel(guildId));
    return true;
  }

  if (interaction.isModalSubmit() && id === 'dev:testes:config:modal:duration') {
    const durVal = interaction.fields.getTextInputValue('duration_text').trim();
    const cfg = guildData(guildId).testConfig.config;
    cfg.durationText = durVal || '24h';

    saveData();
    refreshAllPublishedPanels(client, guildId).catch(() => {});
    await safeAckModal(interaction, testesConfigPanel(guildId));
    return true;
  }

  if (interaction.isModalSubmit() && id === 'dev:testes:config:modal:limits') {
    const globRaw = interaction.fields.getTextInputValue('global_limit').trim();
    const userRaw = interaction.fields.getTextInputValue('per_user_limit').trim();
    const globLimit = parseInt(globRaw, 10);
    const userLimit = parseInt(userRaw, 10);

    const cfg = guildData(guildId).testConfig.config;
    cfg.globalLimit = isNaN(globLimit) || globLimit < 0 ? 0 : globLimit;
    cfg.perUserLimit = isNaN(userLimit) || userLimit < 1 ? 1 : userLimit;

    saveData();
    refreshAllPublishedPanels(client, guildId).catch(() => {});
    await safeAckModal(interaction, testesConfigPanel(guildId));
    return true;
  }

  // 11. Gerenciar / Selecionar Teste
  if (interaction.isButton() && id === 'dev:testes:manage:menu') {
    await interaction.update(testesManagePanel(guildId));
    return true;
  }

  if (interaction.isStringSelectMenu() && (id === 'dev:testes:manage:select' || id === 'dev:testes:select_remove')) {
    const testId = interaction.values[0];
    const d = guildData(guildId);
    const testItem = (d.tests || []).find((t) => t.id === testId);
    if (!testItem) {
      await interaction.update(testesManagePanel(guildId, 'Painel de teste não encontrado.'));
      return true;
    }
    await interaction.update(testesEditPanel(guildId, testItem));
    return true;
  }

  if (interaction.isButton() && id.startsWith('dev:testes:edit:open:')) {
    const testId = id.replace('dev:testes:edit:open:', '');
    const d = guildData(guildId);
    const testItem = (d.tests || []).find((t) => t.id === testId);
    if (!testItem) {
      await interaction.update(testesManagePanel(guildId, 'Painel de teste não encontrado.'));
      return true;
    }
    await interaction.update(testesEditPanel(guildId, testItem));
    return true;
  }

  if (interaction.isStringSelectMenu() && id.startsWith('dev:testes:edit:select_section:')) {
    const testId = id.replace('dev:testes:edit:select_section:', '');
    const d = guildData(guildId);
    const testItem = (d.tests || []).find((t) => t.id === testId);
    if (!testItem) {
      await interaction.update(testesManagePanel(guildId, 'Painel de teste não encontrado.'));
      return true;
    }
    const val = interaction.values[0];
    if (val === 'appearance') {
      await interaction.update(testesEditAppearancePanel(guildId, testItem));
      return true;
    }
    if (val === 'config') {
      await interaction.update(testesEditConfigPanel(guildId, testItem));
      return true;
    }
    return true;
  }

  if (interaction.isButton() && id.startsWith('dev:testes:edit:delete:')) {
    const testId = id.replace('dev:testes:edit:delete:', '');
    const d = guildData(guildId);
    const idx = (d.tests || []).findIndex((t) => t.id === testId);
    let removedTitle = '';
    if (idx !== -1) {
      removedTitle = d.tests[idx].appearance?.title || 'Teste';
      d.tests.splice(idx, 1);
      saveData();
    }
    await interaction.update(testesManagePanel(guildId, `Painel "${removedTitle}" excluído com sucesso!`));
    return true;
  }

  // 11.1 Modais e Botões de Edição de Aparência de Teste Existente
  if (interaction.isButton() && id.startsWith('dev:testes:edit:app:title:')) {
    const testId = id.replace('dev:testes:edit:app:title:', '');
    const d = guildData(guildId);
    const testItem = (d.tests || []).find((t) => t.id === testId);
    const current = testItem?.appearance?.title || '';
    await interaction.showModal(
      singleTextModal(`dev:testes:edit:app:modal:title:${testId}`, 'Título do Painel de Testes', 'Título', current, TextInputStyle.Short, 256)
    );
    return true;
  }

  if (interaction.isButton() && id.startsWith('dev:testes:edit:app:description:')) {
    const testId = id.replace('dev:testes:edit:app:description:', '');
    const d = guildData(guildId);
    const testItem = (d.tests || []).find((t) => t.id === testId);
    const current = testItem?.appearance?.description || '';
    await interaction.showModal(
      singleTextModal(`dev:testes:edit:app:modal:description:${testId}`, 'Descrição do Teste', 'Descrição', current, TextInputStyle.Paragraph, 2000)
    );
    return true;
  }

  if (interaction.isButton() && id.startsWith('dev:testes:edit:app:banner:')) {
    const testId = id.replace('dev:testes:edit:app:banner:', '');
    const d = guildData(guildId);
    const testItem = (d.tests || []).find((t) => t.id === testId);
    const current = testItem?.appearance?.banner || '';
    await interaction.showModal(
      singleTextModal(`dev:testes:edit:app:modal:banner:${testId}`, 'Banner do Painel', 'URL do Banner (https://...)', current, TextInputStyle.Short, 1000)
    );
    return true;
  }

  if (interaction.isButton() && id.startsWith('dev:testes:edit:app:thumbnail:')) {
    const testId = id.replace('dev:testes:edit:app:thumbnail:', '');
    const d = guildData(guildId);
    const testItem = (d.tests || []).find((t) => t.id === testId);
    const current = testItem?.appearance?.thumbnail || '';
    await interaction.showModal(
      singleTextModal(`dev:testes:edit:app:modal:thumbnail:${testId}`, 'Thumbnail do Painel', 'URL da Thumbnail (https://...)', current, TextInputStyle.Short, 1000)
    );
    return true;
  }

  if (interaction.isModalSubmit() && id.startsWith('dev:testes:edit:app:modal:title:')) {
    const testId = id.replace('dev:testes:edit:app:modal:title:', '');
    const d = guildData(guildId);
    const testItem = (d.tests || []).find((t) => t.id === testId);
    if (testItem) {
      if (!testItem.appearance) testItem.appearance = {};
      const val = interaction.fields.getTextInputValue('value').trim();
      testItem.appearance.title = val || 'Teste Grátis';
      saveData();
      refreshAllPublishedPanels(client, guildId).catch(() => {});
      await safeAckModal(interaction, testesEditAppearancePanel(guildId, testItem, 'Título atualizado com sucesso!'));
    } else {
      await safeAckModal(interaction, testesManagePanel(guildId, 'Painel não encontrado.'));
    }
    return true;
  }

  if (interaction.isModalSubmit() && id.startsWith('dev:testes:edit:app:modal:description:')) {
    const testId = id.replace('dev:testes:edit:app:modal:description:', '');
    const d = guildData(guildId);
    const testItem = (d.tests || []).find((t) => t.id === testId);
    if (testItem) {
      if (!testItem.appearance) testItem.appearance = {};
      const val = interaction.fields.getTextInputValue('value').trim();
      testItem.appearance.description = val || 'Resgate seu teste gratuito!';
      saveData();
      refreshAllPublishedPanels(client, guildId).catch(() => {});
      await safeAckModal(interaction, testesEditAppearancePanel(guildId, testItem, 'Descrição atualizada com sucesso!'));
    } else {
      await safeAckModal(interaction, testesManagePanel(guildId, 'Painel não encontrado.'));
    }
    return true;
  }

  if (interaction.isModalSubmit() && id.startsWith('dev:testes:edit:app:modal:banner:')) {
    const testId = id.replace('dev:testes:edit:app:modal:banner:', '');
    const d = guildData(guildId);
    const testItem = (d.tests || []).find((t) => t.id === testId);
    if (testItem) {
      if (!testItem.appearance) testItem.appearance = {};
      const val = interaction.fields.getTextInputValue('value').trim();
      testItem.appearance.banner = isValidHttpUrl(val) ? val : null;
      saveData();
      refreshAllPublishedPanels(client, guildId).catch(() => {});
      await safeAckModal(interaction, testesEditAppearancePanel(guildId, testItem, 'Banner atualizado com sucesso!'));
    } else {
      await safeAckModal(interaction, testesManagePanel(guildId, 'Painel não encontrado.'));
    }
    return true;
  }

  if (interaction.isModalSubmit() && id.startsWith('dev:testes:edit:app:modal:thumbnail:')) {
    const testId = id.replace('dev:testes:edit:app:modal:thumbnail:', '');
    const d = guildData(guildId);
    const testItem = (d.tests || []).find((t) => t.id === testId);
    if (testItem) {
      if (!testItem.appearance) testItem.appearance = {};
      const val = interaction.fields.getTextInputValue('value').trim();
      testItem.appearance.thumbnail = isValidHttpUrl(val) ? val : null;
      saveData();
      refreshAllPublishedPanels(client, guildId).catch(() => {});
      await safeAckModal(interaction, testesEditAppearancePanel(guildId, testItem, 'Thumbnail atualizada com sucesso!'));
    } else {
      await safeAckModal(interaction, testesManagePanel(guildId, 'Painel não encontrado.'));
    }
    return true;
  }

  // 11.2 Modais e Botões de Edição de Regras de Teste Existente
  if (interaction.isButton() && id.startsWith('dev:testes:edit:cfg:invites:')) {
    const testId = id.replace('dev:testes:edit:cfg:invites:', '');
    const d = guildData(guildId);
    const testItem = (d.tests || []).find((t) => t.id === testId);
    const cfg = testItem?.config || {};
    const modal = testesInvitesModal(cfg.requiredInvites ?? 3, cfg.minAccountAgeDays ?? 7);
    modal.setCustomId(`dev:testes:edit:cfg:modal:invites:${testId}`);
    await interaction.showModal(modal);
    return true;
  }

  if (interaction.isButton() && id.startsWith('dev:testes:edit:cfg:duration:')) {
    const testId = id.replace('dev:testes:edit:cfg:duration:', '');
    const d = guildData(guildId);
    const testItem = (d.tests || []).find((t) => t.id === testId);
    const cfg = testItem?.config || {};
    const modal = testesDurationModal(cfg.durationText || '24h');
    modal.setCustomId(`dev:testes:edit:cfg:modal:duration:${testId}`);
    await interaction.showModal(modal);
    return true;
  }

  if (interaction.isButton() && id.startsWith('dev:testes:edit:cfg:limits:')) {
    const testId = id.replace('dev:testes:edit:cfg:limits:', '');
    const d = guildData(guildId);
    const testItem = (d.tests || []).find((t) => t.id === testId);
    const cfg = testItem?.config || {};
    const modal = testesLimitsModal(cfg.globalLimit ?? 0, cfg.perUserLimit ?? 1);
    modal.setCustomId(`dev:testes:edit:cfg:modal:limits:${testId}`);
    await interaction.showModal(modal);
    return true;
  }

  if (interaction.isModalSubmit() && id.startsWith('dev:testes:edit:cfg:modal:invites:')) {
    const testId = id.replace('dev:testes:edit:cfg:modal:invites:', '');
    const d = guildData(guildId);
    const testItem = (d.tests || []).find((t) => t.id === testId);
    if (testItem) {
      if (!testItem.config) testItem.config = {};
      const invRaw = interaction.fields.getTextInputValue('invites_count').trim();
      const ageRaw = interaction.fields.getTextInputValue('min_age_days').trim();
      const invCount = parseInt(invRaw, 10);
      const ageDays = parseInt(ageRaw, 10);
      testItem.config.requiredInvites = isNaN(invCount) || invCount < 0 ? 0 : invCount;
      testItem.config.minAccountAgeDays = isNaN(ageDays) || ageDays < 0 ? 0 : ageDays;
      saveData();
      refreshAllPublishedPanels(client, guildId).catch(() => {});
      await safeAckModal(interaction, testesEditConfigPanel(guildId, testItem, 'Critérios de invites atualizados com sucesso!'));
    } else {
      await safeAckModal(interaction, testesManagePanel(guildId, 'Painel não encontrado.'));
    }
    return true;
  }

  if (interaction.isModalSubmit() && id.startsWith('dev:testes:edit:cfg:modal:duration:')) {
    const testId = id.replace('dev:testes:edit:cfg:modal:duration:', '');
    const d = guildData(guildId);
    const testItem = (d.tests || []).find((t) => t.id === testId);
    if (testItem) {
      if (!testItem.config) testItem.config = {};
      const durVal = interaction.fields.getTextInputValue('duration_text').trim();
      testItem.config.durationText = durVal || '24h';
      saveData();
      refreshAllPublishedPanels(client, guildId).catch(() => {});
      await safeAckModal(interaction, testesEditConfigPanel(guildId, testItem, 'Duração do teste atualizada com sucesso!'));
    } else {
      await safeAckModal(interaction, testesManagePanel(guildId, 'Painel não encontrado.'));
    }
    return true;
  }

  if (interaction.isModalSubmit() && id.startsWith('dev:testes:edit:cfg:modal:limits:')) {
    const testId = id.replace('dev:testes:edit:cfg:modal:limits:', '');
    const d = guildData(guildId);
    const testItem = (d.tests || []).find((t) => t.id === testId);
    if (testItem) {
      if (!testItem.config) testItem.config = {};
      const globRaw = interaction.fields.getTextInputValue('global_limit').trim();
      const userRaw = interaction.fields.getTextInputValue('per_user_limit').trim();
      const globLimit = parseInt(globRaw, 10);
      const userLimit = parseInt(userRaw, 10);
      testItem.config.globalLimit = isNaN(globLimit) || globLimit < 0 ? 0 : globLimit;
      testItem.config.perUserLimit = isNaN(userLimit) || userLimit < 1 ? 1 : userLimit;
      saveData();
      refreshAllPublishedPanels(client, guildId).catch(() => {});
      await safeAckModal(interaction, testesEditConfigPanel(guildId, testItem, 'Limites de resgate atualizados com sucesso!'));
    } else {
      await safeAckModal(interaction, testesManagePanel(guildId, 'Painel não encontrado.'));
    }
    return true;
  }

  // 12. Ações do Painel Público de Testes
  if (interaction.isButton() && id.startsWith('dev:testes:public:invites:')) {
    const testId = id.replace('dev:testes:public:invites:', '');
    const d = guildData(guildId);
    const testItem = (d.tests || []).find((t) => t.id === testId);
    const cfg = testItem?.config || d.testConfig.config;

    const userInvites = await getUserValidInvites(interaction.guild, interaction.user.id, cfg.minAccountAgeDays || 0);

    const ageDays = Math.floor((Date.now() - interaction.user.createdTimestamp) / 86400000);
    const ageOk = cfg.minAccountAgeDays <= 0 || ageDays >= cfg.minAccountAgeDays;

    await interaction.reply({
      content:
        `📊 **Seus Dados de Validação de Invites:**\n\n` +
        `👥 **Invites Válidos:** **${userInvites}** / **${cfg.requiredInvites}** necessários\n` +
        `📅 **Idade da sua Conta:** **${ageDays}** dias (Mínimo exigido: **${cfg.minAccountAgeDays || 0}** dias ${ageOk ? '✅' : '❌'})\n\n` +
        (userInvites >= cfg.requiredInvites && ageOk
          ? `🎉 **Você já cumpre todos os requisitos!** Clique em **Resgatar Teste** para obter seu acesso.`
          : `💡 Convide mais amigos para o servidor para acumular os invites necessários e liberar seu teste gratuito!`),
      flags: MessageFlags.Ephemeral,
    });
    return true;
  }

  if (interaction.isButton() && id.startsWith('dev:testes:public:claim:')) {
    const testId = id.replace('dev:testes:public:claim:', '');
    const d = guildData(guildId);
    const testItem = (d.tests || []).find((t) => t.id === testId);
    const cfg = testItem?.config || d.testConfig.config;

    // 1. Validar Limite Geral
    if (cfg.globalLimit > 0 && (testItem?.claimsCount || 0) >= cfg.globalLimit) {
      await interaction.reply({
        content: '❌ **Limite de resgates atingido!**\nTodas as vagas disponíveis para este teste gratuito já foram preenchidas.',
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    // 2. Validar Limite por Pessoa
    const perUserLimit = cfg.perUserLimit || 1;
    const userClaims = (d.testClaims || []).filter(
      (c) => c.userId === interaction.user.id && (testItem ? c.testId === testItem.id : true)
    );
    if (userClaims.length >= perUserLimit) {
      await interaction.reply({
        content: `❌ **Limite por usuário atingido!**\nVocê já resgatou o limite máximo permitido (${perUserLimit} resgate(s)) para este teste.`,
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    // 3. Validar Idade da Conta
    const ageDays = Math.floor((Date.now() - interaction.user.createdTimestamp) / 86400000);
    if (cfg.minAccountAgeDays > 0 && ageDays < cfg.minAccountAgeDays) {
      await interaction.reply({
        content: `❌ **Conta muito recente!**\nSua conta do Discord tem **${ageDays}** dias. A idade mínima necessária para validação do teste é de **${cfg.minAccountAgeDays}** dias.`,
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    // 4. Validar Quantidade de Invites
    let verifiedInvites = 0;
    if (cfg.requiredInvites > 0) {
      verifiedInvites = await getUserValidInvites(interaction.guild, interaction.user.id, cfg.minAccountAgeDays || 0);
      if (verifiedInvites < cfg.requiredInvites) {
        await interaction.reply({
          content:
            `❌ **Invites insuficientes!**\n\n` +
            `Você possui **${verifiedInvites}** invite(s) contabilizados no momento, mas são necessários **${cfg.requiredInvites}** invites válidos para resgatar este teste gratuito.\n\n` +
            `Convide mais pessoas para o servidor e tente novamente!`,
          flags: MessageFlags.Ephemeral,
        });
        return true;
      }
    }

    // 5. Sucesso - Gerar Licença de Teste
    const licenseKey = `TEST-${Math.random().toString(36).slice(2, 6).toUpperCase()}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
    if (testItem) {
      testItem.claimsCount = (testItem.claimsCount || 0) + 1;
    }

    const claimRecord = {
      id: `claim_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      testId: testItem?.id || testId,
      testTitle: testItem?.appearance?.title || d.testConfig.appearance.title || 'Teste Grátis',
      userId: interaction.user.id,
      userTag: interaction.user.tag || interaction.user.username,
      licenseKey,
      durationText: cfg.durationText || '24h',
      verifiedInvites,
      claimedAt: new Date().toISOString(),
    };

    d.testClaims.push(claimRecord);
    saveData();
    refreshAllPublishedPanels(client, guildId).catch(() => {});

    const claimPayload = testClaimEphemeralPayload(client, claimRecord, testItem);
    await interaction.reply({
      ...claimPayload,
      flags: (claimPayload.flags || MessageFlags.IsComponentsV2) | MessageFlags.Ephemeral,
    });
    return true;
  }

  // ── Módulo Personalização de Botões (Config Botões) ─────────────────────────

  if (interaction.isButton() && id === 'dev:buttons:menu') {
    await interaction.update(painelCategoriasBotoes(guildId));
    return true;
  }

  if (interaction.isStringSelectMenu() && id === 'dev:buttons:select_category') {
    const categoryId = interaction.values[0];
    await interaction.update(painelBotoesDaCategoria(guildId, categoryId));
    return true;
  }

  if (interaction.isStringSelectMenu() && id.startsWith('dev:buttons:select_button:')) {
    const buttonId = interaction.values[0];
    const modal = modalConfigurarBotao(buttonId);
    if (modal) {
      await interaction.showModal(modal);
    }
    return true;
  }

  if (interaction.isModalSubmit() && id.startsWith('dev:buttons:modal:')) {
    const buttonId = id.replace('dev:buttons:modal:', '');
    const styleInput = interaction.fields.getTextInputValue('button_style');
    const emojiInput = interaction.fields.getTextInputValue('button_emoji');

    definirConfigBotao(buttonId, styleInput, emojiInput);

    const def = MAPA_TODOS_BOTOES[buttonId];
    const categoryId = def ? def.categoriaId : 'filas_partidas';

    await safeAckModal(
      interaction,
      painelBotoesDaCategoria(guildId, categoryId, 'Botao atualizado com sucesso! Todos os bots e paineis foram sincronizados.')
    );

    // Auto-refresh de todos os painéis live em todos os servidores
    try {
      const { agendarSincronizacao } = require('./sincronizar_paineis');
      agendarSincronizacao(client);
    } catch (_) {}

    refreshAllPublishedPanels(client).catch(() => {});
    return true;
  }

  // ── Módulo Gestão de Bots ───────────────────────────────────────────────────

  if (interaction.isButton() && id === 'dev:bots:menu') {
    await interaction.update(gestaoBotsPanel(guildId));
    return true;
  }

  if (interaction.isButton() && id === 'dev:bots:menu:back') {
    await interaction.update(gestaoBotsPanel(guildId));
    return true;
  }

  if (interaction.isButton() && id === 'dev:bots:register_tokens') {
    await interaction.showModal(registerBotsModal());
    return true;
  }

  if (interaction.isModalSubmit() && id === 'dev:bots:modal:register') {
    const raw = interaction.fields.getTextInputValue('tokens') || '';
    const lines = raw
      .split(/\r?\n|,/)
      .map((l) => l.trim())
      .filter((l) => l.length > 20);

    if (lines.length === 0) {
      await interaction.reply({
        content: '❌ Nenhum token válido inserido. Certifique-se de colar tokens válidos.',
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    const d = guildData(guildId);
    if (!Array.isArray(d.managedBots)) d.managedBots = [];

    let added = 0;
    for (const tok of lines) {
      if (!d.managedBots.some((b) => b.token === tok)) {
        d.managedBots.push({
          id: `bot_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
          token: tok,
          tag: null,
          botId: null,
          status: 'offline',
          lastError: null,
          addedAt: new Date().toISOString(),
          startedAt: null,
        });
        added++;
      }
    }

    saveData();
    await safeAckModal(interaction, gestaoBotsPanel(guildId, `${added} novo(s) token(s) cadastrado(s) com sucesso.`));
    return true;
  }

  if (interaction.isButton() && id === 'dev:bots:remove_tokens_panel') {
    await interaction.update(gestaoBotsRemoveTokensPanel(guildId));
    return true;
  }

  if (interaction.isStringSelectMenu() && id === 'dev:bots:select_remove') {
    const targetId = interaction.values[0];
    const d = guildData(guildId);
    const existingClient = activeBotClients.get(targetId);
    if (existingClient) {
      existingClient.destroy().catch(() => {});
      activeBotClients.delete(targetId);
    }

    const idx = (d.managedBots || []).findIndex((b) => b.id === targetId);
    let removedTag = '';
    if (idx !== -1) {
      removedTag = d.managedBots[idx].tag || maskToken(d.managedBots[idx].token);
      d.managedBots.splice(idx, 1);
      saveData();
    }

    await interaction.update(gestaoBotsPanel(guildId, `Bot ${removedTag} removido do sistema.`));
    return true;
  }

  if (interaction.isButton() && id === 'dev:bots:stop_panel') {
    await interaction.update(gestaoBotsStopPanel(guildId));
    return true;
  }

  if (interaction.isStringSelectMenu() && id === 'dev:bots:select_stop') {
    const targetId = interaction.values[0];
    const d = guildData(guildId);
    const bot = (d.managedBots || []).find((b) => b.id === targetId);

    const existingClient = activeBotClients.get(targetId);
    if (existingClient) {
      existingClient.destroy().catch(() => {});
      activeBotClients.delete(targetId);
    }

    if (bot) {
      bot.status = 'offline';
      saveData();
    }

    const botName = bot?.tag || (bot ? maskToken(bot.token) : targetId);
    await interaction.update(gestaoBotsPanel(guildId, `Instância do bot ${botName} parada e desconectada.`));
    return true;
  }

  if (interaction.isButton() && id === 'dev:bots:start_all') {
    const d = guildData(guildId);
    const bots = d.managedBots || [];

    if (bots.length === 0) {
      await interaction.reply({
        content: '❌ Nenhum bot cadastrado no sistema. Clique em **Cadastrar tokens** para adicionar.',
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    await interaction.deferUpdate();

    let startedCount = 0;
    let alreadyOnline = 0;
    let errorCount = 0;

    for (const bot of bots) {
      const existing = activeBotClients.get(bot.id);
      if (existing && existing.isReady()) {
        bot.status = 'online';
        bot.tag = existing.user?.tag || bot.tag;
        bot.botId = existing.user?.id || bot.botId;
        alreadyOnline++;
        continue;
      }

      try {
        const subClient = new DiscordClient({
          intents: [
            GatewayIntentBits.Guilds,
            GatewayIntentBits.GuildMessages,
          ],
        });

        subClient.on('error', (err) => {
          console.warn(`[DEV CENTRAL BOT] Erro de conexão em ${bot.id}:`, err.message);
        });

        const loginPromise = subClient.login(bot.token);
        const timeoutPromise = new Promise((_, reject) =>
          setTimeout(() => reject(new Error('Tempo limite de conexão esgotado (12s)')), 12000)
        );

        await Promise.race([loginPromise, timeoutPromise]);

        bot.status = 'online';
        bot.tag = subClient.user?.tag || 'Bot Conectado';
        bot.botId = subClient.user?.id || null;
        bot.lastError = null;
        bot.startedAt = new Date().toISOString();
        activeBotClients.set(bot.id, subClient);
        startedCount++;

        await new Promise((r) => setTimeout(r, 600));
      } catch (err) {
        console.warn(`[DEV CENTRAL BOT] Falha ao logar bot (${maskToken(bot.token)}):`, err.message);
        bot.status = 'error';
        bot.lastError = err.message;
        errorCount++;
      }
    }

    saveData();

    const summary = `Processo finalizado: ${startedCount} iniciado(s), ${alreadyOnline} já ativo(s), ${errorCount} falha(s).`;
    await interaction.editReply(gestaoBotsPanel(guildId, summary));
    return true;
  }

  // ── Módulo Loja ─────────────────────────────────────────────────────────────

  // 1. Abertura pelo menu principal
  if (interaction.isButton() && id === 'dev:loja:menu') {
    await interaction.update(lojaMenuPanel(guildId));
    return true;
  }

  if (interaction.isButton() && id === 'dev:main:back') {
    await interaction.update(mainDevPanel(guildId));
    return true;
  }

  if (interaction.isButton() && id === 'dev:loja:menu:back') {
    await interaction.update(lojaMenuPanel(guildId));
    return true;
  }

  // 2. Select menu da Loja (Aparência / Configurar)
  if (interaction.isStringSelectMenu() && id === 'dev:loja:select_section') {
    const val = interaction.values[0];
    if (val === 'appearance') {
      await interaction.update(lojaAppearancePanel(guildId));
      return true;
    }
    if (val === 'config') {
      await interaction.update(lojaConfigPanel(guildId));
      return true;
    }
    return true;
  }

  // 3. Botão Enviar no menu da Loja
  if (interaction.isButton() && id === 'dev:loja:send_prompt') {
    await interaction.update(lojaSendPanel(guildId));
    return true;
  }

  // 4. Seleção do canal para envio público
  if (interaction.isChannelSelectMenu() && id === 'dev:loja:send_channel') {
    await interaction.deferUpdate();
    const targetChannelId = interaction.values[0];
    const channel = await interaction.guild.channels.fetch(targetChannelId).catch(() => null);

    if (!channel || !channel.isTextBased()) {
      await interaction.editReply(lojaMenuPanel(guildId, 'Canal inválido ou sem permissão para envio.'));
      return true;
    }

    const sentMsg = await sendOrEditPublicPanel(channel, guildId);

    if (!sentMsg) {
      await interaction.editReply(lojaMenuPanel(guildId, 'Não foi possível enviar a mensagem no canal selecionado. Verifique as permissões do bot (Ver Canal, Enviar Mensagens, Inserir Links).'));
      return true;
    }

    const d = guildData(guildId);
    d.panels.push({
      channelId: channel.id,
      messageId: sentMsg.id,
      createdAt: new Date().toISOString(),
    });
    saveData();

    await interaction.editReply(lojaMenuPanel(guildId, `Painel público da loja publicado com sucesso em <#${channel.id}>.`));
    return true;
  }

  // 5. Botões do Sub-painel Aparência
  if (interaction.isButton() && id === 'dev:loja:appearance:title') {
    const current = guildData(guildId).appearance.title;
    await interaction.showModal(
      singleTextModal('dev:loja:appearance:modal:title', 'Título do Painel', 'Título', current, TextInputStyle.Short, 256)
    );
    return true;
  }

  if (interaction.isButton() && id === 'dev:loja:appearance:description') {
    const current = guildData(guildId).appearance.description;
    await interaction.showModal(descriptionModal(current));
    return true;
  }

  if (interaction.isButton() && id === 'dev:loja:appearance:banner') {
    const current = guildData(guildId).appearance.banner;
    await interaction.showModal(
      singleTextModal('dev:loja:appearance:modal:banner', 'Banner do Painel', 'URL do Banner (https://...)', current, TextInputStyle.Short, 1000)
    );
    return true;
  }

  if (interaction.isButton() && id === 'dev:loja:appearance:thumbnail') {
    const current = guildData(guildId).appearance.thumbnail;
    await interaction.showModal(
      singleTextModal('dev:loja:appearance:modal:thumbnail', 'Thumbnail do Painel', 'URL da Thumbnail (https://...)', current, TextInputStyle.Short, 1000)
    );
    return true;
  }

  if (interaction.isButton() && id === 'dev:loja:appearance:footer') {
    const current = guildData(guildId).appearance.footer;
    await interaction.showModal(
      singleTextModal('dev:loja:appearance:modal:footer', 'Rodapé da Loja', 'Texto do Rodapé', current, TextInputStyle.Short, 2048)
    );
    return true;
  }

  // 6. Submissão dos Modais de Aparência
  if (interaction.isModalSubmit() && id === 'dev:loja:appearance:modal:title') {
    const val = interaction.fields.getTextInputValue('value').trim();
    guildData(guildId).appearance.title = val || 'Loja Oficial';
    saveData();
    refreshAllPublishedPanels(client, guildId).catch(() => {});
    await safeAckModal(interaction, lojaAppearancePanel(guildId));
    return true;
  }

  if (interaction.isModalSubmit() && id === 'dev:loja:appearance:modal:description') {
    const p1 = interaction.fields.getTextInputValue('desc_part1') || '';
    const p2 = interaction.fields.getTextInputValue('desc_part2') || '';
    const p3 = interaction.fields.getTextInputValue('desc_part3') || '';
    const combined = [p1, p2, p3].filter((t) => t.trim().length > 0).join('\n\n').trim();

    guildData(guildId).appearance.description = combined || 'Adquira seu plano de acesso com ativação imediata.';
    saveData();
    refreshAllPublishedPanels(client, guildId).catch(() => {});
    await safeAckModal(interaction, lojaAppearancePanel(guildId));
    return true;
  }

  if (interaction.isModalSubmit() && id === 'dev:loja:appearance:modal:banner') {
    const val = interaction.fields.getTextInputValue('value').trim();
    guildData(guildId).appearance.banner = isValidHttpUrl(val) ? val : null;
    saveData();
    refreshAllPublishedPanels(client, guildId).catch(() => {});
    await safeAckModal(interaction, lojaAppearancePanel(guildId));
    return true;
  }

  if (interaction.isModalSubmit() && id === 'dev:loja:appearance:modal:thumbnail') {
    const val = interaction.fields.getTextInputValue('value').trim();
    guildData(guildId).appearance.thumbnail = isValidHttpUrl(val) ? val : null;
    saveData();
    refreshAllPublishedPanels(client, guildId).catch(() => {});
    await safeAckModal(interaction, lojaAppearancePanel(guildId));
    return true;
  }

  if (interaction.isModalSubmit() && id === 'dev:loja:appearance:modal:footer') {
    const val = interaction.fields.getTextInputValue('value').trim();
    guildData(guildId).appearance.footer = val || null;
    saveData();
    refreshAllPublishedPanels(client, guildId).catch(() => {});
    await safeAckModal(interaction, lojaAppearancePanel(guildId));
    return true;
  }

  // 7. Botões do Sub-painel Configurar
  if (interaction.isButton() && id === 'dev:loja:config:price') {
    const current = guildData(guildId).config.price;
    await interaction.showModal(
      singleTextModal('dev:loja:config:modal:price', 'Preço do Bot', 'Valor em Reais (Ex: 29.90)', current.toFixed(2), TextInputStyle.Short, 12)
    );
    return true;
  }

  if (interaction.isButton() && id === 'dev:loja:config:duration') {
    const current = guildData(guildId).config.durationDays;
    await interaction.showModal(
      singleTextModal('dev:loja:config:modal:duration', 'Duração do Plano', 'Dias de duração (0 = vitalício)', String(current), TextInputStyle.Short, 10)
    );
    return true;
  }

  if (interaction.isButton() && id === 'dev:loja:config:payment') {
    const current = guildData(guildId).config.mercadoPagoToken;
    await interaction.showModal(
      singleTextModal('dev:loja:config:modal:payment', 'Mercado Pago Token', 'Access Token do Mercado Pago', current, TextInputStyle.Paragraph, 1000)
    );
    return true;
  }

  if (interaction.isButton() && id === 'dev:loja:config:terms') {
    const current = guildData(guildId).config.terms;
    await interaction.showModal(
      singleTextModal('dev:loja:config:modal:terms', 'Termos de Uso', 'Texto dos Termos de Uso', current, TextInputStyle.Paragraph, 4000)
    );
    return true;
  }

  if (interaction.isButton() && id === 'dev:loja:config:topics_channel') {
    await interaction.update(lojaTopicsChannelPanel(guildId));
    return true;
  }

  if (interaction.isChannelSelectMenu() && id === 'dev:loja:config:select_topics_channel') {
    const selectedChannelId = interaction.values[0];
    guildData(guildId).config.topicsChannelId = selectedChannelId;
    saveData();
    await interaction.update(lojaConfigPanel(guildId));
    return true;
  }

  if (interaction.isButton() && id === 'dev:loja:config:clear_topics_channel') {
    guildData(guildId).config.topicsChannelId = null;
    saveData();
    await interaction.update(lojaConfigPanel(guildId));
    return true;
  }

  if (interaction.isButton() && id === 'dev:loja:config:back_to_config') {
    await interaction.update(lojaConfigPanel(guildId));
    return true;
  }

  // 8. Submissão dos Modais de Configurar
  if (interaction.isModalSubmit() && id === 'dev:loja:config:modal:price') {
    const raw = interaction.fields.getTextInputValue('value').trim().replace(',', '.');
    const num = parseFloat(raw);
    if (!isNaN(num) && num >= 0) {
      guildData(guildId).config.price = num;
      saveData();
      refreshAllPublishedPanels(client, guildId).catch(() => {});
    }
    await safeAckModal(interaction, lojaConfigPanel(guildId));
    return true;
  }

  if (interaction.isModalSubmit() && id === 'dev:loja:config:modal:duration') {
    const raw = interaction.fields.getTextInputValue('value').trim();
    const num = parseInt(raw, 10);
    if (!isNaN(num) && num >= 0) {
      guildData(guildId).config.durationDays = num;
      saveData();
      refreshAllPublishedPanels(client, guildId).catch(() => {});
    }
    await safeAckModal(interaction, lojaConfigPanel(guildId));
    return true;
  }

  if (interaction.isModalSubmit() && id === 'dev:loja:config:modal:payment') {
    const token = interaction.fields.getTextInputValue('value').trim();
    guildData(guildId).config.mercadoPagoToken = token;
    if (token) {
      process.env.MERCADOPAGO_ACCESS_TOKEN = token;
    }
    saveData();
    await safeAckModal(interaction, lojaConfigPanel(guildId));
    return true;
  }

  if (interaction.isModalSubmit() && id === 'dev:loja:config:modal:terms') {
    const terms = interaction.fields.getTextInputValue('value').trim();
    guildData(guildId).config.terms = terms || 'Nenhum termo de uso cadastrado.';
    saveData();
    await safeAckModal(interaction, lojaConfigPanel(guildId));
    return true;
  }

  // 9. Ações do Painel Público
  if (interaction.isButton() && id === 'dev:loja:public:terms') {
    const payload = termsPayload(guildId);
    await interaction.reply({
      ...payload,
      flags: (payload.flags || MessageFlags.IsComponentsV2) | MessageFlags.Ephemeral,
    });
    return true;
  }

  if (interaction.isButton() && id === 'dev:loja:public:buy') {
    await handleStartPurchase(interaction, client);
    return true;
  }

  // 10. Ações dentro do Canal / Tópico de Compra

  // Botão CONFIRMAR (Gera o QR Code Pix e atualiza o painel)
  if (interaction.isButton() && id.startsWith('dev:loja:topic:confirm:')) {
    const purchaseId = id.replace('dev:loja:topic:confirm:', '');
    const d = guildData(guildId);
    let purchase = d.purchases.find((p) => p.id === purchaseId);
    if (!purchase) {
      const found = findPurchaseById(purchaseId);
      purchase = found.purchase;
    }

    if (!purchase || purchase.status === 'approved' || purchase.status === 'cancelled') {
      await interaction.reply({
        content: 'Este pedido já foi finalizado ou cancelado.',
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    await interaction.deferUpdate();

    const price = purchase.price;
    const token = d.config.mercadoPagoToken;

    // Gerar Pix se ainda não tiver e houver token e preço > 0
    if (token && price > 0 && !purchase.pixCode) {
      const pixResult = await createPixPayment(token, price, `Plano Bot - ${interaction.guild.name}`);
      if (pixResult.ok) {
        purchase.pixCode = pixResult.qrCode;
        purchase.qrCodeBase64 = pixResult.qrCodeBase64 || '';
        purchase.paymentId = pixResult.id;
      }
    }

    purchase.status = 'pending';
    saveData();

    const paymentPayload = await purchasePaymentPayload(guildId, purchase);
    await interaction.editReply(paymentPayload);

    if (token && purchase.paymentId) {
      startPaymentWatcher(client, guildId, purchase.id);
    }
    return true;
  }

  // Botão COPIA E COLA (Manda o código Pix puro)
  if (interaction.isButton() && id.startsWith('dev:loja:topic:copypix:')) {
    const purchaseId = id.replace('dev:loja:topic:copypix:', '');
    const d = guildData(guildId);
    let purchase = d.purchases.find((p) => p.id === purchaseId);
    if (!purchase) {
      const found = findPurchaseById(purchaseId);
      purchase = found.purchase;
    }

    if (!purchase || !purchase.pixCode) {
      await interaction.reply({
        content: 'Chave Pix não disponível para este pedido.',
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    await interaction.reply({
      content: purchase.pixCode,
      flags: MessageFlags.Ephemeral,
    });
    return true;
  }

// ── Helper para Encerrar e Excluir Canal/Tópico de Atendimento ─────────────────

async function deletePurchaseTopicChannel(interaction, client, purchaseId, reason = 'Atendimento encerrado') {
  let purchase = null;
  if (purchaseId) {
    const found = findPurchaseById(purchaseId);
    purchase = found.purchase;
    if (purchase && purchase.status !== 'approved') {
      purchase.status = 'cancelled';
      saveData();
    }
    if (activeChecks.has(purchaseId)) {
      clearInterval(activeChecks.get(purchaseId));
      activeChecks.delete(purchaseId);
    }
  }

  const chan = interaction.channel;
  const channelId = purchase?.channelId || interaction.channelId;

  const performDelete = async () => {
    // 1. Tentar deletar o canal atual da interação diretamente
    if (chan && typeof chan.delete === 'function') {
      try {
        await chan.delete(reason);
        return;
      } catch (err) {
        console.warn('[DEV LOJA] chan.delete direto falhou:', err.message);
      }
    }

    // 2. Se for thread e o delete falhou, tentar arquivar e trancar
    if (chan && typeof chan.isThread === 'function' && chan.isThread()) {
      try {
        await chan.setLocked(true, reason).catch(() => {});
        await chan.setArchived(true, reason).catch(() => {});
        return;
      } catch (err) {
        console.warn('[DEV LOJA] chan.setArchived falhou:', err.message);
      }
    }

    // 3. Buscar o canal pelo client / guild e tentar deletar
    if (channelId) {
      try {
        const fetched = await (interaction.guild?.channels?.fetch(channelId) || client?.channels?.fetch(channelId)).catch(() => null);
        if (fetched && typeof fetched.delete === 'function') {
          await fetched.delete(reason).catch(() => {});
        } else if (fetched && typeof fetched.isThread === 'function' && fetched.isThread()) {
          await fetched.setLocked(true, reason).catch(() => {});
          await fetched.setArchived(true, reason).catch(() => {});
        }
      } catch (err) {
        console.warn('[DEV LOJA] Fallback de exclusão do canal falhou:', err.message);
      }
    }
  };

  setTimeout(performDelete, 1000);
}

  // Botão CANCELAR (Cancela o pedido e fecha/deleta o tópico)
  if (interaction.isButton() && id.startsWith('dev:loja:topic:cancel:')) {
    const purchaseId = id.replace('dev:loja:topic:cancel:', '');

    await interaction.reply({
      content: '❌ Pedido cancelado com sucesso. Encerrando e excluindo este atendimento...',
      flags: MessageFlags.Ephemeral,
    }).catch(() => {});

    await deletePurchaseTopicChannel(interaction, client, purchaseId, 'Pedido cancelado pelo usuário');
    return true;
  }

  // Botão FECHAR TÓPICO (Após aprovação)
  if (interaction.isButton() && id.startsWith('dev:loja:topic:close:')) {
    const purchaseId = id.replace('dev:loja:topic:close:', '');

    await interaction.reply({
      content: '🔒 Atendimento finalizado. Encerrando e excluindo este canal...',
      flags: MessageFlags.Ephemeral,
    }).catch(() => {});

    await deletePurchaseTopicChannel(interaction, client, purchaseId, 'Atendimento de compra finalizado');
    return true;
  }

  return false;
}

// ── Handler da Mensagem .dev central ───────────────────────────────────────────

async function handleDevMessage(message, client) {
  if (!message.guild || message.author.bot) return false;
  const texto = typeof message.content === 'string' ? message.content.trim() : '';
  if (!texto.startsWith('.dev')) return false;

  const parts = texto.split(/\s+/);
  const sub = (parts[1] || '').toLowerCase();

  // Sincronização remota via .dev sync ou .dev atualizar
  if (['sync', 'atualizar', 'update'].includes(sub)) {
    await message.delete().catch(() => {});
    if (!isDevAdmin(message.member)) {
      const replyMsg = await message.channel.send({
        content: `❌ <@${message.author.id}>, apenas o dono do bot pode executar a sincronização.`,
      }).catch(() => null);
      if (replyMsg) setTimeout(() => replyMsg.delete().catch(() => {}), 5000);
      return true;
    }

    const statusMsg = await message.channel.send('🔄 **Buscando atualizações no Google AI Studio...**\nConectando à API de sincronização remota...');
    try {
      const { executeSync, getSyncUrl } = require('../sync');
      const syncUrl = getSyncUrl();
      const res = await executeSync({
        url: syncUrl,
        onProgress: (log) => console.log(`[SYNC] ${log}`),
      });

      await statusMsg.edit(
        `✅ **Bot Atualizado com Sucesso!**\n` +
        `• 📦 **Arquivos sincronizados:** ${res.updatedCount}\n` +
        `• 🕒 **Versão:** \`${res.version || res.timestamp}\`\n` +
        `• 🌐 **Origem:** \`${res.sourceUrl || syncUrl}\`\n\n` +
        `🚀 **Reiniciando o bot em 3 segundos para aplicar as alterações...**`
      );

      setTimeout(() => {
        console.log('[SYNC] Reiniciando processo após auto-update via .dev sync...');
        process.exit(0);
      }, 3000);
    } catch (syncErr) {
      console.error('[SYNC] Erro no comando .dev sync:', syncErr.message);
      await statusMsg.edit(`❌ **Falha ao atualizar o bot:** \`${syncErr.message}\`\nVerifique se o painel web de desenvolvimento está ativo.`);
    }
    return true;
  }

  // Aceita tanto ".dev central" quanto ".dev"
  if (sub === 'central' || parts.length === 1) {
    // Apagar a mensagem do comando digitada pelo usuário
    await message.delete().catch(() => {});

    if (!isDevAdmin(message.member)) {
      const replyMsg = await message.channel.send({
        content: `❌ <@${message.author.id}>, apenas o dono do bot pode acessar a Central de Desenvolvedor.`,
      }).catch(() => null);
      if (replyMsg) {
        setTimeout(() => replyMsg.delete().catch(() => {}), 5000);
      }
      return true;
    }
    const payload = mainDevPanel(message.guildId);
    await message.channel.send(payload);
    return true;
  }

  return false;
}

module.exports = {
  handleDevMessage,
  handleDevCentral,
  restorePanels,
  refreshAllPublishedPanels,
  mainDevPanel,
  publicShopPayload,
};
