'use strict';

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const {
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
  ContainerBuilder,
  TextDisplayBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  MessageFlags,
  PermissionFlagsBits,
} = require('discord.js');
const { dataPath } = require('./data-path');

const VAULT_FILE = dataPath('bots_vault.json');
const MAX_BOTS = 25;
const panelRefs = new Map();
const panelTimers = new Map();
const STOCK_FILE = dataPath('bot_stock.json');
let controllerClient = null;
const pendingIpcRequests = new Map();
let panelRefreshTimer = null;

const START_CONCURRENCY = Math.max(
  1,
  Math.min(4, Number.parseInt(process.env.BOT_START_CONCURRENCY ?? '2', 10) || 2),
);
const START_DELAY_MS = Math.max(
  250,
  Number.parseInt(process.env.BOT_START_DELAY_MS ?? '1500', 10) || 1500,
);
const START_TIMEOUT_MS = Math.max(
  15000,
  Number.parseInt(process.env.BOT_START_TIMEOUT_MS ?? '45000', 10) || 45000,
);

function schedulePanelRefresh() {
  if (panelRefreshTimer) return;
  panelRefreshTimer = setTimeout(() => {
    panelRefreshTimer = null;
    refreshBotsPanels();
  }, 250);
  panelRefreshTimer.unref?.();
}

function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function vaultKey() {
  let secret = process.env.SESSION_SECRET;
  if (!secret) {
    try {
      const appCfgPath = dataPath('app_config.json');
      if (fs.existsSync(appCfgPath)) {
        const appCfg = JSON.parse(fs.readFileSync(appCfgPath, 'utf8'));
        if (appCfg?.sessionSecret) {
          secret = appCfg.sessionSecret;
          process.env.SESSION_SECRET = secret;
        }
      }
    } catch (_) {}
  }
  return secret ? crypto.createHash('sha256').update(secret).digest() : null;
}

function ensureDataDir() {
  fs.mkdirSync(path.dirname(VAULT_FILE), { recursive: true });
}

function encryptTokens(tokens) {
  const key = vaultKey();
  if (!key) throw new Error('SESSION_SECRET não configurado; não é seguro salvar tokens.');
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const encrypted = Buffer.concat([cipher.update(JSON.stringify(tokens), 'utf8'), cipher.final()]);
  return {
    version: 1,
    algorithm: 'aes-256-gcm',
    iv: iv.toString('base64'),
    tag: cipher.getAuthTag().toString('base64'),
    data: encrypted.toString('base64'),
  };
}

function decryptTokens(payload) {
  if (!payload?.iv || !payload?.tag || !payload?.data) return [];
  const key = vaultKey();
  if (!key) throw new Error('SESSION_SECRET não configurado; não é seguro ler tokens.');
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(payload.iv, 'base64'));
  decipher.setAuthTag(Buffer.from(payload.tag, 'base64'));
  const plain = Buffer.concat([
    decipher.update(Buffer.from(payload.data, 'base64')),
    decipher.final(),
  ]);
  const tokens = JSON.parse(plain.toString('utf8'));
  return Array.isArray(tokens) ? tokens : [];
}

function readTokens() {
  try {
    if (!fs.existsSync(VAULT_FILE)) return [];
    return decryptTokens(JSON.parse(fs.readFileSync(VAULT_FILE, 'utf8')));
  } catch (error) {
    console.error('[BOTS] Cofre de tokens indisponível:', error.message);
    return [];
  }
}

function isControllerToken(token) {
  const controllerToken = String(process.env.DISCORD_BOT_TOKEN ?? '').trim();
  return Boolean(controllerToken && String(token ?? '').trim() === controllerToken);
}

function workerTokens(tokens) {
  return [...new Set((Array.isArray(tokens) ? tokens : []).map((token) => String(token).trim()).filter(Boolean))]
    .filter((token) => !isControllerToken(token));
}

function tokenDotCount(value) {
  return (String(value).match(/\./g) ?? []).length;
}

function cleanPastedTokenLine(value) {
  return String(value ?? '')
    .trim()
    .replace(/^```(?:[a-z]+)?$/i, '')
    .replace(/^Bot\s+/i, '')
    .replace(/^`+|`+$/g, '')
    .trim();
}

function looksLikeDiscordToken(value) {
  const token = String(value ?? '');
  if (!/^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/.test(token)) return false;
  const [first, second, third] = token.split('.');
  // Discord tokens have three URL-safe segments. The bounds allow current and
  // older token lengths while preventing two separate tokens from being joined.
  return first.length >= 15 && first.length <= 32
    && second.length >= 4 && second.length <= 16
    && third.length >= 20 && third.length <= 100;
}

function parsePastedTokens(raw) {
  const lines = String(raw ?? '')
    .split(/\r?\n/)
    .map(cleanPastedTokenLine)
    .filter((line) => line && !/^```$/i.test(line));
  const tokens = [];
  const invalid = [];
  let pending = '';

  const pushComplete = (value) => {
    if (looksLikeDiscordToken(value)) tokens.push(value);
    else invalid.push(value);
  };

  for (const line of lines) {
    if (!/^[A-Za-z0-9._-]+$/.test(line)) {
      if (pending) {
        invalid.push(pending);
        pending = '';
      }
      invalid.push(line);
      continue;
    }

    if (!pending && looksLikeDiscordToken(line)) {
      tokens.push(line);
      continue;
    }

    if (pending) {
      const joined = `${pending}${line}`;
      if (looksLikeDiscordToken(joined)) {
        tokens.push(joined);
        pending = '';
        continue;
      }
      // A complete new token means the previous fragment was invalid rather
      // than part of it. Never concatenate two independent tokens.
      if (looksLikeDiscordToken(line)) {
        invalid.push(pending);
        tokens.push(line);
        pending = '';
        continue;
      }
      if (tokenDotCount(joined) <= 2 && joined.length <= 150) {
        pending = joined;
        continue;
      }
      invalid.push(pending);
    }
    pending = line;
  }

  if (pending) pushComplete(pending);
  return { tokens: workerTokens(tokens), invalidCount: invalid.length };
}

function saveTokens(tokens) {
  ensureDataDir();
  const temp = `${VAULT_FILE}.tmp`;
  fs.writeFileSync(temp, JSON.stringify(encryptTokens(tokens), null, 2), 'utf8');
  fs.renameSync(temp, VAULT_FILE);
}

function readStock() {
  try {
    if (!fs.existsSync(STOCK_FILE)) return { slots: {} };
    const value = JSON.parse(fs.readFileSync(STOCK_FILE, 'utf8'));
    return value && typeof value === 'object' && value.slots && typeof value.slots === 'object'
      ? value
      : { slots: {} };
  } catch (error) {
    console.error('[BOTS] Estoque indisponível:', error.message);
    return { slots: {} };
  }
}

function saveStock(stock) {
  ensureDataDir();
  const temp = `${STOCK_FILE}.tmp`;
  fs.writeFileSync(temp, JSON.stringify(stock, null, 2), 'utf8');
  fs.renameSync(temp, STOCK_FILE);
}

function clearExpiredReservations(stock) {
  const cutoff = Date.now() - 30 * 60 * 1000;
  for (const [slot, item] of Object.entries(stock.slots)) {
    if (item?.status === 'reservado' && Number(item.reservedAt) < cutoff) delete stock.slots[slot];
  }
}

function formatAge(timestamp) {
  if (!timestamp) return '';
  const seconds = Math.max(0, Math.floor((Date.now() - timestamp) / 1000));
  return seconds < 60 ? `${seconds}s` : `${Math.floor(seconds / 60)}min`;
}

class BotManager {
  constructor() {
    this.children = new Map();
    this.states = new Map();
    this.tokens = readTokens();
    this.startRun = null;
    this.stopRun = null;
  }

  importNumberedEnvironment() {
    if (this.tokens.length > 0) return;
    const tokens = Object.keys(process.env)
      .filter((key) => /^DISCORD_BOT_TOKEN_\d+$/.test(key) && process.env[key])
      .sort((a, b) => Number(a.split('_').pop()) - Number(b.split('_').pop()))
      .map((key) => process.env[key]);
    if (tokens.length > 0) {
      this.tokens = workerTokens(tokens);
      if (this.tokens.length === 0) return;
      saveTokens(this.tokens);
      console.log(`[BOTS] ${this.tokens.length} token(s) numerado(s) importado(s) para o cofre criptografado.`);
    }
  }

  async replaceTokens(raw) {
    if (!vaultKey()) return { ok: false, message: 'O painel está indisponível porque SESSION_SECRET não está configurado no host.' };
    const parsed = parsePastedTokens(raw);
    if (parsed.tokens.length === 0) {
      return {
        ok: false,
        message: parsed.invalidCount
          ? 'Não encontrei nenhum token Discord válido. Cole o token completo ou em linhas quebradas, sem alterar os caracteres.'
          : 'Cole pelo menos um token Discord.',
      };
    }
    if (parsed.tokens.length > MAX_BOTS) return { ok: false, message: `O limite é de ${MAX_BOTS} tokens por cadastro.` };
    const tokens = parsed.tokens;
    if (tokens.length === 0) return { ok: false, message: 'O token do TEAM RYZE é o controlador e não pode ser cadastrado no estoque.' };
    try {
      await this.stopAll();
      saveTokens(tokens);
      this.tokens = tokens;
      this.states = new Map(tokens.map((_, index) => [index + 1, { state: 'parado' }]));
      return {
        ok: true,
        count: tokens.length,
        ignored: parsed.invalidCount,
      };
    } catch (error) {
      console.error('[BOTS] Falha ao salvar tokens:', error.message);
      return { ok: false, message: 'Não foi possível salvar os tokens com segurança.' };
    }
  }

  async removeToken(slot) {
    const numericSlot = Number(slot);
    const tokenIndex = numericSlot - 1;
    if (!Number.isInteger(numericSlot) || tokenIndex < 0 || tokenIndex >= this.tokens.length) {
      return { ok: false, message: 'O token selecionado não está mais disponível.' };
    }

    try {
      await this.stopAll();
      const tokens = [...this.tokens];
      tokens.splice(tokenIndex, 1);
      saveTokens(tokens);
      this.tokens = tokens;
      this.states = new Map([
        [0, this.states.get(0) ?? { state: 'controlador' }],
        ...tokens.map((_, index) => [index + 1, { state: 'parado' }]),
      ]);

      // Os slots mudam de posição depois da remoção. Preserve o vínculo dos
      // bots restantes com o estoque e descarte somente o slot removido.
      const stock = readStock();
      const remappedSlots = {};
      for (const [key, value] of Object.entries(stock.slots ?? {})) {
        const oldSlot = Number(key);
        if (!Number.isInteger(oldSlot) || oldSlot === numericSlot) continue;
        const newSlot = oldSlot > numericSlot ? oldSlot - 1 : oldSlot;
        if (newSlot >= 1 && newSlot <= tokens.length) remappedSlots[String(newSlot)] = value;
      }
      saveStock({ ...stock, slots: remappedSlots });
      return { ok: true, slot: numericSlot };
    } catch (error) {
      console.error('[BOTS] Falha ao remover tokens:', error.message);
      return { ok: false, message: 'Não foi possível remover os tokens com segurança.' };
    }
  }

  startOne(slot, token) {
    if (this.children.has(slot)) return Promise.resolve({ ok: true, existing: true });
    if (token === process.env.DISCORD_BOT_TOKEN) {
      this.states.set(0, {
        state: 'controlador',
        tag: controllerClient?.user?.tag,
        id: controllerClient?.user?.id,
        startedAt: Date.now(),
      });
      schedulePanelRefresh();
      return Promise.resolve({ ok: true, controller: true });
    }
    const baseDataDir = process.env.BOT_DATA_DIR || path.join(__dirname, '..', 'data');
    const env = { ...process.env };
    for (const key of Object.keys(env)) {
      if (/^DISCORD_BOT_TOKEN_\d+$/.test(key)) delete env[key];
    }
    env.BOT_DATA_DIR = baseDataDir;
    env.DISCORD_BOT_TOKEN = token;
    let child;
    try {
      child = spawn(process.execPath, [path.join(__dirname, 'index.js'), '--worker'], {
        env,
        stdio: ['ignore', 'inherit', 'inherit', 'ipc'],
      });
    } catch (error) {
      this.states.set(slot, {
        state: 'erro',
        detail: `falha ao criar processo: ${String(error.message).slice(0, 100)}`,
      });
      schedulePanelRefresh();
      return Promise.resolve({ ok: false, error });
    }

    this.children.set(slot, child);
    this.states.set(slot, { state: 'iniciando', startedAt: Date.now() });

    return new Promise((resolve) => {
      let settled = false;
      let ready = false;
      const finish = (result) => {
        if (settled) return;
        settled = true;
        clearTimeout(timeout);
        resolve(result);
      };
      const timeout = setTimeout(() => {
        this.states.set(slot, {
          state: 'erro',
          detail: `tempo limite de inicialização (${Math.round(START_TIMEOUT_MS / 1000)}s)`,
        });
        schedulePanelRefresh();
        // Do not leave a stuck worker holding a connection slot forever.
        child.kill('SIGTERM');
        finish({ ok: false, timeout: true });
      }, START_TIMEOUT_MS);
      timeout.unref?.();

      child.on('message', (message) => {
        if (message?.type === 'ready') {
          ready = true;
          this.states.set(slot, { state: 'online', tag: message.tag, id: message.id, startedAt: Date.now() });
          schedulePanelRefresh();
          finish({ ok: true, ready: true });
        }
        if (message?.type === 'error') {
          this.states.set(slot, {
            state: 'erro',
            detail: String(message.message || 'falha de login').slice(0, 120),
          });
          schedulePanelRefresh();
          finish({ ok: false, error: message.message });
        }
        if (message?.type === 'guild_check_result') {
          const pending = pendingIpcRequests.get(message.requestId);
          if (pending) {
            pendingIpcRequests.delete(message.requestId);
            pending.resolve(Boolean(message.present));
          }
        }
        if (message?.type === 'leave_guild_result') {
          const pending = pendingIpcRequests.get(message.requestId);
          if (pending) {
            pendingIpcRequests.delete(message.requestId);
            pending.resolve(Boolean(message.ok));
          }
        }
      });
      child.on('error', (error) => {
        this.children.delete(slot);
        this.states.set(slot, {
          state: 'erro',
          detail: `processo indisponível: ${String(error.message).slice(0, 100)}`,
        });
        schedulePanelRefresh();
        finish({ ok: false, error });
      });
      child.on('exit', (code, signal) => {
        this.children.delete(slot);
        const previous = this.states.get(slot);
        if (!ready && previous?.state !== 'erro') {
          this.states.set(slot, {
            state: code === 0 || signal === 'SIGTERM' ? 'parado' : 'erro',
            detail: code === 0 || signal === 'SIGTERM' ? '' : 'processo encerrou',
          });
        }
        schedulePanelRefresh();
        if (!ready) finish({ ok: false, code, signal });
      });
    });
  }

  async startAll() {
    if (this.startRun) return this.startRun;
    if (this.stopRun) await this.stopRun;

    this.tokens = workerTokens(readTokens());
    if (this.tokens.length === 0) return { ok: false, message: 'Nenhum token cadastrado.' };

    const tokens = [...this.tokens];
    this.startRun = (async () => {
      let nextIndex = 0;
      const launchWorker = async () => {
        while (nextIndex < tokens.length) {
          const index = nextIndex++;
          const result = await this.startOne(index + 1, tokens[index]);
          if (!result.existing && nextIndex < tokens.length) await wait(START_DELAY_MS);
        }
      };
      const workerCount = Math.min(START_CONCURRENCY, tokens.length);
      await Promise.all(Array.from({ length: workerCount }, launchWorker));
      schedulePanelRefresh();
      return {
        ok: true,
        message: `Inicialização controlada concluída (${START_CONCURRENCY} processo(s) por vez).`,
      };
    })().finally(() => {
      this.startRun = null;
    });
    return this.startRun;
  }

  async stopAll() {
    if (this.stopRun) return this.stopRun;
    this.stopRun = (async () => {
    const children = [...this.children.values()];
    const exits = children.map((child) => new Promise((resolve) => {
      const done = () => resolve();
      child.once('exit', done);
      child.kill('SIGTERM');
      setTimeout(done, 3000).unref?.();
    }));
    await Promise.all(exits);
    this.children.clear();
    for (const [slot, state] of this.states) {
      if (state.state !== 'controlador') this.states.set(slot, { state: 'parado' });
    }
    schedulePanelRefresh();
    })().finally(() => {
      this.stopRun = null;
    });
    return this.stopRun;
  }

  snapshot() {
    this.tokens = workerTokens(readTokens());
    const rows = this.tokens.map((_, index) => {
      const slot = index + 1;
      return { slot, ...(this.states.get(slot) ?? { state: 'parado' }) };
    });
    if (controllerClient?.user?.id) {
      rows.unshift({ slot: 0, ...(this.states.get(0) ?? { state: 'controlador', id: controllerClient.user.id }) });
    }
    return rows;
  }

  setControllerClient(client) {
    controllerClient = client;
    const storedTokens = readTokens();
    const filteredTokens = workerTokens(storedTokens);
    if (filteredTokens.length !== storedTokens.length) {
      try {
        saveTokens(filteredTokens);
        console.log('[BOTS] Token do controlador removido do cofre de workers.');
      } catch (error) {
        console.error('[BOTS] Não foi possível limpar o token do controlador do cofre:', error.message);
      }
    }
    this.tokens = filteredTokens;
    this.states.set(0, {
      state: 'controlador',
      tag: client.user?.tag,
      id: client.user?.id,
      startedAt: Date.now(),
    });
  }

  stockSnapshot() {
    const stock = readStock();
    clearExpiredReservations(stock);
    const rows = this.snapshot();
    delete stock.slots['0'];
    const validSlots = new Set(rows.map((row) => String(row.slot)));
    for (const slot of Object.keys(stock.slots)) {
      if (!validSlots.has(slot)) delete stock.slots[slot];
    }
    saveStock(stock);
    return rows.map((row) => ({
      ...row,
      stockStatus: row.slot === 0 ? 'controlador' : (stock.slots[String(row.slot)]?.status ?? 'disponivel'),
    }));
  }

  reserveAvailable(metadata = {}) {
    const stock = readStock();
    clearExpiredReservations(stock);
    const rows = this.stockSnapshot();
    const candidate = rows.find((row) =>
      row.slot !== 0 && row.state === 'online' && row.stockStatus === 'disponivel' && row.id,
    );
    if (!candidate) {
      saveStock(stock);
      return { ok: false, message: 'Não há bots online disponíveis no estoque.' };
    }
    stock.slots[String(candidate.slot)] = {
      status: 'reservado',
      saleId: String(metadata.saleId ?? ''),
      guildId: String(metadata.guildId ?? ''),
      buyerId: String(metadata.buyerId ?? ''),
      reservedAt: Date.now(),
    };
    saveStock(stock);
    return { ok: true, slot: candidate.slot, botId: candidate.id, tag: candidate.tag };
  }

  confirmSale(slot, metadata = {}) {
    const stock = readStock();
    const current = stock.slots[String(slot)];
    if (current?.status === 'vendido' && current.saleId !== metadata.saleId) {
      return { ok: false, message: 'Este bot já foi vendido.' };
    }
    stock.slots[String(slot)] = {
      ...current,
      status: 'vendido',
      saleId: String(metadata.saleId ?? current?.saleId ?? ''),
      guildId: String(metadata.guildId ?? current?.guildId ?? ''),
      buyerId: String(metadata.buyerId ?? current?.buyerId ?? ''),
      botId: String(metadata.botId ?? current?.botId ?? ''),
      soldAt: Date.now(),
    };
    saveStock(stock);
    return { ok: true };
  }

  releaseReservation(slot, saleId = '') {
    const stock = readStock();
    const current = stock.slots[String(slot)];
    if (current?.status === 'reservado' && (!saleId || current.saleId === saleId)) {
      delete stock.slots[String(slot)];
      saveStock(stock);
    }
  }

  async isSlotInGuild(slot, guildId) {
    const numericSlot = Number(slot);
    if (controllerClient && numericSlot === 0) {
      return Boolean(controllerClient.guilds.cache.has(String(guildId)));
    }
    const child = this.children.get(numericSlot);
    if (!child?.connected) return false;
    const requestId = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    return new Promise((resolve) => {
      const timeout = setTimeout(() => {
        pendingIpcRequests.delete(requestId);
        resolve(false);
      }, 5000);
      pendingIpcRequests.set(requestId, {
        resolve: (value) => {
          clearTimeout(timeout);
          resolve(value);
        },
      });
      child.send({ type: 'guild_check', requestId, guildId: String(guildId) }, (error) => {
        if (error) {
          clearTimeout(timeout);
          pendingIpcRequests.delete(requestId);
          resolve(false);
        }
      });
    });
  }

  async removeSlotFromGuild(slot, guildId) {
    const numericSlot = Number(slot);
    const child = this.children.get(numericSlot);
    if (!child?.connected) return false;
    const requestId = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    return new Promise((resolve) => {
      const timeout = setTimeout(() => {
        pendingIpcRequests.delete(requestId);
        resolve(false);
      }, 10000);
      pendingIpcRequests.set(requestId, {
        resolve: (value) => {
          clearTimeout(timeout);
          resolve(value);
        },
      });
      child.send({ type: 'leave_guild', requestId, guildId: String(guildId) }, (error) => {
        if (error) {
          clearTimeout(timeout);
          pendingIpcRequests.delete(requestId);
          resolve(false);
        }
      });
    });
  }
}

const botManager = new BotManager();

function getOwnerRoleIds(guildId = null) {
  const roleIds = new Set();

  // 1. Ler data/app_config.json em tempo real
  try {
    const appConfigPath = dataPath('app_config.json');
    if (fs.existsSync(appConfigPath)) {
      const raw = fs.readFileSync(appConfigPath, 'utf8').trim();
      if (raw) {
        const cfg = JSON.parse(raw);
        if (cfg.ownerRoleId) roleIds.add(String(cfg.ownerRoleId).trim());
        if (cfg.BOT_OWNER_ROLE_ID) roleIds.add(String(cfg.BOT_OWNER_ROLE_ID).trim());
        if (cfg.CARGO_OWNER_ID) roleIds.add(String(cfg.CARGO_OWNER_ID).trim());
      }
    }
  } catch (_) {}

  // 2. Checar variáveis de ambiente
  if (process.env.BOT_OWNER_ROLE_ID) roleIds.add(String(process.env.BOT_OWNER_ROLE_ID).trim());
  if (process.env.CARGO_OWNER_ID) roleIds.add(String(process.env.CARGO_OWNER_ID).trim());
  if (process.env.OWNER_ROLE_ID) roleIds.add(String(process.env.OWNER_ROLE_ID).trim());

  // 3. Checar configurações do servidor (guild_configs.json)
  if (guildId) {
    try {
      const { getConfig } = require('./configurar');
      const gCfg = getConfig(guildId);
      if (gCfg?.roles?.admin) roleIds.add(String(gCfg.roles.admin).trim());
      if (gCfg?.roles?.dono) roleIds.add(String(gCfg.roles.dono).trim());
      if (gCfg?.roles?.owner) roleIds.add(String(gCfg.roles.owner).trim());
      if (gCfg?.adminRoleId) roleIds.add(String(gCfg.adminRoleId).trim());
    } catch (_) {}
  }

  return [...roleIds].filter(Boolean);
}

function isBotsOwner(member) {
  if (!member) return false;

  const userId = String(member.id || member.user?.id || '').trim();
  const guild = member.guild;
  const guildId = guild?.id || member.guildId;

  // 1. Dono do Servidor no Discord sempre tem acesso total de Dono
  if (guild && guild.ownerId && String(guild.ownerId).trim() === userId) {
    return true;
  }

  // 2. Administrador do Discord (permissão de Administrador)
  if (member.permissions) {
    try {
      if (typeof member.permissions.has === 'function') {
        if (member.permissions.has(PermissionFlagsBits.Administrator) || member.permissions.has(8n)) {
          return true;
        }
      }
    } catch (_) {}
  }

  // 3. Dono da Aplicação do Bot (Discord Developer Portal)
  if (member.client?.application?.owner) {
    const appOwner = member.client.application.owner;
    if (appOwner.id && String(appOwner.id).trim() === userId) return true;
    if (Array.isArray(appOwner.members) && appOwner.members.some((m) => String(m.user?.id || m.id).trim() === userId)) {
      return true;
    }
  }

  // 4. IDs de usuário fixos configurados como Dono
  const ownerUserIds = [
    process.env.BOT_OWNER_ID,
    process.env.BOT_OWNER_USER_ID,
    process.env.OWNER_ID,
    process.env.DONO_ID,
  ].filter(Boolean).map((id) => String(id).trim());
  if (ownerUserIds.includes(userId)) return true;

  // 5. Cargo de Dono configurado (lido dinamicamente de app_config.json, env e guild_configs)
  const ownerRoles = getOwnerRoleIds(guildId);
  if (ownerRoles.length === 0) return false;

  for (const roleId of ownerRoles) {
    if (!roleId) continue;
    if (member.roles?.cache?.has && member.roles.cache.has(roleId)) return true;
    if (Array.isArray(member._roles) && member._roles.includes(roleId)) return true;
    if (Array.isArray(member.roles) && member.roles.includes(roleId)) return true;
    if (member.roles?.cache && typeof member.roles.cache.has !== 'function' && Array.isArray(member.roles.cache) && member.roles.cache.includes(roleId)) {
      return true;
    }
  }

  return false;
}

function botsPanelPayload(message = null) {
  const rows = botManager.snapshot();
  const online = rows.filter((row) => row.state === 'online' || row.state === 'controlador').length;
  const details = rows.length
    ? rows.map((row) => {
      const suffix = row.tag ? ` — ${row.tag}` : row.detail ? ` — ${row.detail}` : '';
      const age = row.startedAt ? ` (${formatAge(row.startedAt)})` : '';
      return `**Bot ${row.slot}:** ${row.state}${suffix}${age}`;
    }).join('\n')
    : 'Nenhum token cadastrado.';
  const text =
    '## Gerenciamento de Bots\n\n' +
    'Cadastre vários tokens, um por linha, e inicie os bots no mesmo host. ' +
    'Os tokens são armazenados em cofre criptografado e nunca aparecem neste painel ou nos logs.\n\n' +
    `**Status:** ${online}/${rows.length} online\n\n${details}` +
    (message ? `\n\n**Resultado**\n${message}` : '');
  const container = new ContainerBuilder()
    .setAccentColor(0x2c2f33)
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(text))
    .addActionRowComponents(new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('bots:cadastrar').setLabel('Cadastrar tokens').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('bots:iniciar').setLabel('Iniciar').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId('bots:parar').setLabel('Parar').setStyle(ButtonStyle.Danger),
      new ButtonBuilder().setCustomId('bots:atualizar').setLabel('Atualizar').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('bots:remover').setLabel('Remover tokens').setStyle(ButtonStyle.Danger),
    ));
  return { components: [container], flags: MessageFlags.IsComponentsV2 };
}

function botsRemoveSelectPayload() {
  const rows = botManager.snapshot().filter((row) => row.slot !== 0);
  const container = new ContainerBuilder()
    .setAccentColor(0xed4245)
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(
      '## Remover token\n\n' +
      'Selecione o bot/token que deseja remover. O token real nunca é exibido neste painel.\n\n' +
      'Esta ação desligará os workers e removerá somente o token escolhido.',
    ));

  if (rows.length === 0) {
    container.addTextDisplayComponents(new TextDisplayBuilder().setContent('Nenhum token adicional está cadastrado.'));
    return { components: [container], flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral };
  }

  const select = new StringSelectMenuBuilder()
    .setCustomId('bots:remover:select')
    .setPlaceholder('Selecione o token que deseja remover')
    .setMinValues(1)
    .setMaxValues(1)
    .addOptions(rows.map((row) => ({
      label: `Bot ${row.slot}`,
      value: String(row.slot),
      description: `Status: ${row.state}`,
    })));

  container.addActionRowComponents(new ActionRowBuilder().addComponents(select));
  return { components: [container], flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral };
}

function botsModal() {
  return new ModalBuilder()
    .setCustomId('bots:modal_tokens')
    .setTitle('Cadastrar tokens')
    .addComponents(new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('tokens')
        .setLabel('Tokens — completos ou quebrados em linhas')
        .setPlaceholder('Cole os tokens; quebras de linha no meio são aceitas')
        .setStyle(TextInputStyle.Paragraph)
        .setRequired(true)
        .setMaxLength(4000),
    ));
}

function botsRemoveModal(slot) {
  return new ModalBuilder()
    .setCustomId(`bots:modal_remover_token:${slot}`)
    .setTitle(`Remover Bot ${slot}`)
    .addComponents(new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('confirmation')
        .setLabel('Digite REMOVER para confirmar')
        .setPlaceholder('REMOVER')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
        .setMaxLength(20),
    ));
}

function rememberBotsPanel(guildId, userId, message) {
  const key = `${guildId}:${userId}`;
  panelRefs.set(key, message);
  if (panelTimers.has(key)) clearInterval(panelTimers.get(key));
  const timer = setInterval(async () => {
    const current = panelRefs.get(key);
    if (!current) return;
    await current.edit(botsPanelPayload()).catch(() => {
      clearInterval(timer);
      panelTimers.delete(key);
      panelRefs.delete(key);
    });
  }, 5000);
  timer.unref?.();
  panelTimers.set(key, timer);
}

function refreshBotsPanels() {
  for (const [key, message] of panelRefs) {
    message.edit(botsPanelPayload()).catch(() => {
      panelRefs.delete(key);
      const timer = panelTimers.get(key);
      if (timer) clearInterval(timer);
      panelTimers.delete(key);
    });
  }
}

module.exports = {
  botManager,
  botsPanelPayload,
  botsRemoveSelectPayload,
  botsModal,
  botsRemoveModal,
  isBotsOwner,
  getOwnerRoleIds,
  rememberBotsPanel,
  refreshBotsPanels,
  setControllerClient: (client) => botManager.setControllerClient(client),
};