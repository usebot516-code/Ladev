'use strict';

const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  MessageFlags,
} = require('discord.js');
const os = require('os');

// Formata segundos em formato legível (Ex: 1d 4h 12m 30s)
function formatUptime(seconds) {
  const d = Math.floor(seconds / (3600 * 24));
  const h = Math.floor((seconds % (3600 * 24)) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);

  const parts = [];
  if (d > 0) parts.push(`${d}d`);
  if (h > 0 || d > 0) parts.push(`${h}h`);
  if (m > 0 || h > 0 || d > 0) parts.push(`${m}m`);
  parts.push(`${s}s`);
  return parts.join(' ');
}

// Gera o payload do painel de Ping / Status
function gerarPainelPing(client, interactionOrMessage) {
  const wsPing = Math.round(client.ws.ping);
  const uptimeSeconds = Math.floor(process.uptime());
  const uptimeStr = formatUptime(uptimeSeconds);

  // Informações de Memória
  const memUsage = process.memoryUsage();
  const heapUsedMB = (memUsage.heapUsed / 1024 / 1024).toFixed(1);
  const heapTotalMB = (memUsage.heapTotal / 1024 / 1024).toFixed(1);
  const rssMB = (memUsage.rss / 1024 / 1024).toFixed(1);

  // Status da Conexão
  let pingQuality = '🟢 Excelente';
  let pingColor = 0x10b981; // Verde

  if (wsPing < 0) {
    pingQuality = '⚪ Conectando...';
    pingColor = 0x6b7280;
  } else if (wsPing > 200) {
    pingQuality = '🔴 Alto';
    pingColor = 0xef4444; // Vermelho
  } else if (wsPing > 100) {
    pingQuality = '🟡 Médio';
    pingColor = 0xf59e0b; // Amarelo
  }

  // Guildas e Usuários
  const totalGuilds = client.guilds.cache.size;
  let totalMembers = 0;
  try {
    totalMembers = client.guilds.cache.reduce((acc, g) => acc + (g.memberCount || 0), 0);
  } catch (_) {}

  // Informações do Host
  const nodeVersion = process.version;
  const platform = `${os.type()} ${os.arch()}`;

  const embed = new EmbedBuilder()
    .setTitle('⚡ Status de Conexão & Latência')
    .setColor(pingColor)
    .setDescription(
      `Painel em tempo real com as métricas de rede, gateway e infraestrutura do **${client.user.username}**.`
    )
    .addFields(
      {
        name: '🌐 Conexão Discord Gateway',
        value: [
          `• **Latência WebSocket (Ping):** \`${wsPing >= 0 ? wsPing + 'ms' : 'Calculando...'}\` (${pingQuality})`,
          `• **Status:** \`${client.ws.status === 0 ? 'Conectado (READY)' : 'Reconectando'}\``,
          `• **Shards:** \`1 / 1\``,
        ].join('\n'),
        inline: false,
      },
      {
        name: '📊 Estatísticas do Bot',
        value: [
          `• **Servidores:** \`${totalGuilds.toLocaleString('pt-BR')}\``,
          `• **Usuários Monitorados:** \`${totalMembers.toLocaleString('pt-BR')}\``,
          `• **Uptime (Tempo Ativo):** \`${uptimeStr}\``,
        ].join('\n'),
        inline: true,
      },
      {
        name: '💻 Recursos & Servidor',
        value: [
          `• **Memória RAM Usada:** \`${heapUsedMB} MB\` / \`${heapTotalMB} MB\``,
          `• **Memória Total (RSS):** \`${rssMB} MB\``,
          `• **Node.js:** \`${nodeVersion}\``,
        ].join('\n'),
        inline: true,
      },
      {
        name: '🕒 Timestamp',
        value: `<t:${Math.floor(Date.now() / 1000)}:R> • <t:${Math.floor(Date.now() / 1000)}:F>`,
        inline: false,
      }
    )
    .setFooter({
      text: `${client.user.username} • Sistema de Monitoramento`,
      iconURL: client.user.displayAvatarURL({ dynamic: true }),
    })
    .setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('ping:atualizar')
      .setLabel('Atualizar Métricas')
      .setStyle(ButtonStyle.Primary)
      .setEmoji('🔄'),
    new ButtonBuilder()
      .setCustomId('ping:apagar')
      .setLabel('Fechar')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('🗑️')
  );

  return {
    embeds: [embed],
    components: [row],
  };
}

/**
 * Handler do Slash Command /ping
 */
async function handlePing(interaction, client) {
  try {
    const start = Date.now();
    await interaction.deferReply();
    const roundTrip = Date.now() - start;

    const payload = gerarPainelPing(client, interaction);
    
    // Adicionar round-trip da API se aplicável
    if (payload.embeds && payload.embeds[0]) {
      const embed = payload.embeds[0];
      embed.spliceFields(0, 1, {
        name: '🌐 Conexão Discord Gateway & API',
        value: [
          `• **Latência WebSocket (Ping):** \`${Math.round(client.ws.ping)}ms\``,
          `• **Latência REST (Round-trip):** \`${roundTrip}ms\``,
          `• **Status:** \`${client.ws.status === 0 ? 'Conectado (READY)' : 'Reconectando'}\``,
        ].join('\n'),
        inline: false,
      });
    }

    await interaction.editReply(payload);
    return true;
  } catch (err) {
    console.error('[PING] Erro ao responder /ping:', err.message);
    try {
      if (interaction.deferred || interaction.replied) {
        await interaction.editReply({ content: '❌ Erro ao obter dados de ping.' });
      } else {
        await interaction.reply({ content: '❌ Erro ao obter dados de ping.', flags: MessageFlags.Ephemeral });
      }
    } catch (_) {}
    return true;
  }
}

/**
 * Handler do comando de texto .ping
 */
async function handlePingMessage(message, client) {
  try {
    const start = Date.now();
    const msg = await message.reply('📡 *Calculando latência...*');
    const roundTrip = Date.now() - start;

    const payload = gerarPainelPing(client, message);
    if (payload.embeds && payload.embeds[0]) {
      const embed = payload.embeds[0];
      embed.spliceFields(0, 1, {
        name: '🌐 Conexão Discord Gateway & API',
        value: [
          `• **Latência WebSocket (Ping):** \`${Math.round(client.ws.ping)}ms\``,
          `• **Latência REST (Round-trip):** \`${roundTrip}ms\``,
          `• **Status:** \`${client.ws.status === 0 ? 'Conectado (READY)' : 'Reconectando'}\``,
        ].join('\n'),
        inline: false,
      });
    }

    await msg.edit(payload);
    return true;
  } catch (err) {
    console.error('[PING] Erro ao responder .ping:', err.message);
    return false;
  }
}

/**
 * Handler dos botões de interação do painel de ping (Atualizar / Fechar)
 */
async function handlePingInteraction(interaction, client) {
  const id = interaction.customId;
  if (!id.startsWith('ping:')) return false;

  try {
    if (id === 'ping:apagar') {
      await interaction.message.delete().catch(() => {});
      return true;
    }

    if (id === 'ping:atualizar') {
      const start = Date.now();
      await interaction.deferUpdate();
      const roundTrip = Date.now() - start;

      const payload = gerarPainelPing(client, interaction);
      if (payload.embeds && payload.embeds[0]) {
        const embed = payload.embeds[0];
        embed.spliceFields(0, 1, {
          name: '🌐 Conexão Discord Gateway & API',
          value: [
            `• **Latência WebSocket (Ping):** \`${Math.round(client.ws.ping)}ms\``,
            `• **Latência REST (Round-trip):** \`${roundTrip}ms\``,
            `• **Status:** \`${client.ws.status === 0 ? 'Conectado (READY)' : 'Reconectando'}\``,
          ].join('\n'),
          inline: false,
        });
      }

      await interaction.editReply(payload);
      return true;
    }
  } catch (err) {
    console.error('[PING] Erro na interação do ping:', err.message);
  }
  return true;
}

module.exports = {
  handlePing,
  handlePingMessage,
  handlePingInteraction,
  gerarPainelPing,
};
