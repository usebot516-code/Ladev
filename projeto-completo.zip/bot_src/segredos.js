'use strict';

const crypto = require('crypto');

function secretKey() {
  const secret = process.env.SESSION_SECRET;
  return secret ? crypto.createHash('sha256').update(secret).digest() : null;
}

function encryptSecret(value) {
  const key = secretKey();
  if (!key) throw new Error('SESSION_SECRET não configurado.');
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const data = Buffer.concat([cipher.update(String(value), 'utf8'), cipher.final()]);
  return {
    iv: iv.toString('base64'),
    tag: cipher.getAuthTag().toString('base64'),
    data: data.toString('base64'),
  };
}

function decryptSecret(value) {
  if (!value?.iv || !value?.tag || !value?.data) return '';
  const key = secretKey();
  if (!key) return '';
  try {
    const decipher = crypto.createDecipheriv(
      'aes-256-gcm',
      key,
      Buffer.from(value.iv, 'base64'),
    );
    decipher.setAuthTag(Buffer.from(value.tag, 'base64'));
    return Buffer.concat([
      decipher.update(Buffer.from(value.data, 'base64')),
      decipher.final(),
    ]).toString('utf8');
  } catch {
    return '';
  }
}

module.exports = { encryptSecret, decryptSecret, hasSecret: () => Boolean(secretKey()) };