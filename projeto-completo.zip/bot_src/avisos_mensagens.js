'use strict';

const fs = require('fs');
const path = require('path');
const { dataPath } = require('./data-path');

const DATA_FILE = dataPath('avisos_mensagens_data.json');

// Estas são as únicas mensagens autorizadas a receber emoji personalizado.
// O formulário do chat usa exatamente estas chaves e títulos.
const MENSAGENS = {
  fila_nao_encontrada: 'Fila — não encontrada',
  fila_sem_mediador: 'Fila — sem mediador disponível',
  fila_ja_esta: 'Fila — você já está na fila',
  fila_cheia: 'Fila — fila cheia',
  fila_entrou: 'Fila — você entrou',
  fila_saiu: 'Fila — você saiu',
  fila_nao_esta: 'Fila — você não está na fila',
  fila_url_invalida: 'Filas — URL inválida',
  fila_configurar_valores: 'Filas — valores não configurados',
  fila_canal_inacessivel: 'Filas — canal inacessível',
  mediador_cargo_nao_configurado: 'Mediadores — cargo não configurado',
  mediador_sem_cargo: 'Mediadores — cargo de mediador ausente',
  mediador_pix_necessario: 'Mediadores — PIX necessário',
  mediador_auto_ativo: 'Mediadores — mediação automática ativa',
  mediador_ja_esta: 'Mediadores — já está na fila',
  mediador_entrou: 'Mediadores — você entrou',
  mediador_saiu: 'Mediadores — você saiu',
  mediador_nao_esta: 'Mediadores — você não está na fila',
  mediador_pix_salvo: 'Mediadores — PIX salvo',
  mediador_pix_nao_cadastrado: 'Mediadores — PIX não cadastrado',
  analista_sem_cargo: 'Analistas — cargo de analista ausente',
  analista_entrou: 'Analistas — você entrou',
  analista_saiu: 'Analistas — você saiu',
  partida_jogadores_confirmar: 'Partida — somente jogadores podem confirmar',
  partida_jogadores_cancelar: 'Partida — somente jogadores podem cancelar',
  partida_cancelada: 'Partida — cancelada',
  partida_pix_copiar: 'Partida — chave PIX copiada',
  partida_mediador_restrito: 'Partida — acesso restrito ao mediador',
  partida_analista_indisponivel: 'Partida — analista indisponível',
  partida_analista_chamado: 'Partida — analista chamado',
  partida_valor_invalido: 'Partida — valor inválido',
  partida_valor_atualizado: 'Partida — valor atualizado',
  partida_resultado_pendente: 'Partida — resultado pendente',
  partida_encerrada: 'Partida — encerrada',
  partida_pix_nao_configurado: 'Partida — PIX não configurado',
  partida_pagamento_falhou: 'Partida — falha no pagamento',
  ticket_sem_categoria: 'Tickets — nenhuma categoria',
  ticket_ja_aberto: 'Tickets — já existe um ticket aberto',
  ticket_config_incompleta: 'Tickets — configuração incompleta',
  ticket_nao_abriu: 'Tickets — não foi possível criar o tópico',
  ticket_criador_acesso_falhou: 'Tickets — acesso do criador não confirmado',
  ticket_painel_falhou: 'Tickets — painel de gerenciamento não publicado',
  ticket_aberto: 'Tickets — ticket aberto',
  ticket_limite: 'Tickets — limite de categorias',
  ticket_indisponivel: 'Tickets — ticket indisponível',
  ticket_acesso_restrito: 'Tickets — acesso restrito',
  ticket_assumir_restrito: 'Tickets — atendente não autorizado',
  ticket_ja_assumido: 'Tickets — já assumido',
  ticket_aguarde: 'Tickets — aguarde',
  ticket_topico_indisponivel: 'Tickets — tópico indisponível',
  ticket_renomear_sem_nome: 'Tickets — nome ausente',
  ticket_renomear_falhou: 'Tickets — falha ao renomear',
  ticket_renomeado: 'Tickets — tópico renomeado',
  ticket_fechar_sem_permissao: 'Tickets — sem permissão para fechar',
  ticket_membro_sem_permissao: 'Tickets — sem permissão para adicionar membro',
  ticket_membro_adicionado: 'Tickets — membro adicionado',
  ticket_membro_falhou: 'Tickets — falha ao adicionar membro',
  ticket_fechamento_cancelado: 'Tickets — fechamento cancelado',
  ticket_confirmacao_expirada: 'Tickets — confirmação expirada',
  ticket_fechamento_andamento: 'Tickets — fechamento em andamento',
  ticket_encerrando: 'Tickets — encerrando',
  ticket_fechamento_falhou: 'Tickets — falha ao fechar',
  streamer_sem_acesso: 'Streamer — sem acesso',
  streamer_status_restrito: 'Streamer — alteração de status restrita',
  streamer_responsavel: 'Streamer — responsável não entra',
  streamer_offline: 'Streamer — fila off-line',
  streamer_ja_esta: 'Streamer — já está na fila',
  streamer_cheia: 'Streamer — fila cheia',
  streamer_nao_esta: 'Streamer — não está na fila',
  streamer_entrou: 'Streamer — você entrou',
  streamer_saiu: 'Streamer — você saiu',
  ticket_dados_incompletos: 'Tickets — dados incompletos',
  ticket_categoria_duplicada: 'Tickets — categoria duplicada',
  ticket_url_invalida: 'Tickets — URL inválida',
};

const DEFAULT_EMOJIS = {
  fila_nao_encontrada: '❌',
  fila_sem_mediador: '⚠️',
  fila_ja_esta: 'ℹ️',
  fila_cheia: '🚫',
  fila_entrou: '✅',
  fila_saiu: '🚪',
  fila_nao_esta: 'ℹ️',
  fila_url_invalida: '⚠️',
  fila_configurar_valores: '⚙️',
  fila_canal_inacessivel: '🔒',
  mediador_cargo_nao_configurado: '⚠️',
  mediador_sem_cargo: '🚫',
  mediador_pix_necessario: '💳',
  mediador_ja_esta: 'ℹ️',
  mediador_entrou: '✅',
  mediador_saiu: '🚪',
  mediador_nao_esta: 'ℹ️',
  mediador_pix_salvo: '✅',
  mediador_pix_nao_cadastrado: '⚠️',
  analista_sem_cargo: '🚫',
  analista_entrou: '✅',
  analista_saiu: '🚪',
  partida_jogadores_confirmar: '⚠️',
  partida_jogadores_cancelar: '⚠️',
  partida_cancelada: '❌',
  partida_pix_copiar: '📋',
  partida_mediador_restrito: '🔒',
  partida_analista_indisponivel: '⚠️',
  partida_analista_chamado: '📢',
  partida_valor_invalido: '⚠️',
  partida_valor_atualizado: '✅',
  partida_resultado_pendente: '⏳',
  partida_encerrada: '🏁',
  partida_pix_nao_configurado: '⚠️',
  partida_pagamento_falhou: '❌',
  ticket_sem_categoria: '⚠️',
  ticket_ja_aberto: 'ℹ️',
  ticket_config_incompleta: '⚙️',
  ticket_nao_abriu: '❌',
  ticket_criador_acesso_falhou: '⚠️',
  ticket_painel_falhou: '❌',
  ticket_aberto: '🎫',
  ticket_limite: '⚠️',
  ticket_indisponivel: '🚫',
  ticket_acesso_restrito: '🔒',
  ticket_assumir_restrito: '🔒',
  ticket_ja_assumido: 'ℹ️',
  ticket_aguarde: '⏳',
  ticket_topico_indisponivel: '🚫',
  ticket_renomear_sem_nome: '⚠️',
  ticket_renomear_falhou: '❌',
  ticket_renomeado: '✏️',
  ticket_fechar_sem_permissao: '🔒',
  ticket_membro_sem_permissao: '🔒',
  ticket_membro_adicionado: '✅',
  ticket_membro_falhou: '❌',
  ticket_fechamento_cancelado: '↩️',
  ticket_confirmacao_expirada: '⏰',
  ticket_fechamento_andamento: '⏳',
  ticket_encerrando: '🔒',
  ticket_fechamento_falhou: '❌',
  streamer_sem_acesso: '🔒',
  streamer_status_restrito: '🔒',
  streamer_responsavel: '⚠️',
  streamer_offline: '🔴',
  streamer_ja_esta: 'ℹ️',
  streamer_cheia: '🚫',
  streamer_nao_esta: 'ℹ️',
  streamer_entrou: '✅',
  streamer_saiu: '🚪',
  ticket_dados_incompletos: '⚠️',
  ticket_categoria_duplicada: '⚠️',
  ticket_url_invalida: '⚠️',
};

function lerDados() {
  try {
    if (!fs.existsSync(DATA_FILE)) return {};
    const dados = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    return dados && typeof dados === 'object' ? dados : {};
  } catch (error) {
    console.error('[AVISOS-MENSAGENS] Falha ao ler dados:', error.message);
    return {};
  }
}

const state = lerDados();
const emojisResolvidos = new Map();
const locaisCriados = new Map();

function salvarDados() {
  const temporario = `${DATA_FILE}.tmp`;
  try {
    fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
    fs.writeFileSync(temporario, JSON.stringify(state, null, 2), 'utf8');
    fs.renameSync(temporario, DATA_FILE);
  } catch (error) {
    console.error('[AVISOS-MENSAGENS] Falha ao salvar dados:', error.message);
  }
}

function configsDoServidor(guildId) {
  if (!guildId) return {};
  if (!state[guildId] || typeof state[guildId] !== 'object') state[guildId] = {};
  return state[guildId];
}

function normalizarEmoji(valor) {
  const emoji = String(valor ?? '').trim();
  if (!emoji) return null;
  const personalizado = emoji.match(/^<(a?):([A-Za-z0-9_~]+):(\d+)>$/);
  if (!personalizado) return null;
  return `<${personalizado[1]}:${personalizado[2]}:${personalizado[3]}>`;
}

function definirEmoji(guildId, chave, valor) {
  if (!Object.prototype.hasOwnProperty.call(MENSAGENS, chave)) return false;
  const config = configsDoServidor(guildId);
  const emoji = normalizarEmoji(valor);
  if (emoji) config[chave] = emoji;
  else delete config[chave];
  salvarDados();
  return true;
}

function emojiDaMensagem(guildId, chave) {
  if (!Object.prototype.hasOwnProperty.call(MENSAGENS, chave)) return '';
  const configurado = configsDoServidor(guildId)[chave] ?? '';
  if (!configurado) return DEFAULT_EMOJIS[chave] ?? '';
  const id = configurado.match(/^<a?:[A-Za-z0-9_~]+:(\d+)>$/)?.[1];
  return (id && emojisResolvidos.get(id)) || configurado || DEFAULT_EMOJIS[chave] || '';
}

function removerEmojisIniciais(texto) {
  if (!texto || typeof texto !== 'string') return '';
  return texto.replace(/^(\s*(?:<a?:[a-zA-Z0-9_~]+:\d+>|[\p{Extended_Pictographic}\p{Emoji_Presentation}\u200d\ufe0f\u20e3\u2600-\u27bf])\s*)+/u, '').trim();
}

function mensagem(guildId, chave, texto) {
  const emoji = emojiDaMensagem(guildId, chave);
  const textoLimpo = removerEmojisIniciais(texto);
  return emoji ? `${emoji} ${textoLimpo}` : textoLimpo;
}

async function verificarEmojis(client) {
  const ids = new Map();
  for (const config of Object.values(state)) {
    for (const valor of Object.values(config ?? {})) {
      const match = String(valor ?? '').match(/^<a?:([A-Za-z0-9_~]+):(\d+)>$/);
      if (match) {
        ids.set(match[2], {
          nome: match[1],
          animado: match[0].startsWith('<a:'),
        });
      }
    }
  }

  for (const guildId of Object.keys(state)) {
    const guild = client.guilds.cache.get(guildId);
    if (!guild) continue;
    const configs = configsDoServidor(guild.id);
    if (!configs.__locais || typeof configs.__locais !== 'object') configs.__locais = {};

    for (const [id, dados] of ids) {
      let encontrado = guild.emojis.cache.get(id) ?? null;

      if (!encontrado) {
        const local = configs.__locais[id];
        encontrado = local?.id ? guild.emojis.cache.get(local.id) ?? null : null;
      }

      if (!encontrado) {
        try {
          const extensao = dados.animado ? 'gif' : 'png';
          const resposta = await fetch(`https://cdn.discordapp.com/emojis/${id}.${extensao}?size=128&quality=lossless`);
          if (!resposta.ok) throw new Error(`CDN respondeu HTTP ${resposta.status}`);
          const imagem = Buffer.from(await resposta.arrayBuffer());
          const nomeLocal = String(dados.nome || 'emoji')
            .replace(/[^A-Za-z0-9_~]/g, '_')
            .slice(0, 32) || 'emoji';
          encontrado = await guild.emojis.create({
            attachment: imagem,
            name: nomeLocal,
            reason: 'Criar cópia local para mensagens informativas do bot',
          });
          configs.__locais[id] = {
            id: encontrado.id,
            nome: encontrado.name,
            animado: encontrado.animated,
          };
          for (const [chave, valor] of Object.entries(configs)) {
            if (typeof valor !== 'string') continue;
            const origem = valor.match(/^<a?:[A-Za-z0-9_~]+:(\d+)>$/);
            if (origem?.[1] === id) {
              configs[chave] = encontrado.toString();
            }
          }
          salvarDados();
          console.log(`[EMOJIS] Cópia local de ${dados.nome} criada em "${guild.name}" como ${encontrado.toString()}.`);
        } catch (error) {
          console.warn(`[EMOJIS] Não foi possível criar cópia local de ${dados.nome} (${id}) em "${guild.name}": ${error.code ?? error.message}. O bot precisa de "Gerenciar expressões" no servidor.`);
        }
      }

      if (encontrado) {
        const representacao = encontrado.toString();
        emojisResolvidos.set(id, representacao);
        locaisCriados.set(`${guild.id}:${id}`, representacao);
      }
    }
  }
}

module.exports = {
  MENSAGENS,
  definirEmoji,
  emojiDaMensagem,
  mensagem,
  normalizarEmoji,
  verificarEmojis,
};