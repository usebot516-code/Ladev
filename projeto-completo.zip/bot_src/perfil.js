'use strict';

const fs = require('fs');
const path = require('path');
const { EmbedBuilder, MessageFlags } = require('discord.js');
const { createCanvas, loadImage } = require('@napi-rs/canvas');
const { dataPath } = require('./data-path');

const DATA_FILE = dataPath('perfil_data.json');

function _ler() {
  try {
    return fs.existsSync(DATA_FILE)
      ? JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'))
      : {};
  } catch (error) {
    console.error('[PERFIL] Falha ao ler dados:', error.message);
    return {};
  }
}

const _dados = _ler();
const TIMEOUT_PERFIL_MS = 8000;

function _comTimeout(promise, timeoutMs = TIMEOUT_PERFIL_MS, label = 'operação') {
  let timer;
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error(`Tempo limite excedido em ${label}`)), timeoutMs);
  });
  return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
}

let _saving = false;
let _savePending = false;
function _salvar() {
  if (_saving) {
    _savePending = true;
    return;
  }
  _saving = true;
  const tmp = `${DATA_FILE}.tmp`;
  try {
    fs.writeFile(tmp, JSON.stringify(_dados, null, 2), 'utf8', (err) => {
      if (!err) {
        fs.rename(tmp, DATA_FILE, () => {
          _saving = false;
          if (_savePending) {
            _savePending = false;
            _salvar();
          }
        });
      } else {
        _saving = false;
      }
    });
  } catch (error) {
    _saving = false;
  }
}

function _guild(guildId) {
  if (!_dados[guildId]) _dados[guildId] = {};
  return _dados[guildId];
}

function _userData(guildId, userId) {
  const guild = _guild(guildId);
  if (!guild[userId]) guild[userId] = { msgId: null, wins: [] };
  if (!Array.isArray(guild[userId].wins)) guild[userId].wins = [];
  if (!Array.isArray(guild[userId].matches)) guild[userId].matches = [];
  return guild[userId];
}

function _spDate(value) {
  const date = new Date(value);
  return new Date(date.toLocaleString('en-US', { timeZone: 'America/Sao_Paulo' }));
}

function _startOfDay() {
  const date = _spDate(new Date());
  return new Date(date.getFullYear(), date.getMonth(), date.getDate());
}

function _startOfWeek() {
  const date = _spDate(new Date());
  const day = date.getDay();
  const mondayOffset = day === 0 ? -6 : 1 - day;
  return new Date(date.getFullYear(), date.getMonth(), date.getDate() + mondayOffset);
}

function _getStats(guildId, userId) {
  const data = _userData(guildId, userId);
  // Registros antigos só guardavam vitórias. Eles continuam contando como
  // partidas vencidas para não apagar o histórico já existente.
  const historicoAntigo = data.wins.map((win) => ({ ...win, resultado: 'vitoria' }));
  const partidas = [...historicoAntigo, ...data.matches]
    .filter((partida) => partida && partida.date)
    .sort((a, b) => new Date(a.date) - new Date(b.date));
  const vitorias = partidas.filter((partida) => partida.resultado === 'vitoria').length;
  const derrotas = partidas.filter((partida) => partida.resultado === 'derrota').length;
  let consecutivas = 0;
  for (let index = partidas.length - 1; index >= 0; index -= 1) {
    if (partidas[index].resultado !== 'vitoria') break;
    consecutivas += 1;
  }

  return {
    vitorias,
    derrotas,
    partidas: vitorias + derrotas,
    consecutivas,
    taxa: vitorias + derrotas > 0 ? Math.round((vitorias / (vitorias + derrotas)) * 100) : 0,
  };
}

function registrarVitoria(guildId, userId, tipo) {
  const data = _userData(guildId, userId);
  data.wins.push({
    date: new Date().toISOString(),
    tipo: tipo ?? 'Não especificado',
  });
  _salvar();
  console.log(`[PERFIL] Vitória registrada — guild=${guildId} user=${userId} tipo=${tipo}`);
}

function registrarPartida(guildId, jogadorIds, vencedorId, tipo) {
  const data = new Date().toISOString();
  const jogadores = [...new Set((jogadorIds ?? []).filter(Boolean))];
  for (const userId of jogadores) {
    const perfil = _userData(guildId, userId);
    perfil.matches.push({
      date: data,
      resultado: userId === vencedorId ? 'vitoria' : 'derrota',
      tipo: tipo ?? 'Não especificado',
    });
  }
  _salvar();
  console.log(`[PERFIL] Partida registrada — guild=${guildId} jogadores=${jogadores.length} vencedor=${vencedorId}`);
}

function obterEstatisticas(guildId, userId) {
  return _getStats(guildId, userId);
}

function obterRankingVitorias(guildId, dias) {
  const limite = Date.now() - (Number(dias) * 24 * 60 * 60 * 1000);
  const ranking = new Map();
  const guild = _dados[guildId] ?? {};

  for (const [userId, data] of Object.entries(guild)) {
    const vitorias = [
      ...(Array.isArray(data?.wins) ? data.wins.map((item) => ({ ...item, resultado: 'vitoria' })) : []),
      ...(Array.isArray(data?.matches) ? data.matches : []),
    ].filter((partida) => partida?.resultado === 'vitoria' && new Date(partida.date).getTime() >= limite).length;
    if (vitorias > 0) ranking.set(userId, vitorias);
  }

  return [...ranking.entries()]
    .map(([userId, vitorias]) => ({ userId, vitorias }))
    .sort((a, b) => b.vitorias - a.vitorias || a.userId.localeCompare(b.userId));
}

function _hexColor(color) {
  return `#${Number(color ?? 0x5865f2).toString(16).padStart(6, '0').slice(-6)}`;
}

function _roundRect(ctx, x, y, width, height, radius) {
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.arcTo(x + width, y, x + width, y + height, radius);
  ctx.arcTo(x + width, y + height, x, y + height, radius);
  ctx.arcTo(x, y + height, x, y, radius);
  ctx.arcTo(x, y, x + width, y, radius);
  ctx.closePath();
}

async function _gerarImagemPerfil({ displayName, username, avatarUrl, stats, color }) {
  const width = 1200;
  const height = 640;
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');
  const accent = _hexColor(color);

  const background = ctx.createLinearGradient(0, 0, width, height);
  background.addColorStop(0, '#101827');
  background.addColorStop(1, '#172b45');
  ctx.fillStyle = background;
  ctx.fillRect(0, 0, width, height);

  ctx.globalAlpha = 0.22;
  ctx.fillStyle = accent;
  ctx.beginPath();
  ctx.arc(width - 60, 42, 280, 0, Math.PI * 2);
  ctx.fill();
  ctx.globalAlpha = 1;

  _roundRect(ctx, 42, 42, width - 84, height - 84, 28);
  ctx.fillStyle = 'rgba(5, 12, 24, 0.62)';
  ctx.fill();
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.12)';
  ctx.lineWidth = 2;
  ctx.stroke();

  ctx.fillStyle = accent;
  _roundRect(ctx, 72, 74, 8, 176, 4);
  ctx.fill();

  if (avatarUrl) {
    try {
      const avatar = await _comTimeout(loadImage(avatarUrl), TIMEOUT_PERFIL_MS, 'carregamento do avatar');
      ctx.save();
      ctx.beginPath();
      ctx.arc(170, 166, 86, 0, Math.PI * 2);
      ctx.clip();
      ctx.drawImage(avatar, 84, 80, 172, 172);
      ctx.restore();
      ctx.strokeStyle = accent;
      ctx.lineWidth = 6;
      ctx.beginPath();
      ctx.arc(170, 166, 89, 0, Math.PI * 2);
      ctx.stroke();
    } catch (error) {
      console.warn('[PERFIL] Avatar indisponível; continuando sem avatar:', error.message);
    }
  }

  ctx.fillStyle = '#f7fbff';
  ctx.font = '700 46px sans-serif';
  ctx.fillText(String(displayName).slice(0, 25), 294, 146);
  ctx.fillStyle = '#9fb2c8';
  ctx.font = '26px sans-serif';
  ctx.fillText(String(username).slice(0, 32), 298, 190);
  ctx.fillStyle = accent;
  ctx.font = '700 21px sans-serif';
  ctx.fillText('PERFIL DE JOGADOR', 298, 232);

  [
    { label: ['VITÓRIAS'], value: stats.vitorias },
    { label: ['DERROTAS'], value: stats.derrotas },
    { label: ['PARTIDAS'], value: stats.partidas },
    { label: ['VITÓRIAS', 'CONSECUTIVAS'], value: stats.consecutivas },
    { label: ['TAXA DE', 'VITÓRIAS'], value: `${stats.taxa}%` },
  ].forEach((card, index) => {
    const x = 70 + index * 215;
    const y = 330;
    _roundRect(ctx, x, y, 202, 188, 18);
    ctx.fillStyle = 'rgba(255, 255, 255, 0.055)';
    ctx.fill();
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.10)';
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.fillStyle = '#ffffff';
    ctx.font = '700 52px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(String(card.value), x + 101, y + 91);
    ctx.fillStyle = '#9fb2c8';
    ctx.font = '700 14px sans-serif';
    card.label.forEach((line, lineIndex) => {
      ctx.fillText(line, x + 101, y + 137 + lineIndex * 19);
    });
    ctx.textAlign = 'left';
  });

  ctx.fillStyle = '#71859d';
  ctx.font = '18px sans-serif';
  ctx.fillText('Dados registrados pelo sistema de partidas', 86, 570);
  return canvas.toBuffer('image/png');
}

async function _montarPayload(guildId, userId, client, userForProfile = null) {
  const { getConfig } = require('./configurar');
  const color = getConfig(guildId)?.embedColor ?? 0x5865f2;
  const stats = _getStats(guildId, userId);
  const user = userForProfile
    ?? client.users.cache.get(userId)
    ?? await _comTimeout(client.users.fetch(userId), TIMEOUT_PERFIL_MS, 'busca do usuário').catch((error) => {
      console.warn('[PERFIL] Não foi possível buscar o usuário; usando menção:', error.message);
      return null;
    });
  const displayName = user?.globalName ?? user?.username ?? `Membro ${userId.slice(-4)}`;
  const username = user?.username ? `@${user.username}` : `<@${userId}>`;
  const avatarUrl = user?.displayAvatarURL({ extension: 'png', size: 256 }) ?? null;
  const image = await _gerarImagemPerfil({
    displayName,
    username,
    avatarUrl,
    stats,
    color,
  });

  return {
    embeds: [
      new EmbedBuilder()
        .setColor(color)
        .setTitle('Estatísticas do jogador')
        .setDescription(`Perfil de <@${userId}>`)
        .setImage('attachment://perfil-estatisticas.png'),
    ],
    files: [{ attachment: image, name: 'perfil-estatisticas.png' }],
    allowedMentions: { users: [userId] },
  };
}

async function _publicarPerfil(channel, guildId, userId, client, userForProfile = null) {
  console.log(`[PERFIL] Gerando perfil — guild=${guildId} user=${userId}`);
  const payload = await _montarPayload(guildId, userId, client, userForProfile);
  const data = _userData(guildId, userId);
  let updated = false;

  if (data.msgId) {
    const message = await _comTimeout(channel.messages.fetch(data.msgId), TIMEOUT_PERFIL_MS, 'busca da mensagem do perfil').catch(() => null);
    if (message) {
      await _comTimeout(message.edit(payload), TIMEOUT_PERFIL_MS, 'atualização da mensagem do perfil');
      updated = true;
    } else {
      data.msgId = null;
    }
  }

  if (!updated) {
    const message = await _comTimeout(channel.send(payload), TIMEOUT_PERFIL_MS, 'envio da mensagem do perfil');
    data.msgId = message.id;
  }
  _salvar();
  console.log(`[PERFIL] Perfil publicado — guild=${guildId} user=${userId}`);
}

async function _validarCanalPerfil(channel, guildId, reply) {
  const { getConfig } = require('./configurar');
  const channelId = getConfig(guildId)?.channels?.ponto ?? null;
  if (!channelId) {
    await reply('O canal de perfil não foi configurado. Use `configurar` → Canais → Canal de Ponto para definir.');
    return false;
  }
  if (channel.id !== channelId) {
    await reply(`Este comando só pode ser usado em <#${channelId}>.`);
    return false;
  }
  return true;
}

async function handlePerfilMessage(message, client) {
  if (!(await _validarCanalPerfil(message.channel, message.guildId, (text) => message.reply(text)))) return true;
  const target = message.mentions.users.first() ?? message.author;
  console.log(`[PERFIL] Gerando .p para ${target.id}`);
  try {
    await _publicarPerfil(message.channel, message.guildId, target.id, client, target);
  } catch (error) {
    console.error('[PERFIL] Falha ao enviar estatísticas:', error.message);
    await message.reply('Não consegui gerar as estatísticas neste momento.').catch(() => {});
  }
  return true;
}

async function handlePerfil(interaction, client) {
  if (!interaction.isChatInputCommand() || interaction.commandName !== 'p') return false;
  const { getConfig } = require('./configurar');
  const channelId = getConfig(interaction.guildId)?.channels?.ponto ?? null;
  if (!channelId) {
    await interaction.reply({
      content: '⚠️ O canal de perfil não foi configurado. Use `/configurar` ➔ **Canais** ➔ **Canal de Ponto**.',
      flags: MessageFlags.Ephemeral,
    });
    return true;
  }
  if (interaction.channelId !== channelId) {
    await interaction.reply({
      content: `🔒 Este comando só pode ser usado em <#${channelId}>.`,
      flags: MessageFlags.Ephemeral,
    });
    return true;
  }

  const userId = interaction.options.getUser('membro')?.id ?? interaction.user.id;
  const selectedUser = interaction.options.getUser('membro') ?? interaction.user;
  await interaction.deferReply({ flags: MessageFlags.Ephemeral });
  try {
    const channel = await client.channels.fetch(channelId);
    await _publicarPerfil(channel, interaction.guildId, userId, client, selectedUser);
    await interaction.editReply({ content: '✅ Perfil atualizado no canal configurado.' });
  } catch (error) {
    console.error('[PERFIL] Falha ao enviar estatísticas:', error.message);
    await interaction.editReply({ content: '❌ Não consegui gerar as estatísticas neste momento.' });
  }
  return true;
}

module.exports = {
  handlePerfil,
  handlePerfilMessage,
  registrarVitoria,
  registrarPartida,
  obterEstatisticas,
  obterRankingVitorias,
};