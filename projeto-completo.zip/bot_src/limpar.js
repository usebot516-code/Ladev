'use strict';

const {
  MessageFlags,
  PermissionFlagsBits,
} = require('discord.js');

const LIMITE_IDADE_EXCLUSAO_EM_MASSA = 14 * 24 * 60 * 60 * 1000;

function podeGerenciarMensagens(interaction) {
  return Boolean(interaction.member?.permissions?.has(PermissionFlagsBits.ManageMessages));
}

function botPodeGerenciarMensagens(interaction) {
  const botMembro = interaction.guild?.members?.me;
  const permissoes = botMembro && interaction.channel?.permissionsFor(botMembro);
  return Boolean(permissoes?.has(PermissionFlagsBits.ManageMessages));
}

async function apagarMensagens(channel, quantidade) {
  let apagadas = 0;
  let tentativasSemProgresso = 0;

  while (apagadas < quantidade && tentativasSemProgresso < 1) {
    const restante = quantidade - apagadas;
    const mensagens = await channel.messages.fetch({ limit: Math.min(100, restante) });
    if (!mensagens.size) break;

    const candidatas = [...mensagens.values()].slice(0, restante);
    const recentes = candidatas.filter(
      (mensagem) => Date.now() - mensagem.createdTimestamp < LIMITE_IDADE_EXCLUSAO_EM_MASSA,
    );
    const antigas = candidatas.filter(
      (mensagem) => Date.now() - mensagem.createdTimestamp >= LIMITE_IDADE_EXCLUSAO_EM_MASSA,
    );
    let progresso = 0;

    if (recentes.length) {
      try {
        const removidas = await channel.bulkDelete(recentes, true);
        progresso += removidas.size;
      } catch (error) {
        console.warn('[LIMPAR] Exclusão em massa falhou; tentando mensagens individualmente:', error.message);
        for (const mensagem of recentes) {
          try {
            await mensagem.delete();
            progresso += 1;
          } catch (_) {
            // A mensagem pode ter sido removida ou não estar mais acessível.
          }
        }
      }
    }

    for (const mensagem of antigas) {
      try {
        await mensagem.delete();
        progresso += 1;
      } catch (_) {
        // O Discord pode recusar mensagens sem acesso ou já removidas.
      }
    }

    apagadas += progresso;
    if (progresso === 0) tentativasSemProgresso += 1;
  }

  return apagadas;
}

async function handleLimpar(interaction) {
  if (!interaction.isChatInputCommand() || interaction.commandName !== 'limpar') return false;

  if (!interaction.guild) {
    await interaction.reply({
      content: '⚠️ Este comando só pode ser usado em um servidor.',
      flags: MessageFlags.Ephemeral,
    });
    return true;
  }

  if (!podeGerenciarMensagens(interaction)) {
    await interaction.reply({
      content: '🔒 Você precisa da permissão **Gerenciar mensagens** para usar este comando.',
      flags: MessageFlags.Ephemeral,
    });
    return true;
  }

  if (!botPodeGerenciarMensagens(interaction)) {
    await interaction.reply({
      content: '🔒 Eu preciso da permissão **Gerenciar mensagens** neste canal para apagar mensagens.',
      flags: MessageFlags.Ephemeral,
    });
    return true;
  }

  const quantidade = interaction.options.getInteger('quantidade', true);
  if (!Number.isInteger(quantidade) || quantidade < 1 || quantidade > 1000) {
    await interaction.reply({
      content: '⚠️ A quantidade deve ser um número inteiro entre 1 e 1000.',
      flags: MessageFlags.Ephemeral,
    });
    return true;
  }

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });
  try {
    const apagadas = await apagarMensagens(interaction.channel, quantidade);
    await interaction.editReply({
      content: apagadas
        ? `🗑️ Foram apagadas **${apagadas}** mensagem(ns) neste canal.`
        : 'ℹ️ Não encontrei mensagens que eu pudesse apagar neste canal.',
    });
    console.log(`[LIMPAR] guild=${interaction.guildId} canal=${interaction.channelId} solicitadas=${quantidade} apagadas=${apagadas} usuário=${interaction.user.id}`);
  } catch (error) {
    console.error('[LIMPAR] Falha ao apagar mensagens:', error.message);
    await interaction.editReply({
      content: '❌ Não consegui apagar as mensagens. Verifique se o canal permite gerenciar mensagens.',
    });
  }

  return true;
}

module.exports = { handleLimpar };