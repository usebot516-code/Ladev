'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const {
  EmbedBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  RoleSelectMenuBuilder,
  ChannelSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ChannelType,
  MessageFlags,
  PermissionFlagsBits,
} = require('discord.js');
const { getConfig } = require('./configurar');
const { painelV2FromEmbed, renovarUrlImagem } = require('./visual');
const { dataPath } = require('./data-path');

const DATA_FILE = dataPath('sorteios_data.json');
const state = readData();

// Mapas temporários de sessão por usuário: guildId:userId -> draft
const drafts = new Map();
const editingSorteio = new Map();

function readData() {
  try {
    return fs.existsSync(DATA_FILE) ? JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')) : {};
  } catch (error) {
    console.error('[SORTEIOS] Falha ao ler dados:', error.message);
    return {};
  }
}

let _saving = false;
let _savePending = false;
function saveData() {
  if (_saving) {
    _savePending = true;
    return;
  }
  _saving = true;
  const tmp = `${DATA_FILE}.tmp`;
  try {
    fs.mkdir(path.dirname(DATA_FILE), { recursive: true }, () => {
      fs.writeFile(tmp, JSON.stringify(state, null, 2), 'utf8', (err) => {
        if (!err) {
          fs.rename(tmp, DATA_FILE, () => {
            _saving = false;
            if (_savePending) {
              _savePending = false;
              saveData();
            }
          });
        } else {
          _saving = false;
        }
      });
    });
  } catch (error) {
    _saving = false;
  }
}

function defaultGuild() {
  return {
    sorteios: [],
    paineis: [],
  };
}

function guildState(guildId) {
  if (!state[guildId]) state[guildId] = defaultGuild();
  if (!Array.isArray(state[guildId].sorteios)) state[guildId].sorteios = [];
  if (!Array.isArray(state[guildId].paineis)) state[guildId].paineis = [];
  return state[guildId];
}

function color(guildId) {
  const c = getConfig(guildId)?.embed_cor;
  if (!c) return 0x2b2d31;
  const parsed = parseInt(String(c).replace('#', ''), 16);
  return isNaN(parsed) ? 0x2b2d31 : parsed;
}

function truncate(str, max = 100) {
  if (!str) return '';
  return str.length > max ? `${str.slice(0, max - 3)}...` : str;
}

// Converte string de data "DD/MM/AAAA HH:mm" ou "DD/MM HH:mm" para ISO String
function parseDataEncerramento(input) {
  if (!input || typeof input !== 'string') return null;
  const raw = input.trim();
  const match = raw.match(/^(\d{1,2})\/(\d{1,2})(?:\/(\d{4}))?(?:\s+(\d{1,2}):(\d{2}))?$/);
  if (!match) return null;

  const dia = parseInt(match[1], 10);
  const mes = parseInt(match[2], 10) - 1; // 0-indexed
  const now = new Date();
  const ano = match[3] ? parseInt(match[3], 10) : now.getFullYear();
  const hora = match[4] !== undefined ? parseInt(match[4], 10) : 23;
  const min = match[5] !== undefined ? parseInt(match[5], 10) : 59;

  if (dia < 1 || dia > 31 || mes < 0 || mes > 11 || hora < 0 || hora > 23 || min < 0 || min > 59) {
    return null;
  }

  const d = new Date(ano, mes, dia, hora, min, 0);
  if (isNaN(d.getTime())) return null;
  return d.toISOString();
}

function formatDataLegivel(isoStr) {
  if (!isoStr) return 'Manual (Sem data programada)';
  try {
    const d = new Date(isoStr);
    if (isNaN(d.getTime())) return 'Manual';
    const timestampSec = Math.floor(d.getTime() / 1000);
    return `<t:${timestampSec}:F> (<t:${timestampSec}:R>)`;
  } catch (e) {
    return 'Manual';
  }
}

function getDraft(guildId, userId) {
  const key = `${guildId}:${userId}`;
  if (!drafts.has(key)) {
    drafts.set(key, {
      titulo: 'Grande Sorteio',
      descricao: 'Clique no botão abaixo para entrar e concorrer ao prêmio!',
      banner: null,
      thumbnail: null,
      premioTipo: null, // 'role' | 'custom'
      premioNome: null,
      premioDescricao: null,
      roleId: null,
      bonusRoleId: null,
      bonusChances: null,
      tempBonusRoleId: null,
      dataSorteio: null, // ISO String ou null (sorteio manual)
      ganhadores: 1,
    });
  }
  return drafts.get(key);
}

function resetDraft(guildId, userId) {
  drafts.delete(`${guildId}:${userId}`);
}

// ─── Paineis Administrativos ──────────────────────────────────────────────────

function mainPanel(guildId, notice = '') {
  const data = guildState(guildId);
  const ativos = data.sorteios.filter((s) => s.status === 'ativo').length;
  const encerrados = data.sorteios.filter((s) => s.status === 'encerrado' || s.status === 'revogado').length;

  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle('PAINEL DE SORTEIOS')
    .setDescription(`${notice ? `${notice}\n\n` : ''}Gerencie os sorteios do servidor, configure a aparência, defina os prêmios, cargos com chances extras, data de encerramento e realize publicações automáticas.`)
    .addFields(
      { name: 'Sorteios Cadastrados', value: `${data.sorteios.length} no total (🟢 ${ativos} ativos • 🔴 ${encerrados} finalizados/revogados)`, inline: false },
    );

  const selectMenu = new StringSelectMenuBuilder()
    .setCustomId('sorteios:main:select')
    .setPlaceholder('Selecione uma opção')
    .addOptions(
      {
        label: 'Criar Sorteio',
        value: 'criar',
        description: 'Configurar a aparência, prêmios, chances extras e publicar um novo sorteio',
      },
      {
        label: 'Remover Sorteio',
        value: 'remover',
        description: 'Excluir um sorteio cadastrado do sistema',
      },
      {
        label: 'Editar Sorteio',
        value: 'editar',
        description: 'Editar configurações, aparência, prêmio, data e cargo com chances extras',
      },
    );

  return painelV2FromEmbed(embed, [
    new ActionRowBuilder().addComponents(selectMenu),
  ]);
}

function createSorteioPanel(guildId, userId, notice = '') {
  const draft = getDraft(guildId, userId);

  let premioTexto = 'Não definido';
  if (draft.premioTipo === 'role' && draft.roleId) {
    premioTexto = `Cargo: <@&${draft.roleId}>`;
  } else if (draft.premioTipo === 'custom' && draft.premioNome) {
    premioTexto = `Personalizado: **${draft.premioNome}**\n${truncate(draft.premioDescricao || '', 100)}`;
  }

  const bonusTexto = draft.bonusRoleId && draft.bonusChances
    ? `<@&${draft.bonusRoleId}> (${draft.bonusChances}x chances)`
    : 'Nenhum cargo configurado';

  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle('CRIAR NOVO SORTEIO')
    .setDescription(`${notice ? `${notice}\n\n` : ''}Configure os detalhes do sorteio utilizando o menu de seleção abaixo.\nQuando tudo estiver pronto, clique em **Enviar Sorteio**.`)
    .addFields(
      { name: 'Título', value: truncate(draft.titulo || 'Não definido', 256), inline: true },
      { name: 'Vencedores', value: `${draft.ganhadores || 1} ganhador(es)`, inline: true },
      { name: 'Cargo com Mais Chances', value: bonusTexto, inline: true },
      { name: 'Data / Horário do Sorteio', value: formatDataLegivel(draft.dataSorteio), inline: false },
      { name: 'Descrição', value: truncate(draft.descricao || 'Não definida', 1024), inline: false },
      { name: 'Imagens', value: `Banner: ${draft.banner ? 'Configurado' : 'Não definido'}\nThumbnail: ${draft.thumbnail ? 'Configurada' : 'Não definida'}`, inline: true },
      { name: 'Prêmio', value: premioTexto, inline: true },
    );

  const selectMenu = new StringSelectMenuBuilder()
    .setCustomId('sorteios:create:select')
    .setPlaceholder('Escolha o que deseja configurar')
    .addOptions(
      {
        label: 'Aparência',
        value: 'aparencia',
        description: 'Definir título, descrição, banner e thumbnail',
      },
      {
        label: 'Prêmio',
        value: 'premio',
        description: 'Escolher se o prêmio será Cargo ou Personalizado',
      },
      {
        label: 'Data do Sorteio',
        value: 'data',
        description: 'Definir o dia e horário que o sorteio será realizado automaticamente',
      },
      {
        label: 'Cargo com mais chances',
        value: 'bonus_role',
        description: 'Definir cargo que terá chances extras / multiplicador no sorteio',
      },
    );

  const rows = [
    new ActionRowBuilder().addComponents(selectMenu),
  ];

  const actionButtons = [];
  const prontoParaEnviar = Boolean(draft.titulo && draft.descricao && draft.premioTipo);
  if (prontoParaEnviar) {
    actionButtons.push(
      new ButtonBuilder()
        .setCustomId('sorteios:create:send')
        .setLabel('Enviar Sorteio')
        .setStyle(ButtonStyle.Success),
    );
  }

  actionButtons.push(
    new ButtonBuilder()
      .setCustomId('sorteios:back:main')
      .setLabel('Voltar')
      .setStyle(ButtonStyle.Secondary),
  );

  rows.push(new ActionRowBuilder().addComponents(actionButtons));

  return painelV2FromEmbed(embed, rows);
}

function prizeTypePanel(guildId, notice = '') {
  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle('TIPO DE PRÊMIO DO SORTEIO')
    .setDescription(`${notice ? `${notice}\n\n` : ''}Escolha a modalidade do prêmio que os vencedores receberão:\n\n• **Cargo**: O cargo do Discord será concedido automaticamente ao ganhador no momento do sorteio.\n• **Personalizado**: Um prêmio textual com instruções personalizadas.`);

  return painelV2FromEmbed(embed, [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('sorteios:premio:role').setLabel('Cargo').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('sorteios:premio:custom').setLabel('Personalizado').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('sorteios:back:create').setLabel('Voltar').setStyle(ButtonStyle.Secondary),
    ),
  ]);
}

function roleSelectPanel(guildId, notice = '') {
  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle('SELECIONE O CARGO DO PRÊMIO')
    .setDescription(`${notice ? `${notice}\n\n` : ''}Selecione no menu abaixo o cargo do Discord que será entregue automaticamente aos ganhadores.`);

  return painelV2FromEmbed(embed, [
    new ActionRowBuilder().addComponents(
      new RoleSelectMenuBuilder().setCustomId('sorteios:premio:role_select').setPlaceholder('Selecione o cargo do prêmio'),
    ),
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('sorteios:back:premio_type').setLabel('Voltar').setStyle(ButtonStyle.Secondary),
    ),
  ]);
}

function bonusRolePanel(guildId, draft, notice = '') {
  const bonusAtual = draft.bonusRoleId && draft.bonusChances
    ? `<@&${draft.bonusRoleId}> com **${draft.bonusChances}x chances**`
    : 'Nenhum';

  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle('CARGO COM MAIS CHANCES')
    .setDescription(`${notice ? `${notice}\n\n` : ''}Selecione no menu abaixo o cargo do Discord que terá chances extras / multiplicador no sorteio.\nApós selecionar o cargo, você informará a quantidade de chances extras.\n\n• **Configuração Atual:** ${bonusAtual}`);

  const rows = [
    new ActionRowBuilder().addComponents(
      new RoleSelectMenuBuilder().setCustomId('sorteios:create_bonus:role_select').setPlaceholder('Selecione o cargo'),
    ),
  ];

  const buttons = [];
  if (draft.bonusRoleId) {
    buttons.push(
      new ButtonBuilder().setCustomId('sorteios:create_bonus:remove').setLabel('Remover Cargo Bônus').setStyle(ButtonStyle.Danger),
    );
  }
  buttons.push(
    new ButtonBuilder().setCustomId('sorteios:back:create').setLabel('Voltar').setStyle(ButtonStyle.Secondary),
  );

  rows.push(new ActionRowBuilder().addComponents(buttons));
  return painelV2FromEmbed(embed, rows);
}

function editBonusRolePanel(guildId, sorteio, notice = '') {
  const bonusAtual = sorteio.bonusRoleId && sorteio.bonusChances
    ? `<@&${sorteio.bonusRoleId}> com **${sorteio.bonusChances}x chances**`
    : 'Nenhum';

  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle('EDITAR CARGO COM MAIS CHANCES')
    .setDescription(`${notice ? `${notice}\n\n` : ''}Selecione no menu abaixo o cargo que terá chances extras para o sorteio **${truncate(sorteio.titulo, 80)}**.\n\n• **Configuração Atual:** ${bonusAtual}`);

  const rows = [
    new ActionRowBuilder().addComponents(
      new RoleSelectMenuBuilder().setCustomId(`sorteios:edit_bonus:role_select:${sorteio.id}`).setPlaceholder('Selecione o cargo'),
    ),
  ];

  const buttons = [];
  if (sorteio.bonusRoleId) {
    buttons.push(
      new ButtonBuilder().setCustomId(`sorteios:edit_bonus:remove:${sorteio.id}`).setLabel('Remover Cargo Bônus').setStyle(ButtonStyle.Danger),
    );
  }
  buttons.push(
    new ButtonBuilder().setCustomId(`sorteios:edit_bonus:back:${sorteio.id}`).setLabel('Voltar').setStyle(ButtonStyle.Secondary),
  );

  rows.push(new ActionRowBuilder().addComponents(buttons));
  return painelV2FromEmbed(embed, rows);
}

function revokeSelectPanel(guildId, notice = '') {
  const data = guildState(guildId);
  const ativos = data.sorteios.filter((s) => s.status === 'ativo');

  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle('REVOGAR SORTEIO ATIVO')
    .setDescription(`${notice ? `${notice}\n\n` : ''}Selecione no menu abaixo o sorteio ativo que você deseja cancelar e revogar imediatamente.`);

  if (!ativos.length) {
    return painelV2FromEmbed(
      embed.setDescription('Nenhum sorteio ativo no momento para ser revogado.'),
      [],
    );
  }

  const options = ativos.slice(0, 25).map((s) => ({
    label: truncate(s.titulo || 'Sorteio', 100),
    value: s.id,
    description: `${s.participantes?.length || 0} participante(s) • Prêmio: ${s.premioTipo === 'role' ? 'Cargo' : 'Personalizado'}`,
  }));

  return painelV2FromEmbed(embed, [
    new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder().setCustomId('sorteios:revogar:select').setPlaceholder('Selecione o sorteio para revogar').addOptions(options),
    ),
  ]);
}

function reiniciarSelectPanel(guildId, notice = '') {
  const data = guildState(guildId);
  const elegiveis = data.sorteios.filter((s) => s.status === 'encerrado' || s.status === 'ativo');

  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle('REINICIAR SORTEIO')
    .setDescription(`${notice ? `${notice}\n\n` : ''}Selecione no menu abaixo o sorteio que deseja reiniciar e re-sortear novos vencedores.\nOs novos ganhadores serão sorteados a partir dos participantes existentes e anunciados no canal público com marcação.`);

  if (!elegiveis.length) {
    return painelV2FromEmbed(
      embed.setDescription('Nenhum sorteio cadastrado no momento para ser reiniciado.'),
      [],
    );
  }

  const options = elegiveis.slice(0, 25).map((s) => ({
    label: truncate(s.titulo || 'Sorteio', 100),
    value: s.id,
    description: `${s.status === 'ativo' ? '🟢 Ativo' : '🔴 Encerrado'} • ${s.participantes?.length || 0} participantes`,
  }));

  return painelV2FromEmbed(embed, [
    new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder().setCustomId('sorteios:reiniciar:select').setPlaceholder('Selecione o sorteio para reiniciar').addOptions(options),
    ),
  ]);
}

function removeSorteioPanel(guildId, notice = '') {
  const data = guildState(guildId);
  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle('REMOVER SORTEIO')
    .setDescription(`${notice ? `${notice}\n\n` : ''}Selecione o sorteio que deseja excluir permanentemente do sistema.`);

  if (!data.sorteios.length) {
    return painelV2FromEmbed(
      embed.setDescription('Nenhum sorteio cadastrado para remover.'),
      [new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('sorteios:back:main').setLabel('Voltar').setStyle(ButtonStyle.Secondary))],
    );
  }

  const options = data.sorteios.slice(0, 25).map((s) => ({
    label: truncate(s.titulo || 'Sorteio', 100),
    value: s.id,
    description: `${s.status === 'ativo' ? '🟢 Ativo' : (s.status === 'revogado' ? '⛔ Revogado' : '🔴 Encerrado')} • ${s.participantes?.length || 0} participantes`,
  }));

  return painelV2FromEmbed(embed, [
    new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder().setCustomId('sorteios:remove:select').setPlaceholder('Selecione o sorteio para remover').addOptions(options),
    ),
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('sorteios:back:main').setLabel('Voltar').setStyle(ButtonStyle.Secondary),
    ),
  ]);
}

function editSelectPanel(guildId, notice = '') {
  const data = guildState(guildId);
  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle('EDITAR SORTEIO')
    .setDescription(`${notice ? `${notice}\n\n` : ''}Selecione qual sorteio deseja gerenciar ou editar.`);

  if (!data.sorteios.length) {
    return painelV2FromEmbed(
      embed.setDescription('Nenhum sorteio cadastrado para editar.'),
      [new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('sorteios:back:main').setLabel('Voltar').setStyle(ButtonStyle.Secondary))],
    );
  }

  const options = data.sorteios.slice(0, 25).map((s) => ({
    label: truncate(s.titulo || 'Sorteio', 100),
    value: s.id,
    description: `${s.status === 'ativo' ? '🟢 Ativo' : (s.status === 'revogado' ? '⛔ Revogado' : '🔴 Encerrado')} • ${s.participantes?.length || 0} participantes`,
  }));

  return painelV2FromEmbed(embed, [
    new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder().setCustomId('sorteios:edit:select_sorteio').setPlaceholder('Selecione o sorteio').addOptions(options),
    ),
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('sorteios:back:main').setLabel('Voltar').setStyle(ButtonStyle.Secondary),
    ),
  ]);
}

function editDetailPanel(guildId, sorteio, notice = '') {
  let premioTexto = 'Não definido';
  if (sorteio.premioTipo === 'role' && sorteio.roleId) {
    premioTexto = `Cargo: <@&${sorteio.roleId}>`;
  } else if (sorteio.premioTipo === 'custom' && sorteio.premioNome) {
    premioTexto = `Personalizado: **${sorteio.premioNome}**\n${truncate(sorteio.premioDescricao || '', 100)}`;
  }

  const bonusTexto = sorteio.bonusRoleId && sorteio.bonusChances
    ? `<@&${sorteio.bonusRoleId}> (${sorteio.bonusChances}x chances)`
    : 'Nenhum';

  const vencedoresStr = sorteio.vencedores?.length
    ? sorteio.vencedores.map((id) => `<@${id}>`).join(', ')
    : 'Nenhum sorteado ainda';

  let statusLabel = '🟢 Ativo';
  if (sorteio.status === 'revogado') statusLabel = '⛔ Revogado / Cancelado';
  else if (sorteio.status === 'encerrado') statusLabel = '🔴 Encerrado';

  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle(`GERENCIAR: ${truncate(sorteio.titulo, 100)}`)
    .setDescription(`${notice ? `${notice}\n\n` : ''}Status: **${statusLabel}**\nParticipantes: **${sorteio.participantes?.length || 0}**\nVencedor(es): ${vencedoresStr}`)
    .addFields(
      { name: 'Título', value: truncate(sorteio.titulo || 'Não definido', 256), inline: true },
      { name: 'Prêmio', value: premioTexto, inline: true },
      { name: 'Cargo com Mais Chances', value: bonusTexto, inline: true },
      { name: 'Data / Horário do Sorteio', value: formatDataLegivel(sorteio.dataSorteio), inline: false },
      { name: 'Descrição', value: truncate(sorteio.descricao || 'Não definida', 1024), inline: false },
      { name: 'Imagens', value: `Banner: ${sorteio.banner ? 'Configurado' : 'Não definido'}\nThumbnail: ${sorteio.thumbnail ? 'Configurada' : 'Não definida'}`, inline: true },
    );

  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`sorteios:edit:aparencia:${sorteio.id}`).setLabel('Editar Aparência').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId(`sorteios:edit:premio:${sorteio.id}`).setLabel('Editar Prêmio').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId(`sorteios:edit:data:${sorteio.id}`).setLabel('Editar Data').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId(`sorteios:edit:bonus:${sorteio.id}`).setLabel('Cargo Bônus').setStyle(ButtonStyle.Primary),
  );

  const row2 = new ActionRowBuilder();
  if (sorteio.status === 'ativo') {
    row2.addComponents(
      new ButtonBuilder().setCustomId(`sorteios:edit:sortear:${sorteio.id}`).setLabel('Realizar Sorteio Agora').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId(`sorteios:edit:encerrar:${sorteio.id}`).setLabel('Encerrar').setStyle(ButtonStyle.Secondary),
    );
  }
  row2.addComponents(
    new ButtonBuilder().setCustomId('sorteios:back:edit_list').setLabel('Voltar').setStyle(ButtonStyle.Secondary),
  );

  return painelV2FromEmbed(embed, [row1, row2]);
}

// ─── Modals ───────────────────────────────────────────────────────────────────

function aparenciaModal(draft = {}, customId = 'sorteios:modal:aparencia') {
  const modal = new ModalBuilder()
    .setCustomId(customId)
    .setTitle('Aparência do Sorteio');

  const inputTitulo = new TextInputBuilder()
    .setCustomId('titulo')
    .setLabel('Título do Sorteio')
    .setStyle(TextInputStyle.Short)
    .setMaxLength(256)
    .setRequired(true);
  if (draft.titulo) inputTitulo.setValue(draft.titulo.slice(0, 256));

  const inputDescricao = new TextInputBuilder()
    .setCustomId('descricao')
    .setLabel('Descrição do Sorteio')
    .setStyle(TextInputStyle.Paragraph)
    .setMaxLength(2000)
    .setRequired(true);
  if (draft.descricao) inputDescricao.setValue(draft.descricao.slice(0, 2000));

  const inputBanner = new TextInputBuilder()
    .setCustomId('banner')
    .setLabel('URL do Banner (Opcional)')
    .setStyle(TextInputStyle.Short)
    .setMaxLength(1000)
    .setRequired(false);
  if (draft.banner) inputBanner.setValue(draft.banner.slice(0, 1000));

  const inputThumbnail = new TextInputBuilder()
    .setCustomId('thumbnail')
    .setLabel('URL da Thumbnail (Opcional)')
    .setStyle(TextInputStyle.Short)
    .setMaxLength(1000)
    .setRequired(false);
  if (draft.thumbnail) inputThumbnail.setValue(draft.thumbnail.slice(0, 1000));

  modal.addComponents(
    new ActionRowBuilder().addComponents(inputTitulo),
    new ActionRowBuilder().addComponents(inputDescricao),
    new ActionRowBuilder().addComponents(inputBanner),
    new ActionRowBuilder().addComponents(inputThumbnail),
  );

  return modal;
}

function dataModal(customId = 'sorteios:modal:data', dataAtualIso = null) {
  const modal = new ModalBuilder()
    .setCustomId(customId)
    .setTitle('Data e Horário do Sorteio');

  let valorPadrao = '';
  if (dataAtualIso) {
    try {
      const d = new Date(dataAtualIso);
      const dia = String(d.getDate()).padStart(2, '0');
      const mes = String(d.getMonth() + 1).padStart(2, '0');
      const ano = d.getFullYear();
      const hora = String(d.getHours()).padStart(2, '0');
      const min = String(d.getMinutes()).padStart(2, '0');
      valorPadrao = `${dia}/${mes}/${ano} ${hora}:${min}`;
    } catch (e) {
      valorPadrao = '';
    }
  }

  const inputData = new TextInputBuilder()
    .setCustomId('data_hora')
    .setLabel('Data e Horário (DD/MM/AAAA HH:mm)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('Ex: 25/12/2026 20:00 (ou deixe vazio)')
    .setMaxLength(30)
    .setRequired(false);
  if (valorPadrao) inputData.setValue(valorPadrao);

  modal.addComponents(new ActionRowBuilder().addComponents(inputData));
  return modal;
}

function bonusChancesModal(customId = 'sorteios:modal:bonus_chances', currentChances = 2) {
  const modal = new ModalBuilder()
    .setCustomId(customId)
    .setTitle('Chances do Cargo');

  const inputChances = new TextInputBuilder()
    .setCustomId('chances')
    .setLabel('Quantidade de Chances (Multiplicador)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('Ex: 2, 3, 5 ou 10')
    .setMaxLength(5)
    .setRequired(true);

  if (currentChances) inputChances.setValue(String(currentChances));

  modal.addComponents(new ActionRowBuilder().addComponents(inputChances));
  return modal;
}

function customPrizeModal(customId = 'sorteios:modal:premio_custom', current = {}) {
  const modal = new ModalBuilder()
    .setCustomId(customId)
    .setTitle('Prêmio Personalizado');

  const inputNome = new TextInputBuilder()
    .setCustomId('nome')
    .setLabel('Nome do Prêmio')
    .setStyle(TextInputStyle.Short)
    .setMaxLength(100)
    .setRequired(true);
  if (current.premioNome) inputNome.setValue(current.premioNome.slice(0, 100));

  const inputDesc = new TextInputBuilder()
    .setCustomId('descricao')
    .setLabel('Descrição / Instruções do Prêmio')
    .setStyle(TextInputStyle.Paragraph)
    .setMaxLength(1000)
    .setRequired(true);
  if (current.premioDescricao) inputDesc.setValue(current.premioDescricao.slice(0, 1000));

  modal.addComponents(
    new ActionRowBuilder().addComponents(inputNome),
    new ActionRowBuilder().addComponents(inputDesc),
  );

  return modal;
}

// ─── Painel Público do Sorteio ────────────────────────────────────────────────

function publicSorteioPanel(guildId, sorteio) {
  let premioTexto = 'Não especificado';
  if (sorteio.premioTipo === 'role' && sorteio.roleId) {
    premioTexto = `<@&${sorteio.roleId}>`;
  } else if (sorteio.premioTipo === 'custom' && sorteio.premioNome) {
    premioTexto = `**${sorteio.premioNome}**\n${sorteio.premioDescricao || ''}`;
  }

  const participantesCount = Array.isArray(sorteio.participantes) ? sorteio.participantes.length : 0;
  const isEncerrado = sorteio.status === 'encerrado';
  const isRevogado = sorteio.status === 'revogado';

  let statusText = '🟢 **Sorteio Ativo** — Clique no botão abaixo para participar!';
  if (isEncerrado) {
    const vencStr = sorteio.vencedores?.length
      ? sorteio.vencedores.map((id) => `<@${id}>`).join(', ')
      : 'Nenhum vencedor sorteado';
    statusText = `🔴 **Sorteio Encerrado**\n🏆 **Ganhador(es):** ${vencStr}`;
  } else if (isRevogado) {
    statusText = '⛔ **Sorteio Revogado / Cancelado pela Administração**';
  }

  const dataEncerramentoTexto = formatDataLegivel(sorteio.dataSorteio);

  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle(sorteio.titulo || 'SORTEIO')
    .setDescription(`${sorteio.descricao || 'Participe do sorteio!'}\n\n${statusText}`)
    .addFields(
      { name: 'Prêmio', value: truncate(premioTexto, 1024), inline: true },
      { name: 'Participantes', value: `**${participantesCount}** membro(s)`, inline: true },
    );

  if (sorteio.bonusRoleId && sorteio.bonusChances) {
    embed.addFields({
      name: 'Cargo com Mais Chances',
      value: `<@&${sorteio.bonusRoleId}> (**${sorteio.bonusChances}x chances**)`,
      inline: false,
    });
  }

  embed.addFields({ name: 'Sorteio Programado', value: dataEncerramentoTexto, inline: false });

  if (sorteio.banner) embed.setImage(sorteio.banner);
  if (sorteio.thumbnail) embed.setThumbnail(sorteio.thumbnail);

  const row = new ActionRowBuilder();
  if (!isEncerrado && !isRevogado) {
    row.addComponents(
      new ButtonBuilder()
        .setCustomId(`sorteios:public:participar:${sorteio.id}`)
        .setLabel(`Participar (${participantesCount})`)
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId(`sorteios:public:sair:${sorteio.id}`)
        .setLabel('Sair')
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId(`sorteios:public:lista:${sorteio.id}`)
        .setLabel('Ver Participantes')
        .setStyle(ButtonStyle.Secondary),
    );
  } else if (isRevogado) {
    row.addComponents(
      new ButtonBuilder()
        .setCustomId(`sorteios:public:revogado:${sorteio.id}`)
        .setLabel(`Revogado (${participantesCount})`)
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(true),
      new ButtonBuilder()
        .setCustomId(`sorteios:public:lista:${sorteio.id}`)
        .setLabel('Ver Participantes')
        .setStyle(ButtonStyle.Secondary),
    );
  } else {
    row.addComponents(
      new ButtonBuilder()
        .setCustomId(`sorteios:public:encerrado:${sorteio.id}`)
        .setLabel(`Encerrado (${participantesCount})`)
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(true),
      new ButtonBuilder()
        .setCustomId(`sorteios:public:lista:${sorteio.id}`)
        .setLabel('Ver Participantes')
        .setStyle(ButtonStyle.Secondary),
    );
  }

  return painelV2FromEmbed(embed, [row]);
}

async function refreshPublicPanels(client, guildId, sorteioId) {
  const data = guildState(guildId);
  const sorteio = data.sorteios.find((s) => s.id === sorteioId);
  if (!sorteio) return;

  const paineis = data.paineis.filter((p) => p.sorteioId === sorteioId);
  for (const p of paineis) {
    try {
      const channel = await client.channels.fetch(p.channelId).catch(() => null);
      if (!channel?.messages) continue;
      const msg = await channel.messages.fetch(p.messageId).catch(() => null);
      if (!msg) continue;
      await msg.edit(publicSorteioPanel(guildId, sorteio)).catch(() => {});
    } catch (e) {
      console.warn(`[SORTEIOS] Falha ao atualizar painel público ${p.messageId}:`, e.message);
    }
  }
}

// ─── Envio do Painel Público de Anúncio dos Ganhadores com Marcação ────────────

async function anunciarGanhadoresNoCanal(client, guildId, sorteio, vencedores) {
  if (!vencedores || !vencedores.length) return;

  const data = guildState(guildId);
  const paineis = data.paineis.filter((p) => p.sorteioId === sorteio.id);
  const mencoes = vencedores.map((uid) => `<@${uid}>`).join(' ');

  let premioTexto = 'Não especificado';
  if (sorteio.premioTipo === 'role' && sorteio.roleId) {
    premioTexto = `<@&${sorteio.roleId}>`;
  } else if (sorteio.premioTipo === 'custom' && sorteio.premioNome) {
    premioTexto = `**${sorteio.premioNome}**\n${sorteio.premioDescricao || ''}`;
  }

  const annEmbed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle(`🎉 VENCEDOR(ES) DO SORTEIO: ${truncate(sorteio.titulo, 100)}`)
    .setDescription(`Parabéns aos novos ganhadores do sorteio!\n\n🏆 **Ganhador(es):** ${vencedores.map((id) => `<@${id}>`).join(', ')}\n🎁 **Prêmio:** ${premioTexto}\n👥 **Total de Participantes:** ${sorteio.participantes?.length || 0}\n📅 **Realizado em:** <t:${Math.floor(Date.now() / 1000)}:F>`);

  if (sorteio.banner) annEmbed.setImage(sorteio.banner);
  if (sorteio.thumbnail) annEmbed.setThumbnail(sorteio.thumbnail);

  for (const p of paineis) {
    try {
      const channel = await client.channels.fetch(p.channelId).catch(() => null);
      if (channel?.send) {
        await channel.send({
          content: `🎉 Parabéns ${mencoes}! Vocês ganharam o sorteio **${sorteio.titulo}**!`,
          embeds: [annEmbed],
        }).catch((err) => {
          console.warn('[SORTEIOS] Falha ao enviar mensagem de ganhadores:', err.message);
        });
      }
    } catch (e) {
      console.warn('[SORTEIOS] Erro ao buscar canal do anúncio:', e.message);
    }
  }
}

async function sortearVencedores(guild, sorteio, quantidade = 1) {
  if (!sorteio.participantes || sorteio.participantes.length === 0) {
    return { ok: false, message: 'Não há nenhum participante no sorteio para escolher vencedor.' };
  }

  // Montar pool ponderada com base no cargo de chances extras
  let pool = [];
  const bonusRoleId = sorteio.bonusRoleId;
  const bonusChances = Math.max(1, parseInt(sorteio.bonusChances, 10) || 1);

  for (const uid of sorteio.participantes) {
    let chances = 1;
    if (bonusRoleId && bonusChances > 1 && guild) {
      try {
        const member = await guild.members.fetch(uid).catch(() => null);
        if (member && member.roles.cache.has(bonusRoleId)) {
          chances = bonusChances;
        }
      } catch (_) {}
    }
    for (let c = 0; c < chances; c++) {
      pool.push(uid);
    }
  }

  const vencedores = [];
  const totalDesejado = Math.min(quantidade, sorteio.participantes.length);

  while (vencedores.length < totalDesejado && pool.length > 0) {
    const idx = Math.floor(Math.random() * pool.length);
    const sorteado = pool[idx];
    if (!vencedores.includes(sorteado)) {
      vencedores.push(sorteado);
    }
    // Remove todas as entradas desse participante para não ser sorteado duas vezes
    pool = pool.filter((id) => id !== sorteado);
  }

  sorteio.vencedores = vencedores;
  sorteio.status = 'encerrado';
  sorteio.encerradoEm = new Date().toISOString();

  // Se o prêmio for cargo, conceder automaticamente no servidor
  if (sorteio.premioTipo === 'role' && sorteio.roleId && guild) {
    for (const uid of vencedores) {
      try {
        const member = await guild.members.fetch(uid).catch(() => null);
        if (member && !member.roles.cache.has(sorteio.roleId)) {
          await member.roles.add(sorteio.roleId).catch((err) => {
            console.warn(`[SORTEIOS] Não foi possível dar cargo ao vencedor ${uid}:`, err.message);
          });
        }
      } catch (err) {
        console.warn(`[SORTEIOS] Erro ao buscar membro ${uid}:`, err.message);
      }
    }
  }

  return { ok: true, vencedores };
}

// ─── Interaction Handler ──────────────────────────────────────────────────────

async function handleSorteios(interaction, client) {
  const id = interaction.customId ?? '';
  const guildId = interaction.guildId;

  // ── Comando Slash /sorteios ─────────────────────────────────────────────────
  if (interaction.isChatInputCommand() && interaction.commandName === 'sorteios') {
    if (!interaction.member?.permissions?.has(PermissionFlagsBits.ManageGuild) && !interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) {
      await interaction.reply({
        content: 'Você precisa da permissão **Gerenciar Servidor** para acessar o painel de sorteios.',
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    const sub = interaction.options.getSubcommand(false);
    if (sub === 'revogar') {
      await interaction.reply({
        ...revokeSelectPanel(guildId),
        flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
      });
      return true;
    }

    if (sub === 'reiniciar') {
      await interaction.reply({
        ...reiniciarSelectPanel(guildId),
        flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
      });
      return true;
    }

    resetDraft(guildId, interaction.user.id);
    await interaction.reply({
      ...mainPanel(guildId),
      flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
    });
    return true;
  }

  if (!id.startsWith('sorteios:')) return false;

  // ── Interações Públicas (Participar / Sair / Ver Lista) ─────────────────────
  if (id.startsWith('sorteios:public:')) {
    const parts = id.split(':');
    const action = parts[2];
    const sorteioId = parts[3];
    const data = guildState(guildId);
    const sorteio = data.sorteios.find((s) => s.id === sorteioId);

    if (!sorteio) {
      await interaction.reply({
        content: 'Este sorteio não foi encontrado ou já foi excluído.',
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    if (action === 'participar') {
      if (sorteio.status === 'encerrado') {
        await interaction.reply({
          content: '🔒 Este sorteio já foi encerrado e não aceita mais participantes.',
          flags: MessageFlags.Ephemeral,
        });
        return true;
      }
      if (sorteio.status === 'revogado') {
        await interaction.reply({
          content: '⛔ Este sorteio foi revogado pela administração e está cancelado.',
          flags: MessageFlags.Ephemeral,
        });
        return true;
      }

      if (!Array.isArray(sorteio.participantes)) sorteio.participantes = [];
      const userId = interaction.user.id;
      const jaParticipa = sorteio.participantes.includes(userId);

      if (jaParticipa) {
        await interaction.reply({
          content: '⚠️ **Você já está participando deste sorteio!**\nCaso queira sair da disputa, clique no botão **Sair**.',
          flags: MessageFlags.Ephemeral,
        });
        return true;
      }

      sorteio.participantes.push(userId);
      saveData();
      await refreshPublicPanels(client, guildId, sorteio.id);
      await interaction.reply({
        content: '🎉 **Você entrou no sorteio com sucesso!** Boa sorte!',
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    if (action === 'sair') {
      if (sorteio.status === 'encerrado' || sorteio.status === 'revogado') {
        await interaction.reply({
          content: 'Este sorteio já foi finalizado.',
          flags: MessageFlags.Ephemeral,
        });
        return true;
      }

      if (!Array.isArray(sorteio.participantes)) sorteio.participantes = [];
      const userId = interaction.user.id;
      const jaParticipa = sorteio.participantes.includes(userId);

      if (!jaParticipa) {
        await interaction.reply({
          content: '⚠️ Você não está participando deste sorteio.',
          flags: MessageFlags.Ephemeral,
        });
        return true;
      }

      sorteio.participantes = sorteio.participantes.filter((u) => u !== userId);
      saveData();
      await refreshPublicPanels(client, guildId, sorteio.id);
      await interaction.reply({
        content: 'Você saiu da participação deste sorteio com sucesso. Se mudar de ideia, pode clicar em Participar novamente.',
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    if (action === 'lista') {
      const participantes = sorteio.participantes || [];
      if (!participantes.length) {
        await interaction.reply({
          content: 'Ainda não há nenhum participante neste sorteio. Seja o primeiro a participar!',
          flags: MessageFlags.Ephemeral,
        });
        return true;
      }

      const listaTexto = participantes.slice(0, 50).map((uid, index) => `${index + 1}. <@${uid}>`).join('\n');
      const resto = participantes.length > 50 ? `\n... e mais ${participantes.length - 50} participante(s)` : '';

      const embed = new EmbedBuilder()
        .setColor(color(guildId))
        .setTitle(`👥 Participantes (${participantes.length})`)
        .setDescription(`${listaTexto}${resto}`);

      await interaction.reply({
        embeds: [embed],
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }
  }

  // ── Interações Administrativas ──────────────────────────────────────────────
  if (!interaction.member?.permissions?.has(PermissionFlagsBits.ManageGuild) && !interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) {
    await interaction.reply({
      content: 'Você não tem permissão para gerenciar sorteios.',
      flags: MessageFlags.Ephemeral,
    });
    return true;
  }

  // ── Menu Principal: Seleção de Criar, Remover ou Editar ─────────────────────
  if (interaction.isStringSelectMenu() && id === 'sorteios:main:select') {
    const value = interaction.values[0];
    if (value === 'criar') {
      resetDraft(guildId, interaction.user.id);
      await interaction.update(createSorteioPanel(guildId, interaction.user.id));
      return true;
    }
    if (value === 'remover') {
      await interaction.update(removeSorteioPanel(guildId));
      return true;
    }
    if (value === 'editar') {
      await interaction.update(editSelectPanel(guildId));
      return true;
    }
  }

  // ── Botões de Navegação / Voltar ────────────────────────────────────────────
  if (interaction.isButton() && id === 'sorteios:back:main') {
    await interaction.update(mainPanel(guildId));
    return true;
  }
  if (interaction.isButton() && id === 'sorteios:back:create') {
    await interaction.update(createSorteioPanel(guildId, interaction.user.id));
    return true;
  }
  if (interaction.isButton() && id === 'sorteios:back:premio_type') {
    await interaction.update(prizeTypePanel(guildId));
    return true;
  }
  if (interaction.isButton() && id === 'sorteios:back:edit_list') {
    await interaction.update(editSelectPanel(guildId));
    return true;
  }

  // ── Criar Sorteio: Menu Select (Aparência / Prêmio / Data / Cargo Bônus) ────
  if (interaction.isStringSelectMenu() && id === 'sorteios:create:select') {
    const value = interaction.values[0];
    const draft = getDraft(guildId, interaction.user.id);

    if (value === 'aparencia') {
      await interaction.showModal(aparenciaModal(draft, 'sorteios:modal:aparencia'));
      return true;
    }
    if (value === 'premio') {
      await interaction.update(prizeTypePanel(guildId));
      return true;
    }
    if (value === 'data') {
      await interaction.showModal(dataModal('sorteios:modal:data', draft.dataSorteio));
      return true;
    }
    if (value === 'bonus_role') {
      await interaction.update(bonusRolePanel(guildId, draft));
      return true;
    }
  }

  // ── Modal Submit: Aparência (Criar) ─────────────────────────────────────────
  if (interaction.isModalSubmit() && id === 'sorteios:modal:aparencia') {
    const draft = getDraft(guildId, interaction.user.id);
    draft.titulo = interaction.fields.getTextInputValue('titulo').trim();
    draft.descricao = interaction.fields.getTextInputValue('descricao').trim();
    draft.banner = interaction.fields.getTextInputValue('banner').trim() || null;
    draft.thumbnail = interaction.fields.getTextInputValue('thumbnail').trim() || null;

    await interaction.deferUpdate();
    await interaction.editReply(createSorteioPanel(guildId, interaction.user.id, 'Aparência configurada com sucesso.'));
    return true;
  }

  // ── Modal Submit: Data do Sorteio (Criar) ───────────────────────────────────
  if (interaction.isModalSubmit() && id === 'sorteios:modal:data') {
    const draft = getDraft(guildId, interaction.user.id);
    const inputStr = interaction.fields.getTextInputValue('data_hora').trim();

    if (!inputStr) {
      draft.dataSorteio = null;
      await interaction.deferUpdate();
      await interaction.editReply(createSorteioPanel(guildId, interaction.user.id, 'Data do sorteio definida como manual (sem data programada).'));
      return true;
    }

    const parsedIso = parseDataEncerramento(inputStr);
    if (!parsedIso) {
      await interaction.deferUpdate();
      await interaction.editReply(createSorteioPanel(guildId, interaction.user.id, '⚠️ Formato de data inválido. Use: `DD/MM/AAAA HH:mm` (ex: 25/12/2026 20:00).'));
      return true;
    }

    draft.dataSorteio = parsedIso;
    await interaction.deferUpdate();
    await interaction.editReply(createSorteioPanel(guildId, interaction.user.id, `Data do sorteio programada para ${formatDataLegivel(parsedIso)}.`));
    return true;
  }

  // ── Cargo com Mais Chances (Criar) ──────────────────────────────────────────
  if (interaction.isRoleSelectMenu() && id === 'sorteios:create_bonus:role_select') {
    const roleId = interaction.values[0];
    const role = await interaction.guild.roles.fetch(roleId).catch(() => null);
    if (!role) {
      await interaction.update(bonusRolePanel(guildId, getDraft(guildId, interaction.user.id), 'Não foi possível encontrar esse cargo.'));
      return true;
    }

    const draft = getDraft(guildId, interaction.user.id);
    draft.tempBonusRoleId = role.id;

    // Abre o modal para definir a quantidade de chances extras
    await interaction.showModal(bonusChancesModal('sorteios:modal:bonus_chances', draft.bonusChances || 2));
    return true;
  }

  if (interaction.isModalSubmit() && id === 'sorteios:modal:bonus_chances') {
    const draft = getDraft(guildId, interaction.user.id);
    const chancesRaw = interaction.fields.getTextInputValue('chances').trim();
    const chancesNum = Math.max(2, parseInt(chancesRaw, 10) || 2);

    if (draft.tempBonusRoleId) {
      draft.bonusRoleId = draft.tempBonusRoleId;
      draft.tempBonusRoleId = null;
    }
    draft.bonusChances = chancesNum;

    await interaction.deferUpdate();
    await interaction.editReply(createSorteioPanel(guildId, interaction.user.id, `Cargo <@&${draft.bonusRoleId}> configurado com **${chancesNum}x chances** no sorteio.`));
    return true;
  }

  if (interaction.isButton() && id === 'sorteios:create_bonus:remove') {
    const draft = getDraft(guildId, interaction.user.id);
    draft.bonusRoleId = null;
    draft.bonusChances = null;
    draft.tempBonusRoleId = null;

    await interaction.update(createSorteioPanel(guildId, interaction.user.id, 'Cargo com mais chances removido.'));
    return true;
  }

  // ── Botões do Tipo de Prêmio (Cargo / Personalizado / Voltar) ───────────────
  if (interaction.isButton() && id === 'sorteios:premio:role') {
    await interaction.update(roleSelectPanel(guildId));
    return true;
  }
  if (interaction.isButton() && id === 'sorteios:premio:custom') {
    const draft = getDraft(guildId, interaction.user.id);
    await interaction.showModal(customPrizeModal('sorteios:modal:premio_custom', draft));
    return true;
  }

  // ── Select Menu: Cargo do Prêmio ────────────────────────────────────────────
  if (interaction.isRoleSelectMenu() && id === 'sorteios:premio:role_select') {
    const roleId = interaction.values[0];
    const role = await interaction.guild.roles.fetch(roleId).catch(() => null);
    if (!role) {
      await interaction.update(roleSelectPanel(guildId, 'Não foi possível encontrar esse cargo. Tente novamente.'));
      return true;
    }
    if (role.managed) {
      await interaction.update(roleSelectPanel(guildId, 'Cargos gerenciados pelo Discord/Bots não podem ser concedidos como prêmio.'));
      return true;
    }

    const draft = getDraft(guildId, interaction.user.id);
    draft.premioTipo = 'role';
    draft.roleId = role.id;
    draft.premioNome = role.name;
    draft.premioDescricao = null;

    await interaction.update(createSorteioPanel(guildId, interaction.user.id, `Prêmio configurado para o cargo **@${role.name}**.`));
    return true;
  }

  // ── Modal Submit: Prêmio Personalizado ──────────────────────────────────────
  if (interaction.isModalSubmit() && id === 'sorteios:modal:premio_custom') {
    const draft = getDraft(guildId, interaction.user.id);
    draft.premioTipo = 'custom';
    draft.premioNome = interaction.fields.getTextInputValue('nome').trim();
    draft.premioDescricao = interaction.fields.getTextInputValue('descricao').trim();
    draft.roleId = null;

    await interaction.deferUpdate();
    await interaction.editReply(createSorteioPanel(guildId, interaction.user.id, 'Prêmio personalizado configurado com sucesso.'));
    return true;
  }

  // ── Enviar Sorteio (Seleção de Canal) ───────────────────────────────────────
  if (interaction.isButton() && id === 'sorteios:create:send') {
    const draft = getDraft(guildId, interaction.user.id);
    if (!draft.titulo || !draft.descricao || !draft.premioTipo) {
      await interaction.reply({
        content: 'Configure a aparência e o prêmio antes de enviar o sorteio.',
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    const embed = new EmbedBuilder()
      .setColor(color(guildId))
      .setTitle('PUBLICAR SORTEIO')
      .setDescription('Selecione o canal de texto onde o painel público do sorteio será enviado.');

    await interaction.update(painelV2FromEmbed(embed, [
      new ActionRowBuilder().addComponents(
        new ChannelSelectMenuBuilder()
          .setCustomId('sorteios:create:channel_select')
          .setPlaceholder('Selecione o canal')
          .setChannelTypes([ChannelType.GuildText, ChannelType.GuildAnnouncement]),
      ),
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('sorteios:back:create').setLabel('Voltar').setStyle(ButtonStyle.Secondary),
      ),
    ]));
    return true;
  }

  if (interaction.isChannelSelectMenu() && id === 'sorteios:create:channel_select') {
    const channelId = interaction.values[0];
    const channel = await interaction.guild.channels.fetch(channelId).catch(() => null);
    if (!channel?.send) {
      await interaction.reply({ content: 'Não foi possível acessar o canal selecionado.', flags: MessageFlags.Ephemeral });
      return true;
    }

    const draft = getDraft(guildId, interaction.user.id);
    const sorteioId = `${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
    const novoSorteio = {
      id: sorteioId,
      titulo: draft.titulo,
      descricao: draft.descricao,
      banner: draft.banner,
      thumbnail: draft.thumbnail,
      premioTipo: draft.premioTipo,
      premioNome: draft.premioNome,
      premioDescricao: draft.premioDescricao,
      roleId: draft.roleId,
      bonusRoleId: draft.bonusRoleId,
      bonusChances: draft.bonusChances,
      dataSorteio: draft.dataSorteio,
      ganhadores: draft.ganhadores || 1,
      status: 'ativo',
      participantes: [],
      vencedores: [],
      criadoEm: new Date().toISOString(),
      encerradoEm: null,
      revogadoEm: null,
    };

    const data = guildState(guildId);
    data.sorteios.push(novoSorteio);

    const publicMsg = await channel.send(publicSorteioPanel(guildId, novoSorteio));
    data.paineis.push({
      sorteioId: novoSorteio.id,
      channelId: channel.id,
      messageId: publicMsg.id,
    });
    saveData();

    resetDraft(guildId, interaction.user.id);
    await interaction.update(mainPanel(guildId, `Sorteio publicado com sucesso no canal <#${channel.id}>!`));
    return true;
  }

  // ── Revogar Sorteio Ativo ───────────────────────────────────────────────────
  if (interaction.isStringSelectMenu() && id === 'sorteios:revogar:select') {
    const sorteioId = interaction.values[0];
    const data = guildState(guildId);
    const sorteio = data.sorteios.find((s) => s.id === sorteioId);

    if (!sorteio) {
      await interaction.update(revokeSelectPanel(guildId, 'Sorteio não encontrado.'));
      return true;
    }

    sorteio.status = 'revogado';
    sorteio.revogadoEm = new Date().toISOString();
    saveData();

    await refreshPublicPanels(client, guildId, sorteio.id);

    // Enviar mensagem informativa no canal do sorteio se houver painel
    const painel = data.paineis.find((p) => p.sorteioId === sorteio.id);
    if (painel) {
      try {
        const ch = await client.channels.fetch(painel.channelId).catch(() => null);
        if (ch?.send) {
          await ch.send({
            content: `⚠️ O sorteio **${sorteio.titulo}** foi revogado e cancelado pela administração.`,
          }).catch(() => {});
        }
      } catch (_) {}
    }

    await interaction.update(mainPanel(guildId, `O sorteio **${sorteio.titulo}** foi revogado e cancelado com sucesso.`));
    return true;
  }

  // ── Reiniciar Sorteio (Re-sortear Vencedores) ───────────────────────────────
  if (interaction.isStringSelectMenu() && id === 'sorteios:reiniciar:select') {
    const sorteioId = interaction.values[0];
    const data = guildState(guildId);
    const sorteio = data.sorteios.find((s) => s.id === sorteioId);

    if (!sorteio) {
      await interaction.update(reiniciarSelectPanel(guildId, 'Sorteio não encontrado.'));
      return true;
    }

    if (!sorteio.participantes || sorteio.participantes.length === 0) {
      await interaction.update(reiniciarSelectPanel(guildId, `⚠️ O sorteio **${sorteio.titulo}** não possui nenhum participante cadastrado para ser reiniciado.`));
      return true;
    }

    const resultado = await sortearVencedores(interaction.guild, sorteio, sorteio.ganhadores || 1);
    if (!resultado.ok) {
      await interaction.update(reiniciarSelectPanel(guildId, `⚠️ ${resultado.message}`));
      return true;
    }

    saveData();
    await refreshPublicPanels(client, guildId, sorteio.id);

    // Enviar anúncio público no canal do sorteio marcando todos os ganhadores
    await anunciarGanhadoresNoCanal(client, guildId, sorteio, resultado.vencedores);

    await interaction.update(mainPanel(guildId, `🎉 O sorteio **${sorteio.titulo}** foi reiniciado com sucesso!\nNovos ganhadores sorteados: ${resultado.vencedores.map((u) => `<@${u}>`).join(', ')} e anunciados no canal público.`));
    return true;
  }

  // ── Remover Sorteio ─────────────────────────────────────────────────────────
  if (interaction.isStringSelectMenu() && id === 'sorteios:remove:select') {
    const sorteioId = interaction.values[0];
    const data = guildState(guildId);
    const index = data.sorteios.findIndex((s) => s.id === sorteioId);

    if (index === -1) {
      await interaction.update(removeSorteioPanel(guildId, 'Sorteio não encontrado.'));
      return true;
    }

    const [removido] = data.sorteios.splice(index, 1);
    data.paineis = data.paineis.filter((p) => p.sorteioId !== sorteioId);
    saveData();

    await interaction.update(mainPanel(guildId, `Sorteio **${removido.titulo}** removido com sucesso.`));
    return true;
  }

  // ── Editar Sorteio: Seleção e Ações ─────────────────────────────────────────
  if (interaction.isStringSelectMenu() && id === 'sorteios:edit:select_sorteio') {
    const sorteioId = interaction.values[0];
    const data = guildState(guildId);
    const sorteio = data.sorteios.find((s) => s.id === sorteioId);
    if (!sorteio) {
      await interaction.update(editSelectPanel(guildId, 'Sorteio não encontrado.'));
      return true;
    }
    await interaction.update(editDetailPanel(guildId, sorteio));
    return true;
  }

  if (interaction.isButton() && id.startsWith('sorteios:edit:aparencia:')) {
    const sorteioId = id.split(':').pop();
    const data = guildState(guildId);
    const sorteio = data.sorteios.find((s) => s.id === sorteioId);
    if (!sorteio) {
      await interaction.reply({ content: 'Sorteio não encontrado.', flags: MessageFlags.Ephemeral });
      return true;
    }
    await interaction.showModal(aparenciaModal(sorteio, `sorteios:modal:edit_aparencia:${sorteio.id}`));
    return true;
  }

  if (interaction.isModalSubmit() && id.startsWith('sorteios:modal:edit_aparencia:')) {
    const sorteioId = id.split(':').pop();
    const data = guildState(guildId);
    const sorteio = data.sorteios.find((s) => s.id === sorteioId);
    if (!sorteio) {
      await interaction.reply({ content: 'Sorteio não encontrado.', flags: MessageFlags.Ephemeral });
      return true;
    }

    sorteio.titulo = interaction.fields.getTextInputValue('titulo').trim();
    sorteio.descricao = interaction.fields.getTextInputValue('descricao').trim();
    sorteio.banner = interaction.fields.getTextInputValue('banner').trim() || null;
    sorteio.thumbnail = interaction.fields.getTextInputValue('thumbnail').trim() || null;
    saveData();

    await refreshPublicPanels(client, guildId, sorteio.id);
    await interaction.deferUpdate();
    await interaction.editReply(editDetailPanel(guildId, sorteio, 'Aparência atualizada e painel público sincronizado.'));
    return true;
  }

  // ── Editar Data do Sorteio ──────────────────────────────────────────────────
  if (interaction.isButton() && id.startsWith('sorteios:edit:data:')) {
    const sorteioId = id.split(':').pop();
    const data = guildState(guildId);
    const sorteio = data.sorteios.find((s) => s.id === sorteioId);
    if (!sorteio) {
      await interaction.reply({ content: 'Sorteio não encontrado.', flags: MessageFlags.Ephemeral });
      return true;
    }
    await interaction.showModal(dataModal(`sorteios:modal:edit_data:${sorteio.id}`, sorteio.dataSorteio));
    return true;
  }

  if (interaction.isModalSubmit() && id.startsWith('sorteios:modal:edit_data:')) {
    const sorteioId = id.split(':').pop();
    const data = guildState(guildId);
    const sorteio = data.sorteios.find((s) => s.id === sorteioId);
    if (!sorteio) {
      await interaction.reply({ content: 'Sorteio não encontrado.', flags: MessageFlags.Ephemeral });
      return true;
    }

    const inputStr = interaction.fields.getTextInputValue('data_hora').trim();
    if (!inputStr) {
      sorteio.dataSorteio = null;
    } else {
      const parsedIso = parseDataEncerramento(inputStr);
      if (!parsedIso) {
        await interaction.deferUpdate();
        await interaction.editReply(editDetailPanel(guildId, sorteio, '⚠️ Formato de data inválido. Use: `DD/MM/AAAA HH:mm` (ex: 25/12/2026 20:00).'));
        return true;
      }
      sorteio.dataSorteio = parsedIso;
    }

    saveData();
    await refreshPublicPanels(client, guildId, sorteio.id);
    await interaction.deferUpdate();
    await interaction.editReply(editDetailPanel(guildId, sorteio, 'Data do sorteio atualizada com sucesso.'));
    return true;
  }

  // ── Editar Cargo Bônus (Edição) ─────────────────────────────────────────────
  if (interaction.isButton() && id.startsWith('sorteios:edit:bonus:')) {
    const sorteioId = id.split(':').pop();
    const data = guildState(guildId);
    const sorteio = data.sorteios.find((s) => s.id === sorteioId);
    if (!sorteio) {
      await interaction.reply({ content: 'Sorteio não encontrado.', flags: MessageFlags.Ephemeral });
      return true;
    }
    await interaction.update(editBonusRolePanel(guildId, sorteio));
    return true;
  }

  if (interaction.isButton() && id.startsWith('sorteios:edit_bonus:back:')) {
    const sorteioId = id.split(':').pop();
    const data = guildState(guildId);
    const sorteio = data.sorteios.find((s) => s.id === sorteioId);
    if (!sorteio) {
      await interaction.update(editSelectPanel(guildId));
      return true;
    }
    await interaction.update(editDetailPanel(guildId, sorteio));
    return true;
  }

  if (interaction.isRoleSelectMenu() && id.startsWith('sorteios:edit_bonus:role_select:')) {
    const sorteioId = id.split(':').pop();
    const roleId = interaction.values[0];
    const data = guildState(guildId);
    const sorteio = data.sorteios.find((s) => s.id === sorteioId);
    if (!sorteio) {
      await interaction.reply({ content: 'Sorteio não encontrado.', flags: MessageFlags.Ephemeral });
      return true;
    }

    await interaction.showModal(bonusChancesModal(`sorteios:modal:edit_bonus_chances:${sorteio.id}:${roleId}`, sorteio.bonusChances || 2));
    return true;
  }

  if (interaction.isModalSubmit() && id.startsWith('sorteios:modal:edit_bonus_chances:')) {
    const parts = id.split(':');
    const sorteioId = parts[3];
    const roleId = parts[4];
    const data = guildState(guildId);
    const sorteio = data.sorteios.find((s) => s.id === sorteioId);
    if (!sorteio) {
      await interaction.reply({ content: 'Sorteio não encontrado.', flags: MessageFlags.Ephemeral });
      return true;
    }

    const chancesRaw = interaction.fields.getTextInputValue('chances').trim();
    const chancesNum = Math.max(2, parseInt(chancesRaw, 10) || 2);

    sorteio.bonusRoleId = roleId;
    sorteio.bonusChances = chancesNum;
    saveData();

    await refreshPublicPanels(client, guildId, sorteio.id);
    await interaction.deferUpdate();
    await interaction.editReply(editDetailPanel(guildId, sorteio, `Cargo com mais chances atualizado para <@&${roleId}> (${chancesNum}x chances).`));
    return true;
  }

  if (interaction.isButton() && id.startsWith('sorteios:edit_bonus:remove:')) {
    const sorteioId = id.split(':').pop();
    const data = guildState(guildId);
    const sorteio = data.sorteios.find((s) => s.id === sorteioId);
    if (!sorteio) {
      await interaction.reply({ content: 'Sorteio não encontrado.', flags: MessageFlags.Ephemeral });
      return true;
    }

    sorteio.bonusRoleId = null;
    sorteio.bonusChances = null;
    saveData();

    await refreshPublicPanels(client, guildId, sorteio.id);
    await interaction.update(editDetailPanel(guildId, sorteio, 'Cargo com mais chances removido.'));
    return true;
  }

  // ── Editar Prêmio (Edição) ──────────────────────────────────────────────────
  if (interaction.isButton() && id.startsWith('sorteios:edit:premio:')) {
    const sorteioId = id.split(':').pop();
    editingSorteio.set(`${guildId}:${interaction.user.id}`, sorteioId);

    const embed = new EmbedBuilder()
      .setColor(color(guildId))
      .setTitle('EDITAR PRÊMIO DO SORTEIO')
      .setDescription('Escolha a nova modalidade do prêmio:');

    await interaction.update(painelV2FromEmbed(embed, [
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`sorteios:edit_premio:role:${sorteioId}`).setLabel('Cargo').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId(`sorteios:edit_premio:custom:${sorteioId}`).setLabel('Personalizado').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId(`sorteios:edit_premio:back:${sorteioId}`).setLabel('Voltar').setStyle(ButtonStyle.Secondary),
      ),
    ]));
    return true;
  }

  if (interaction.isButton() && id.startsWith('sorteios:edit_premio:back:')) {
    const sorteioId = id.split(':').pop();
    const data = guildState(guildId);
    const sorteio = data.sorteios.find((s) => s.id === sorteioId);
    if (!sorteio) {
      await interaction.update(editSelectPanel(guildId));
      return true;
    }
    await interaction.update(editDetailPanel(guildId, sorteio));
    return true;
  }

  if (interaction.isButton() && id.startsWith('sorteios:edit_premio:role:')) {
    const sorteioId = id.split(':').pop();
    const embed = new EmbedBuilder()
      .setColor(color(guildId))
      .setTitle('SELECIONE O NOVO CARGO')
      .setDescription('Selecione o cargo que será entregue aos ganhadores.');

    await interaction.update(painelV2FromEmbed(embed, [
      new ActionRowBuilder().addComponents(
        new RoleSelectMenuBuilder().setCustomId(`sorteios:edit_premio:role_select:${sorteioId}`).setPlaceholder('Selecione o cargo'),
      ),
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`sorteios:edit_premio:back:${sorteioId}`).setLabel('Voltar').setStyle(ButtonStyle.Secondary),
      ),
    ]));
    return true;
  }

  if (interaction.isRoleSelectMenu() && id.startsWith('sorteios:edit_premio:role_select:')) {
    const sorteioId = id.split(':').pop();
    const data = guildState(guildId);
    const sorteio = data.sorteios.find((s) => s.id === sorteioId);
    if (!sorteio) {
      await interaction.update(editSelectPanel(guildId, 'Sorteio não encontrado.'));
      return true;
    }

    const role = await interaction.guild.roles.fetch(interaction.values[0]).catch(() => null);
    if (!role || role.managed) {
      await interaction.reply({ content: 'Cargo inválido ou gerenciado pelo Discord.', flags: MessageFlags.Ephemeral });
      return true;
    }

    sorteio.premioTipo = 'role';
    sorteio.roleId = role.id;
    sorteio.premioNome = role.name;
    sorteio.premioDescricao = null;
    saveData();

    await refreshPublicPanels(client, guildId, sorteio.id);
    await interaction.update(editDetailPanel(guildId, sorteio, `Prêmio alterado para o cargo **@${role.name}**.`));
    return true;
  }

  if (interaction.isButton() && id.startsWith('sorteios:edit_premio:custom:')) {
    const sorteioId = id.split(':').pop();
    const data = guildState(guildId);
    const sorteio = data.sorteios.find((s) => s.id === sorteioId);
    if (!sorteio) {
      await interaction.reply({ content: 'Sorteio não encontrado.', flags: MessageFlags.Ephemeral });
      return true;
    }
    await interaction.showModal(customPrizeModal(`sorteios:modal:edit_premio_custom:${sorteio.id}`, sorteio));
    return true;
  }

  if (interaction.isModalSubmit() && id.startsWith('sorteios:modal:edit_premio_custom:')) {
    const sorteioId = id.split(':').pop();
    const data = guildState(guildId);
    const sorteio = data.sorteios.find((s) => s.id === sorteioId);
    if (!sorteio) {
      await interaction.reply({ content: 'Sorteio não encontrado.', flags: MessageFlags.Ephemeral });
      return true;
    }

    sorteio.premioTipo = 'custom';
    sorteio.premioNome = interaction.fields.getTextInputValue('nome').trim();
    sorteio.premioDescricao = interaction.fields.getTextInputValue('descricao').trim();
    sorteio.roleId = null;
    saveData();

    await refreshPublicPanels(client, guildId, sorteio.id);
    await interaction.deferUpdate();
    await interaction.editReply(editDetailPanel(guildId, sorteio, 'Prêmio personalizado atualizado.'));
    return true;
  }

  // ── Sortear Vencedor / Revogar / Encerrar Sorteio ────────────────────────────
  if (interaction.isButton() && (id.startsWith('sorteios:edit:sortear:') || id.startsWith('sorteios:edit:resortear:'))) {
    const sorteioId = id.split(':').pop();
    const data = guildState(guildId);
    const sorteio = data.sorteios.find((s) => s.id === sorteioId);
    if (!sorteio) {
      await interaction.reply({ content: 'Sorteio não encontrado.', flags: MessageFlags.Ephemeral });
      return true;
    }

    const resultado = await sortearVencedores(interaction.guild, sorteio, sorteio.ganhadores || 1);
    if (!resultado.ok) {
      await interaction.update(editDetailPanel(guildId, sorteio, `⚠️ ${resultado.message}`));
      return true;
    }

    saveData();
    await refreshPublicPanels(client, guildId, sorteio.id);

    // Enviar mensagem de anúncio público marcando todos os ganhadores
    await anunciarGanhadoresNoCanal(client, guildId, sorteio, resultado.vencedores);

    await interaction.update(editDetailPanel(guildId, sorteio, `🎉 Sorteio realizado com sucesso! Vencedor(es): ${resultado.vencedores.map((u) => `<@${u}>`).join(', ')}.`));
    return true;
  }

  if (interaction.isButton() && id.startsWith('sorteios:edit:revogar:')) {
    const sorteioId = id.split(':').pop();
    const data = guildState(guildId);
    const sorteio = data.sorteios.find((s) => s.id === sorteioId);
    if (!sorteio) {
      await interaction.reply({ content: 'Sorteio não encontrado.', flags: MessageFlags.Ephemeral });
      return true;
    }

    sorteio.status = 'revogado';
    sorteio.revogadoEm = new Date().toISOString();
    saveData();
    await refreshPublicPanels(client, guildId, sorteio.id);

    // Notificar no canal do sorteio
    const painel = data.paineis.find((p) => p.sorteioId === sorteio.id);
    if (painel) {
      try {
        const ch = await client.channels.fetch(painel.channelId).catch(() => null);
        if (ch?.send) {
          await ch.send({
            content: `⚠️ O sorteio **${sorteio.titulo}** foi revogado e cancelado pela administração.`,
          }).catch(() => {});
        }
      } catch (_) {}
    }

    await interaction.update(editDetailPanel(guildId, sorteio, 'Sorteio revogado e cancelado com sucesso.'));
    return true;
  }

  if (interaction.isButton() && id.startsWith('sorteios:edit:encerrar:')) {
    const sorteioId = id.split(':').pop();
    const data = guildState(guildId);
    const sorteio = data.sorteios.find((s) => s.id === sorteioId);
    if (!sorteio) {
      await interaction.reply({ content: 'Sorteio não encontrado.', flags: MessageFlags.Ephemeral });
      return true;
    }

    sorteio.status = 'encerrado';
    sorteio.encerradoEm = new Date().toISOString();
    saveData();
    await refreshPublicPanels(client, guildId, sorteio.id);

    await interaction.update(editDetailPanel(guildId, sorteio, 'Sorteio encerrado com sucesso.'));
    return true;
  }

  return false;
}

// ─── Rotina de Verificação e Sorteio Automático ───────────────────────────────

let rotinaIniciada = false;

function iniciarRotinaSorteiosAutomaticos(client) {
  if (rotinaIniciada) return;
  rotinaIniciada = true;

  setInterval(async () => {
    const agora = new Date();

    for (const [guildId, data] of Object.entries(state)) {
      if (!Array.isArray(data.sorteios)) continue;

      for (const sorteio of data.sorteios) {
        if (sorteio.status !== 'ativo' || !sorteio.dataSorteio) continue;

        const dataAlvo = new Date(sorteio.dataSorteio);
        if (isNaN(dataAlvo.getTime())) continue;

        if (agora >= dataAlvo) {
          // Chegou a hora do sorteio!
          try {
            const guild = await client.guilds.fetch(guildId).catch(() => null);
            const resultado = await sortearVencedores(guild, sorteio, sorteio.ganhadores || 1);

            saveData();
            await refreshPublicPanels(client, guildId, sorteio.id);

            // Anúncio público marcando todos os ganhadores no canal
            if (resultado.ok && resultado.vencedores.length > 0) {
              await anunciarGanhadoresNoCanal(client, guildId, sorteio, resultado.vencedores);
            } else {
              const painel = data.paineis?.find((p) => p.sorteioId === sorteio.id);
              if (painel && client) {
                const channel = await client.channels.fetch(painel.channelId).catch(() => null);
                if (channel?.send) {
                  await channel.send({
                    content: `⏰ O sorteio **${sorteio.titulo}** chegou à data programada, mas não havia participantes suficientes. O sorteio foi encerrado.`,
                  }).catch(() => {});
                }
              }
            }
          } catch (e) {
            console.error(`[SORTEIOS] Erro ao processar sorteio automático ${sorteio.id}:`, e.message);
          }
        }
      }
    }
  }, 30 * 1000); // Checa a cada 30 segundos
}

// ─── Restauração de Painéis ───────────────────────────────────────────────────

async function restorePanels(client) {
  iniciarRotinaSorteiosAutomaticos(client);

  for (const [guildId, data] of Object.entries(state)) {
    if (!Array.isArray(data.sorteios) || !Array.isArray(data.paineis)) continue;
    for (const p of data.paineis) {
      try {
        const channel = await client.channels.fetch(p.channelId).catch(() => null);
        if (!channel?.messages) continue;
        const msg = await channel.messages.fetch(p.messageId).catch(() => null);
        if (!msg) continue;
        const sorteio = data.sorteios.find((s) => s.id === sorteioId);
        if (!sorteio) continue;
        await msg.edit(publicSorteioPanel(guildId, sorteio)).catch(() => {});
      } catch (err) {
        // Ignora erros de canais/mensagens deletadas
      }
    }
  }
}

module.exports = {
  handleSorteios,
  restorePanels,
  iniciarRotinaSorteiosAutomaticos,
};
