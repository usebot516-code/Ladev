'use strict';

const fs = require('fs');
const path = require('path');
const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  MessageFlags,
} = require('discord.js');
const { dataPath } = require('./data-path');
const { painelV2FromEmbed, avatarDoServidor } = require('./visual');
const { lerJSON, salvarJSON } = require('./storage');

const DATA_FILE = dataPath('botoes_config.json');

// ── Lista Completa de Botões Organizada em no Máximo 5 Categorias ──────────────

const CATEGORIAS_BOTOES = {
  filas_partidas: {
    id: 'filas_partidas',
    nome: 'Filas & Partidas',
    descricao: 'Botoes de entrada em filas, modos de jogo, copia de dados e acoes da partida',
    emoji: null,
    botoes: [
      { id: 'fila_entrar', label: 'Entrar na Fila', defaultStyle: ButtonStyle.Primary, defaultEmoji: null, customIdMatch: 'fq:in' },
      { id: 'fila_sair', label: 'Sair da Fila', defaultStyle: ButtonStyle.Danger, defaultEmoji: null, customIdMatch: 'fq:out' },
      { id: 'fila_gelo_normal', label: 'Gelo Normal', defaultStyle: ButtonStyle.Primary, defaultEmoji: null, customIdMatch: 'gelo_normal' },
      { id: 'fila_gelo_infinito', label: 'Gelo Infinito', defaultStyle: ButtonStyle.Primary, defaultEmoji: null, customIdMatch: 'gelo_infinito' },
      { id: 'fila_1_emu', label: '1 EMU', defaultStyle: ButtonStyle.Primary, defaultEmoji: null, customIdMatch: 'emu1' },
      { id: 'fila_2_emu', label: '2 EMU', defaultStyle: ButtonStyle.Primary, defaultEmoji: null, customIdMatch: 'emu2' },
      { id: 'fila_3_emu', label: '3 EMU', defaultStyle: ButtonStyle.Primary, defaultEmoji: null, customIdMatch: 'emu3' },
      { id: 'partida_copiar_id', label: 'Copiar ID da Sala', defaultStyle: ButtonStyle.Secondary, defaultEmoji: null, customIdMatch: 'copiar_sala_id' },
      { id: 'partida_copiar_senha', label: 'Copiar Senha da Sala', defaultStyle: ButtonStyle.Secondary, defaultEmoji: null, customIdMatch: 'copiar_sala_senha' },
      { id: 'partida_copiar_pix', label: 'Copiar Chave PIX', defaultStyle: ButtonStyle.Secondary, defaultEmoji: null, customIdMatch: 'copiar' },
      { id: 'partida_chamar_mediador', label: 'Chamar Mediador', defaultStyle: ButtonStyle.Primary, defaultEmoji: null, customIdMatch: 'chamar_mediador' },
      { id: 'partida_trocar_sala', label: 'Trocar Sala', defaultStyle: ButtonStyle.Secondary, defaultEmoji: null, customIdMatch: 'trocar_sala' },
      { id: 'partida_ver_print', label: 'Ver Print da Partida', defaultStyle: ButtonStyle.Secondary, defaultEmoji: null, customIdMatch: 'ver_print' },
      { id: 'partida_vitoria_normal', label: 'Vitoria Normal', defaultStyle: ButtonStyle.Secondary, defaultEmoji: null, customIdMatch: 'normal' },
      { id: 'partida_vitoria_wo', label: 'Vitoria por W.O', defaultStyle: ButtonStyle.Secondary, defaultEmoji: null, customIdMatch: 'wo' },
      { id: 'partida_cancelar_resultado', label: 'Cancelar Escolha', defaultStyle: ButtonStyle.Secondary, defaultEmoji: null, customIdMatch: 'cancelar_resultado' },
      { id: 'partida_fechar', label: 'Fechar Partida', defaultStyle: ButtonStyle.Danger, defaultEmoji: null, customIdMatch: 'fechar' },
      { id: 'filas_enviar', label: 'Enviar Painel de Fila', defaultStyle: ButtonStyle.Success, defaultEmoji: null, customIdMatch: 'filas:enviar' },
      { id: 'filas_limpar', label: 'Limpar Fila', defaultStyle: ButtonStyle.Danger, defaultEmoji: null, customIdMatch: 'filas:limpar' },
    ],
  },
  equipe_mediacao: {
    id: 'equipe_mediacao',
    nome: 'Equipe & Mediacao',
    descricao: 'Botoes dos paineis de mediadores, analistas e filas de streamers',
    emoji: null,
    botoes: [
      { id: 'fmed_entrar', label: 'Entrar na Fila (Mediador)', defaultStyle: ButtonStyle.Success, defaultEmoji: null, customIdMatch: 'fmed:in' },
      { id: 'fmed_sair', label: 'Sair da Fila (Mediador)', defaultStyle: ButtonStyle.Danger, defaultEmoji: null, customIdMatch: 'fmed:out' },
      { id: 'fmed_pix', label: 'Config Mediador / PIX', defaultStyle: ButtonStyle.Secondary, defaultEmoji: null, customIdMatch: 'fmed:pix' },
      { id: 'fmed_ranking', label: 'Ranking Mediadores', defaultStyle: ButtonStyle.Secondary, defaultEmoji: null, customIdMatch: 'fmed:ranking' },
      { id: 'fmed_limpar', label: 'Limpar Fila Mediador', defaultStyle: ButtonStyle.Danger, defaultEmoji: null, customIdMatch: 'fmed:limpar' },
      { id: 'fan_entrar', label: 'Entrar na Fila (Analista)', defaultStyle: ButtonStyle.Success, defaultEmoji: null, customIdMatch: 'fan:entrar' },
      { id: 'fan_sair', label: 'Sair da Fila (Analista)', defaultStyle: ButtonStyle.Danger, defaultEmoji: null, customIdMatch: 'fan:sair' },
      { id: 'fan_ranking', label: 'Ranking Analistas', defaultStyle: ButtonStyle.Secondary, defaultEmoji: null, customIdMatch: 'fan:ranking' },
      { id: 'fan_historico', label: 'Ver Historico (Analista)', defaultStyle: ButtonStyle.Secondary, defaultEmoji: null, customIdMatch: 'fan:historico' },
      { id: 'streamer_entrar', label: 'Entrar na Fila (Streamer)', defaultStyle: ButtonStyle.Success, defaultEmoji: null, customIdMatch: 'streamer:fila:entrar' },
      { id: 'streamer_sair', label: 'Sair da Fila (Streamer)', defaultStyle: ButtonStyle.Danger, defaultEmoji: null, customIdMatch: 'streamer:fila:sair' },
      { id: 'streamer_online', label: 'Status Online/Offline', defaultStyle: ButtonStyle.Success, defaultEmoji: null, customIdMatch: 'streamer:fila:online' },
      { id: 'streamer_historico', label: 'Ver Historico (Streamer)', defaultStyle: ButtonStyle.Secondary, defaultEmoji: null, customIdMatch: 'streamer:fila:historico' },
      { id: 'streamer_informacoes', label: 'Alterar Informacoes', defaultStyle: ButtonStyle.Primary, defaultEmoji: null, customIdMatch: 'streamer:fila:informacoes' },
      { id: 'team_ryze_entrar', label: 'Entrar na Call', defaultStyle: ButtonStyle.Success, defaultEmoji: null, customIdMatch: 'team_ryze:call:entrar' },
      { id: 'team_ryze_sair', label: 'Sair da Call', defaultStyle: ButtonStyle.Danger, defaultEmoji: null, customIdMatch: 'team_ryze:call:sair' },
    ],
  },
  economia_ranking: {
    id: 'economia_ranking',
    nome: 'Economia, Ranking & Sorteios',
    descricao: 'Botoes de perfil, ranking por periodo e participacao em sorteios',
    emoji: null,
    botoes: [
      { id: 'ranking_perfil', label: 'Perfil', defaultStyle: ButtonStyle.Primary, defaultEmoji: null, customIdMatch: 'ranking:perfil' },
      { id: 'ranking_periodos', label: 'Ranking', defaultStyle: ButtonStyle.Success, defaultEmoji: null, customIdMatch: 'ranking:periodos' },
      { id: 'ranking_anterior', label: 'Anterior (Ranking)', defaultStyle: ButtonStyle.Secondary, defaultEmoji: null, customIdMatch: 'ranking:pagina' },
      { id: 'ranking_proximo', label: 'Proximo (Ranking)', defaultStyle: ButtonStyle.Secondary, defaultEmoji: null, customIdMatch: 'ranking:pagina' },
      { id: 'loja_coins_comprar', label: 'Comprar Produto (Loja Coins)', defaultStyle: ButtonStyle.Success, defaultEmoji: null, customIdMatch: 'loja:buy:confirm' },
      { id: 'loja_coins_fechar_topico', label: 'Fechar Topico (Loja Coins)', defaultStyle: ButtonStyle.Danger, defaultEmoji: null, customIdMatch: 'loja:topic:close' },
      { id: 'sorteio_participar', label: 'Participar do Sorteio', defaultStyle: ButtonStyle.Success, defaultEmoji: null, customIdMatch: 'sorteios:public:participar' },
      { id: 'sorteio_sair', label: 'Sair do Sorteio', defaultStyle: ButtonStyle.Danger, defaultEmoji: null, customIdMatch: 'sorteios:public:sair' },
      { id: 'sorteio_lista', label: 'Ver Participantes', defaultStyle: ButtonStyle.Secondary, defaultEmoji: null, customIdMatch: 'sorteios:public:lista' },
      { id: 'sorteio_sortear', label: 'Realizar Sorteio Agora', defaultStyle: ButtonStyle.Success, defaultEmoji: null, customIdMatch: 'sorteios:edit:sortear' },
      { id: 'sorteio_encerrar', label: 'Encerrar Sorteio', defaultStyle: ButtonStyle.Secondary, defaultEmoji: null, customIdMatch: 'sorteios:edit:encerrar' },
    ],
  },
  atendimento_seguranca: {
    id: 'atendimento_seguranca',
    nome: 'Atendimento & Seguranca',
    descricao: 'Botoes de tickets, avisos, consulta de blacklist e exposed',
    emoji: null,
    botoes: [
      { id: 'ticket_enviar', label: 'Enviar Ticket', defaultStyle: ButtonStyle.Success, defaultEmoji: null, customIdMatch: 'ticket:send' },
      { id: 'ticket_fechar', label: 'Fechar Ticket', defaultStyle: ButtonStyle.Danger, defaultEmoji: null, customIdMatch: 'ticket:close' },
      { id: 'ticket_assumir', label: 'Assumir Ticket', defaultStyle: ButtonStyle.Primary, defaultEmoji: null, customIdMatch: 'ticket:assumir' },
      { id: 'ticket_confirmar_fechamento', label: 'Confirmar Fechamento', defaultStyle: ButtonStyle.Danger, defaultEmoji: null, customIdMatch: 'ticket:close:confirm' },
      { id: 'ticket_cancelar_fechamento', label: 'Cancelar Fechamento', defaultStyle: ButtonStyle.Secondary, defaultEmoji: null, customIdMatch: 'ticket:close:cancel' },
      { id: 'bl_consultar', label: 'Consultar Blacklist', defaultStyle: ButtonStyle.Secondary, defaultEmoji: null, customIdMatch: 'blacklist:consultar' },
      { id: 'bl_jogadores', label: 'Jogadores na Blacklist', defaultStyle: ButtonStyle.Secondary, defaultEmoji: null, customIdMatch: 'blacklist:jogadores' },
      { id: 'bl_anterior', label: 'Anterior (Blacklist)', defaultStyle: ButtonStyle.Secondary, defaultEmoji: null, customIdMatch: 'blacklist:jogadores_nav' },
      { id: 'bl_proximo', label: 'Proximo (Blacklist)', defaultStyle: ButtonStyle.Secondary, defaultEmoji: null, customIdMatch: 'blacklist:jogadores_nav' },
      { id: 'exposed_voltar', label: 'Voltar (Exposed)', defaultStyle: ButtonStyle.Secondary, defaultEmoji: null, customIdMatch: 'exposed:voltar' },
      { id: 'exposed_editar', label: 'Editar (Exposed)', defaultStyle: ButtonStyle.Primary, defaultEmoji: null, customIdMatch: 'exposed:editar' },
      { id: 'exposed_enviar', label: 'Enviar Exposed', defaultStyle: ButtonStyle.Danger, defaultEmoji: null, customIdMatch: 'exposed:enviar' },
      { id: 'avisos_enviar', label: 'Enviar Aviso', defaultStyle: ButtonStyle.Success, defaultEmoji: null, customIdMatch: 'avisos:enviar' },
      { id: 'avisos_limpar', label: 'Limpar Avisos', defaultStyle: ButtonStyle.Danger, defaultEmoji: null, customIdMatch: 'avisos:limpar' },
      { id: 'avisos_voltar', label: 'Voltar (Avisos)', defaultStyle: ButtonStyle.Secondary, defaultEmoji: null, customIdMatch: 'avisos:voltar' },
    ],
  },
  dev_central_loja: {
    id: 'dev_central_loja',
    nome: 'Dev Central & Loja',
    descricao: 'Botoes de compra na loja, termos de uso e gestao de bots',
    emoji: null,
    botoes: [
      { id: 'loja_comprar', label: 'Comprar', defaultStyle: ButtonStyle.Success, defaultEmoji: null, customIdMatch: 'dev:loja:public:buy' },
      { id: 'loja_termos', label: 'Ler Termos', defaultStyle: ButtonStyle.Secondary, defaultEmoji: null, customIdMatch: 'dev:loja:public:terms' },
      { id: 'bots_iniciar', label: 'Iniciar', defaultStyle: ButtonStyle.Success, defaultEmoji: null, customIdMatch: 'dev:bots:start_all' },
      { id: 'bots_parar', label: 'Parar', defaultStyle: ButtonStyle.Danger, defaultEmoji: null, customIdMatch: 'dev:bots:stop_panel' },
      { id: 'bots_cadastrar', label: 'Cadastrar tokens', defaultStyle: ButtonStyle.Secondary, defaultEmoji: null, customIdMatch: 'dev:bots:register_tokens' },
      { id: 'bots_remover', label: 'Remover tokens', defaultStyle: ButtonStyle.Secondary, defaultEmoji: null, customIdMatch: 'dev:bots:remove_tokens_panel' },
      { id: 'testes_resgatar', label: 'Resgatar Teste Gratis', defaultStyle: ButtonStyle.Success, defaultEmoji: null, customIdMatch: 'dev:testes:public:claim' },
      { id: 'dev_painel_loja', label: 'Criar Painel Loja', defaultStyle: ButtonStyle.Success, defaultEmoji: null, customIdMatch: 'dev:loja:create_panel' },
      { id: 'dev_painel_testes', label: 'Criar Painel Testes', defaultStyle: ButtonStyle.Success, defaultEmoji: null, customIdMatch: 'dev:testes:create_panel' },
      { id: 'dev_loja_cfg', label: 'Loja config', defaultStyle: ButtonStyle.Secondary, defaultEmoji: null, customIdMatch: 'dev:loja:menu' },
      { id: 'dev_bots_cfg', label: 'Gestao bots', defaultStyle: ButtonStyle.Secondary, defaultEmoji: null, customIdMatch: 'dev:bots:menu' },
      { id: 'dev_testes_cfg', label: 'Config testes', defaultStyle: ButtonStyle.Secondary, defaultEmoji: null, customIdMatch: 'dev:testes:menu' },
      { id: 'dev_buttons_cfg', label: 'Config botoes', defaultStyle: ButtonStyle.Secondary, defaultEmoji: null, customIdMatch: 'dev:buttons:menu' },
      { id: 'dev_voltar', label: 'Voltar (Dev Central)', defaultStyle: ButtonStyle.Secondary, defaultEmoji: null, customIdMatch: 'dev:main:back' },
    ],
  },
};

// Índice rápido de botão por ID
const MAPA_TODOS_BOTOES = {};
for (const [catKey, catVal] of Object.entries(CATEGORIAS_BOTOES)) {
  for (const b of catVal.botoes) {
    MAPA_TODOS_BOTOES[b.id] = { ...b, categoriaId: catKey };
  }
}

// ── Mapeamento de Aliases e Resolução Exata ───────────────────────────────────

const ALIASES_EXATOS = {
  'entrar_fila': 'fila_entrar',
  'fila_entrar': 'fila_entrar',
  'sair': 'fila_sair',
  'fila_sair': 'fila_sair',
  'gelo_normal': 'fila_gelo_normal',
  'fila_gelo_normal': 'fila_gelo_normal',
  'gelo_infinito': 'fila_gelo_infinito',
  'fila_gelo_infinito': 'fila_gelo_infinito',
  'emu_1': 'fila_1_emu',
  'emu1': 'fila_1_emu',
  'fila_1_emu': 'fila_1_emu',
  'emu_2': 'fila_2_emu',
  'emu2': 'fila_2_emu',
  'fila_2_emu': 'fila_2_emu',
  'emu_3': 'fila_3_emu',
  'emu3': 'fila_3_emu',
  'fila_3_emu': 'fila_3_emu',

  'partida_copiar_id': 'partida_copiar_id',
  'partida_copiar_senha': 'partida_copiar_senha',
  'partida_copiar_pix': 'partida_copiar_pix',
  'partida_chamar_mediador': 'partida_chamar_mediador',
  'partida_trocar_sala': 'partida_trocar_sala',
  'partida_ver_print': 'partida_ver_print',
  'partida_vitoria_normal': 'partida_vitoria_normal',
  'partida_vitoria_wo': 'partida_vitoria_wo',
  'partida_cancelar_resultado': 'partida_cancelar_resultado',
  'partida_fechar': 'partida_fechar',
  'filas_enviar': 'filas_enviar',
  'filas_limpar': 'filas_limpar',

  'fmed_entrar': 'fmed_entrar',
  'fmed_sair': 'fmed_sair',
  'fmed_pix': 'fmed_pix',
  'fmed_ranking': 'fmed_ranking',
  'fmed_limpar': 'fmed_limpar',
  'fan_entrar': 'fan_entrar',
  'fan_sair': 'fan_sair',
  'fan_ranking': 'fan_ranking',
  'fan_historico': 'fan_historico',
  'streamer_entrar': 'streamer_entrar',
  'streamer_sair': 'streamer_sair',
  'streamer_online': 'streamer_online',
  'streamer_historico': 'streamer_historico',
  'streamer_informacoes': 'streamer_informacoes',
  'team_ryze_entrar': 'team_ryze_entrar',
  'team_ryze_sair': 'team_ryze_sair',

  'ranking_perfil': 'ranking_perfil',
  'ranking_periodos': 'ranking_periodos',
  'ranking_anterior': 'ranking_anterior',
  'ranking_proximo': 'ranking_proximo',
  'loja_coins_comprar': 'loja_coins_comprar',
  'loja_coins_fechar_topico': 'loja_coins_fechar_topico',
  'sorteio_participar': 'sorteio_participar',
  'sorteio_sair': 'sorteio_sair',
  'sorteio_lista': 'sorteio_lista',
  'sorteio_sortear': 'sorteio_sortear',
  'sorteio_encerrar': 'sorteio_encerrar',

  'ticket_enviar': 'ticket_enviar',
  'ticket_fechar': 'ticket_fechar',
  'ticket_assumir': 'ticket_assumir',
  'ticket_confirmar_fechamento': 'ticket_confirmar_fechamento',
  'ticket_cancelar_fechamento': 'ticket_cancelar_fechamento',
  'bl_consultar': 'bl_consultar',
  'bl_jogadores': 'bl_jogadores',
  'bl_anterior': 'bl_anterior',
  'bl_proximo': 'bl_proximo',
  'exposed_voltar': 'exposed_voltar',
  'exposed_editar': 'exposed_editar',
  'exposed_enviar': 'exposed_enviar',
  'avisos_enviar': 'avisos_enviar',
  'avisos_limpar': 'avisos_limpar',
  'avisos_voltar': 'avisos_voltar',

  'loja_comprar': 'loja_comprar',
  'loja_termos': 'loja_termos',
  'bots_iniciar': 'bots_iniciar',
  'bots_parar': 'bots_parar',
  'bots_cadastrar': 'bots_cadastrar',
  'bots_remover': 'bots_remover',
  'testes_resgatar': 'testes_resgatar',
  'dev_painel_loja': 'dev_painel_loja',
  'dev_painel_testes': 'dev_painel_testes',
  'dev_loja_cfg': 'dev_loja_cfg',
  'dev_bots_cfg': 'dev_bots_cfg',
  'dev_testes_cfg': 'dev_testes_cfg',
  'dev_buttons_cfg': 'dev_buttons_cfg',
  'dev_voltar': 'dev_voltar',
};

function resolverIdBotao(identificador) {
  if (!identificador || typeof identificador !== 'string') return null;
  const id = identificador.trim();

  // 1. Match direto ou por alias
  if (MAPA_TODOS_BOTOES[id]) return id;
  if (ALIASES_EXATOS[id]) return ALIASES_EXATOS[id];

  // 2. Match específico por regras de regex do custom_id
  if (/^fq:in:.*:gelo_normal$/i.test(id) || id.includes('gelo_normal')) return 'fila_gelo_normal';
  if (/^fq:in:.*:gelo_infinito$/i.test(id) || id.includes('gelo_infinito')) return 'fila_gelo_infinito';
  if (/^fq:in:.*:emu1$/i.test(id) || id.includes('emu1') || id.endsWith(':emu_1')) return 'fila_1_emu';
  if (/^fq:in:.*:emu2$/i.test(id) || id.includes('emu2') || id.endsWith(':emu_2')) return 'fila_2_emu';
  if (/^fq:in:.*:emu3$/i.test(id) || id.includes('emu3') || id.endsWith(':emu_3')) return 'fila_3_emu';
  if (/^fq:in:/i.test(id) || id.includes('entrar')) return 'fila_entrar';
  if (/^fq:out:/i.test(id) || id.includes('sair')) return 'fila_sair';

  if (/partida:.*:copiar_sala_id/i.test(id)) return 'partida_copiar_id';
  if (/partida:.*:copiar_sala_senha/i.test(id)) return 'partida_copiar_senha';
  if (/partida:.*:copiar/i.test(id)) return 'partida_copiar_pix';
  if (/partida:.*:chamar_mediador/i.test(id) || id === 'chamar_mediador') return 'partida_chamar_mediador';
  if (/partida:.*:trocar_sala/i.test(id) || id === 'trocar_sala') return 'partida_trocar_sala';
  if (/partida:.*:ver_print/i.test(id) || id === 'ver_print') return 'partida_ver_print';
  if (/partida:.*:wo/i.test(id)) return 'partida_vitoria_wo';
  if (/partida:.*:normal/i.test(id)) return 'partida_vitoria_normal';
  if (/partida:.*:cancelar_resultado/i.test(id)) return 'partida_cancelar_resultado';
  if (/partida:.*:fechar/i.test(id)) return 'partida_fechar';
  if (/filas:enviar/i.test(id)) return 'filas_enviar';
  if (/filas:limpar/i.test(id)) return 'filas_limpar';

  if (/fmed:in/i.test(id)) return 'fmed_entrar';
  if (/fmed:out/i.test(id)) return 'fmed_sair';
  if (/fmed:pix/i.test(id)) return 'fmed_pix';
  if (/fmed:ranking/i.test(id)) return 'fmed_ranking';
  if (/fmed:limpar/i.test(id)) return 'fmed_limpar';

  if (/fan:entrar/i.test(id)) return 'fan_entrar';
  if (/fan:sair/i.test(id)) return 'fan_sair';
  if (/fan:ranking/i.test(id)) return 'fan_ranking';
  if (/fan:historico/i.test(id)) return 'fan_historico';

  if (/streamer:fila:entrar/i.test(id)) return 'streamer_entrar';
  if (/streamer:fila:sair/i.test(id)) return 'streamer_sair';
  if (/streamer:fila:online/i.test(id)) return 'streamer_online';
  if (/streamer:fila:historico/i.test(id)) return 'streamer_historico';
  if (/streamer:fila:informacoes/i.test(id)) return 'streamer_informacoes';

  if (/team_ryze:call:entrar/i.test(id) || /team_ryze:entrar/i.test(id)) return 'team_ryze_entrar';
  if (/team_ryze:call:sair/i.test(id) || /team_ryze:sair/i.test(id)) return 'team_ryze_sair';

  if (/ranking:perfil/i.test(id)) return 'ranking_perfil';
  if (/ranking:periodos/i.test(id)) return 'ranking_periodos';
  if (/ranking:pagina:prev/i.test(id) || /ranking:prev/i.test(id)) return 'ranking_anterior';
  if (/ranking:pagina:next/i.test(id) || /ranking:next/i.test(id)) return 'ranking_proximo';

  if (/loja:buy:confirm/i.test(id)) return 'loja_coins_comprar';
  if (/loja:topic:close/i.test(id)) return 'loja_coins_fechar_topico';

  if (/sorteios:public:participar/i.test(id)) return 'sorteio_participar';
  if (/sorteios:public:sair/i.test(id)) return 'sorteio_sair';
  if (/sorteios:public:lista/i.test(id)) return 'sorteio_lista';
  if (/sorteios:edit:sortear/i.test(id)) return 'sorteio_sortear';
  if (/sorteios:edit:encerrar/i.test(id)) return 'sorteio_encerrar';

  if (/ticket:send/i.test(id)) return 'ticket_enviar';
  if (/ticket:close:confirm/i.test(id)) return 'ticket_confirmar_fechamento';
  if (/ticket:close:cancel/i.test(id)) return 'ticket_cancelar_fechamento';
  if (/ticket:close/i.test(id)) return 'ticket_fechar';
  if (/ticket:assumir/i.test(id)) return 'ticket_assumir';

  if (/blacklist:consultar/i.test(id)) return 'bl_consultar';
  if (/blacklist:jogadores_nav:prev/i.test(id)) return 'bl_anterior';
  if (/blacklist:jogadores_nav:next/i.test(id)) return 'bl_proximo';
  if (/blacklist:jogadores/i.test(id)) return 'bl_jogadores';

  if (/exposed:voltar/i.test(id)) return 'exposed_voltar';
  if (/exposed:editar/i.test(id)) return 'exposed_editar';
  if (/exposed:enviar/i.test(id)) return 'exposed_enviar';

  if (/avisos:enviar/i.test(id)) return 'avisos_enviar';
  if (/avisos:limpar/i.test(id)) return 'avisos_limpar';
  if (/avisos:voltar/i.test(id)) return 'avisos_voltar';

  if (/dev:loja:public:buy/i.test(id)) return 'loja_comprar';
  if (/dev:loja:public:terms/i.test(id)) return 'loja_termos';
  if (/dev:bots:start_all/i.test(id)) return 'bots_iniciar';
  if (/dev:bots:stop_panel/i.test(id)) return 'bots_parar';
  if (/dev:bots:register_tokens/i.test(id)) return 'bots_cadastrar';
  if (/dev:bots:remove_tokens_panel/i.test(id)) return 'bots_remover';
  if (/dev:testes:public:claim/i.test(id) || /dev:testes:claim/i.test(id)) return 'testes_resgatar';
  if (/dev:loja:create_panel/i.test(id)) return 'dev_painel_loja';
  if (/dev:testes:create_panel/i.test(id)) return 'dev_painel_testes';
  if (/dev:loja:menu/i.test(id)) return 'dev_loja_cfg';
  if (/dev:bots:menu/i.test(id)) return 'dev_bots_cfg';
  if (/dev:testes:menu/i.test(id)) return 'dev_testes_cfg';
  if (/dev:buttons:menu/i.test(id)) return 'dev_buttons_cfg';
  if (/dev:main:back/i.test(id)) return 'dev_voltar';

  return null;
}

// ── Persistência Global ───────────────────────────────────────────────────────

function lerConfiguracaoGlobalBotoes() {
  try {
    const data = lerJSON(DATA_FILE, {});
    if (data && typeof data === 'object') return data;
  } catch (err) {
    console.error('[BOTOES] Erro ao ler botoes_config.json:', err.message);
  }
  return {};
}

let _configBotoesGlobal = lerConfiguracaoGlobalBotoes();

function salvarConfiguracaoGlobalBotoes(dados) {
  _configBotoesGlobal = dados;
  try {
    salvarJSON(DATA_FILE, dados);
  } catch (err) {
    console.error('[BOTOES] Erro ao salvar botoes_config.json:', err.message);
  }
}

// ── Utilitários de Estilo e Emoji ─────────────────────────────────────────────

function parseButtonStyle(str, fallback = ButtonStyle.Secondary) {
  if (!str) return fallback;
  const s = String(str).trim().toLowerCase();
  if (s.includes('azul') || s.includes('blue') || s.includes('primary') || s === '1') {
    return ButtonStyle.Primary;
  }
  if (s.includes('verde') || s.includes('green') || s.includes('success') || s === '3') {
    return ButtonStyle.Success;
  }
  if (s.includes('vermelho') || s.includes('red') || s.includes('danger') || s === '4') {
    return ButtonStyle.Danger;
  }
  if (s.includes('cinza') || s.includes('grey') || s.includes('gray') || s.includes('secondary') || s === '2') {
    return ButtonStyle.Secondary;
  }
  return fallback;
}

function getStyleName(styleEnum) {
  switch (styleEnum) {
    case ButtonStyle.Primary:
      return 'Azul (Primary)';
    case ButtonStyle.Success:
      return 'Verde (Success)';
    case ButtonStyle.Danger:
      return 'Vermelho (Danger)';
    case ButtonStyle.Secondary:
    default:
      return 'Cinza (Secondary)';
  }
}

function getStyleShortName(styleEnum) {
  switch (styleEnum) {
    case ButtonStyle.Primary:
      return 'Azul';
    case ButtonStyle.Success:
      return 'Verde';
    case ButtonStyle.Danger:
      return 'Vermelho';
    case ButtonStyle.Secondary:
    default:
      return 'Cinza';
  }
}

function parseEmojiInput(str) {
  if (!str) return null;
  const clean = String(str).trim();
  if (!clean || ['nenhum', 'none', 'vazio', 'remover', 'padrao', 'padrão'].includes(clean.toLowerCase())) {
    return null;
  }
  const custom = clean.match(/^<(a?):([A-Za-z0-9_~]+):(\d+)>$/);
  if (custom) {
    return {
      animated: custom[1] === 'a',
      name: custom[2],
      id: custom[3],
    };
  }
  return clean;
}

function formatEmojiDisplay(emojiVal) {
  if (!emojiVal) return 'Nenhum';
  if (typeof emojiVal === 'object' && emojiVal.id) {
    return `<${emojiVal.animated ? 'a' : ''}:${emojiVal.name}:${emojiVal.id}>`;
  }
  return String(emojiVal);
}

// ── Obtenção e Aplicação de Configurações ──────────────────────────────────────

function obterConfigBotao(botaoId) {
  const resolvedId = resolverIdBotao(botaoId) || botaoId;
  const def = MAPA_TODOS_BOTOES[resolvedId];
  if (!def) return null;

  // Atualiza cache em memória para garantir consistência
  _configBotoesGlobal = lerConfiguracaoGlobalBotoes();
  const salvo = _configBotoesGlobal[resolvedId] || {};

  const style = salvo.style !== undefined ? parseButtonStyle(salvo.style, def.defaultStyle) : def.defaultStyle;
  const emoji = salvo.emoji !== undefined ? salvo.emoji : (def.defaultEmoji || null);

  return {
    id: resolvedId,
    label: def.label,
    style,
    emoji,
    isCustomStyle: salvo.style !== undefined,
    isCustomEmoji: salvo.emoji !== undefined,
    categoriaId: def.categoriaId,
  };
}

function definirConfigBotao(botaoId, styleInput, emojiInput) {
  const resolvedId = resolverIdBotao(botaoId) || botaoId;
  const def = MAPA_TODOS_BOTOES[resolvedId];
  if (!def) return false;

  _configBotoesGlobal = lerConfiguracaoGlobalBotoes();
  const current = _configBotoesGlobal[resolvedId] || {};
  const parsedStyle = parseButtonStyle(styleInput, def.defaultStyle);
  const parsedEmoji = parseEmojiInput(emojiInput);

  _configBotoesGlobal[resolvedId] = {
    ...current,
    style: getStyleShortName(parsedStyle),
    emoji: parsedEmoji,
  };

  salvarConfiguracaoGlobalBotoes(_configBotoesGlobal);
  return true;
}

/**
 * Aplica automaticamente a personalização (estilo e emoji) em um ButtonBuilder ou componente existente.
 */
function aplicarEstiloBotao(buttonBuilder, botaoIdOuCustomId) {
  if (!buttonBuilder) return buttonBuilder;

  const config = obterConfigBotao(botaoIdOuCustomId);
  if (config) {
    // 1. Aplica o estilo
    if (typeof buttonBuilder.setStyle === 'function') {
      buttonBuilder.setStyle(config.style);
    }
    if (buttonBuilder.data) {
      buttonBuilder.data.style = config.style;
    }
    if (buttonBuilder.style !== undefined && typeof buttonBuilder.style !== 'function') {
      buttonBuilder.style = config.style;
    }

    // 2. Aplica ou remove o emoji
    if (config.emoji) {
      if (typeof buttonBuilder.setEmoji === 'function') {
        try {
          buttonBuilder.setEmoji(config.emoji);
        } catch (_) {
          if (buttonBuilder.data) {
            if (typeof config.emoji === 'object' && config.emoji?.id) {
              buttonBuilder.data.emoji = { id: config.emoji.id, name: config.emoji.name, animated: Boolean(config.emoji.animated) };
            } else if (typeof config.emoji === 'string') {
              buttonBuilder.data.emoji = { name: config.emoji };
            }
          }
        }
      } else if (buttonBuilder.data) {
        if (typeof config.emoji === 'object' && config.emoji?.id) {
          buttonBuilder.data.emoji = { id: config.emoji.id, name: config.emoji.name, animated: Boolean(config.emoji.animated) };
        } else if (typeof config.emoji === 'string') {
          buttonBuilder.data.emoji = { name: config.emoji };
        }
      }
    } else {
      if (buttonBuilder.data && buttonBuilder.data.emoji) {
        delete buttonBuilder.data.emoji;
      }
    }
  }

  return buttonBuilder;
}

/**
 * Cria um ButtonBuilder novo já estilizado e configurado.
 */
function criarBotaoCustom(botaoId, labelFallback, customId, defaultStyle = ButtonStyle.Secondary, defaultEmoji = null) {
  const config = obterConfigBotao(botaoId);
  const btn = new ButtonBuilder()
    .setCustomId(customId)
    .setLabel(config ? config.label : labelFallback)
    .setStyle(config ? config.style : defaultStyle);

  const emoji = config ? config.emoji : defaultEmoji;
  if (emoji) {
    try {
      btn.setEmoji(emoji);
    } catch (_) {}
  }

  return btn;
}

// Cor padrão fixa vermelha para todos os painéis administrativos de dono do bot
const COR_PAINEL_DONO = 0xED4245;

// ── Painéis do Sistema "Config Botões" ─────────────────────────────────────────

function painelCategoriasBotoes(guildId, aviso = null) {
  let desc =
    'Selecione no menu abaixo a **categoria** dos botões que você deseja personalizar.\n\n' +
    '• **Alcance Global:** Qualquer alteração aqui reflete instantaneamente em todos os bots e servidores.\n' +
    '• **Personalização:** Modifique a cor (Azul, Verde, Vermelho, Cinza) e o emoji de cada botão.';

  if (aviso) {
    desc += `\n\n**Aviso:** ${aviso}`;
  }

  const embed = new EmbedBuilder()
    .setColor(COR_PAINEL_DONO)
    .setTitle('CONFIGURACAO GLOBAL DE BOTOES')
    .setDescription(desc)
    .addFields(
      Object.values(CATEGORIAS_BOTOES).map((cat) => ({
        name: cat.nome,
        value: `${cat.descricao}\n*(${cat.botoes.length} botoes)*`,
        inline: false,
      }))
    );

  const selectCategorias = new StringSelectMenuBuilder()
    .setCustomId('dev:buttons:select_category')
    .setPlaceholder('Selecione uma categoria para configurar')
    .addOptions(
      Object.values(CATEGORIAS_BOTOES).map((cat) => ({
        label: cat.nome.slice(0, 100),
        value: cat.id,
        description: cat.descricao.slice(0, 100),
      }))
    );

  const rowSelect = new ActionRowBuilder().addComponents(selectCategorias);

  const rowBotoes = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('dev:main:back')
      .setLabel('Voltar')
      .setStyle(ButtonStyle.Secondary)
  );

  return painelV2FromEmbed(embed, [rowSelect, rowBotoes]);
}

function painelBotoesDaCategoria(guildId, categoriaId, aviso = null) {
  const cat = CATEGORIAS_BOTOES[categoriaId] || CATEGORIAS_BOTOES.filas_partidas;

  let desc =
    `Voce esta na categoria **${cat.nome}**.\n` +
    'Selecione no menu abaixo o botao que voce deseja customizar (cor e emoji).\n\n' +
    '**Configuracoes Atuais dos Botoes:**\n';

  const previewList = cat.botoes.map((b, idx) => {
    const cfg = obterConfigBotao(b.id);
    const emojiStr = cfg.emoji ? formatEmojiDisplay(cfg.emoji) : '*(sem emoji)*';
    const styleStr = getStyleShortName(cfg.style);
    return `\`${idx + 1}.\` **${b.label}** -> Cor: \`${styleStr}\` | Emoji: ${emojiStr}`;
  }).join('\n');

  desc += previewList;

  if (aviso) {
    desc += `\n\n**Aviso:** ${aviso}`;
  }

  const embed = new EmbedBuilder()
    .setColor(COR_PAINEL_DONO)
    .setTitle(`BOTOES: ${cat.nome.toUpperCase()}`)
    .setDescription(desc);

  const selectBotoes = new StringSelectMenuBuilder()
    .setCustomId(`dev:buttons:select_button:${cat.id}`)
    .setPlaceholder('Escolha um botao para editar a cor e emoji')
    .addOptions(
      cat.botoes.map((b) => {
        const cfg = obterConfigBotao(b.id);
        const styleStr = getStyleShortName(cfg.style);
        const option = {
          label: b.label.slice(0, 100),
          value: b.id,
          description: `Cor: ${styleStr} | ID: ${b.id}`.slice(0, 100),
        };
        return option;
      })
    );

  const rowSelect = new ActionRowBuilder().addComponents(selectBotoes);

  const rowBotoes = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('dev:buttons:menu')
      .setLabel('Voltar')
      .setStyle(ButtonStyle.Secondary)
  );

  return painelV2FromEmbed(embed, [rowSelect, rowBotoes]);
}

function modalConfigurarBotao(botaoId) {
  const def = MAPA_TODOS_BOTOES[botaoId];
  if (!def) return null;

  const cfg = obterConfigBotao(botaoId);
  const styleDisplay = getStyleShortName(cfg.style);
  const emojiDisplay = cfg.emoji ? (typeof cfg.emoji === 'object' ? formatEmojiDisplay(cfg.emoji) : String(cfg.emoji)) : '';

  const modal = new ModalBuilder()
    .setCustomId(`dev:buttons:modal:${botaoId}`)
    .setTitle(`Configurar: ${def.label}`.slice(0, 45));

  const inputCor = new TextInputBuilder()
    .setCustomId('button_style')
    .setLabel('Cor do Botão (Azul, Verde, Vermelho, Cinza)')
    .setPlaceholder('Ex: Azul (Primary), Verde (Success), Vermelho, Cinza')
    .setStyle(TextInputStyle.Short)
    .setValue(styleDisplay)
    .setMaxLength(30)
    .setRequired(true);

  const inputEmoji = new TextInputBuilder()
    .setCustomId('button_emoji')
    .setLabel('Emoji do Botão (Unicode ou <:nome:id>)')
    .setPlaceholder('Ex: ⚔️ ou <:icone:123456789> (ou deixe vazio)')
    .setStyle(TextInputStyle.Short)
    .setMaxLength(100)
    .setRequired(false);

  if (emojiDisplay) {
    inputEmoji.setValue(emojiDisplay);
  }

  modal.addComponents(
    new ActionRowBuilder().addComponents(inputCor),
    new ActionRowBuilder().addComponents(inputEmoji),
  );

  return modal;
}

module.exports = {
  CATEGORIAS_BOTOES,
  MAPA_TODOS_BOTOES,
  obterConfigBotao,
  definirConfigBotao,
  aplicarEstiloBotao,
  criarBotaoCustom,
  painelCategoriasBotoes,
  painelBotoesDaCategoria,
  modalConfigurarBotao,
  getStyleName,
  getStyleShortName,
  formatEmojiDisplay,
};
