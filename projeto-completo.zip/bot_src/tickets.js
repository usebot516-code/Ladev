'use strict';

const fs = require('fs');
const path = require('path');
const {
  EmbedBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ChannelSelectMenuBuilder,
  UserSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ChannelType,
  MessageFlags,
  PermissionFlagsBits,
} = require('discord.js');

const { painelV2FromEmbed } = require('./visual');
const { getConfig } = require('./configurar');
const { mensagem: _msg } = require('./avisos_mensagens');
const { dataPath } = require('./data-path');

const DATA_FILE = dataPath('tickets_data.json');
const state = readData();
const pendingClosures = new Map();
const pendingCreations = new Set(); // lock por userId — evita criação duplicada
const pendingClaims = new Set(); // lock por ticket — evita dois atendentes assumirem ao mesmo tempo
const pendingCloseActions = new Set(); // lock por ticket — evita fechamento duplicado
const MAX_CATEGORIES = 25; // limite do Discord para opções em um menu de seleção

function readData() {
  try {
    return fs.existsSync(DATA_FILE) ? JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')) : {};
  } catch (error) {
    console.error('[TICKETS] Falha ao ler dados:', error.message);
    return {};
  }
}

let _saving = false;
let _savePending = false;
function saveData() {
  if (_saving) {
    _savePending = true;
    return;
  }
  _saving = true;
  const tmp = `${DATA_FILE}.tmp`;
  try {
    fs.mkdir(path.dirname(DATA_FILE), { recursive: true }, () => {
      fs.writeFile(tmp, JSON.stringify(state, null, 2), 'utf8', (err) => {
        if (!err) {
          fs.rename(tmp, DATA_FILE, () => {
            _saving = false;
            if (_savePending) {
              _savePending = false;
              saveData();
            }
          });
        } else {
          _saving = false;
        }
      });
    });
  } catch (error) {
    _saving = false;
  }
}

function guildState(guildId) {
  if (!state[guildId]) state[guildId] = { appearance: { title: 'Central de Tickets', description: 'Selecione uma categoria para abrir um ticket.', banner: null, thumbnail: null }, categories: [], panels: [], tickets: [] };
  const current = state[guildId];
  current.appearance = { title: 'Central de Tickets', description: 'Selecione uma categoria para abrir um ticket.', banner: null, thumbnail: null, ...(current.appearance ?? {}) };
  current.appearance.title = String(current.appearance.title || 'Central de Tickets').trim().slice(0, 256);
  current.appearance.description = String(current.appearance.description || 'Selecione uma categoria para abrir um ticket.').trim().slice(0, 4000);
  if (!Array.isArray(current.categories)) current.categories = [];
  if (!Array.isArray(current.panels)) current.panels = [];
  if (!Array.isArray(current.tickets)) current.tickets = [];
  current.categories = current.categories
    .filter((item) => item && typeof item === 'object')
    .map((item) => ({
      ...item,
      id: String(item.id || `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`),
      name: String(item.name || 'Categoria').trim().slice(0, 100),
      description: String(item.description || 'Categoria de atendimento').trim().slice(0, 500),
      emoji: String(item.emoji || '').trim().slice(0, 100),
      roleIds: Array.isArray(item.roleIds) ? [...new Set(item.roleIds.map(String).filter(Boolean))] : [],
    }));
  current.tickets = current.tickets
    .filter((item) => item && typeof item === 'object')
    .map((item) => ({
      ...item,
      id: String(item.id || `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`),
      threadId: item.threadId ? String(item.threadId) : null,
      panelMessageId: item.panelMessageId ? String(item.panelMessageId) : null,
      creatorId: String(item.creatorId || ''),
      categoryId: String(item.categoryId || ''),
      categoryName: String(item.categoryName || 'Atendimento').trim().slice(0, 100),
      categoryDescription: String(item.categoryDescription || 'Utilize o menu abaixo para gerenciar este ticket.').trim().slice(0, 500),
      roleIds: Array.isArray(item.roleIds) ? [...new Set(item.roleIds.map(String).filter(Boolean))] : [],
      responsibleId: item.responsibleId ? String(item.responsibleId) : null,
      closedAt: item.closedAt ? String(item.closedAt) : null,
      closeReason: String(item.closeReason || '').slice(0, 1000),
    }));
  return current;
}

function color(guildId) {
  return getConfig(guildId)?.embedColor ?? 0x5865f2;
}

function validUrl(value) {
  try {
    const url = new URL(String(value ?? '').trim());
    return ['http:', 'https:'].includes(url.protocol) ? url.toString() : null;
  } catch (_) {
    return null;
  }
}

function topicSlug(value, fallback = 'atendimento') {
  const slug = String(value ?? '')
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/gi, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 70);
  return slug || fallback;
}

function ticketTopicName(categoryName, memberName) {
  return `ticket-${topicSlug(categoryName)}-${topicSlug(memberName, 'membro')}`.slice(0, 100);
}

async function waitForThreadMember(thread, userId) {
  for (let attempt = 0; attempt < 4; attempt += 1) {
    const member = await thread.members.fetch(userId).catch(() => null);
    if (member) return true;
    await new Promise((resolve) => setTimeout(resolve, 350));
  }
  return false;
}

function panelEmbed(guildId, title, description, fields = []) {
  return new EmbedBuilder().setColor(color(guildId)).setTitle(title).setDescription(description).addFields(fields);
}

function truncateField(value, max = 1024) {
  const text = String(value ?? '');
  return text.length > max ? `${text.slice(0, max - 1)}…` : text;
}

function configPanel(guildId, notice = '') {
  const data = guildState(guildId);
  const a = data.appearance;
  const categories = data.categories.length ? truncateField(data.categories.map((item, index) => `${index + 1}. ${item.name}`).join('\n')) : 'Nenhuma categoria cadastrada';
  const embed = panelEmbed(guildId, 'CONFIGURAÇÃO DE TICKETS', `${notice ? `${notice}\n\n` : ''}Configure o painel público de tickets. Todas as alterações são salvas automaticamente.`, [
    { name: 'Aparência', value: `Título: **${a.title}**\nDescrição: **${a.description.slice(0, 250)}**\nBanner: **${a.banner ? 'Configurado' : 'Não definido'}**\nThumbnail: **${a.thumbnail ? 'Configurada' : 'Não definida'}**` },
    { name: `Categorias • ${data.categories.length}`, value: categories },
  ]);
  const menu = new StringSelectMenuBuilder().setCustomId('ticket:config_menu').setPlaceholder('Escolha o que deseja configurar').addOptions(
    { label: 'Aparência', value: 'appearance', description: 'Título, descrição e imagens do painel' },
    { label: 'Categorias', value: 'categories', description: 'Criar, remover, visualizar e ordenar categorias' },
  );
  return { ...painelV2FromEmbed(embed, [new ActionRowBuilder().addComponents(menu), new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('ticket:send').setLabel('Enviar').setStyle(ButtonStyle.Success))]), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 };
}

function appearancePanel(guildId, notice = '') {
  const a = guildState(guildId).appearance;
  const embed = panelEmbed(guildId, 'APARÊNCIA DO PAINEL DE TICKETS', `${notice ? `${notice}\n\n` : ''}Ajuste o conteúdo visual que será exibido no painel público.`, [
    { name: 'Título', value: a.title },
    { name: 'Descrição', value: a.description.slice(0, 1000) },
    { name: 'Imagens', value: `Banner: ${a.banner ? 'Configurado' : 'Não definido'}\nThumbnail: ${a.thumbnail ? 'Configurada' : 'Não definida'}` },
  ]);
  return painelV2FromEmbed(embed, [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('ticket:appearance:title').setLabel('Título').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('ticket:appearance:description').setLabel('Descrição').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('ticket:appearance:images').setLabel('Imagens').setStyle(ButtonStyle.Secondary),
    ),
    new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('ticket:back:config').setLabel('Voltar').setStyle(ButtonStyle.Secondary)),
  ]);
}

function imagesPanel(guildId, notice = '') {
  const a = guildState(guildId).appearance;
  const embed = panelEmbed(guildId, 'IMAGENS DO PAINEL DE TICKETS', `${notice ? `${notice}\n\n` : ''}Informe URLs públicas diretas para as imagens. Deixe vazio para remover.`, [
    { name: 'Banner', value: truncateField(a.banner ?? 'Não definido') },
    { name: 'Thumbnail', value: truncateField(a.thumbnail ?? 'Não definida') },
  ]);
  return painelV2FromEmbed(embed, [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('ticket:appearance:banner').setLabel('Banner').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('ticket:appearance:thumbnail').setLabel('Thumbnail').setStyle(ButtonStyle.Secondary),
    ),
    new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('ticket:back:appearance').setLabel('Voltar').setStyle(ButtonStyle.Secondary)),
  ]);
}

function categoriesPanel(guildId, notice = '') {
  const data = guildState(guildId);
  const embed = panelEmbed(guildId, 'CATEGORIAS DE TICKETS', `${notice ? `${notice}\n\n` : ''}Gerencie as categorias exibidas no painel público.`, [
    { name: 'Categorias cadastradas', value: data.categories.length ? truncateField(data.categories.map((item, i) => `${i + 1}. ${item.name}`).join('\n')) : 'Nenhuma categoria cadastrada' },
  ]);
  return painelV2FromEmbed(embed, [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('ticket:categories:create').setLabel('Criar Categoria').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('ticket:categories:remove').setLabel('Remover Categorias').setStyle(ButtonStyle.Secondary),
    ),
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('ticket:categories:roles').setLabel('Cargos Responsáveis').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('ticket:back:config').setLabel('Voltar').setStyle(ButtonStyle.Secondary),
    ),
  ]);
}

function selectMenuEmoji(value) {
  const emoji = String(value ?? '').trim();
  const custom = emoji.match(/^<(a?):([A-Za-z0-9_~]+):(\d+)>$/);
  if (custom) {
    return {
      animated: custom[1] === 'a',
      name: custom[2],
      id: custom[3],
    };
  }
  return emoji || null;
}

function categoryMenu(guildId, customId, placeholder) {
  const data = guildState(guildId);
  const menu = new StringSelectMenuBuilder().setCustomId(customId).setPlaceholder(placeholder);
  const options = data.categories.slice(0, MAX_CATEGORIES).map((item) => {
    const option = {
      label: item.name.slice(0, 100),
      value: item.id,
      description: item.description.slice(0, 100) || 'Categoria de atendimento',
    };
    const emoji = selectMenuEmoji(item.emoji);
    if (emoji) option.emoji = emoji;
    return option;
  });
  if (options.length) menu.addOptions(options);
  else menu.setDisabled(true).addOptions({ label: 'Nenhuma categoria cadastrada', value: 'none', description: 'Crie uma categoria primeiro' });
  return menu;
}

function categoriesListPanel(guildId) {
  const data = guildState(guildId);
  const description = data.categories.length
    ? data.categories.map((item, i) => `${i + 1}. ${item.emoji || '•'} **${item.name}**\n${item.description || 'Sem descrição'}`).join('\n\n').slice(0, 3900)
    : 'Nenhuma categoria cadastrada.';
  return painelV2FromEmbed(panelEmbed(guildId, 'CATEGORIAS CADASTRADAS', description), [new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('ticket:back:categories').setLabel('Voltar').setStyle(ButtonStyle.Secondary))]);
}

function rolesPanel(guildId, categoryId, notice = '') {
  const data = guildState(guildId);
  const cfg = getConfig(guildId);
  const category = data.categories.find((item) => item.id === categoryId);
  const roles = category?.roleIds?.length ? truncateField(category.roleIds.map((id) => `<@&${id}>`).join(', ')) : 'Nenhum cargo específico; use os cargos permitidos na configuração.';
  const embed = panelEmbed(guildId, 'CARGOS RESPONSÁVEIS', `${notice ? `${notice}\n\n` : ''}Defina os cargos que poderão atender cada categoria. O menu de cargos usa somente os cargos cadastrados em /configurar.`, [
    { name: 'Categoria', value: category ? category.name : 'Selecione uma categoria' },
    { name: 'Cargos desta categoria', value: roles },
    { name: 'Cargos permitidos no sistema', value: cfg.roles.tickets.length ? truncateField(cfg.roles.tickets.map((id) => `<@&${id}>`).join(', ')) : 'Nenhum cargo cadastrado em /configurar' },
  ]);
  const roleMenu = new StringSelectMenuBuilder()
    .setCustomId(`ticket:roles:select:${categoryId || 'none'}`)
    .setPlaceholder('Selecione os cargos responsáveis')
    .setMinValues(1)
    .setMaxValues(Math.max(1, Math.min(10, cfg.roles.tickets.slice(0, 25).length || 1)))
    .addOptions(
      cfg.roles.tickets.length
        ? cfg.roles.tickets.slice(0, 25).map((roleId) => ({ label: `Cargo ${roleId}`.slice(0, 100), value: roleId, description: 'Cargo autorizado em /configurar' }))
        : [{ label: 'Nenhum cargo configurado', value: 'none', description: 'Cadastre cargos em /configurar' }],
    );
  return painelV2FromEmbed(embed, [
    new ActionRowBuilder().addComponents(categoryMenu(guildId, 'ticket:roles:category', 'Selecione a categoria')),
    new ActionRowBuilder().addComponents(roleMenu),
    new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('ticket:back:categories').setLabel('Voltar').setStyle(ButtonStyle.Secondary)),
  ]);
}

function publicPanel(guildId) {
  const data = guildState(guildId);
  const a = data.appearance;
  const embed = panelEmbed(guildId, a.title, a.description);
  if (a.banner) embed.setImage(a.banner);
  if (a.thumbnail) embed.setThumbnail(a.thumbnail);
  const menu = new StringSelectMenuBuilder().setCustomId('ticket:public:category').setPlaceholder('Selecione uma categoria');
  const options = data.categories.slice(0, MAX_CATEGORIES).map((item) => {
    const option = {
      label: item.name.slice(0, 100),
      value: item.id,
      description: item.description.slice(0, 100) || 'Abrir atendimento',
    };
    const emoji = selectMenuEmoji(item.emoji);
    if (emoji) option.emoji = emoji;
    return option;
  });
  if (options.length) menu.addOptions(options);
  else menu.setDisabled(true).addOptions({ label: 'Nenhuma categoria disponível', value: 'none', description: 'O painel ainda não foi configurado' });
  return painelV2FromEmbed(embed, [new ActionRowBuilder().addComponents(menu)]);
}

function ticketPanel(guildId, ticket, notice = '') {
  const status = ticket.responsibleId ? `<@${ticket.responsibleId}>` : 'Aguardando atendente';
  const description = [
    notice,
    ticket.categoryDescription || 'Utilize o menu abaixo para gerenciar este ticket.',
  ].filter(Boolean).join('\n\n');
  const embed = panelEmbed(guildId, 'ATENDIMENTO DE TICKET', description, [
    { name: 'Categoria', value: ticket.categoryName, inline: true },
    { name: 'Criador', value: `<@${ticket.creatorId}>`, inline: true },
    { name: 'Responsável', value: status, inline: true },
  ]);
  const menu = new StringSelectMenuBuilder().setCustomId(`ticket:thread:menu:${ticket.id}`).setPlaceholder('Escolha uma ação no ticket').addOptions(
    { label: 'Assumir', value: 'claim', description: 'Assumir a responsabilidade pelo ticket' },
    { label: 'Renomear', value: 'rename', description: 'Alterar o nome do canal' },
    { label: 'Adicionar Membro', value: 'add_member', description: 'Conceder acesso a um membro' },
    { label: 'Fechar', value: 'close', description: 'Encerrar o ticket e gerar o transcript' },
  );
  return painelV2FromEmbed(embed, [new ActionRowBuilder().addComponents(menu)]);
}

function createCategoryModal() {
  const modal = new ModalBuilder().setCustomId('ticket:modal:create').setTitle('Criar Categoria de Ticket');
  modal.addComponents(
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('name').setLabel('Nome').setStyle(TextInputStyle.Short).setMaxLength(80).setRequired(true)),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('description').setLabel('Descrição').setStyle(TextInputStyle.Paragraph).setMaxLength(500).setRequired(true)),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('emoji').setLabel('Emoji (Unicode ou personalizado)').setStyle(TextInputStyle.Short).setMaxLength(100).setRequired(false)),
  );
  return modal;
}

function textModal(id, title, fieldId, label, value, style = TextInputStyle.Paragraph, maxLength = 1000) {
  const modal = new ModalBuilder().setCustomId(id).setTitle(title);
  const input = new TextInputBuilder().setCustomId(fieldId).setLabel(label).setStyle(style).setMaxLength(maxLength).setRequired(false);
  if (value) input.setValue(value.slice(0, maxLength));
  modal.addComponents(new ActionRowBuilder().addComponents(input));
  return modal;
}

function noCategories(interaction) {
  return interaction.reply({ content: _msg(interaction.guildId, 'ticket_sem_categoria', 'Crie uma categoria antes de continuar.'), flags: MessageFlags.Ephemeral });
}

async function update(interaction, payload) {
  if (interaction.deferred || interaction.replied) return interaction.editReply(payload);
  return interaction.update(payload);
}

async function refreshPublishedPanels(client, guildId) {
  const data = guildState(guildId);
  const validPanels = [];
  for (const panel of data.panels) {
    const channel = await client.channels.fetch(panel.channelId).catch(() => null);
    const message = channel?.messages?.fetch ? await channel.messages.fetch(panel.messageId).catch(() => null) : null;
    if (message) {
      await message.edit(publicPanel(guildId)).catch(() => {});
      validPanels.push(panel);
    }
  }
  data.panels = validPanels;
  saveData();
}

function canManageTicket(interaction, ticket) {
  const cfg = getConfig(interaction.guildId);
  const memberRoles = interaction.member?.roles?.cache;
  const allowed = new Set([...(cfg.roles.tickets ?? []), ...(ticket.roleIds ?? [])]);
  return interaction.user.id === ticket.creatorId || Boolean(memberRoles?.some((role) => allowed.has(role.id))) || interaction.member?.permissions?.has(PermissionFlagsBits.ManageChannels);
}

function canClaimTicket(interaction, ticket) {
  const cfg = getConfig(interaction.guildId);
  const memberRoles = interaction.member?.roles?.cache;
  const allowed = new Set([...(cfg.roles.tickets ?? []), ...(ticket.roleIds ?? [])]);
  return Boolean(memberRoles?.some((role) => allowed.has(role.id))) || interaction.member?.permissions?.has(PermissionFlagsBits.ManageChannels);
}

async function createTicket(interaction, client, category) {
  // Defer imediatamente para evitar expiração da interaction (erro 10062)
  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  const data = guildState(interaction.guildId);
  const existing = data.tickets.find((item) => item.creatorId === interaction.user.id && !item.closedAt);
  if (existing) {
    const existingChannel = existing.threadId
      ? await interaction.guild.channels.fetch(existing.threadId).catch(() => null)
      : null;
    if (existingChannel) {
      await interaction.editReply({ content: _msg(interaction.guildId, 'ticket_ja_aberto', `Você já possui um ticket aberto. Seu atendimento atual está em <#${existing.threadId}>.`) });
      return;
    }
    // Remove somente referências cujo tópico já não existe, liberando o usuário
    // para abrir um novo ticket sem apagar qualquer canal real.
    data.tickets = data.tickets.filter((item) => item !== existing);
    saveData();
  }

  const cfg = getConfig(interaction.guildId);
  const parent = cfg.channels.tickets ? await interaction.guild.channels.fetch(cfg.channels.tickets).catch(() => null) : null;
  const configuredRoles = cfg.roles.tickets ?? [];
  if (!parent || !configuredRoles.length) {
    await interaction.editReply({ content: _msg(interaction.guildId, 'ticket_config_incompleta', 'Configure o canal dos tópicos e pelo menos um cargo permitido em /configurar antes de abrir um ticket.') });
    return;
  }
  const ticketId = `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
  const roleIds = Array.isArray(category.roleIds) ? [...new Set(category.roleIds.map(String).filter(Boolean))] : [];
  const ticket = { id: ticketId, threadId: null, creatorId: interaction.user.id, categoryId: category.id, categoryName: category.name, categoryDescription: category.description, roleIds, responsibleId: null, openedAt: new Date().toISOString(), closedAt: null, closeReason: '' };
  const memberName = interaction.member?.displayName
    || interaction.user.globalName
    || interaction.user.username
    || 'membro';
  const responsibleRoleIds = ticket.roleIds.length ? ticket.roleIds : configuredRoles;
  
  let thread = null;
  const topicName = ticketTopicName(category.name, memberName);

  if (parent.threads?.create) {
    try {
      thread = await parent.threads.create({
        name: topicName,
        type: ChannelType.PrivateThread,
        invitable: false,
        autoArchiveDuration: 1440,
        reason: `Ticket aberto por ${interaction.user.tag}`,
      });
    } catch (errPrivado) {
      console.log('[TICKETS] Tópico privado indisponível, tentando tópico público:', errPrivado.message);
      try {
        thread = await parent.threads.create({
          name: topicName,
          type: ChannelType.PublicThread,
          autoArchiveDuration: 1440,
          reason: `Ticket aberto por ${interaction.user.tag}`,
        });
      } catch (errPublico) {
        console.log('[TICKETS] Tópico público também falhou:', errPublico.message);
      }
    }
  }

  if (!thread) {
    // Fallback: se o parent for categoria ou canal sem suporte direto a tópicos, cria canal de texto
    const permOverwrites = [
      { id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] },
      {
        id: interaction.guild.members.me.id,
        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.ManageChannels],
      },
      {
        id: interaction.user.id,
        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
      },
      ...responsibleRoleIds.map((roleId) => ({
        id: roleId,
        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
      })),
    ];
    thread = await interaction.guild.channels.create({
      name: topicName,
      type: ChannelType.GuildText,
      parent: parent.parentId || parent.id || null,
      permissionOverwrites: permOverwrites,
      reason: `Ticket aberto por ${interaction.user.tag}`,
    }).catch(() => null);
  }

  if (!thread) {
    await interaction.editReply({ content: _msg(interaction.guildId, 'ticket_nao_abriu', 'Não foi possível criar o tópico de atendimento. Verifique as permissões do bot no canal configurado.') });
    return;
  }

  if (typeof thread.join === 'function') await thread.join().catch(() => {});
  if (thread.members?.add) await thread.members.add(interaction.user.id).catch(() => {});

  ticket.threadId = thread.id;
  data.tickets.push(ticket);
  saveData();

  // Um único painel de suporte: as menções ficam na mesma mensagem do painel.
  const pingMention = responsibleRoleIds.length ? responsibleRoleIds.map((id) => `<@&${id}>`).join(' ') : '';
  const notice = [
    pingMention,
    `Novo ticket aberto por <@${ticket.creatorId}>.`,
  ].filter(Boolean).join('\n');
  const message = await thread.send({
    ...ticketPanel(interaction.guildId, ticket, notice),
    allowedMentions: {
      roles: responsibleRoleIds,
      users: [ticket.creatorId],
    },
  }).catch((error) => {
    console.error('[TICKETS] Falha ao publicar painel no tópico:', error.message, error.code ?? '');
    return null;
  });
  if (!message) {
    data.tickets = data.tickets.filter((item) => item.id !== ticket.id);
    saveData();
    await thread.delete('Não foi possível publicar o painel do ticket').catch(() => {});
    await interaction.editReply({ content: _msg(interaction.guildId, 'ticket_painel_falhou', 'O tópico foi desfeito porque o painel de gerenciamento não pôde ser publicado. Verifique as permissões do bot.') });
    return;
  }
  ticket.panelMessageId = message?.id ?? null;
  saveData();

  await interaction.editReply({ content: _msg(interaction.guildId, 'ticket_aberto', `Ticket aberto. Seu atendimento foi criado em <#${thread.id}>.`) });
}

async function collectMessages(channel) {
  const messages = [];
  let before;
  let truncated = false;
  for (let i = 0; i < 10; i += 1) {
    const batch = await channel.messages.fetch({ limit: 100, ...(before ? { before } : {}) });
    if (!batch?.size) break;
    messages.push(...batch.values());
    before = batch.last()?.id;
    if (batch.size < 100) break;
    if (i === 9) truncated = true;
  }
  const sorted = messages.sort((a, b) => a.createdTimestamp - b.createdTimestamp);
  sorted.truncated = truncated;
  return sorted;
}

function escapeHtml(value) {
  return String(value ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function transcriptHtml(ticket, messages, guild) {
  const body = messages.map((message) => {
    const avatar = message.author?.displayAvatarURL?.({ extension: 'png', size: 128 }) || '';
    const embeds = (message.embeds ?? []).map((embed) => `<div class="embed"><strong>${escapeHtml(embed.title || '')}</strong><div>${escapeHtml(embed.description || '')}</div>${embed.image?.url ? `<img src="${escapeHtml(embed.image.url)}">` : ''}</div>`).join('');
    const attachments = [...(message.attachments?.values?.() ?? [])].map((file) => `<a href="${escapeHtml(file.url)}" target="_blank" rel="noreferrer">${escapeHtml(file.name || 'Anexo')}</a>`).join(' ');
    return `<article class="message"><img class="avatar" src="${escapeHtml(avatar)}"><div class="content"><div class="meta"><strong>${escapeHtml(message.member?.displayName || message.author?.globalName || message.author?.username || 'Usuário')}</strong><time>${new Date(message.createdTimestamp).toLocaleString('pt-BR')}</time></div><div class="text">${escapeHtml(message.content).replace(/\n/g, '<br>')}</div>${embeds}${attachments ? `<div class="attachments">${attachments}</div>` : ''}</div></article>`;
  }).join('\n');
  const truncationNotice = messages.truncated
    ? '<p><strong>Observação:</strong> este transcript foi limitado às 1.000 mensagens mais recentes.</p>'
    : '';
  return `<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Transcript — ${escapeHtml(ticket.categoryName)}</title><style>
  :root{color-scheme:dark}*{box-sizing:border-box}body{margin:0;background:#313338;color:#dbdee1;font:15px Arial,sans-serif}.header{padding:28px max(20px,calc((100% - 980px)/2));background:#1e1f22;border-bottom:1px solid #111214}.header h1{margin:0 0 10px;color:#fff;font-size:22px}.info{display:flex;flex-wrap:wrap;gap:8px;color:#b5bac1;font-size:13px}.wrap{max-width:980px;margin:0 auto;padding:22px 20px 50px}.message{display:flex;gap:14px;padding:12px 0}.avatar{width:40px;height:40px;border-radius:50%;object-fit:cover;background:#5865f2}.content{min-width:0;flex:1}.meta{display:flex;align-items:baseline;gap:10px;margin-bottom:4px}.meta strong{color:#f2f3f5}.meta time{color:#949ba4;font-size:12px}.text{white-space:normal;overflow-wrap:anywhere;line-height:1.45}.embed{margin-top:8px;padding:10px 14px;border-left:4px solid #5865f2;background:#2b2d31;border-radius:4px;max-width:620px}.embed img{display:block;max-width:100%;max-height:360px;margin-top:10px;border-radius:3px}.attachments{margin-top:8px;color:#00a8fc;overflow-wrap:anywhere}.attachments a{color:#00a8fc;margin-right:10px}@media(max-width:600px){.header{padding:22px 16px}.wrap{padding:16px 12px}.message{gap:10px}.avatar{width:34px;height:34px}.meta{display:block}.meta time{display:block;margin-top:2px}}
   </style></head><body><header class="header"><h1>Transcript de Ticket</h1><div class="info"><span>Servidor: ${escapeHtml(guild?.name)}</span><span>Categoria: ${escapeHtml(ticket.categoryName)}</span><span>Criador: ${escapeHtml(ticket.creatorId)}</span></div></header><main class="wrap">${truncationNotice}${body || '<p>Nenhuma mensagem registrada.</p>'}</main></body></html>`;
}

async function closeTicket(interaction, client, ticket, reason) {
  if (!interaction.channel?.messages || typeof interaction.channel.delete !== 'function') {
    return { ok: false, message: 'O canal não está mais disponível. O registro foi mantido para conferência.' };
  }
  const closedAt = new Date();
  let messages;
  try {
    messages = await collectMessages(interaction.channel);
  } catch (error) {
    console.error('[TICKETS] Falha ao coletar mensagens do transcript:', error.message, error.code ?? '');
    return { ok: false, message: 'Não foi possível ler as mensagens deste canal para gerar o transcript. Verifique a permissão Ler Histórico de Mensagens.' };
  }
  const html = transcriptHtml(ticket, messages, interaction.guild);
  const cfg = getConfig(interaction.guildId);
  const logChannel = cfg.channels.ticketsLogs ? await interaction.guild.channels.fetch(cfg.channels.ticketsLogs).catch(() => null) : null;
  if (!logChannel?.send) {
    return { ok: false, message: 'Configure o Canal de Logs de Tickets em /configurar antes de fechar o ticket.' };
  }
  const closeReason = reason || 'Não informado';
  const opened = new Date(ticket.openedAt);
  const totalSeconds = Math.max(0, Math.floor((closedAt - opened) / 1000));
  const duration = `${Math.floor(totalSeconds / 3600)}h ${Math.floor((totalSeconds % 3600) / 60)}min ${totalSeconds % 60}s`;
  const logEmbed = panelEmbed(interaction.guildId, 'TICKET ENCERRADO', 'O ticket foi encerrado e o transcript foi anexado.', [
    { name: 'Criador', value: `<@${ticket.creatorId}>`, inline: true },
    { name: 'Categoria', value: ticket.categoryName, inline: true },
    { name: 'Responsável', value: ticket.responsibleId ? `<@${ticket.responsibleId}>` : 'Não assumido', inline: true },
    { name: 'Abertura', value: `<t:${Math.floor(opened.getTime() / 1000)}:F>`, inline: true },
    { name: 'Fechamento', value: `<t:${Math.floor(closedAt.getTime() / 1000)}:F>`, inline: true },
    { name: 'Tempo total', value: duration, inline: true },
    { name: 'Motivo', value: closeReason.slice(0, 1024), inline: false },
  ]);
  const logMessage = await logChannel.send({
    ...painelV2FromEmbed(logEmbed),
    files: [{ attachment: Buffer.from(html, 'utf8'), name: `transcript-${ticket.id}.html` }],
  }).catch((error) => {
    console.error('[TICKETS] Falha ao enviar transcript ao canal de logs:', error.message, error.code ?? '');
    return null;
  });
  if (!logMessage) {
    return { ok: false, message: 'Não foi possível enviar o transcript ao canal de logs. Verifique Ver Canal, Enviar Mensagens, Inserir Links e Anexar Arquivos nesse canal. O ticket continua aberto.' };
  }
  const deleted = await interaction.channel.delete(`Ticket encerrado: ${closeReason}`).then(() => true).catch(() => false);
  if (!deleted) {
    return { ok: false, message: 'O transcript foi gerado, mas não foi possível apagar o canal. Verifique a permissão Gerenciar Canais.' };
  }
  ticket.closedAt = closedAt.toISOString();
  ticket.closeReason = closeReason;
  const data = guildState(interaction.guildId);
  data.tickets = data.tickets.filter((item) => item.id !== ticket.id);
  saveData();
  return { ok: true };
}


function closeSelectPanel(guildId, notice = '') {
  const data = guildState(guildId);
  const openTickets = (data.tickets || []).filter(t => t.threadId);
  
  if (!openTickets.length) {
    const embed = panelEmbed(
      guildId,
      'FECHAMENTO DE TICKETS',
      `${notice ? `${notice}\n\n` : ''}Não há nenhum ticket aberto no momento para ser encerrado.`
    );
    return {
      ...painelV2FromEmbed(embed, []),
      flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
    };
  }

  const embed = panelEmbed(
    guildId,
    'FECHAMENTO DE TICKETS',
    `${notice ? `${notice}\n\n` : ''}Selecione o ticket aberto que você deseja visualizar e encerrar.`
  );

  const menu = new StringSelectMenuBuilder()
    .setCustomId('ticket:fechar:select')
    .setPlaceholder('Selecione um ticket aberto');

  const options = openTickets.slice(0, 25).map((t) => {
    const openedDate = new Date(t.openedAt);
    const dateStr = !isNaN(openedDate.getTime()) ? openedDate.toLocaleDateString('pt-BR') : '';
    return {
      label: `Ticket #${t.id.slice(-6)} - ${t.categoryName}`.slice(0, 100),
      value: t.id,
      description: `Criador: ${t.creatorId} | Abertura: ${dateStr}`.slice(0, 100),
    };
  });
  menu.addOptions(options);

  return {
    ...painelV2FromEmbed(embed, [
      new ActionRowBuilder().addComponents(menu),
    ]),
    flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
  };
}

function ticketInfoClosePanel(guildId, ticket) {
  const opened = new Date(ticket.openedAt);
  const openedTimestamp = Math.floor(opened.getTime() / 1000);
  const openedFormatted = !isNaN(openedTimestamp) ? `<t:${openedTimestamp}:F> (<t:${openedTimestamp}:R>)` : 'Data não registrada';

  const embed = panelEmbed(
    guildId,
    'INFORMAÇÕES DO TICKET',
    'Confira as informações abaixo antes de confirmar o encerramento do canal.',
    [
      { name: 'ID do Ticket', value: ticket.id, inline: true },
      { name: 'Categoria', value: ticket.categoryName || 'Não definida', inline: true },
      { name: 'Criador', value: `<@${ticket.creatorId}>`, inline: true },
      { name: 'Responsável', value: ticket.responsibleId ? `<@${ticket.responsibleId}>` : 'Não assumido', inline: true },
      { name: 'Canal', value: ticket.threadId ? `<#${ticket.threadId}>` : 'Canal não encontrado', inline: true },
      { name: 'Data de Abertura', value: openedFormatted, inline: false },
    ]
  );

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`ticket:fechar:confirm:${ticket.id}`)
      .setLabel('Confirmar')
      .setStyle(ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId('ticket:fechar:back')
      .setLabel('Voltar')
      .setStyle(ButtonStyle.Secondary)
  );

  return {
    ...painelV2FromEmbed(embed, [row]),
    flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
  };
}

async function closeTicketDirect(guildId, ticket, client, reason = 'Encerrado via /tickets fechar') {
  const channel = ticket.threadId ? await client.channels.fetch(ticket.threadId).catch(() => null) : null;
  const closedAt = new Date();
  
  if (channel && channel.messages) {
    try {
      const messages = await collectMessages(channel);
      const html = transcriptHtml(ticket, messages, channel.guild);
      const cfg = getConfig(guildId);
      const logChannel = cfg.channels.ticketsLogs ? await channel.guild.channels.fetch(cfg.channels.ticketsLogs).catch(() => null) : null;
      
      if (logChannel?.send) {
        const opened = new Date(ticket.openedAt);
        const totalSeconds = Math.max(0, Math.floor((closedAt - opened) / 1000));
        const duration = `${Math.floor(totalSeconds / 3600)}h ${Math.floor((totalSeconds % 3600) / 60)}min ${totalSeconds % 60}s`;
        const logEmbed = panelEmbed(guildId, 'TICKET ENCERRADO', 'O ticket foi encerrado e o transcript foi anexado.', [
          { name: 'Criador', value: `<@${ticket.creatorId}>`, inline: true },
          { name: 'Categoria', value: ticket.categoryName, inline: true },
          { name: 'Responsável', value: ticket.responsibleId ? `<@${ticket.responsibleId}>` : 'Não assumido', inline: true },
          { name: 'Abertura', value: `<t:${Math.floor(opened.getTime() / 1000)}:F>`, inline: true },
          { name: 'Fechamento', value: `<t:${Math.floor(closedAt.getTime() / 1000)}:F>`, inline: true },
          { name: 'Tempo total', value: duration, inline: true },
          { name: 'Motivo', value: reason.slice(0, 1024), inline: false },
        ]);
        await logChannel.send({
          ...painelV2FromEmbed(logEmbed),
          files: [{ attachment: Buffer.from(html, 'utf8'), name: `transcript-${ticket.id}.html` }],
        }).catch((err) => console.error('[TICKETS] Erro ao enviar log:', err.message));
      }
    } catch (e) {
      console.error('[TICKETS] Falha ao coletar transcript:', e.message);
    }

    if (typeof channel.delete === 'function') {
      await channel.delete(`Ticket encerrado: ${reason}`).catch((err) => console.error('[TICKETS] Erro ao deletar canal:', err.message));
    }
  }

  ticket.closedAt = closedAt.toISOString();
  ticket.closeReason = reason;
  const data = guildState(guildId);
  data.tickets = data.tickets.filter((item) => item.id !== ticket.id);
  saveData();
  return { ok: true };
}


async function handleTickets(interaction, client) {
  const guildId = interaction.guildId;
  if (!guildId) return false;
  const id = interaction.customId ?? '';

  if (interaction.isChatInputCommand() && (interaction.commandName === 'tickets' || interaction.commandName === 'ticket')) {
    const subcommand = interaction.options.getSubcommand(false);

    // Fluxo do subcomando /tickets fechar
    if (subcommand === 'fechar') {
      const data = guildState(guildId);
      // Se o comando for executado diretamente dentro do canal do ticket
      const currentTicket = data.tickets.find((t) => t.threadId === interaction.channelId);
      if (currentTicket) {
        if (!canManageTicket(interaction, currentTicket)) {
          await interaction.reply({ content: 'Você não possui permissão para fechar este ticket.', flags: MessageFlags.Ephemeral });
          return true;
        }
        await interaction.reply(ticketInfoClosePanel(guildId, currentTicket));
        return true;
      }

      // Se for executado fora de um ticket, verifica permissão para gerenciar tickets
      const cfg = getConfig(guildId);
      const memberRoles = interaction.member?.roles?.cache;
      const allowed = new Set([...(cfg.roles.tickets ?? [])]);
      const hasPermission = interaction.member?.permissions?.has(PermissionFlagsBits.ManageGuild) ||
                            interaction.member?.permissions?.has(PermissionFlagsBits.ManageChannels) ||
                            Boolean(memberRoles?.some((r) => allowed.has(r.id)));

      if (!hasPermission) {
        await interaction.reply({ content: 'Apenas moderadores e administradores de tickets podem acessar o painel de fechamento.', flags: MessageFlags.Ephemeral });
        return true;
      }

      await interaction.reply(closeSelectPanel(guildId));
      return true;
    }

    // Fluxo do subcomando /tickets painel (apenas administradores)
    if (!interaction.member?.permissions?.has(PermissionFlagsBits.ManageGuild) && !interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) {
      await interaction.reply({ content: 'Apenas administradores podem configurar o painel de tickets.', flags: MessageFlags.Ephemeral });
      return true;
    }
    await interaction.reply(configPanel(guildId));
    return true;
  }
  if (interaction.isButton() && id === 'ticket:send') {
    const cfg = getConfig(guildId);
    if (!cfg.channels.tickets || !(cfg.roles.tickets ?? []).length) {
      await interaction.reply({ content: _msg(guildId, 'ticket_config_incompleta', 'Defina o canal dos tópicos e pelo menos um cargo permitido em /configurar antes de enviar o painel público.'), flags: MessageFlags.Ephemeral });
      return true;
    }
    const data = guildState(guildId);
    if (!data.categories.length) { await interaction.reply({ content: _msg(guildId, 'ticket_sem_categoria', 'Crie uma categoria antes de enviar o painel público.'), flags: MessageFlags.Ephemeral }); return true; }
    await interaction.update({ ...painelV2FromEmbed(panelEmbed(guildId, 'ENVIAR PAINEL DE TICKETS', 'Selecione o canal onde o painel público será publicado.'), [new ActionRowBuilder().addComponents(new ChannelSelectMenuBuilder().setCustomId('ticket:send:channel').setPlaceholder('Selecione o canal').setChannelTypes([ChannelType.GuildText, ChannelType.GuildAnnouncement])), new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('ticket:back:config').setLabel('Voltar').setStyle(ButtonStyle.Secondary))]), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 });
    return true;
  }
  if (!id.startsWith('ticket:') && !(interaction.isStringSelectMenu() && interaction.customId === 'ticket:public:category')) return false;
  if (interaction.isStringSelectMenu() && id === 'ticket:config_menu') {
    await interaction.update(interaction.values[0] === 'appearance' ? appearancePanel(guildId) : categoriesPanel(guildId)); return true;
  }
  if (interaction.isButton() && id === 'ticket:back:config') { await update(interaction, configPanel(guildId)); return true; }
  if (interaction.isButton() && id === 'ticket:back:appearance') { await update(interaction, appearancePanel(guildId)); return true; }
  if (interaction.isButton() && id === 'ticket:back:categories') { await update(interaction, categoriesPanel(guildId)); return true; }
  if (interaction.isButton() && id === 'ticket:appearance:title') { await interaction.showModal(textModal('ticket:modal:title', 'Alterar Título', 'value', 'Título da embed', guildState(guildId).appearance.title, TextInputStyle.Short, 256)); return true; }
  if (interaction.isButton() && id === 'ticket:appearance:description') { await interaction.showModal(textModal('ticket:modal:description', 'Alterar Descrição', 'value', 'Descrição da embed', guildState(guildId).appearance.description, TextInputStyle.Paragraph, 4000)); return true; }
  if (interaction.isButton() && id === 'ticket:appearance:images') { await interaction.update(imagesPanel(guildId)); return true; }
  if (interaction.isButton() && (id === 'ticket:appearance:banner' || id === 'ticket:appearance:thumbnail')) {
    const key = id.endsWith('banner') ? 'banner' : 'thumbnail';
    await interaction.showModal(textModal(`ticket:modal:${key}`, `Alterar ${key === 'banner' ? 'Banner' : 'Thumbnail'}`, 'value', 'URL da imagem', guildState(guildId).appearance[key] ?? '', TextInputStyle.Short, 2000)); return true;
  }
  if (interaction.isButton() && id === 'ticket:categories:create') {
    if (guildState(guildId).categories.length >= MAX_CATEGORIES) {
      await interaction.reply({ content: _msg(guildId, 'ticket_limite', `O Discord permite no máximo ${MAX_CATEGORIES} categorias neste painel.`), flags: MessageFlags.Ephemeral });
      return true;
    }
    await interaction.showModal(createCategoryModal());
    return true;
  }
  if (interaction.isButton() && id === 'ticket:categories:remove') { if (!guildState(guildId).categories.length) { await noCategories(interaction); return true; } await interaction.update(painelV2FromEmbed(panelEmbed(guildId, 'REMOVER CATEGORIAS', 'Selecione a categoria que deseja remover.'), [new ActionRowBuilder().addComponents(categoryMenu(guildId, 'ticket:remove:select', 'Selecione a categoria')), new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('ticket:back:categories').setLabel('Voltar').setStyle(ButtonStyle.Secondary))])); return true; }
  if (interaction.isButton() && id === 'ticket:categories:view') { await interaction.update(categoriesListPanel(guildId)); return true; }
  if (interaction.isButton() && id === 'ticket:categories:roles') { await interaction.update(rolesPanel(guildId)); return true; }
  if (interaction.isStringSelectMenu() && id === 'ticket:remove:select') {
    await interaction.deferUpdate();
    const data = guildState(guildId); data.categories = data.categories.filter((item) => item.id !== interaction.values[0]); saveData(); await refreshPublishedPanels(client, guildId); await interaction.editReply(categoriesPanel(guildId, 'Categoria removida e painel atualizado.')); return true;
  }
  if (interaction.isStringSelectMenu() && id === 'ticket:roles:category') { await interaction.update(rolesPanel(guildId, interaction.values[0])); return true; }
  if (interaction.isStringSelectMenu() && id.startsWith('ticket:roles:select:')) {
    await interaction.deferUpdate();
    const categoryId = id.split(':').pop(); const cfg = getConfig(guildId); const values = interaction.values.filter((roleId) => cfg.roles.tickets.includes(roleId)); const category = guildState(guildId).categories.find((item) => item.id === categoryId);
    if (category) category.roleIds = values; saveData(); await refreshPublishedPanels(client, guildId); await interaction.editReply(rolesPanel(guildId, categoryId, 'Cargos responsáveis atualizados.')); return true;
  }
  if (interaction.isChannelSelectMenu() && id === 'ticket:send:channel') {
    await interaction.deferUpdate();
    const channelId = interaction.values[0]; const channel = await interaction.guild.channels.fetch(channelId).catch(() => null); const message = channel ? await channel.send(publicPanel(guildId)).catch(() => null) : null;
    if (message) { guildState(guildId).panels.push({ channelId, messageId: message.id }); saveData(); await interaction.editReply(configPanel(guildId, 'Painel público enviado e salvo.')); } else await interaction.editReply(configPanel(guildId, 'Não foi possível enviar o painel nesse canal.'));
    return true;
  }
  if (interaction.isModalSubmit() && id.startsWith('ticket:modal:rename:')) {
    const ticket = guildState(guildId).tickets.find((item) => item.id === id.split(':').pop());
    if (!ticket || interaction.channelId !== ticket.threadId) {
      await interaction.reply({ content: _msg(guildId, 'ticket_indisponivel', 'Este ticket não está mais disponível.'), flags: MessageFlags.Ephemeral });
      return true;
    }
    if (!canManageTicket(interaction, ticket)) {
      await interaction.reply({ content: _msg(guildId, 'ticket_acesso_restrito', 'Você não possui permissão para renomear este ticket.'), flags: MessageFlags.Ephemeral });
      return true;
    }
    const name = interaction.fields.getTextInputValue('value').trim();
    if (!name) {
      await interaction.reply({ content: _msg(guildId, 'ticket_renomear_sem_nome', 'Informe um nome para o canal.'), flags: MessageFlags.Ephemeral });
      return true;
    }
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });
    const renamed = await interaction.channel.setName(name.slice(0, 100)).then(() => true).catch(() => false);
    if (!renamed) {
      await interaction.editReply({ content: _msg(guildId, 'ticket_renomear_falhou', 'Não foi possível renomear o canal. Verifique as permissões do bot.') });
      return true;
    }
    const message = ticket.panelMessageId && interaction.channel?.messages?.fetch
      ? await interaction.channel.messages.fetch(ticket.panelMessageId).catch(() => null)
      : null;
    if (message) await message.edit(ticketPanel(guildId, ticket)).catch(() => {});
    await interaction.editReply({ content: _msg(guildId, 'ticket_renomeado', 'O nome do canal foi atualizado.') });
    return true;
  }
  if (interaction.isModalSubmit() && id.startsWith('ticket:modal:close:')) {
    const ticket = guildState(guildId).tickets.find((item) => item.id === id.split(':').pop());
    if (!ticket || interaction.channelId !== ticket.threadId) {
      await interaction.reply({ content: _msg(guildId, 'ticket_indisponivel', 'Este ticket não está mais disponível.'), flags: MessageFlags.Ephemeral });
      return true;
    }
    if (!canManageTicket(interaction, ticket)) {
      await interaction.reply({ content: _msg(guildId, 'ticket_fechar_sem_permissao', 'Você não possui permissão para fechar este ticket.'), flags: MessageFlags.Ephemeral });
      return true;
    }
    const reason = interaction.fields.getTextInputValue('reason').trim().slice(0, 1000) || 'Não informado';
    const key = `${guildId}:${ticket.id}:${interaction.user.id}`;
    pendingClosures.set(key, reason);
    setTimeout(() => {
      if (pendingClosures.get(key) === reason) pendingClosures.delete(key);
    }, 15 * 60 * 1000).unref?.();
    await interaction.reply({ embeds: [panelEmbed(guildId, 'CONFIRMAR FECHAMENTO', 'O transcript será gerado e enviado ao canal de logs antes de encerrar o ticket.')], components: [new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`ticket:close:confirm:${ticket.id}`).setLabel('Confirmar').setStyle(ButtonStyle.Danger), new ButtonBuilder().setCustomId(`ticket:close:cancel:${ticket.id}`).setLabel('Cancelar').setStyle(ButtonStyle.Secondary))], flags: MessageFlags.Ephemeral });
    return true;
  }
  if (interaction.isModalSubmit() && id.startsWith('ticket:modal:')) {
    const kind = id.split(':').pop(); const data = guildState(guildId);
    if (kind === 'create') {
      if (data.categories.length >= MAX_CATEGORIES) {
        await interaction.reply({ content: _msg(guildId, 'ticket_limite', `O Discord permite no máximo ${MAX_CATEGORIES} categorias neste painel.`), flags: MessageFlags.Ephemeral });
        return true;
      }
      const name = interaction.fields.getTextInputValue('name').trim();
      const description = interaction.fields.getTextInputValue('description').trim();
      if (!name || !description) {
        await interaction.reply({ content: _msg(guildId, 'ticket_dados_incompletos', 'Informe o nome e a descrição da categoria.'), flags: MessageFlags.Ephemeral });
        return true;
      }
      if (data.categories.some((item) => item.name.localeCompare(name, 'pt-BR', { sensitivity: 'accent' }) === 0)) {
        await interaction.reply({ content: _msg(guildId, 'ticket_categoria_duplicada', 'Já existe uma categoria com esse nome.'), flags: MessageFlags.Ephemeral });
        return true;
      }
      const category = { id: `${Date.now()}-${Math.random().toString(36).slice(2, 5)}`, name: name.slice(0, 100), description: description.slice(0, 500), emoji: interaction.fields.getTextInputValue('emoji').trim().slice(0, 100), roleIds: [] };
      data.categories.push(category);
      saveData();
      await interaction.deferUpdate();
      await refreshPublishedPanels(client, guildId);
      await interaction.editReply(categoriesPanel(guildId, 'Categoria criada e painel atualizado.'));
      return true;
    }
    if (kind === 'title' || kind === 'description') data.appearance[kind] = interaction.fields.getTextInputValue('value').trim() || (kind === 'title' ? 'Central de Tickets' : 'Selecione uma categoria para abrir um ticket.');
    if (kind === 'banner' || kind === 'thumbnail') { const raw = interaction.fields.getTextInputValue('value').trim(); data.appearance[kind] = raw ? validUrl(raw) : null; if (raw && !data.appearance[kind]) { await interaction.reply({ content: _msg(guildId, 'ticket_url_invalida', 'URL inválida. Use uma URL pública começando com http:// ou https://.'), flags: MessageFlags.Ephemeral }); return true; } }
    saveData(); await interaction.deferUpdate(); await refreshPublishedPanels(client, guildId); await interaction.editReply(appearancePanel(guildId, 'Configuração salva e painéis públicos atualizados.')); return true;
  }
  if (interaction.isStringSelectMenu() && id === 'ticket:public:category') {
    const category = guildState(guildId).categories.find((item) => item.id === interaction.values[0]);
    if (!category) { await interaction.reply({ content: _msg(guildId, 'ticket_indisponivel', 'Essa categoria não está mais cadastrada.'), flags: MessageFlags.Ephemeral }); return true; }
    // Lock por usuário: impede que cliques rápidos/duplicados criem múltiplos tópicos
    const creationKey = `${guildId}:${interaction.user.id}`;
    if (pendingCreations.has(creationKey)) {
      await interaction.reply({ content: _msg(guildId, 'ticket_aguarde', 'Seu ticket já está sendo criado, aguarde um momento.'), flags: MessageFlags.Ephemeral });
      return true;
    }
    pendingCreations.add(creationKey);
    try {
      await createTicket(interaction, client, category);
    } finally {
      pendingCreations.delete(creationKey);
    }
    return true;
  }
  if (interaction.isStringSelectMenu() && id.startsWith('ticket:thread:menu:')) {
    const ticket = guildState(guildId).tickets.find((item) => item.id === id.split(':').pop());
    if (!ticket || interaction.channelId !== ticket.threadId) {
      await interaction.reply({ content: _msg(guildId, 'ticket_indisponivel', 'Este painel pertence a um ticket que já foi removido ou não está mais disponível.'), flags: MessageFlags.Ephemeral }).catch(() => {});
      return true;
    }
    if (!canManageTicket(interaction, ticket)) { await interaction.reply({ content: _msg(guildId, 'ticket_acesso_restrito', 'Você não possui permissão para gerenciar este ticket.'), flags: MessageFlags.Ephemeral }); return true; }
    const action = interaction.values[0];
    if (action === 'claim') {
      if (!canClaimTicket(interaction, ticket)) {
        await interaction.reply({ content: _msg(guildId, 'ticket_assumir_restrito', 'Somente um atendente autorizado pode assumir este ticket.'), flags: MessageFlags.Ephemeral });
        return true;
      }
      if (ticket.responsibleId && ticket.responsibleId !== interaction.user.id) {
        await interaction.reply({ content: _msg(guildId, 'ticket_ja_assumido', `Este ticket já está sendo atendido por <@${ticket.responsibleId}>.`), flags: MessageFlags.Ephemeral });
        return true;
      }
      const claimKey = `${guildId}:${ticket.id}`;
      if (pendingClaims.has(claimKey)) {
        await interaction.reply({ content: _msg(guildId, 'ticket_aguarde', 'Outro atendente está assumindo este ticket agora.'), flags: MessageFlags.Ephemeral });
        return true;
      }
      pendingClaims.add(claimKey);
      try {
        await interaction.deferUpdate();
        const thread = interaction.channel;
        if (!thread) {
          await interaction.editReply({ content: _msg(guildId, 'ticket_topico_indisponivel', 'Não foi possível acessar este canal ou tópico. Tente novamente.'), components: [] }).catch(() => {});
          return true;
        }
        const alreadyClaimedByUser = ticket.responsibleId === interaction.user.id;
        ticket.responsibleId = interaction.user.id;
        saveData();
        const message = thread.messages?.cache?.get(ticket.panelMessageId)
          || (thread.messages?.fetch ? await thread.messages.fetch(ticket.panelMessageId).catch(() => null) : null);
        if (message) {
          await message.edit(ticketPanel(guildId, ticket)).catch((error) => {
            console.error('[TICKETS] Falha ao atualizar painel após assumir:', error.message);
          });
        }
        if (!alreadyClaimedByUser) {
          await thread.send({
            content: `**Atendimento assumido**\n<@${interaction.user.id}> assumiu este ticket e será responsável pelo atendimento.`,
            allowedMentions: { users: [interaction.user.id] },
          }).catch((error) => {
            console.error('[TICKETS] Falha ao publicar confirmação de atendimento:', error.message);
          });
        }
        if (thread.members?.add) {
          await thread.members.add(interaction.user.id).catch(() => {});
        }
        if (thread.permissionOverwrites?.edit) {
          const responsibleRoleIds = ticket.roleIds.length ? ticket.roleIds : (getConfig(guildId).roles.tickets ?? []);
          const preserved = new Set([ticket.creatorId, interaction.user.id, interaction.client.user.id]);
          for (const roleId of responsibleRoleIds) {
            const role = interaction.guild.roles.cache.get(roleId);
            for (const member of role?.members?.values?.() ?? []) {
              if (!preserved.has(member.id)) {
                await thread.permissionOverwrites.delete(member.id).catch(() => {});
              }
            }
          }
          await thread.permissionOverwrites.edit(interaction.user.id, {
            ViewChannel: true, SendMessages: true, ReadMessageHistory: true,
          }).catch(() => {});
        }
      } finally {
        pendingClaims.delete(claimKey);
      }
      return true;
    }
    if (action === 'rename') { await interaction.showModal(textModal(`ticket:modal:rename:${ticket.id}`, 'Renomear Tópico', 'value', 'Novo nome do tópico', interaction.channel.name, TextInputStyle.Short, 100)); return true; }
    if (action === 'add_member') { await interaction.reply({ embeds: [panelEmbed(guildId, 'Adicionar Membro', 'Selecione o membro que receberá acesso ao tópico.')], components: [new ActionRowBuilder().addComponents(new UserSelectMenuBuilder().setCustomId(`ticket:member:${ticket.id}`).setPlaceholder('Selecione o membro'))], flags: MessageFlags.Ephemeral }); return true; }
    if (action === 'close') { await interaction.showModal(textModal(`ticket:modal:close:${ticket.id}`, 'Fechar Ticket', 'reason', 'Motivo do fechamento (opcional)', '', TextInputStyle.Paragraph, 1000)); return true; }
  }
  if (interaction.isUserSelectMenu() && id.startsWith('ticket:member:')) {
    const ticket = guildState(guildId).tickets.find((item) => item.id === id.split(':').pop());
    if (!ticket || interaction.channelId !== ticket.threadId) {
      await interaction.update({ content: _msg(guildId, 'ticket_indisponivel', 'Este ticket não está mais disponível.'), embeds: [], components: [] });
      return true;
    }
    if (!canManageTicket(interaction, ticket)) {
      await interaction.update({ content: _msg(guildId, 'ticket_membro_sem_permissao', 'Você não possui permissão para adicionar membros.'), embeds: [], components: [] });
      return true;
    }
    const memberId = interaction.values[0];
    const thread = interaction.channel;
    await interaction.deferUpdate();
    let granted = false;
    if (thread.members?.add) {
      granted = await thread.members.add(memberId).then(() => true).catch(() => false);
    } else if (thread.permissionOverwrites?.edit) {
      granted = await thread.permissionOverwrites.edit(memberId, {
        ViewChannel: true, SendMessages: true, ReadMessageHistory: true,
      }).then(() => true).catch(() => false);
    }
    await interaction.editReply({ content: granted ? _msg(guildId, 'ticket_membro_adicionado', 'O membro recebeu acesso ao atendimento.') : _msg(guildId, 'ticket_membro_falhou', 'Não foi possível adicionar o membro. Verifique as permissões do bot.'), components: [] });
    return true;
  }
  if (interaction.isButton() && (id.startsWith('ticket:close:confirm:') || id.startsWith('ticket:close:cancel:'))) {
    const ticketId = id.split(':').pop();
    const ticket = guildState(guildId).tickets.find((item) => item.id === ticketId);
    if (!ticket) {
      await interaction.update({ content: _msg(guildId, 'ticket_indisponivel', 'Este ticket já foi encerrado.'), embeds: [], components: [] });
      return true;
    }
    if (!canManageTicket(interaction, ticket)) {
      await interaction.update({ content: _msg(guildId, 'ticket_fechar_sem_permissao', 'Você não possui permissão para fechar este ticket.'), embeds: [], components: [] });
      return true;
    }
    const key = `${guildId}:${ticket.id}:${interaction.user.id}`;
    if (id.includes(':cancel:')) {
      pendingClosures.delete(key);
      await interaction.update({ content: _msg(guildId, 'ticket_fechamento_cancelado', 'Fechamento cancelado. O ticket continua aberto.'), components: [] });
      return true;
    }
    const reason = pendingClosures.get(key);
    if (reason === undefined) {
      await interaction.update({ content: _msg(guildId, 'ticket_confirmacao_expirada', 'A confirmação expirou. Abra o menu novamente para iniciar o fechamento.'), components: [] });
      return true;
    }
    const closeKey = `${guildId}:${ticket.id}`;
    if (pendingCloseActions.has(closeKey)) {
      await interaction.update({ content: _msg(guildId, 'ticket_fechamento_andamento', 'Este ticket já está sendo encerrado.'), components: [] });
      return true;
    }
    pendingCloseActions.add(closeKey);
    pendingClosures.delete(key);
    await interaction.update({ content: _msg(guildId, 'ticket_encerrando', 'Encerrando ticket. Gerando transcript e enviando os logs...'), components: [] });
    try {
      const result = await closeTicket(interaction, client, ticket, reason);
      if (!result.ok) {
        await interaction.followUp({ content: _msg(guildId, 'ticket_fechamento_falhou', result.message), flags: MessageFlags.Ephemeral }).catch(() => {});
      }
    } finally {
      pendingCloseActions.delete(closeKey);
    }
    return true;
  }

  if (interaction.isStringSelectMenu() && id === 'ticket:fechar:select') {
    const ticketId = interaction.values[0];
    if (ticketId === 'none') {
      await interaction.reply({ content: 'Nenhum ticket selecionado.', flags: MessageFlags.Ephemeral });
      return true;
    }
    const ticket = guildState(guildId).tickets.find((t) => t.id === ticketId);
    if (!ticket) {
      await interaction.update(closeSelectPanel(guildId, 'Este ticket não foi encontrado ou já foi encerrado.'));
      return true;
    }
    await interaction.update(ticketInfoClosePanel(guildId, ticket));
    return true;
  }

  if (interaction.isButton() && id === 'ticket:fechar:back') {
    await interaction.update(closeSelectPanel(guildId));
    return true;
  }

  if (interaction.isButton() && id.startsWith('ticket:fechar:confirm:')) {
    const ticketId = id.replace('ticket:fechar:confirm:', '');
    const ticket = guildState(guildId).tickets.find((t) => t.id === ticketId);
    if (!ticket) {
      await interaction.update({ content: 'Este ticket já foi encerrado ou não está mais disponível.', embeds: [], components: [] });
      return true;
    }
    if (!canManageTicket(interaction, ticket)) {
      await interaction.update({ content: 'Você não possui permissão para fechar este ticket.', embeds: [], components: [] });
      return true;
    }
    const closeKey = `${guildId}:${ticket.id}`;
    if (pendingCloseActions.has(closeKey)) {
      await interaction.update({ content: 'Este ticket já está sendo encerrado.', embeds: [], components: [] });
      return true;
    }
    pendingCloseActions.add(closeKey);
    await interaction.update({ content: 'Encerrando ticket e apagando canal...', embeds: [], components: [] });
    try {
      await closeTicketDirect(guildId, ticket, client, 'Encerrado via /tickets fechar por ' + interaction.user.tag);
      await interaction.editReply({ content: 'Ticket encerrado e canal apagado com sucesso.', embeds: [], components: [] });
    } finally {
      pendingCloseActions.delete(closeKey);
    }
    return true;
  }

  return false;
}

async function restaurarPaineisTickets(client) {
  for (const guildId of Object.keys(state)) {
    const data = guildState(guildId);
    const validPanels = [];
    for (const panel of data.panels) {
      const channel = await client.channels.fetch(panel.channelId).catch(() => null);
      const message = channel?.messages?.fetch
        ? await channel.messages.fetch(panel.messageId).catch(() => null)
        : null;
      if (message) {
        await message.edit(publicPanel(guildId)).catch(() => {});
        validPanels.push(panel);
      }
    }
    data.panels = validPanels;

    const validTickets = [];
    for (const ticket of data.tickets) {
      const channel = await client.channels.fetch(ticket.threadId).catch(() => null);
      if (!channel) continue;
      let message = ticket.panelMessageId && channel.messages?.fetch
        ? await channel.messages.fetch(ticket.panelMessageId).catch(() => null)
        : null;
      if (message) {
        await message.edit(ticketPanel(guildId, ticket)).catch(() => {});
      } else if (typeof channel.send === 'function') {
        message = await channel.send({ ...ticketPanel(guildId, ticket), allowedMentions: { parse: [] } }).catch(() => null);
        if (message) ticket.panelMessageId = message.id;
      }
      if (message) validTickets.push(ticket);
    }
    data.tickets = validTickets;
  }
  saveData();
}

module.exports = { handleTickets, restaurarPaineisTickets, refreshPublishedPanels };