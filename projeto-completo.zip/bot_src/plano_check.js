'use strict';

const fs = require('fs');
const { MessageFlags } = require('discord.js');
const { dataPath } = require('./data-path');
const { isBotsOwner } = require('./bots');

function lerJSONSeguro(caminho) {
  try {
    if (fs.existsSync(caminho)) {
      const raw = fs.readFileSync(caminho, 'utf8').trim();
      if (raw) return JSON.parse(raw);
    }
  } catch (_) {}
  return null;
}

/**
 * Verifica se um membro é o Dono do Bot (usado exclusivamente para `.dev central` e gerenciamento mestre).
 */
function isBotOwnerUser(member) {
  if (!member) return false;
  if (isBotsOwner(member)) return true;
  
  const ownerIds = [
    process.env.BOT_OWNER_ID,
    process.env.BOT_OWNER_USER_ID,
    process.env.OWNER_ID,
    process.env.DONO_ID,
  ].filter(Boolean).map(String);
  
  if (ownerIds.includes(String(member.id))) return true;
  if (member.client?.application?.owner?.id && String(member.client.application.owner.id) === String(member.id)) return true;
  
  return false;
}

/**
 * Verifica se o servidor possui um plano ou teste ativo ou se o executor é Dono do Bot.
 * @param {string} guildId
 * @param {object} [member]
 * @returns {{ ativo: boolean, motivo?: string, plano?: object, tipo?: string, expiraEm?: string, vitalicio?: boolean }}
 */
function verificarPlanoAtivo(guildId, member = null) {
  // Se o membro tiver o cargo de Dono do Bot ou permissões de dono, tem acesso total liberado
  if (member && isBotOwnerUser(member)) {
    return { ativo: true, tipo: 'Dono do Bot (Bypass)', vitalicio: true };
  }

  if (!guildId) {
    return { ativo: false, motivo: 'ID do servidor inválido.' };
  }

  const agora = Date.now();

  // 1. Verificar configuração do servidor (guild_configs.json)
  try {
    const { getConfig, updateConfig } = require('./configurar');
    const cfg = getConfig(guildId);
    if (cfg?.plan) {
      const plan = cfg.plan;
      const isAtivo = plan.active === true || plan.status === 'active' || plan.status === 'ativado';
      if (isAtivo) {
        if (!plan.expiresAt) {
          return { ativo: true, plano: plan, tipo: plan.planType || 'Vitalício', vitalicio: true };
        }
        const expiraMs = new Date(plan.expiresAt).getTime();
        if (expiraMs > agora) {
          return { ativo: true, plano: plan, tipo: plan.planType || 'Temporário', expiraEm: plan.expiresAt, vitalicio: false };
        } else {
          // Expirou
          plan.active = false;
          plan.status = 'expirado';
          try { updateConfig(guildId, { plan }); } catch (_) {}
        }
      }
    }
  } catch (_) {}

  // 2. Verificar dev_central_data.json (compras e testes ativados)
  const devCentralData = lerJSONSeguro(dataPath('dev_central_data.json'));
  if (devCentralData) {
    // Compras
    const purchases = devCentralData.purchases || [];
    for (const p of purchases) {
      if (p.redeemed && p.redeemedGuildId === guildId) {
        if (!p.expiresAt) {
          return { ativo: true, plano: p, tipo: 'Vitalício', vitalicio: true };
        }
        const expiraMs = new Date(p.expiresAt).getTime();
        if (expiraMs > agora) {
          return { ativo: true, plano: p, tipo: `${p.durationDays || 0} dias`, expiraEm: p.expiresAt, vitalicio: false };
        }
      }
    }

    // Testes
    const testClaims = devCentralData.testClaims || [];
    for (const t of testClaims) {
      if (t.redeemed && t.redeemedGuildId === guildId) {
        if (!t.expiresAt) {
          return { ativo: true, plano: t, tipo: 'Teste', vitalicio: true };
        }
        const expiraMs = new Date(t.expiresAt).getTime();
        if (expiraMs > agora) {
          return { ativo: true, plano: t, tipo: `Teste (${t.durationText || '24h'})`, expiraEm: t.expiresAt, vitalicio: false };
        }
      }
    }
  }

  // 3. Verificar loja_data.json (licenças e planos de acesso)
  const lojaData = lerJSONSeguro(dataPath('loja_data.json'));
  if (lojaData && typeof lojaData === 'object') {
    for (const guildKey of Object.keys(lojaData)) {
      const gData = lojaData[guildKey];
      const sales = gData?.sales || [];
      for (const s of sales) {
        if ((s.status === 'ativado' || s.redeemed) && (s.activatedGuildId === guildId || s.redeemedGuildId === guildId)) {
          if (!s.expiresAt) {
            return { ativo: true, plano: s, tipo: 'Vitalício', vitalicio: true };
          }
          const expiraMs = new Date(s.expiresAt).getTime();
          if (expiraMs > agora) {
            return { ativo: true, plano: s, tipo: 'Plano Concedido', expiraEm: s.expiresAt, vitalicio: false };
          }
        }
      }
    }
  }

  return {
    ativo: false,
    motivo: 'Este servidor não possui um plano ou teste ativo no momento.',
  };
}

const MENSAGEM_SEM_PLANO =
  '❌ **Acesso Restrito — Plano Inativo**\n\n' +
  'Este servidor não possui um plano ou teste ativo no momento.\n' +
  'Para utilizar os comandos e funcionalidades do bot, adquira ou resgate um plano ativo.';

/**
 * Responde a uma interação avisando que o servidor não possui plano ativo.
 */
async function responderSemPlano(interaction) {
  try {
    const payload = { content: MENSAGEM_SEM_PLANO, flags: MessageFlags.Ephemeral };
    if (interaction.deferred || interaction.replied) {
      await interaction.followUp(payload).catch(() => {});
    } else {
      await interaction.reply(payload).catch(() => {});
    }
  } catch (err) {
    console.warn('[PLANO] Falha ao responder sem plano:', err.message);
  }
}

module.exports = {
  verificarPlanoAtivo,
  responderSemPlano,
  isBotOwnerUser,
  MENSAGEM_SEM_PLANO,
};
