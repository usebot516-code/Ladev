'use strict';

const { ChannelType, PermissionFlagsBits } = require('discord.js');
const {
  publicarPainelFilaAnalista,
} = require('./fila_analista');
const {
  publicarPainelMediador,
} = require('./fila_mediador');
const {
  publicarPainelRanking,
} = require('./ranking');
const {
  publicarPainelBlacklist,
} = require('./blacklist');

const PAINEIS = [
  {
    chave: 'mediador',
    rotulo: 'fila de mediadores',
    aliases: [
      'fila-mediador',
      'fila-med',
      'fila-md',
      'filas-med',
      'fila-mediadores',
      'filas-md',
      'med',
      'mediadores',
      'mediador',
      'md',
      'config-mediador',
      'config-med',
      'config-md',
      'configurar-pix',
      'config-pix',
      'pix',
    ],
    categorias: [
      'mediador',
      'mediadores',
      'gerencia',
      'gerencias',
      'atendimento',
    ],
    publicar: publicarPainelMediador,
    identificadores: ['fmed:in', 'fmed:out', 'fmed:pix', 'fmed:ranking'],
  },
  {
    chave: 'analista',
    rotulo: 'fila de analistas',
    aliases: [
      'fila-analista',
      'fila-ana',
      'fila-an',
      'filas-analista',
      'filas-ana',
      'filas-an',
      'analista',
      'analistas',
      'ana',
      'an',
      'anal',
      'equipe-analista',
      'equipe-ana',
      'analise',
      'anl',
    ],
    categorias: [
      'analista',
      'analistas',
      'gerencia',
      'gerencias',
      'atendimento',
    ],
    publicar: publicarPainelFilaAnalista,
    identificadores: ['fan:entrar', 'fan:sair', 'fan:ranking', 'fan:historico', 'fan:principal'],
  },
  {
    chave: 'ranking',
    rotulo: 'ranking',
    aliases: [
      'ranking',
      'rank',
      'ranking-geral',
      'rank-geral',
      'top',
      'top-geral',
      'top-global',
      'placar',
      'classificacao',
      'classificação',
      'leaderboard',
      'lideres',
      'líderes',
      'hall-da-fama',
      'podio',
    ],
    categorias: [
      'ranking',
      'classificacao',
      'classificação',
      'eventos',
      'gerencia',
    ],
    publicar: publicarPainelRanking,
    identificadores: ['ranking:periodo'],
  },
  {
    chave: 'blacklist',
    rotulo: 'blacklist',
    aliases: ['blacklist'],
    categorias: [],
    publicar: publicarPainelBlacklist,
    identificadores: ['blacklist:consultar', 'blacklist:jogadores', 'blacklist:adicionar'],
  },
];

const COMPATIBILIDADE_MINIMA = 0.76;
const PESO_PALAVRAS = 0.68;
const PESO_NOME_COMPLETO = 0.32;

const processandoGuilds = new Set();

function normalizarNome(value) {
  return String(value ?? '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^\p{L}\p{N}]+/gu, '');
}

function palavrasNormalizadas(value) {
  return String(value ?? '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .split(/[^\p{L}\p{N}]+/u)
    .map((palavra) => palavra.replace(/[^\p{L}\p{N}]/gu, ''))
    .filter(Boolean);
}

function distanciaLevenshtein(a, b) {
  const anterior = Array.from({ length: b.length + 1 }, (_, index) => index);
  for (let i = 1; i <= a.length; i += 1) {
    const atual = [i];
    for (let j = 1; j <= b.length; j += 1) {
      atual[j] = Math.min(
        atual[j - 1] + 1,
        anterior[j] + 1,
        anterior[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1),
      );
    }
    for (let j = 0; j <= b.length; j += 1) anterior[j] = atual[j];
  }
  return anterior[b.length];
}

function similaridadeNomeCompleto(nome, credencial) {
  const canal = normalizarNome(nome);
  const referencia = normalizarNome(credencial);
  if (!canal || !referencia) return 0;

  const distancia = distanciaLevenshtein(canal, referencia);
  const comprimento = Math.max(canal.length, referencia.length);
  return 1 - (distancia / comprimento);
}

function similaridadePalavra(a, b) {
  const primeira = normalizarNome(a);
  const segunda = normalizarNome(b);
  if (!primeira || !segunda) return 0;
  const comprimento = Math.max(primeira.length, segunda.length);
  return 1 - (distanciaLevenshtein(primeira, segunda) / comprimento);
}

function similaridadePalavras(nome, credencial) {
  const palavrasCanal = palavrasNormalizadas(nome);
  const palavrasCredencial = palavrasNormalizadas(credencial);
  if (!palavrasCanal.length || !palavrasCredencial.length) return 0;

  const usadas = new Set();
  let pesoCorrespondido = 0;
  let pesoCredencial = 0;
  const pesoCanalTotal = palavrasCanal.reduce((total, palavra) => total + palavra.length, 0);

  for (const palavraCredencial of palavrasCredencial) {
    const peso = palavraCredencial.length;
    pesoCredencial += peso;

    let melhor = { indice: -1, valor: 0 };
    palavrasCanal.forEach((palavraCanal, indice) => {
      if (usadas.has(indice)) return;
      const valor = similaridadePalavra(palavraCanal, palavraCredencial);
      if (valor > melhor.valor) melhor = { indice, valor };
    });

    // Termos muito curtos são identificadores (ss, md, an, adm), não palavras
    // comuns. Eles precisam coincidir quase exatamente para não transformar
    // "fila-ss" em "fila-med" ou "fila-adm" em "fila-ana".
    const tamanhoMinimo = Math.min(
      palavraCredencial.length,
      melhor.indice >= 0 ? palavrasCanal[melhor.indice].length : 0,
    );
    const limite = tamanhoMinimo <= 2 ? 0.92 : tamanhoMinimo <= 3 ? 0.84 : 0.65;
    if (melhor.indice >= 0 && melhor.valor >= limite) {
      usadas.add(melhor.indice);
      pesoCorrespondido += peso * melhor.valor;
    }
  }

  const coberturaCredencial = pesoCorrespondido / pesoCredencial;
  const coberturaCanal = pesoCorrespondido / Math.max(pesoCanalTotal, 1);
  // Se o servidor removeu apenas os separadores (por exemplo configpix),
  // preservamos a comparação do nome completo em vez de descartar o canal
  // por não ser possível reconstruir as palavras originais.
  if (palavrasCanal.length === 1 && palavrasCredencial.length > 1) {
    return similaridadeNomeCompleto(nome, credencial);
  }
  return (2 * coberturaCredencial * coberturaCanal)
    / Math.max(coberturaCredencial + coberturaCanal, 1);
}

function pontuarCanal(channel, aliases, categorias = [], parentName = null) {
  const nome = normalizarNome(channel?.name);
  if (!nome) return 0;

  const melhorCredencial = aliases.reduce((melhor, credencial) => {
    const similaridadePalavrasNome = similaridadePalavras(channel?.name, credencial);
    const similaridadeNome = similaridadeNomeCompleto(nome, credencial);
    const compatibilidade = (similaridadePalavrasNome * PESO_PALAVRAS)
      + (similaridadeNome * PESO_NOME_COMPLETO);
    return compatibilidade > melhor.compatibilidade
      ? { compatibilidade, credencial, similaridadePalavrasNome, similaridadeNome }
      : melhor;
  }, {
    compatibilidade: 0,
    credencial: '',
    similaridadePalavrasNome: 0,
    similaridadeNome: 0,
  });

  const categoria = normalizarNome(parentName ?? channel?.parent?.name ?? channel?.parentName);
  const categoriaCompatibilidade = categorias.reduce(
    (melhor, credencial) => Math.max(
      melhor,
      (similaridadePalavras(categoria, credencial) * PESO_PALAVRAS)
      + (similaridadeNomeCompleto(categoria, credencial) * PESO_NOME_COMPLETO),
    ),
    0,
  );

  // A categoria é apenas um reforço. A decisão principal sempre vem do nome
  // completo do canal comparado com todas as credenciais do painel.
  const pontuacao = melhorCredencial.compatibilidade
    + (melhorCredencial.compatibilidade >= 0.72
      && categoriaCompatibilidade >= COMPATIBILIDADE_MINIMA ? 0.04 : 0);

  return {
    valor: pontuacao,
    compatibilidade: melhorCredencial.compatibilidade,
    credencial: melhorCredencial.credencial,
    similaridadePalavras: melhorCredencial.similaridadePalavrasNome,
    similaridadeNome: melhorCredencial.similaridadeNome,
  };
}

function canaisDeTexto(channels) {
  return [...channels.values()]
    .filter((channel) => {
      if (!channel || channel.isThread?.()) return false;
      // Voice channels also expose text-like helpers in some discord.js
      // versions, but panel messages must only target real text/news channels.
      if (channel.type !== ChannelType.GuildText && channel.type !== ChannelType.GuildAnnouncement) {
        return false;
      }
      return channel.isTextBased?.() && typeof channel.send === 'function';
    });
}

function encontrarCanais(channels, aliases, categorias = []) {
  return canaisDeTexto(channels)
    .map((channel) => ({
      channel,
      score: pontuarCanal(
        channel,
        aliases,
        categorias,
        channels.get?.(channel.parentId)?.name ?? channels.get?.(channel.parent_id)?.name ?? null,
      ),
    }))
    .filter(({ score }) => score.compatibilidade >= COMPATIBILIDADE_MINIMA)
    .sort((a, b) => b.score.valor - a.score.valor || b.score.compatibilidade - a.score.compatibilidade || a.channel.position - b.channel.position);
}

function encontrarCanal(channels, aliases, categorias = []) {
  return encontrarCanais(channels, aliases, categorias)[0]?.channel ?? null;
}

async function permissaoParaPainel(guild, channel) {
  // No evento GuildCreate, `guild.members.me` frequentemente ainda não foi
  // preenchido pelo cache. Usar esse valor vazio/stale faz permissionsFor()
  // retornar null e a automação conclui incorretamente que o bot não enxerga
  // o canal. Busca o membro atual antes de validar as permissões.
  const membro = await guild?.members?.fetchMe?.().catch(() => null)
    ?? guild?.members?.me
    ?? guild?.client?.user;
  const permissions = channel?.permissionsFor?.(membro)
    ?? channel?.permissionsFor?.(guild?.client?.user);
  if (!permissions) {
    return { ok: false, faltantes: ['Ver canal', 'Enviar mensagens'] };
  }

  const exigidas = [
    [PermissionFlagsBits.ViewChannel, 'Ver canal'],
    [PermissionFlagsBits.SendMessages, 'Enviar mensagens'],
    [PermissionFlagsBits.EmbedLinks, 'Inserir links'],
  ];
  const faltantes = exigidas
    .filter(([flag]) => !permissions.has(flag))
    .map(([, label]) => label);
  return { ok: faltantes.length === 0, faltantes };
}

async function buscarCanais(guild) {
  const channels = await guild.channels.fetch().catch(() => guild.channels.cache);
  return channels ?? guild.channels.cache;
}

function coletarIdentificadores(valor, encontrados = []) {
  if (!valor || typeof valor !== 'object') return encontrados;
  if (typeof valor.customId === 'string') encontrados.push(valor.customId);
  if (typeof valor.custom_id === 'string') encontrados.push(valor.custom_id);
  for (const item of Object.values(valor)) {
    if (item && typeof item === 'object') coletarIdentificadores(item, encontrados);
  }
  return encontrados;
}

async function removerPainelDuplicado(channel, painel, mensagemOficial, botUserId) {
  if (!channel?.messages?.fetch || !painel.identificadores?.length || !botUserId) return;
  const mensagens = await channel.messages.fetch({ limit: 100 }).catch(() => null);
  if (!mensagens) return;
  const identificadores = new Set(painel.identificadores);
  let removidas = 0;
  for (const mensagem of mensagens.values()) {
    if (mensagem.id === mensagemOficial?.id || mensagem.author?.id !== botUserId) continue;
    const ids = coletarIdentificadores(mensagem.components);
    if (!ids.some((id) => identificadores.has(id))) continue;
    await mensagem.delete().catch(() => {});
    removidas += 1;
  }
  if (removidas > 0) {
    console.log(`[AUTO] ${removidas} painel(is) duplicado(s) removido(s) de #${channel.name}.`);
  }
}

async function automatizarPaineisGuild(guild) {
  if (!guild?.id || processandoGuilds.has(guild.id)) return;
  processandoGuilds.add(guild.id);

  try {
    console.log(`[AUTO] Procurando painéis na guild ${guild.id} (${guild.name}).`);
    const channels = await buscarCanais(guild);
    for (const painel of PAINEIS) {
      const candidatos = encontrarCanais(channels, painel.aliases, painel.categorias);
      if (candidatos.length === 0) {
        console.log(`[AUTO] Nenhum canal encontrado para ${painel.rotulo} na guild ${guild.id}.`);
        continue;
      }

      // O primeiro item é sempre o único canal escolhido pelo maior score.
      // Os demais ficam apenas como informação de desempate/diagnóstico: um
      // painel nunca é publicado em dois canais.
      const escolhido = candidatos[0];
      const channel = escolhido.channel;
      console.log(
        `[AUTO] Canal escolhido para ${painel.rotulo}: #${channel.name} `
        + `(compatibilidade ${(escolhido.score.valor * 100).toFixed(1)}%, `
        + `credencial "${escolhido.score.credencial}").`,
      );
      const acesso = await permissaoParaPainel(guild, channel);
      if (!acesso.ok) {
        console.warn(
          `[AUTO] Canal escolhido para ${painel.rotulo} não permite publicação `
          + `(${acesso.faltantes.join(', ')}).`,
        );
        continue;
      }

      try {
        const mensagem = await painel.publicar(guild, channel);
        await removerPainelDuplicado(
          channel,
          painel,
          mensagem,
          guild.client?.user?.id,
        );
        console.log(`[AUTO] Painel de ${painel.rotulo} publicado em #${channel.name} (${guild.id}).`);
      } catch (error) {
        console.error(`[AUTO] Falha ao publicar ${painel.rotulo} em #${channel.name}:`, error.message);
      }
    }
  } finally {
    processandoGuilds.delete(guild.id);
  }
}

async function automatizarPaineisTodos(client) {
  for (const guild of client.guilds.cache.values()) await automatizarPaineisGuild(guild);
}

module.exports = {
  automatizarPaineisGuild,
  automatizarPaineisTodos,
  encontrarCanais,
  encontrarCanal,
  normalizarNome,
  permissaoParaPainel,
};