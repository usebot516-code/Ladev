'use strict';

// ── Sincronizador Global de Painéis ──────────────────────────────────────────
// Garante que QUALQUER alteração feita no bot (configurações, aparências,
// estoques de bots, regras, canais, cores, etc.) atualize instantaneamente
// todos os painéis já enviados nos servidores Discord.

let _clientRef = null;
const _syncDebounceTimers = new Map();

function setSyncClient(client) {
  _clientRef = client;
}

function getSyncClient() {
  return _clientRef;
}

/**
 * Dispara uma atualização imediata em todos os painéis do bot
 * @param {import('discord.js').Client} [client] - Instância do Discord client
 * @param {string|null} [targetGuildId] - ID da guild específica ou null para todas
 */
async function sincronizarTodosOsPaineis(client = null, targetGuildId = null) {
  const c = client || _clientRef;
  if (!c) return;

  // Lazy require para evitar dependências circulares
  const { restaurarPaineis } = require('./filas');
  const { restaurarPainelMediador } = require('./fila_mediador');
  const { restaurarPainelFilaAnalista } = require('./fila_analista');
  const { restaurarPainelRanking } = require('./ranking');
  const { restaurarPaineisStreamer } = require('./fila_streamer');
  const { restaurarPartidas } = require('./partida');
  const { restaurarPaineisTickets } = require('./tickets');
  const { restaurarAvisos } = require('./avisos');
  const { restorePanels: restaurarPaineisSorteios } = require('./sorteios');
  const { restaurarPainelBlacklist } = require('./blacklist');
  const { restaurarPaineisExposed } = require('./exposed');
  const { refreshAllPublishedPanels: restaurarPaineisDevCentral } = require('./dev_central');

  const tasks = [
    () => restaurarPaineis(c, targetGuildId).catch((e) => console.warn('[SYNC-FILAS] Erro:', e.message)),
    () => restaurarPainelMediador(c, targetGuildId).catch((e) => console.warn('[SYNC-MED] Erro:', e.message)),
    () => restaurarPainelFilaAnalista(c, targetGuildId).catch((e) => console.warn('[SYNC-ANALISTA] Erro:', e.message)),
    () => restaurarPainelRanking(c, targetGuildId).catch((e) => console.warn('[SYNC-RANKING] Erro:', e.message)),
    () => restaurarPaineisStreamer(c, targetGuildId).catch((e) => console.warn('[SYNC-STREAMER] Erro:', e.message)),
    () => restaurarPartidas(c, targetGuildId).catch((e) => console.warn('[SYNC-PARTIDAS] Erro:', e.message)),
    () => restaurarPaineisTickets(c, targetGuildId).catch((e) => console.warn('[SYNC-TICKETS] Erro:', e.message)),
    () => restaurarAvisos(c, targetGuildId).catch((e) => console.warn('[SYNC-AVISOS] Erro:', e.message)),
    () => restaurarPaineisSorteios(c, targetGuildId).catch((e) => console.warn('[SYNC-SORTEIOS] Erro:', e.message)),
    () => restaurarPainelBlacklist(c, targetGuildId).catch((e) => console.warn('[SYNC-BLACKLIST] Erro:', e.message)),
    () => restaurarPaineisExposed(c, targetGuildId).catch((e) => console.warn('[SYNC-EXPOSED] Erro:', e.message)),
    () => restaurarPaineisDevCentral(c, targetGuildId).catch((e) => console.warn('[SYNC-DEV] Erro:', e.message)),
  ];

  await Promise.allSettled(tasks.map((fn) => fn()));
  console.log(`[SYNC-PAINEIS] Painéis sincronizados com sucesso${targetGuildId ? ` para a guilda ${targetGuildId}` : ' globalmente'}.`);
}

/**
 * Agenda uma sincronização com debounce para evitar spam na API do Discord
 * quando várias configurações forem alteradas em sequência rápida.
 */
function agendarSincronizacao(client = null, targetGuildId = null, delayMs = 350) {
  const c = client || _clientRef;
  if (!c) return;

  const key = targetGuildId || '__GLOBAL__';
  if (_syncDebounceTimers.has(key)) {
    clearTimeout(_syncDebounceTimers.get(key));
  }

  const timer = setTimeout(() => {
    _syncDebounceTimers.delete(key);
    sincronizarTodosOsPaineis(c, targetGuildId).catch((err) => {
      console.error('[SYNC-PAINEIS] Erro ao executar sincronização agendada:', err.message);
    });
  }, delayMs);

  _syncDebounceTimers.set(key, timer);
}

module.exports = {
  setSyncClient,
  getSyncClient,
  sincronizarTodosOsPaineis,
  agendarSincronizacao,
};
