'use strict';

// ── Sistema de Fila de Streamers ──────────────────────────────────────────────

const fs = require('fs');
const path = require('path');
const {
  EmbedBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  UserSelectMenuBuilder,
  ChannelSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ChannelType,
  PermissionFlagsBits,
  MessageFlags,
} = require('discord.js');
const { painelV2FromEmbed } = require('./visual');
const { mensagem: _msg } = require('./avisos_mensagens');
const { dataPath } = require('./data-path');

const DATA_FILE = dataPath('streamer_data.json');
const MAX_JOGADORES_STREAMER = 10;
const JOGADORES_POR_PARTIDA_STREAMER = 1;
const COR_FILA = 0xF1C40F;
const MODOS_STREAMER = ['1x1', '2x2', '3x3', '4x4'];
const TIPOS_STREAMER = ['Mobile', 'Emulador', 'Misto'];

function _lerDados() {
  try {
    return fs.existsSync(DATA_FILE)
      ? JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'))
      : {};
  } catch (error) {
    console.error('[STREAMER] Falha ao ler dados:', error.message);
    return {};
  }
}

let _saving = false;
let _savePending = false;
function _salvarDados(dados) {
  if (_saving) {
    _savePending = true;
    return;
  }
  _saving = true;
  const tmp = `${DATA_FILE}.tmp`;
  try {
    fs.writeFile(tmp, JSON.stringify(dados, null, 2), 'utf8', (err) => {
      if (!err) {
        fs.rename(tmp, DATA_FILE, () => {
          _saving = false;
          if (_savePending) {
            _savePending = false;
            _salvarDados(_dados);
          }
        });
      } else {
        _saving = false;
      }
    });
  } catch (error) {
    _saving = false;
  }
}

const _dados = _lerDados();
const _sessoes = new Map();
const _precos = new Map();
const _partidasEmCriacao = new Set();
let _autoRefreshTimer = null;
let _autoRefreshEmAndamento = false;

function _guild(guildId) {
  if (!_dados[guildId]) _dados[guildId] = { streamers: {} };
  if (!_dados[guildId].streamers) _dados[guildId].streamers = {};
  return _dados[guildId];
}

function _streamer(guildId, streamerId) {
  const streamer = _guild(guildId).streamers[streamerId] ?? null;
  if (!streamer) return null;
  streamer.setup = { ..._novaConfiguracao(), ...(streamer.setup ?? {}) };
  streamer.painel = { msgId: null, chanId: null, ...(streamer.painel ?? {}) };
  streamer.jogadores = Array.isArray(streamer.jogadores)
    ? streamer.jogadores.filter((j, index, lista) =>
        j?.id &&
        j.id !== streamer.streamerId &&
        lista.findIndex((item) => item?.id === j.id) === index,
      )
    : [];
  streamer.historico = Array.isArray(streamer.historico) ? streamer.historico : [];
  streamer.preco = Number.isFinite(Number(streamer.preco)) ? Number(streamer.preco) : null;
  streamer.partidaAtivaId = typeof streamer.partidaAtivaId === 'string' ? streamer.partidaAtivaId : null;
  streamer.online = streamer.online !== false;
  return streamer;
}

function _novaConfiguracao() {
  return {
    titulo: 'Fila do Streamer',
    descricao: 'Entre na fila para jogar contra o streamer.',
    modo: '1x1',
    tipo: 'Mobile',
    thumbnail: null,
    banner: null,
  };
}

function _novoStreamer(streamerId, mediatorId) {
  return {
    streamerId,
    mediatorId,
    setup: _novaConfiguracao(),
    painel: { msgId: null, chanId: null },
    jogadores: [],
    preco: null,
    partidaAtivaId: null,
    online: true,
    historico: [],
  };
}

function _salvar() {
  _salvarDados(_dados);
}

function _sessao(guildId, userId) {
  const key = `${guildId}:${userId}`;
  if (!_sessoes.has(key)) {
    _sessoes.set(key, { guildId, streamerId: null, mediatorId: null, preco: '' });
  }
  return _sessoes.get(key);
}

function _cor(guildId) {
  try {
    const { getConfig } = require('./configurar');
    return getConfig(guildId)?.embedColor ?? 0x2F3136;
  } catch (_) {
    return 0x2F3136;
  }
}

function _urlImagem(valor) {
  const url = String(valor ?? '').trim();
  if (!url) return null;
  try {
    const parsed = new URL(url);
    return ['http:', 'https:'].includes(parsed.protocol) ? url : null;
  } catch (_) {
    return null;
  }
}

function _ehAdmin(interaction) {
  return Boolean(interaction.member?.permissions?.has(PermissionFlagsBits.Administrator));
}

async function _garantirCargo(guild, memberId, nomeCargo, roleId = null) {
  const membro = await guild.members.fetch(memberId).catch(() => null);
  if (!membro) return { ok: false, mensagem: 'Não foi possível localizar o membro selecionado.' };

  let cargo = roleId
    ? await guild.roles.fetch(roleId).catch(() => null)
    : null;
  if (!cargo) {
    cargo = guild.roles.cache.find(
      (role) => !role.managed && role.name.toLowerCase() === nomeCargo.toLowerCase(),
    ) ?? null;
  }
  if (!cargo) {
    cargo = await guild.roles.create({
      name: nomeCargo,
      reason: `Cargo automático do sistema de fila de streamer para ${membro.user.tag}`,
    }).catch(() => null);
  }
  if (!cargo) {
    return {
      ok: false,
      mensagem: `Não foi possível localizar ou criar o cargo ${nomeCargo}.`,
    };
  }

  if (!membro.roles.cache.has(cargo.id)) {
    const atribuido = await membro.roles.add(
      cargo,
      `Cargo automático do sistema de fila de streamer para ${membro.user.tag}`,
    ).then(() => true).catch(() => false);
    if (!atribuido) {
      return {
        ok: false,
        mensagem: `Não foi possível atribuir o cargo ${cargo.name}. Verifique a hierarquia de cargos do bot.`,
      };
    }
  }
  return { ok: true, cargo };
}

function _mentionUsers(streamer) {
  return {
    users: [...new Set([streamer.streamerId, ...(streamer.jogadores ?? []).map((j) => j.id)].filter(Boolean))],
  };
}

function _temAcesso(interaction, streamer) {
  return Boolean(
    streamer &&
    (_ehAdmin(interaction) ||
      interaction.user.id === streamer.streamerId ||
      interaction.user.id === streamer.mediatorId),
  );
}

function _ehResponsavel(interaction, streamer) {
  return Boolean(
    streamer &&
    (interaction.user.id === streamer.streamerId ||
      interaction.user.id === streamer.mediatorId),
  );
}

function _streamersDoUsuario(guildId, userId) {
  return Object.values(_guild(guildId).streamers).filter(
    (streamer) => streamer.streamerId === userId || streamer.mediatorId === userId,
  );
}

function _limiteFila(guildId) {
  return MAX_JOGADORES_STREAMER;
}

function _jogadoresDaFila(streamer) {
  return (streamer.jogadores ?? []).slice(0, MAX_JOGADORES_STREAMER);
}

function _partidaAtiva(guildId, streamer) {
  try {
    const { obterPartidaStreamerAtiva } = require('./partida');
    const partida = obterPartidaStreamerAtiva(guildId, streamer.streamerId, streamer.partidaAtivaId)
      ?? (streamer.partidaAtivaId
        ? obterPartidaStreamerAtiva(guildId, streamer.streamerId)
        : null);
    if (partida) {
      if (streamer.partidaAtivaId !== partida.id) {
        streamer.partidaAtivaId = partida.id;
        _salvar();
      }
      return partida;
    }
  } catch (error) {
    console.error('[STREAMER] Falha ao consultar partida ativa:', error.message);
  }

  if (streamer.partidaAtivaId) {
    streamer.partidaAtivaId = null;
    _salvar();
  }
  return null;
}

function _aviso(titulo, descricao, cor = 0x5865F2) {
  return new EmbedBuilder()
    .setTitle(titulo)
    .setDescription(descricao)
    .setColor(cor);
}

function _nomeUsuario(guild, id) {
  const membro = guild?.members?.cache?.get(id);
  return membro?.displayName || membro?.user?.globalName || membro?.user?.username || id;
}

function _precoKey(guildId, streamerId) {
  return `${guildId}:${streamerId}`;
}

function _precoStreamer(guildId, streamer) {
  const configurado = _validarPreco(streamer?.preco);
  if (configurado !== null) return configurado;
  return _validarPreco(_precos.get(_precoKey(guildId, streamer?.streamerId)));
}

function _pixStreamer(guildId, streamer) {
  try {
    const { obterPixMediador } = require('./fila_mediador');
    return obterPixMediador(guildId, streamer?.mediatorId);
  } catch (error) {
    console.error('[STREAMER] Falha ao consultar PIX do mediador:', error.message);
    return null;
  }
}

function _validarConfiguracaoFila(guildId, streamer) {
  const faltantes = [];
  try {
    const { getConfig } = require('./configurar');
    const cfg = getConfig(guildId);
    if (!cfg?.channels?.filaStreamer && !cfg?.channels?.filas) {
      faltantes.push('canal de tópicos/filas configurado em /configurar');
    }
  } catch (_) {}
  if (!streamer?.mediatorId) faltantes.push('mediador responsável');
  if (!streamer?.mediatorId || !_pixStreamer(guildId, streamer)?.chave) {
    faltantes.push('chave PIX do mediador');
  }
  if (_precoStreamer(guildId, streamer) === null) faltantes.push('valor da partida');
  if (!String(streamer?.setup?.titulo ?? '').trim()) faltantes.push('título');
  if (!String(streamer?.setup?.descricao ?? '').trim()) faltantes.push('descrição');
  if (!MODOS_STREAMER.includes(streamer?.setup?.modo)) faltantes.push('modo');
  if (!TIPOS_STREAMER.includes(streamer?.setup?.tipo)) faltantes.push('tipo');
  return faltantes;
}

function _opcoesModo(modoAtual) {
  return MODOS_STREAMER.map((modo) => ({
    label: modo,
    value: modo,
    description: modo === modoAtual ? 'Modo atual' : `Partida no formato ${modo}`,
  }));
}

function _opcoesTipo(tipoAtual) {
  return TIPOS_STREAMER.map((tipo) => ({
    label: tipo,
    value: tipo,
    description: tipo === tipoAtual ? 'Tipo atual' : `Partida ${tipo}`,
  }));
}

function _painelPrincipal(guildId) {
  const g = _guild(guildId);
  const total = Object.keys(g.streamers).length;
  const embed = new EmbedBuilder()
    .setTitle('CONFIGURAÇÃO DA FILA STREAMER')
    .setColor(_cor(guildId))
    .setDescription(
      'Gerencie filas individuais de streamers com atualização automática em um único painel.',
    )
    .addFields({
      name: 'Streamers configurados',
      value: total > 0
        ? Object.values(g.streamers)
            .map((item) => `<@${item.streamerId}> — Mediador <@${item.mediatorId}>`)
            .join('\n')
        : 'Nenhum streamer configurado.',
    });

  const menu = new StringSelectMenuBuilder()
    .setCustomId('streamer:acao')
    .setPlaceholder('Escolha uma ação')
    .addOptions([
      {
        label: 'Criar Fila',
        value: 'criar',
        description: 'Personalizar e publicar uma fila',
      },
      {
        label: 'Adicionar Streamer',
        value: 'adicionar',
        description: 'Cadastrar um streamer e seu mediador',
      },
      {
        label: 'Remover Streamer',
        value: 'remover',
        description: 'Excluir uma fila cadastrada',
      },
    ]);

  return painelV2FromEmbed(embed, [
    new ActionRowBuilder().addComponents(menu),
  ]);
}

function _painelRemover(guildId) {
  const streamers = Object.values(_guild(guildId).streamers);
  const embed = new EmbedBuilder()
    .setTitle('REMOVER STREAMER')
    .setColor(_cor(guildId))
    .setDescription(
      'Selecione o streamer que deseja remover.\nO cargo do streamer e do mediador correspondente serão retirados automaticamente.',
    );

  if (!streamers.length) {
    embed.addFields({ name: 'Streamers configurados', value: 'Nenhum streamer configurado.' });
    return painelV2FromEmbed(embed, [
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('streamer:voltar').setLabel('Voltar').setStyle(ButtonStyle.Secondary),
      ),
    ]);
  }

  embed.addFields({
    name: 'Streamers configurados',
    value: streamers.map((item) => `<@${item.streamerId}> — Mediador <@${item.mediatorId}>`).join('\n'),
  });

  const select = new StringSelectMenuBuilder()
    .setCustomId('streamer:confirmar_remover')
    .setPlaceholder('Escolher streamer para remover')
    .addOptions(
      streamers.map((item) => ({
        label: `Streamer ...${item.streamerId.slice(-5)}`,
        value: item.streamerId,
        description: `Mediador: ...${item.mediatorId.slice(-5)}`,
      })),
    );

  return painelV2FromEmbed(embed, [
    new ActionRowBuilder().addComponents(select),
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('streamer:voltar').setLabel('Voltar').setStyle(ButtonStyle.Secondary),
    ),
  ]);
}

function _painelAdicionar(guildId, sessao) {
  const embed = new EmbedBuilder()
    .setTitle('ADICIONAR STREAMER')
    .setColor(_cor(guildId))
    .setDescription('Selecione o streamer e o mediador responsável. Ambos poderão personalizar a fila.');

  const streamerSelect = new UserSelectMenuBuilder()
    .setCustomId('streamer:selecionar_streamer')
    .setPlaceholder('Escolher streamer')
    .setMinValues(1)
    .setMaxValues(1);
  const mediatorSelect = new UserSelectMenuBuilder()
    .setCustomId('streamer:selecionar_mediador')
    .setPlaceholder('Escolher mediador responsável')
    .setMinValues(1)
    .setMaxValues(1);

  const resumo = [
    `Streamer: ${sessao.streamerId ? `<@${sessao.streamerId}>` : 'Não selecionado'}`,
    `Mediador: ${sessao.mediatorId ? `<@${sessao.mediatorId}>` : 'Não selecionado'}`,
  ].join('\n');
  embed.addFields({ name: 'Seleção atual', value: resumo });

  return painelV2FromEmbed(embed, [
    new ActionRowBuilder().addComponents(streamerSelect),
    new ActionRowBuilder().addComponents(mediatorSelect),
    new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('streamer:voltar')
        .setLabel('Voltar')
        .setStyle(ButtonStyle.Secondary),
    ),
  ]);
}

function _painelSelecionarConfigurado(guildId, streamers = Object.values(_guild(guildId).streamers)) {
  const embed = new EmbedBuilder()
    .setTitle('SELECIONAR STREAMER')
    .setColor(_cor(guildId))
    .setDescription('Escolha o streamer cuja fila será personalizada.');
  const select = new StringSelectMenuBuilder()
    .setCustomId('streamer:selecionar_configuracao')
    .setPlaceholder('Escolher streamer')
    .addOptions(streamers.map((item) => ({
      label: `Streamer ${item.streamerId.slice(-5)}`,
      value: item.streamerId,
      description: `Mediador: ${item.mediatorId.slice(-5)}`,
    })))
    .setMinValues(1)
    .setMaxValues(1);
  embed.addFields({
    name: 'Streamers disponíveis',
    value: streamers.map((item) => `<@${item.streamerId}>`).join('\n') || 'Nenhum streamer configurado.',
  });
  return painelV2FromEmbed(embed, [
    new ActionRowBuilder().addComponents(select),
    new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('streamer:voltar')
        .setLabel('Voltar')
        .setStyle(ButtonStyle.Secondary),
    ),
  ]);
}

function _painelCriar(guildId, streamerId, guild) {
  const streamer = _streamer(guildId, streamerId);
  const preco = _precoStreamer(guildId, streamer);
  const setup = streamer.setup;
  const pendencias = _validarConfiguracaoFila(guildId, streamer);
  const embed = new EmbedBuilder()
    .setTitle('CRIAR FILA STREAMER')
    .setColor(_cor(guildId))
    .setDescription('Personalize o painel da fila. As alterações são salvas automaticamente.')
    .addFields({
      name: 'Configuração atual',
      value: [
        `Streamer: <@${streamer.streamerId}>`,
        `Mediador: <@${streamer.mediatorId}>`,
        `Título: **${setup.titulo || 'Não definido'}**`,
        `Descrição: **${setup.descricao || 'Não definida'}**`,
        `Valor: **${preco != null ? `R$ ${Number(preco).toFixed(2).replace('.', ',')}` : 'Não definido'}**`,
        `Modo: **${setup.modo || 'Não definido'}**`,
        `Tipo: **${setup.tipo || 'Não definido'}**`,
        `PIX do mediador: **${_pixStreamer(guildId, streamer)?.chave ? 'Configurado' : 'Não configurado'}**`,
        `Imagens: **${setup.thumbnail || setup.banner ? 'Configuradas' : 'Não configuradas'}**`,
      ].join('\n'),
    });
  embed.addFields({
    name: pendencias.length ? 'Pendências para publicar' : 'Status',
    value: pendencias.length
      ? pendencias.map((item) => `• ${item}`).join('\n')
      : 'Tudo configurado. A fila pode ser publicada.',
  });

  const menu = new StringSelectMenuBuilder()
    .setCustomId(`streamer:config:${streamerId}`)
    .setPlaceholder('Escolha uma configuração')
    .addOptions([
      { label: 'Título', value: 'titulo', description: 'Definir o título da fila' },
      { label: 'Descrição', value: 'descricao', description: 'Definir a descrição da fila' },
      { label: 'Valor', value: 'preco', description: 'Definir o valor deste envio' },
      { label: 'Modo', value: 'modo', description: 'Escolher 1x1, 2x2, 3x3 ou 4x4' },
      { label: 'Tipo', value: 'tipo', description: 'Escolher Mobile, Emulador ou Misto' },
      { label: 'Imagens', value: 'imagens', description: 'Configurar thumbnail e banner' },
    ]);

  return painelV2FromEmbed(embed, [
    new ActionRowBuilder().addComponents(menu),
    new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`streamer:enviar:${streamerId}`)
        .setLabel('Enviar')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId(`streamer:pix:${streamerId}`)
        .setLabel('Chave PIX')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('streamer:voltar')
        .setLabel('Voltar')
        .setStyle(ButtonStyle.Secondary),
    ),
  ]);
}

function _painelInformacoes(guildId, streamerId, guild, contexto = 'public') {
  const streamer = _streamer(guildId, streamerId);
  const setup = streamer.setup;
  const preco = _precoStreamer(guildId, streamer);
  const embed = new EmbedBuilder()
    .setTitle('ALTERAR INFORMAÇÕES')
    .setColor(_cor(guildId))
    .setDescription('Escolha qual informação da fila você deseja alterar.')
    .addFields({
      name: 'Configuração atual',
      value: [
        `Título: **${setup.titulo || 'Não definido'}**`,
        `Descrição: **${setup.descricao || 'Não definida'}**`,
        `Valor: **${preco == null ? 'Não definido' : `R$ ${preco.toFixed(2).replace('.', ',')}`}**`,
        `Modo: **${setup.modo || 'Não definido'}**`,
        `Tipo: **${setup.tipo || 'Não definido'}**`,
      ].join('\n'),
    });
  const menu = new StringSelectMenuBuilder()
    .setCustomId(`streamer:info:${streamerId}:${contexto}`)
    .setPlaceholder('Escolha uma informação')
    .addOptions([
      { label: 'Título', value: 'titulo', description: 'Alterar o título da fila' },
      { label: 'Descrição', value: 'descricao', description: 'Alterar a descrição da fila' },
      { label: 'Valor', value: 'valor', description: 'Alterar o valor da partida' },
      { label: 'Modo', value: 'modo', description: 'Escolher 1x1, 2x2, 3x3 ou 4x4' },
      { label: 'Tipo', value: 'tipo', description: 'Escolher Mobile, Emulador ou Misto' },
    ]);
  return painelV2FromEmbed(embed, [
    new ActionRowBuilder().addComponents(menu),
  ]);
}

function _painelEscolherFormato(guildId, streamerId, contexto, campo) {
  const streamer = _streamer(guildId, streamerId);
  const modo = campo === 'modo';
  const menu = new StringSelectMenuBuilder()
    .setCustomId(`streamer:info_${campo}:${streamerId}:${contexto}`)
    .setPlaceholder(modo ? 'Escolher modo' : 'Escolher tipo')
    .addOptions(modo ? _opcoesModo(streamer.setup.modo) : _opcoesTipo(streamer.setup.tipo));
  const embed = new EmbedBuilder()
    .setTitle(modo ? 'ALTERAR MODO' : 'ALTERAR TIPO')
    .setColor(_cor(guildId))
    .setDescription(modo
      ? 'Escolha o formato da partida: 1x1, 2x2, 3x3 ou 4x4.'
      : 'Escolha a plataforma da partida: Mobile, Emulador ou Misto.');
  return painelV2FromEmbed(embed, [
    new ActionRowBuilder().addComponents(menu),
    new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`streamer:info:voltar:${streamerId}:${contexto}`)
        .setLabel('Voltar')
        .setStyle(ButtonStyle.Secondary),
    ),
  ]);
}

function _painelEscolherCanal(guildId, streamerId) {
  const embed = new EmbedBuilder()
    .setTitle('ENVIAR FILA STREAMER')
    .setColor(_cor(guildId))
    .setDescription(`Escolha o canal onde a fila de <@${streamerId}> será publicada.`);
  const select = new ChannelSelectMenuBuilder()
    .setCustomId(`streamer:canal:${streamerId}`)
    .setPlaceholder('Escolher canal da fila')
    .setChannelTypes([ChannelType.GuildText, ChannelType.GuildAnnouncement])
    .setMinValues(1)
    .setMaxValues(1);
  return painelV2FromEmbed(embed, [
    new ActionRowBuilder().addComponents(select),
    new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`streamer:configurar:${streamerId}`)
        .setLabel('Voltar')
        .setStyle(ButtonStyle.Secondary),
    ),
  ]);
}

function _filaEmbedSemImagens(streamer, guild) {
  const jogadores = _jogadoresDaFila(streamer);
  const limite = _limiteFila(guild?.id);
  const preco = _precoStreamer(guild?.id, streamer);
  const lista = jogadores.length
    ? jogadores.map((j) => `• <@${j.id}>`).join('\n')
    : 'Nenhum jogador na fila.';
  const partidaAtiva = guild?.id ? _partidaAtiva(guild.id, streamer) : null;
  const embed = new EmbedBuilder()
    .setTitle(streamer.setup.titulo || 'Fila do Streamer')
    .setDescription(streamer.setup.descricao || 'Entre na fila para jogar contra o streamer.')
    .setColor(_cor(guild?.id))
    .addFields(
      { name: 'Streamer responsável', value: `<@${streamer.streamerId}>`, inline: false },
      { name: 'Status', value: streamer.online ? 'Online' : 'Off-line', inline: true },
      { name: 'Valor da partida', value: preco === null ? 'Não definido' : `R$ ${preco.toFixed(2).replace('.', ',')}`, inline: true },
      { name: 'Formato', value: `${streamer.setup.modo || 'Não definido'} • ${streamer.setup.tipo || 'Não definido'}`, inline: true },
      { name: 'Partida atual', value: partidaAtiva ? 'Em andamento — a fila de espera será puxada ao encerrar.' : 'Nenhuma partida em andamento.', inline: false },
    );

  if (jogadores.length > 0) {
    embed.addFields({
      name: `Fila de espera • ${jogadores.length}/${limite}`,
      value: lista,
      inline: false,
    });
  }

  return embed;
}

function _filaEmbedComImagens(streamer, guild, thumbnail, banner) {
  const embed = _filaEmbedSemImagens(streamer, guild);
  embed.setThumbnail(thumbnail);
  if (banner) embed.setImage(banner);
  return embed;
}

function _filaEmbed(streamer, guild) {
  const thumbnail = _urlImagem(streamer.setup.thumbnail);
  const banner = _urlImagem(streamer.setup.banner);
  if (thumbnail) return _filaEmbedComImagens(streamer, guild, thumbnail, banner);
  if (banner) return _filaEmbedComImagens(streamer, guild, banner, null);
  return _filaEmbedSemImagens(streamer, guild);
}

function _filaRows(streamer) {
  return [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`streamer:fila:entrar:${streamer.streamerId}`)
        .setLabel('Entrar na Fila')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId(`streamer:fila:sair:${streamer.streamerId}`)
        .setLabel('Sair da Fila')
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId(`streamer:fila:online:${streamer.streamerId}`)
        .setLabel(streamer.online ? 'Off-line' : 'Online')
        .setStyle(streamer.online ? ButtonStyle.Danger : ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId(`streamer:fila:historico:${streamer.streamerId}`)
        .setLabel('Ver Histórico')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(`streamer:fila:informacoes:${streamer.streamerId}`)
        .setLabel('Alterar informações')
        .setStyle(ButtonStyle.Primary),
    ),
  ];
}

function _historicoEmbed(streamer, guild) {
  const hoje = new Date().toISOString().slice(0, 10);
  const registros = (streamer.historico ?? []).filter((item) => item.data === hoje);
  const descricao = registros.length
    ? registros
        .slice(-20)
        .reverse()
        .map((item, index) => {
          const jogadores = item.jogadores.map((id) => `<@${id}>`).join(', ');
          return `**${index + 1}.** ${item.resultado || 'Resultado registrado'}\n${jogadores || 'Nenhum jogador'} — ${item.horario}`;
        })
        .join('\n\n')
    : 'Nenhuma partida registrada hoje.';
  return new EmbedBuilder()
    .setTitle('HISTÓRICO DIÁRIO DA FILA')
    .setColor(_cor(guild?.id))
    .setDescription(`Streamer: <@${streamer.streamerId}>\n\n${descricao}`);
}

async function _refreshPublico(streamer, guildId, client, mensagemClicada = null) {
  if (!streamer?.painel?.msgId || !streamer.painel.chanId) return;

  const guildObj = client.guilds.cache.get(guildId) || null;
  const payload = {
    ...painelV2FromEmbed(_filaEmbed(streamer, guildObj), _filaRows(streamer)),
    allowedMentions: _mentionUsers(streamer),
  };

  if (mensagemClicada?.id === streamer.painel.msgId && typeof mensagemClicada.edit === 'function') {
    await mensagemClicada.edit(payload).catch(() => {});
    return;
  }

  const canal = client.channels.cache.get(streamer.painel.chanId) || await client.channels.fetch(streamer.painel.chanId).catch(() => null);
  const mensagem = canal?.messages?.cache?.get(streamer.painel.msgId) || (canal?.messages ? await canal.messages.fetch(streamer.painel.msgId).catch(() => null) : null);
  if (!mensagem) return;
  try {
    await mensagem.edit(payload);
  } catch (err) {
    if (err.code === 10008) {
      // Mensagem apagada — limpar referência stale
      streamer.painel = { msgId: null, chanId: null };
      _salvar();
    }
  }
}

async function _autoRefreshPaineisStreamer(client) {
  if (_autoRefreshEmAndamento) return;
  _autoRefreshEmAndamento = true;
  try {
    for (const [guildId, guildData] of Object.entries(_dados)) {
      for (const streamer of Object.values(guildData.streamers ?? {})) {
        if (!streamer.painel?.msgId) continue;
        await _refreshPublico(streamer, guildId, client).catch((error) => {
          console.error('[STREAMER] Falha no auto-refresh do painel:', error.message);
        });
      }
    }
  } finally {
    _autoRefreshEmAndamento = false;
  }
}

function _iniciarAutoRefresh(client) {
  if (_autoRefreshTimer) return;
  _autoRefreshTimer = setInterval(() => {
    _autoRefreshPaineisStreamer(client).catch((error) => {
      console.error('[STREAMER] Falha no ciclo de auto-refresh:', error.message);
    });
  }, 30_000);
  _autoRefreshTimer.unref?.();
}

async function _enviarPublico(streamer, guildId, canal, client) {
  const mensagem = await canal.send({
    ...painelV2FromEmbed(_filaEmbed(streamer, canal.guild), _filaRows(streamer)),
    allowedMentions: _mentionUsers(streamer),
  });
  streamer.painel = { msgId: mensagem.id, chanId: canal.id };
  _salvar();
  console.log(`[STREAMER] Painel enviado para ${streamer.streamerId} no canal ${canal.id}.`);
}

async function _criarPartidaStreamer(guildId, streamer, client) {
  const lockKey = _precoKey(guildId, streamer.streamerId);
  if (_partidasEmCriacao.has(lockKey)) return { ok: false, message: 'Já estou criando a partida desta fila.' };
  _partidasEmCriacao.add(lockKey);

  try {
    if (_partidaAtiva(guildId, streamer)) {
      return { ok: true, created: false, active: true };
    }

    const pendencias = _validarConfiguracaoFila(guildId, streamer);
    if (pendencias.length) {
      return {
        ok: false,
        message: `A fila ainda não está liberada. O mediador precisa configurar: ${pendencias.join(', ')}.`,
      };
    }

    const jogadoresFila = _jogadoresDaFila(streamer);
    if (jogadoresFila.length < JOGADORES_POR_PARTIDA_STREAMER) {
      return { ok: true, created: false };
    }
    const desafiantes = jogadoresFila.slice(0, JOGADORES_POR_PARTIDA_STREAMER);
    const guild = client.guilds.cache.get(guildId);
    const { getConfig } = require('./configurar');
    const cfg = getConfig(guildId);
    const canalPaiId = cfg?.channels?.filaStreamer || cfg?.channels?.filas || streamer.painel?.chanId;
    const canal = canalPaiId
      ? await client.channels.fetch(canalPaiId).catch(() => null)
      : null;
    if (!guild) return { ok: false, message: 'Não encontrei o servidor desta fila.' };
    if (!canal) {
      return {
        ok: false,
        message: 'O canal da fila não está disponível. Publique o painel novamente em um canal válido.',
      };
    }
    if (!canal.threads?.create && !canal.guild?.channels?.create) {
      return {
        ok: false,
        message: 'Não consegui criar tópicos neste canal. Verifique se o canal suporta tópicos.',
      };
    }
    const botMember = guild.members.me ?? await guild.members.fetchMe().catch(() => null);
    const permissoes = botMember ? canal.permissionsFor(botMember) : null;
    const necessarias = [
      [PermissionFlagsBits.ViewChannel, 'Ver canal'],
      [PermissionFlagsBits.SendMessages, 'Enviar mensagens'],
      [PermissionFlagsBits.ReadMessageHistory, 'Ler histórico de mensagens'],
      [PermissionFlagsBits.ManageChannels, 'Gerenciar canais'],
    ];
    const faltantes = permissoes
      ? necessarias.filter(([flag]) => !permissoes.has(flag)).map(([, nome]) => nome)
      : necessarias.map(([, nome]) => nome);
    if (faltantes.length) {
      return {
        ok: false,
        message: `Faltam permissões no canal da fila: ${faltantes.join(', ')}.`,
      };
    }

    const jogadores = [...desafiantes];
    const preco = _precoStreamer(guildId, streamer);
    if (preco === null) {
      return { ok: false, message: 'Defina o preço da fila antes de formar a partida.' };
    }
    const { criarPartida } = require('./partida');
    let partidaCanal = null;
    try {
      const nomeTopico = `partida-streamer-${streamer.setup?.modo ?? '1v1'}`.toLowerCase().replace(/[^a-z0-9-_]+/g, '-').slice(0, 80);
      
      if (canal && typeof canal.threads?.create === 'function' && canal.type === ChannelType.GuildText) {
        try {
          partidaCanal = await canal.threads.create({
            name: nomeTopico,
            type: ChannelType.PrivateThread,
            invitable: false,
            autoArchiveDuration: 60,
            reason: 'Partida formada na fila de streamer',
          });
        } catch (errPrivado) {
          console.log('[STREAMER] Tentando tópico público:', errPrivado.message);
          try {
            partidaCanal = await canal.threads.create({
              name: nomeTopico,
              type: ChannelType.PublicThread,
              autoArchiveDuration: 60,
              reason: 'Partida formada na fila de streamer',
            });
          } catch (errPublico) {
            console.log('[STREAMER] Falha ao criar tópico público:', errPublico.message);
          }
        }
      }

      if (!partidaCanal) {
        console.log('[STREAMER] Criando canal de texto dedicado para a partida de streamer...');
        const botId = client.user.id;
        const overwrites = [
          {
            id: guild.roles.everyone.id,
            deny: [PermissionFlagsBits.ViewChannel],
          },
          {
            id: botId,
            allow: [
              PermissionFlagsBits.ViewChannel,
              PermissionFlagsBits.SendMessages,
              PermissionFlagsBits.EmbedLinks,
              PermissionFlagsBits.AttachFiles,
              PermissionFlagsBits.ManageChannels,
              PermissionFlagsBits.ReadMessageHistory,
            ],
          },
        ];
        if (streamer.mediatorId) {
          overwrites.push({
            id: streamer.mediatorId,
            allow: [
              PermissionFlagsBits.ViewChannel,
              PermissionFlagsBits.SendMessages,
              PermissionFlagsBits.EmbedLinks,
              PermissionFlagsBits.AttachFiles,
              PermissionFlagsBits.ReadMessageHistory,
            ],
          });
        }
        if (streamer.streamerId) {
          overwrites.push({
            id: streamer.streamerId,
            allow: [
              PermissionFlagsBits.ViewChannel,
              PermissionFlagsBits.SendMessages,
              PermissionFlagsBits.EmbedLinks,
              PermissionFlagsBits.AttachFiles,
              PermissionFlagsBits.ReadMessageHistory,
            ],
          });
        }
        for (const j of jogadores) {
          if (j.id) {
            overwrites.push({
              id: j.id,
              allow: [
                PermissionFlagsBits.ViewChannel,
                PermissionFlagsBits.SendMessages,
                PermissionFlagsBits.EmbedLinks,
                PermissionFlagsBits.AttachFiles,
                PermissionFlagsBits.ReadMessageHistory,
              ],
            });
          }
        }
        const parentCat = canal.type === ChannelType.GuildCategory ? canal.id : (canal.parentId || null);
        partidaCanal = await guild.channels.create({
          name: nomeTopico,
          type: ChannelType.GuildText,
          parent: parentCat,
          permissionOverwrites: overwrites,
          reason: 'Partida formada na fila de streamer',
        });
      }

      if (!partidaCanal) {
        throw new Error('Não foi possível criar tópico nem canal para a partida de streamer.');
      }

      if (typeof partidaCanal.join === 'function') await partidaCanal.join().catch(() => {});
      if (partidaCanal.members && typeof partidaCanal.members.add === 'function') {
        if (streamer.mediatorId) await partidaCanal.members.add(streamer.mediatorId).catch(() => {});
        if (streamer.streamerId) await partidaCanal.members.add(streamer.streamerId).catch(() => {});
        for (const j of jogadores) {
          await partidaCanal.members.add(j.id).catch(() => {});
        }
      }

      const partida = await criarPartida({
        guildId,
        canal: partidaCanal,
        jogadores,
        mediadorId: streamer.mediatorId,
        setup: {
          tipo: streamer.setup.tipo,
          modo: streamer.setup.modo,
          streamerId: streamer.streamerId,
        },
        valor: Number(preco),
        tipo: streamer.setup.tipo,
        modo: streamer.setup.modo,
        client,
      });

      streamer.partidaAtivaId = partida.id;
      const idsRemovidos = new Set(jogadores.map((j) => j.id));
      streamer.jogadores = streamer.jogadores.filter((j) => !idsRemovidos.has(j.id));
      _salvar();
    } catch (error) {
      console.error(`[STREAMER] Falha ao criar partida (code=${error.code ?? 'n/a'}):`, error.message);
      await partidaCanal?.delete('Falha ao criar tópico da partida de streamer').catch(() => {});
      return {
        ok: false,
        message: 'Não consegui criar o tópico da partida. Verifique se o bot pode criar e gerenciar tópicos no canal.',
      };
    }

    await _refreshPublico(streamer, guildId, client);
    return { ok: true, created: true };
  } finally {
    _partidasEmCriacao.delete(lockKey);
  }
}

function _painelCriarComGuild(guildId, streamerId, guild, userId) {
  _sessao(guildId, userId).streamerId = streamerId;
  return _painelCriar(guildId, streamerId, guild);
}

async function _atualizarConfiguracaoPublica(streamer, guildId, client) {
  if (streamer.painel?.msgId) await _refreshPublico(streamer, guildId, client);
}

function _validarPreco(valor) {
  const numero = Number.parseFloat(String(valor).replace(',', '.'));
  return Number.isFinite(numero) && numero >= 0 ? numero : null;
}

function _salvarAssociacao(guildId, sessao) {
  if (!sessao.streamerId || !sessao.mediatorId) return false;
  const existente = _streamer(guildId, sessao.streamerId);
  _guild(guildId).streamers[sessao.streamerId] = existente
    ? { ...existente, mediatorId: sessao.mediatorId }
    : _novoStreamer(sessao.streamerId, sessao.mediatorId);
  _salvar();
  return true;
}

async function handleFilaStreamer(interaction, client) {
  const guildId = interaction.guildId;
  if (!guildId) return false;

  const isFilaStreamerCmd = interaction.isChatInputCommand() && (
    interaction.commandName === 'fila_streamer' ||
    (interaction.commandName === 'fila' && interaction.options.getSubcommand(false) === 'streamer')
  );

  if (isFilaStreamerCmd) {
    // Streamer ou mediador cadastrado → abre direto o próprio painel quando
    // houver apenas uma fila sob sua responsabilidade.
    if (!_ehAdmin(interaction)) {
      const proprios = _streamersDoUsuario(guildId, interaction.user.id);
      if (!proprios.length) {
        await interaction.reply({
          content: '⚠️ Você não possui uma fila de streamer configurada.',
          flags: MessageFlags.Ephemeral,
        });
        return true;
      }
      if (proprios.length === 1) {
        _sessao(guildId, interaction.user.id).streamerId = proprios[0].streamerId;
        await interaction.reply({
          ..._painelCriar(guildId, proprios[0].streamerId, interaction.guild),
          flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
        });
        return true;
      }
      await interaction.reply({
        ..._painelSelecionarConfigurado(guildId, proprios),
        flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
      });
      return true;
    }
    // Admin → painel de gerenciamento completo
    await interaction.reply({
      ..._painelPrincipal(guildId),
      flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
    });
    return true;
  }

  const id = interaction.customId ?? '';
  if (!id.startsWith('streamer:')) return false;

  if (interaction.isStringSelectMenu() && id === 'streamer:acao') {
    const acao = interaction.values[0];
    if (acao === 'criar') {
      const streamers = Object.values(_guild(guildId).streamers);
      if (!streamers.length) {
        await interaction.reply({
          content: '⚠️ É necessário configurar pelo menos 1 streamer antes de enviar uma fila.',
          flags: MessageFlags.Ephemeral,
        });
        return true;
      }
      const disponiveis = _ehAdmin(interaction)
        ? streamers
        : _streamersDoUsuario(guildId, interaction.user.id);
      if (!disponiveis.length) {
        await interaction.reply({
          content: '⚠️ Você não possui uma fila de streamer configurada.',
          flags: MessageFlags.Ephemeral,
        });
        return true;
      }
      if (disponiveis.length === 1) {
        await interaction.update(
          _painelCriarComGuild(guildId, disponiveis[0].streamerId, interaction.guild, interaction.user.id),
        );
      } else {
        await interaction.update(_painelSelecionarConfigurado(guildId, disponiveis));
      }
      return true;
    }

    if (acao === 'adicionar') {
      if (!_ehAdmin(interaction)) {
        await interaction.reply({
          content: '🔒 Apenas administradores podem adicionar streamers.',
          flags: MessageFlags.Ephemeral,
        });
        return true;
      }
      _sessoes.set(`${guildId}:${interaction.user.id}`, {
        guildId,
        streamerId: null,
        mediatorId: null,
        preco: '',
      });
      await interaction.update(_painelAdicionar(guildId, _sessao(guildId, interaction.user.id)));
      return true;
    }

    if (acao === 'remover') {
      if (!_ehAdmin(interaction)) {
        await interaction.reply({
          content: '🔒 Apenas administradores podem remover streamers.',
          flags: MessageFlags.Ephemeral,
        });
        return true;
      }
      await interaction.update(_painelRemover(guildId));
      return true;
    }

    await interaction.reply({
      content: '⚠️ Ação inválida.',
      flags: MessageFlags.Ephemeral,
    });
    return true;
  }

  if (id === 'streamer:criar') {
    const streamers = Object.values(_guild(guildId).streamers);
    if (!streamers.length) {
      await interaction.reply({
        content: '⚠️ É necessário configurar pelo menos 1 streamer antes de enviar uma fila.',
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    const disponiveis = _ehAdmin(interaction)
      ? streamers
      : _streamersDoUsuario(guildId, interaction.user.id);
    if (!disponiveis.length) {
      await interaction.reply({
        content: '⚠️ Você não possui uma fila de streamer configurada.',
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    if (disponiveis.length === 1) {
      await interaction.update(
        _painelCriarComGuild(guildId, disponiveis[0].streamerId, interaction.guild, interaction.user.id),
      );
    } else {
      if (!_ehAdmin(interaction) && !disponiveis.some((streamer) => _temAcesso(interaction, streamer))) {
        await interaction.reply({ content: '🔒 Você não possui acesso a esta configuração.', flags: MessageFlags.Ephemeral });
        return true;
      }
      await interaction.update(_painelSelecionarConfigurado(guildId, disponiveis));
    }
    return true;
  }

  if (id === 'streamer:adicionar') {
    if (!_ehAdmin(interaction)) {
      await interaction.reply({ content: '🔒 Apenas administradores podem adicionar streamers.', flags: MessageFlags.Ephemeral });
      return true;
    }
    _sessoes.set(`${guildId}:${interaction.user.id}`, { guildId, streamerId: null, mediatorId: null, preco: '' });
    await interaction.update(_painelAdicionar(guildId, _sessao(guildId, interaction.user.id)));
    return true;
  }

  if (id === 'streamer:remover') {
    if (!_ehAdmin(interaction)) {
      await interaction.reply({ content: '🔒 Apenas administradores podem remover streamers.', flags: MessageFlags.Ephemeral });
      return true;
    }
    await interaction.update(_painelRemover(guildId));
    return true;
  }

  if (interaction.isStringSelectMenu() && id === 'streamer:confirmar_remover') {
    if (!_ehAdmin(interaction)) {
      await interaction.reply({ content: '🔒 Apenas administradores podem remover streamers.', flags: MessageFlags.Ephemeral });
      return true;
    }
    const streamerId = interaction.values[0];
    const streamer = _streamer(guildId, streamerId);
    if (!streamer) {
      await interaction.reply({ content: '⚠️ Streamer não encontrado.', flags: MessageFlags.Ephemeral });
      return true;
    }

    const { getConfig } = require('./configurar');
    const cfg = getConfig(guildId);

    // Remover cargo do streamer
    const membroStreamer = await interaction.guild.members.fetch(streamer.streamerId).catch(() => null);
    if (membroStreamer) {
      const roleStreamerId = cfg.roles?.streamer ?? null;
      const cargoStreamer = roleStreamerId
        ? await interaction.guild.roles.fetch(roleStreamerId).catch(() => null)
        : interaction.guild.roles.cache.find((r) => !r.managed && r.name.toLowerCase() === 'streamer') ?? null;
      if (cargoStreamer) await membroStreamer.roles.remove(cargoStreamer).catch(() => {});
    }

    // Remover cargo do mediador de streamer
    const membroMediador = await interaction.guild.members.fetch(streamer.mediatorId).catch(() => null);
    if (membroMediador) {
      const roleMediadorId = cfg.roles?.mediadorStreamer ?? cfg.roles?.mediador ?? null;
      const cargoMediador = roleMediadorId
        ? await interaction.guild.roles.fetch(roleMediadorId).catch(() => null)
        : interaction.guild.roles.cache.find((r) => !r.managed && r.name.toLowerCase() === 'mediador de streamer') ?? null;
      if (cargoMediador) await membroMediador.roles.remove(cargoMediador).catch(() => {});
    }

    // Remover da base de dados
    delete _guild(guildId).streamers[streamerId];
    _salvar();

    await interaction.update(_painelPrincipal(guildId));
    return true;
  }

  if (id === 'streamer:voltar') {
    if (!_ehAdmin(interaction)) {
      // Streamer/mediador volta direto para o próprio painel de config
      const proprios = _streamersDoUsuario(guildId, interaction.user.id);
      if (proprios.length === 1) {
        await interaction.update(
          _painelCriarComGuild(guildId, proprios[0].streamerId, interaction.guild, interaction.user.id),
        );
        return true;
      }
      if (proprios.length > 1) {
        await interaction.update(_painelSelecionarConfigurado(guildId, proprios));
        return true;
      }
      await interaction.reply({ content: '🔒 Você não possui acesso a esta configuração.', flags: MessageFlags.Ephemeral });
      return true;
    }
    await interaction.update(_painelPrincipal(guildId));
    return true;
  }

  if (interaction.isUserSelectMenu() && id === 'streamer:selecionar_streamer') {
    if (!_ehAdmin(interaction)) {
      await interaction.reply({
        content: '🔒 Apenas administradores podem configurar streamers.',
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }
    const sessao = _sessao(guildId, interaction.user.id);
    sessao.streamerId = interaction.values[0];
    const resultadoCargo = await _garantirCargo(
      interaction.guild,
      sessao.streamerId,
      'Streamer',
      require('./configurar').getConfig(guildId).roles?.streamer ?? null,
    );
    if (!resultadoCargo.ok) {
      await interaction.reply({
        content: resultadoCargo.mensagem,
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }
    _salvarAssociacao(guildId, sessao);
    await interaction.update(_painelAdicionar(guildId, sessao));
    return true;
  }

  if (interaction.isUserSelectMenu() && id === 'streamer:selecionar_mediador') {
    if (!_ehAdmin(interaction)) {
      await interaction.reply({
        content: '🔒 Apenas administradores podem configurar streamers.',
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }
    const sessao = _sessao(guildId, interaction.user.id);
    sessao.mediatorId = interaction.values[0];
    const config = require('./configurar').getConfig(guildId);
    const cargoMediador = config.roles?.mediadorStreamer || config.roles?.mediador;
    const resultadoCargo = await _garantirCargo(
      interaction.guild,
      sessao.mediatorId,
      'Mediador de Streamer',
      cargoMediador ?? null,
    );
    if (!resultadoCargo.ok) {
      await interaction.reply({
        content: resultadoCargo.mensagem,
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }
    _salvarAssociacao(guildId, sessao);
    await interaction.update(_painelAdicionar(guildId, sessao));
    return true;
  }

  if (interaction.isStringSelectMenu() && id === 'streamer:selecionar_configuracao') {
    const streamerId = interaction.values[0];
    const streamer = _streamer(guildId, streamerId);
    if (!_ehAdmin(interaction) && !_streamersDoUsuario(guildId, interaction.user.id).some((item) => item.streamerId === streamerId)) {
      await interaction.reply({
        content: '🔒 Você não possui acesso a esta configuração.',
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }
    if (!_temAcesso(interaction, streamer)) {
      await interaction.reply({ content: '🔒 Você não possui acesso a esta configuração.', flags: MessageFlags.Ephemeral });
      return true;
    }
    _sessao(guildId, interaction.user.id).streamerId = streamerId;
    await interaction.update(_painelCriarComGuild(guildId, streamerId, interaction.guild, interaction.user.id));
    return true;
  }

  if (interaction.isStringSelectMenu() && id.startsWith('streamer:config:')) {
    const streamerId = id.split(':')[2];
    const streamer = _streamer(guildId, streamerId);
    if (!_temAcesso(interaction, streamer)) {
      await interaction.reply({ content: '🔒 Você não possui acesso a esta configuração.', flags: MessageFlags.Ephemeral });
      return true;
    }
    const escolha = interaction.values[0];
    if (escolha === 'modo' || escolha === 'tipo') {
      await interaction.update(_painelEscolherFormato(guildId, streamerId, 'create', escolha));
      return true;
    }
    if (escolha === 'imagens') {
      const modal = new ModalBuilder()
        .setCustomId(`streamer:modal:imagens:${streamerId}`)
        .setTitle('Configurar Imagens');
      modal.addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder().setCustomId('thumbnail').setLabel('Thumbnail').setStyle(TextInputStyle.Short).setRequired(false).setPlaceholder('https://...').setValue(streamer.setup.thumbnail || ''),
        ),
        new ActionRowBuilder().addComponents(
          new TextInputBuilder().setCustomId('banner').setLabel('Banner').setStyle(TextInputStyle.Short).setRequired(false).setPlaceholder('https://...').setValue(streamer.setup.banner || ''),
        ),
      );
      await interaction.showModal(modal);
      return true;
    }
    const modal = new ModalBuilder()
      .setCustomId(`streamer:modal:${escolha}:${streamerId}`)
      .setTitle(`Definir ${escolha}`);
    const campo = new TextInputBuilder()
      .setCustomId('valor')
      .setLabel(escolha === 'titulo' ? 'Título da fila' : escolha === 'descricao' ? 'Descrição da fila' : 'Valor da partida')
      .setStyle(escolha === 'descricao' ? TextInputStyle.Paragraph : TextInputStyle.Short)
      .setRequired(true);
    if (escolha === 'titulo') campo.setValue(streamer.setup.titulo || '');
    if (escolha === 'descricao') campo.setValue(streamer.setup.descricao || '');
    if (escolha === 'preco') campo.setPlaceholder('Ex: 10,00');
    modal.addComponents(new ActionRowBuilder().addComponents(campo));
    await interaction.showModal(modal);
    return true;
  }

  if (id.startsWith('streamer:pix:')) {
    const streamerId = id.split(':')[2];
    const streamer = _streamer(guildId, streamerId);
    if (!streamer || interaction.user.id !== streamer.mediatorId) {
      await interaction.reply({
        content: '🔒 Somente o mediador responsável pode configurar a chave PIX desta fila.',
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }
    const { abrirModalPix } = require('./fila_mediador');
    await abrirModalPix(interaction, `streamer:modal:pix:${streamerId}:create`);
    return true;
  }

  if (interaction.isStringSelectMenu()
    && id.startsWith('streamer:info:')
    && !id.startsWith('streamer:info:voltar:')) {
    const [, , streamerId, contexto = 'public'] = id.split(':');
    const streamer = _streamer(guildId, streamerId);
    if (!streamer || (contexto === 'public'
      ? interaction.user.id !== streamer.mediatorId
      : !_temAcesso(interaction, streamer))) {
      await interaction.reply({ content: '🔒 Somente o mediador responsável pode alterar estas informações.', flags: MessageFlags.Ephemeral });
      return true;
    }
    const escolha = interaction.values[0];
    if (escolha === 'modo' || escolha === 'tipo') {
      await interaction.update(_painelEscolherFormato(guildId, streamerId, contexto, escolha));
      return true;
    }
    const modal = new ModalBuilder()
      .setCustomId(`streamer:modal:${escolha}:${streamerId}:${contexto}`)
      .setTitle(`Alterar ${escolha}`);
    const campo = new TextInputBuilder()
      .setCustomId('valor')
      .setLabel(escolha === 'titulo' ? 'Título da fila' : escolha === 'descricao' ? 'Descrição da fila' : 'Valor da partida')
      .setStyle(escolha === 'descricao' ? TextInputStyle.Paragraph : TextInputStyle.Short)
      .setRequired(true);
    if (escolha === 'titulo') campo.setValue(streamer.setup.titulo || '');
    if (escolha === 'descricao') campo.setValue(streamer.setup.descricao || '');
    if (escolha === 'valor') {
      const preco = _precoStreamer(guildId, streamer);
      if (preco !== null) campo.setValue(preco.toFixed(2).replace('.', ','));
      else campo.setPlaceholder('Ex: 10,00');
    }
    modal.addComponents(new ActionRowBuilder().addComponents(campo));
    await interaction.showModal(modal);
    return true;
  }

  if (interaction.isStringSelectMenu() && (id.startsWith('streamer:info_modo:') || id.startsWith('streamer:info_tipo:'))) {
    const [, campo, streamerId, contexto = 'public'] = id.split(':');
    const streamer = _streamer(guildId, streamerId);
    if (!streamer || (contexto === 'public'
      ? interaction.user.id !== streamer.mediatorId
      : !_temAcesso(interaction, streamer))) {
      await interaction.reply({ content: '🔒 Somente o mediador responsável pode alterar estas informações.', flags: MessageFlags.Ephemeral });
      return true;
    }
    const valor = interaction.values[0];
    if (campo === 'info_modo') streamer.setup.modo = MODOS_STREAMER.includes(valor) ? valor : streamer.setup.modo;
    if (campo === 'info_tipo') streamer.setup.tipo = TIPOS_STREAMER.includes(valor) ? valor : streamer.setup.tipo;
    _salvar();
    await _atualizarConfiguracaoPublica(streamer, guildId, client);
    if (contexto === 'public') {
      await interaction.update(_painelInformacoes(guildId, streamerId, interaction.guild, 'public'));
    } else {
      await interaction.update(_painelCriarComGuild(guildId, streamerId, interaction.guild, interaction.user.id));
    }
    return true;
  }

  if (id.startsWith('streamer:info:voltar:')) {
    const [, , , streamerId, contexto = 'public'] = id.split(':');
    const streamer = _streamer(guildId, streamerId);
    if (!streamer || (contexto === 'public'
      ? interaction.user.id !== streamer.mediatorId
      : !_temAcesso(interaction, streamer))) {
      await interaction.reply({ content: '🔒 Você não possui acesso a esta configuração.', flags: MessageFlags.Ephemeral });
      return true;
    }
    if (contexto === 'public') {
      await interaction.update(_painelInformacoes(guildId, streamerId, interaction.guild, 'public'));
    } else {
      await interaction.update(_painelCriarComGuild(guildId, streamerId, interaction.guild, interaction.user.id));
    }
    return true;
  }

  if (interaction.isModalSubmit() && id.startsWith('streamer:modal:')) {
    const [, , tipo, streamerId, contextoInicial] = id.split(':');
    const contexto = contextoInicial || (tipo === 'valor_publico' ? 'public' : 'create');
    const streamer = _streamer(guildId, streamerId);
    if (!streamer || (contexto === 'public'
      ? interaction.user.id !== streamer.mediatorId
      : !_temAcesso(interaction, streamer))) {
      await interaction.reply({ content: '🔒 Você não possui acesso a esta configuração.', flags: MessageFlags.Ephemeral });
      return true;
    }
    if (tipo === 'pix') {
      if (interaction.user.id !== streamer.mediatorId) {
        await interaction.reply({
          content: '🔒 Somente o mediador responsável pode configurar a chave PIX desta fila.',
          flags: MessageFlags.Ephemeral,
        });
        return true;
      }
      const { salvarPixMediador } = require('./fila_mediador');
      salvarPixMediador(guildId, streamer.mediatorId, {
        titular: interaction.fields.getTextInputValue('titular'),
        cidade: interaction.fields.getTextInputValue('cidade'),
        tipo: interaction.fields.getTextInputValue('tipo'),
        chave: interaction.fields.getTextInputValue('chave'),
      });
      await interaction.deferUpdate();
      await interaction.editReply(_painelCriarComGuild(guildId, streamerId, interaction.guild, interaction.user.id));
      return true;
    }
    if (tipo === 'imagens') {
      const thumbnailRaw = interaction.fields.getTextInputValue('thumbnail').trim();
      const bannerRaw = interaction.fields.getTextInputValue('banner').trim();
      streamer.setup.thumbnail = thumbnailRaw ? _urlImagem(thumbnailRaw) : null;
      streamer.setup.banner = bannerRaw ? _urlImagem(bannerRaw) : null;
      if ((thumbnailRaw && !streamer.setup.thumbnail) || (bannerRaw && !streamer.setup.banner)) {
        await interaction.reply({ content: '⚠️ Use URLs públicas iniciadas por http:// ou https://.', flags: MessageFlags.Ephemeral });
        return true;
      }
    } else if (tipo === 'preco' || tipo === 'valor_publico' || tipo === 'valor') {
      const preco = _validarPreco(interaction.fields.getTextInputValue('valor'));
      if (preco === null) {
        await interaction.reply({ content: '⚠️ Informe um preço numérico válido.', flags: MessageFlags.Ephemeral });
        return true;
      }
      _sessao(guildId, interaction.user.id).preco = preco.toFixed(2);
      _precos.set(_precoKey(guildId, streamerId), preco);
      streamer.preco = preco;
    } else if (tipo === 'titulo') {
      streamer.setup.titulo = interaction.fields.getTextInputValue('valor').trim();
    } else if (tipo === 'descricao') {
      streamer.setup.descricao = interaction.fields.getTextInputValue('valor').trim();
    }
    _salvar();
    await _atualizarConfiguracaoPublica(streamer, guildId, client);
    if (contexto === 'public') {
      await interaction.reply({
        content: '✅ Informação da fila atualizada.',
        flags: MessageFlags.Ephemeral,
      });
    } else {
      await interaction.deferUpdate();
      await interaction.editReply(_painelCriarComGuild(guildId, streamerId, interaction.guild, interaction.user.id));
    }
    return true;
  }

  if (id.startsWith('streamer:enviar:')) {
    const streamerId = id.split(':')[2];
    const streamer = _streamer(guildId, streamerId);
    if (!_temAcesso(interaction, streamer)) {
      await interaction.reply({ content: '🔒 Você não possui acesso a esta configuração.', flags: MessageFlags.Ephemeral });
      return true;
    }
    const pendencias = _validarConfiguracaoFila(guildId, streamer);
    if (pendencias.length) {
      await interaction.reply({
        content: `⚠️ Configure a fila antes de publicar. Pendências: ${pendencias.join(', ')}.`,
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }
    await interaction.update(_painelEscolherCanal(guildId, streamerId));
    return true;
  }

  if (interaction.isChannelSelectMenu() && id.startsWith('streamer:canal:')) {
    const streamerId = id.split(':')[2];
    const streamer = _streamer(guildId, streamerId);
    if (!_temAcesso(interaction, streamer)) {
      await interaction.reply({ content: '🔒 Você não possui acesso a esta configuração.', flags: MessageFlags.Ephemeral });
      return true;
    }
    const pendencias = _validarConfiguracaoFila(guildId, streamer);
    if (pendencias.length) {
      await interaction.reply({
        content: `⚠️ A fila não pode ser publicada ainda. Pendências: ${pendencias.join(', ')}.`,
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }
    const canal = await interaction.guild.channels.fetch(interaction.values[0]).catch(() => null);
    if (!canal?.isTextBased?.()) {
      await interaction.reply({ content: '⚠️ Não foi possível acessar o canal selecionado.', flags: MessageFlags.Ephemeral });
      return true;
    }
    try {
      await _enviarPublico(streamer, guildId, canal, client);
    } catch (error) {
      console.error('[STREAMER] Falha ao enviar painel:', error.message);
      await interaction.reply({
        content: '❌ Não foi possível enviar o painel para o canal selecionado.',
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }
    await interaction.update(_painelCriarComGuild(guildId, streamerId, interaction.guild, interaction.user.id));
    return true;
  }

  if (id.startsWith('streamer:fila:')) {
    const [, , acao, streamerId] = id.split(':');
    const streamer = _streamer(guildId, streamerId);
    if (!streamer) return true;

    if (acao === 'historico') {
      if (!_ehResponsavel(interaction, streamer)) {
        await interaction.reply({ content: '🔒 Somente o streamer ou o mediador desta fila pode ver o histórico.', flags: MessageFlags.Ephemeral });
        return true;
      }
      await interaction.reply({
        ...painelV2FromEmbed(_historicoEmbed(streamer, interaction.guild), []),
        allowedMentions: _mentionUsers(streamer),
        flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
      });
      return true;
    }
    if (acao === 'informacoes') {
      if (interaction.user.id !== streamer.mediatorId) {
        await interaction.reply({
          content: '🔒 Somente o mediador responsável pode alterar as informações desta fila.',
          flags: MessageFlags.Ephemeral,
        });
        return true;
      }
      await interaction.deferReply({
        flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
      });
      await interaction.editReply(_painelInformacoes(guildId, streamerId, interaction.guild, 'public'));
      return true;
    }
    if (acao === 'valor') {
      if (interaction.user.id !== streamer.mediatorId) {
        await interaction.reply({
          content: '🔒 Somente o mediador responsável pode alterar o valor desta fila.',
          flags: MessageFlags.Ephemeral,
        });
        return true;
      }
      const modal = new ModalBuilder()
        .setCustomId(`streamer:modal:valor:${streamer.streamerId}:public`)
        .setTitle('Alterar valor da partida');
      const campo = new TextInputBuilder()
        .setCustomId('valor')
        .setLabel('Novo valor da partida')
        .setStyle(TextInputStyle.Short)
        .setPlaceholder('Ex: 10,00')
        .setRequired(true);
      const preco = _precoStreamer(guildId, streamer);
      if (preco !== null) campo.setValue(preco.toFixed(2).replace('.', ','));
      modal.addComponents(new ActionRowBuilder().addComponents(campo));
      await interaction.showModal(modal);
      return true;
    }
    if (acao === 'voltar') {
      await interaction.update({
        ...painelV2FromEmbed(_filaEmbed(streamer, interaction.guild), _filaRows(streamer)),
        allowedMentions: _mentionUsers(streamer),
      });
      return true;
    }
    if (acao === 'online') {
      if (!_ehResponsavel(interaction, streamer)) {
        await interaction.reply({ content: _msg(guildId, 'streamer_status_restrito', 'Somente o streamer ou o mediador desta fila pode alterar o status.'), flags: MessageFlags.Ephemeral });
        return true;
      }
      streamer.online = !streamer.online;
      _salvar();
      await interaction.update({
        ...painelV2FromEmbed(_filaEmbed(streamer, interaction.guild), _filaRows(streamer)),
        allowedMentions: _mentionUsers(streamer),
      });
      return true;
    }
    if (acao === 'entrar') {
      const { isUserBlacklisted } = require('./blacklist');
      const blCheck = isUserBlacklisted(guildId, interaction.user.id);
      if (blCheck.blacklisted) {
        await interaction.reply({
          content: _msg(guildId, 'fila_blacklist', 'Você está registrado na blacklist e não pode entrar em filas do servidor.'),
          flags: MessageFlags.Ephemeral,
        });
        return true;
      }

      if (interaction.user.id === streamer.streamerId) {
        await interaction.reply({ content: _msg(guildId, 'streamer_responsavel', 'O streamer é o responsável pela fila e não precisa entrar nela.'), flags: MessageFlags.Ephemeral });
        return true;
      }
      if (!streamer.online) {
        await interaction.reply({ content: _msg(guildId, 'streamer_offline', 'A fila está off-line no momento.'), flags: MessageFlags.Ephemeral });
        return true;
      }
      const pendencias = _validarConfiguracaoFila(guildId, streamer);
      if (pendencias.length) {
        await interaction.reply({
          content: `⚠️ Esta fila ainda não está liberada. O mediador precisa configurar: ${pendencias.join(', ')}.`,
          flags: MessageFlags.Ephemeral,
        });
        return true;
      }
      if (_partidaAtiva(guildId, streamer) && streamer.jogadores.length >= _limiteFila(guildId)) {
        await interaction.reply({
          content: _msg(guildId, 'streamer_cheia', `A partida atual está em andamento e a fila de espera já atingiu o limite de ${_limiteFila(guildId)} jogador(es).`),
          flags: MessageFlags.Ephemeral,
        });
        return true;
      }
      if (streamer.jogadores.some((j) => j.id === interaction.user.id)) {
        await interaction.reply({ content: _msg(guildId, 'streamer_ja_esta', 'Você já está nesta fila.'), flags: MessageFlags.Ephemeral });
        return true;
      }
      const limite = _limiteFila(guildId);
      if (_jogadoresDaFila(streamer).length >= limite) {
        await interaction.reply({ content: _msg(guildId, 'streamer_cheia', `A fila já atingiu o limite de ${limite} jogador(es) para o modo configurado.`), flags: MessageFlags.Ephemeral });
        return true;
      }
      streamer.jogadores.push({ id: interaction.user.id, data: new Date().toISOString() });
      _salvar();
      await interaction.update({
        ...painelV2FromEmbed(_filaEmbed(streamer, interaction.guild), _filaRows(streamer)),
        allowedMentions: _mentionUsers(streamer),
      });
      await interaction.followUp({ content: _msg(guildId, 'streamer_entrou', 'Você entrou na fila do streamer.'), flags: MessageFlags.Ephemeral });
      const resultado = await _criarPartidaStreamer(guildId, streamer, client);
      if (resultado && !resultado.ok) {
        await interaction.followUp({
          content: resultado.message,
          flags: MessageFlags.Ephemeral,
        });
      }
      return true;
    }
    if (acao === 'sair') {
      const antes = streamer.jogadores.length;
      streamer.jogadores = streamer.jogadores.filter((j) => j.id !== interaction.user.id);
      if (antes === streamer.jogadores.length) {
        await interaction.reply({ content: _msg(guildId, 'streamer_nao_esta', 'Você não está nesta fila.'), flags: MessageFlags.Ephemeral });
        return true;
      }
      _salvar();
      await interaction.update({
        ...painelV2FromEmbed(_filaEmbed(streamer, interaction.guild), _filaRows(streamer)),
        allowedMentions: _mentionUsers(streamer),
      });
      await interaction.followUp({ content: _msg(guildId, 'streamer_saiu', 'Você saiu da fila do streamer.'), flags: MessageFlags.Ephemeral });
      return true;
    }
  }

  if (id.startsWith('streamer:configurar:')) {
    const streamerId = id.split(':')[2];
    const streamer = _streamer(guildId, streamerId);
    if (!_temAcesso(interaction, streamer)) {
      await interaction.reply({ content: '🔒 Você não possui acesso a esta configuração.', flags: MessageFlags.Ephemeral });
      return true;
    }
    await interaction.update(_painelCriarComGuild(guildId, streamerId, interaction.guild, interaction.user.id));
    return true;
  }

  return false;
}

async function removerDaFilaStreamer(guildId, userId, client) {
  const guildData = _guild(guildId);
  let alterado = false;
  for (const streamer of Object.values(guildData.streamers)) {
    const antes = streamer.jogadores.length;
    streamer.jogadores = streamer.jogadores.filter((j) => j.id !== userId);
    if (streamer.jogadores.length !== antes) {
      alterado = true;
      await _refreshPublico(streamer, guildId, client);
    }
  }
  if (alterado) _salvar();
  return alterado;
}

function registrarPartidaStreamer(guildId, partida) {
  if (!partida?.streamerId) return;
  const streamer = _streamer(guildId, partida.streamerId);
  if (!streamer) return;
  const agora = new Date();
  const resultado = partida.resultado?.tipo || 'Partida encerrada';
  streamer.historico.push({
    id: partida.id,
    data: agora.toISOString().slice(0, 10),
    horario: agora.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
    jogadores: partida.jogadores.map((j) => j.id),
    resultado,
  });
  streamer.historico = streamer.historico.slice(-100);
  _salvar();
}

async function liberarPartidaStreamer(guildId, partidaId, client) {
  const streamerId = partidaId?.streamerId ?? null;
  const id = partidaId?.id ?? partidaId ?? null;
  if (!streamerId || !id) return;

  const streamer = _streamer(guildId, streamerId);
  if (!streamer) return;
  if (streamer.partidaAtivaId === id) streamer.partidaAtivaId = null;
  _salvar();
  await _refreshPublico(streamer, guildId, client).catch((error) => {
    console.error('[STREAMER] Falha ao atualizar fila após encerramento:', error.message);
  });
  await _criarPartidaStreamer(guildId, streamer, client).catch((error) => {
    console.error('[STREAMER] Falha ao puxar próximo jogador:', error.message);
  });
}

async function restaurarPaineisStreamer(client) {
  _iniciarAutoRefresh(client);
  for (const [guildId, guildData] of Object.entries(_dados)) {
    for (const streamer of Object.values(guildData.streamers ?? {})) {
      if (!streamer.painel?.msgId) continue;
      await _refreshPublico(streamer, guildId, client).catch((error) => {
        console.error('[STREAMER] Falha ao restaurar painel:', error.message);
      });
      if (!_partidaAtiva(guildId, streamer) && streamer.jogadores?.length) {
        await _criarPartidaStreamer(guildId, streamer, client).catch((error) => {
          console.error('[STREAMER] Falha ao formar fila pendente após reinício:', error.message);
        });
      }
    }
  }
}

module.exports = {
  handleFilaStreamer,
  registrarPartidaStreamer,
  liberarPartidaStreamer,
  restaurarPaineisStreamer,
  removerDaFilaStreamer,
};