'use strict';

const fs   = require('fs');
const path = require('path');
const {
  EmbedBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ChannelSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
  LabelBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ContainerBuilder,
  TextDisplayBuilder,
  MediaGalleryBuilder,
  MediaGalleryItemBuilder,
  SectionBuilder,
  ThumbnailBuilder,
  MessageFlags,
  ChannelType,
  PermissionFlagsBits,
} = require('discord.js');

const { painelV2FromEmbed, renovarUrlImagem } = require('./visual');
const { getConfig } = require('./configurar');
const { dataPath } = require('./data-path');

// ── Persistência ──────────────────────────────────────────────────────────────

const DATA_FILE = dataPath('avisos_data.json');

function readData() {
  try {
    return fs.existsSync(DATA_FILE) ? JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')) : {};
  } catch (e) {
    console.error('[AVISOS] Falha ao ler dados:', e.message);
    return {};
  }
}

const state = readData();

function saveData() {
  const tmp = `${DATA_FILE}.tmp`;
  try {
    fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
    fs.writeFileSync(tmp, JSON.stringify(state, null, 2), 'utf8');
    fs.renameSync(tmp, DATA_FILE);
  } catch (e) {
    console.error('[AVISOS] Falha ao salvar dados:', e.message);
  }
}

// ── Estado em memória ─────────────────────────────────────────────────────────

// guildId:userId -> { guildId, data: { titulo, descricao, banner, thumbnail, rodape, canais, intervalo }, editId }
const sessoes = new Map();

// guildId:avisoId -> NodeJS.Timeout
const timers = new Map();
const enviosEmAndamento = new Set();

// ── Helpers ───────────────────────────────────────────────────────────────────

function chaveSessao(guildId, userId) {
  return `${guildId}:${userId}`;
}

function chaveAvisoEstado(guildId, avisoId) {
  return `${guildId}:${avisoId}`;
}

function guildState(guildId) {
  if (!state[guildId]) state[guildId] = { avisos: [] };
  if (!Array.isArray(state[guildId].avisos)) state[guildId].avisos = [];
  for (const a of state[guildId].avisos) {
    if (!a.id) a.id = gerarId();
    if (!a.mensagens) a.mensagens = {};
    if (!Array.isArray(a.canais)) a.canais = [];
  }
  return state[guildId];
}

function embedColor(guildId) {
  return getConfig(guildId)?.embedColor ?? 0x5865f2;
}

function gerarId() {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
}

function chaveAviso(aviso) {
  return JSON.stringify({
    titulo: String(aviso?.titulo ?? '').trim(),
    descricao: String(aviso?.descricao ?? '').trim(),
    banner: String(aviso?.banner ?? '').trim(),
    thumbnail: String(aviso?.thumbnail ?? '').trim(),
    rodape: String(aviso?.rodape ?? '').trim(),
    canais: [...new Set(aviso?.canais ?? [])].sort(),
    intervalo: Number(aviso?.intervalo ?? 0),
  });
}

function limparAvisosDuplicados() {
  let removidos = 0;

  for (const data of Object.values(state)) {
    if (!Array.isArray(data?.avisos)) continue;

    const vistos = new Set();
    data.avisos = data.avisos.filter((aviso) => {
      if (!aviso || typeof aviso !== 'object') return false;
      if (!aviso.id) aviso.id = gerarId();
      const chave = chaveAviso(aviso);
      if (vistos.has(chave)) {
        removidos += 1;
        return false;
      }
      vistos.add(chave);
      return true;
    });
  }

  if (removidos > 0) {
    console.warn(`[AVISOS] ${removidos} aviso(s) duplicado(s) removido(s).`);
    saveData();
  }
}

function validUrl(value) {
  if (!value) return '';
  let str = String(value).trim();
  if (str.startsWith('<') && str.endsWith('>')) {
    str = str.slice(1, -1).trim();
  }
  try {
    const url = new URL(str);
    return ['http:', 'https:'].includes(url.protocol) ? url.toString() : '';
  } catch (_) { return ''; }
}

function draftVazio() {
  return { titulo: '', descricao: '', banner: '', thumbnail: '', rodape: '', canais: [], intervalo: null };
}

// ── Construção do aviso para envio no canal ───────────────────────────────────

function buildAvisoMessage(aviso, guildId) {
  const accent    = embedColor(guildId);
  const container = new ContainerBuilder().setAccentColor(accent);

  const titulo = String(aviso?.titulo || 'Aviso').trim();
  let texto = `## ${titulo}`;
  if (aviso?.descricao) texto += `\n\n${aviso.descricao}`;
  if (aviso?.rodape)   texto += `\n\n-# ${aviso.rodape}`;

  if (texto.length > 4000) {
    texto = texto.slice(0, 3995) + '...';
  }

  const thumbUrl = aviso?.thumbnail ? (typeof renovarUrlImagem === 'function' ? renovarUrlImagem(aviso.thumbnail) : aviso.thumbnail) : null;
  const bannerUrl = aviso?.banner ? (typeof renovarUrlImagem === 'function' ? renovarUrlImagem(aviso.banner) : aviso.banner) : null;

  if (thumbUrl) {
    container.addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(new TextDisplayBuilder().setContent(texto))
        .setThumbnailAccessory(new ThumbnailBuilder().setURL(thumbUrl))
    );
  } else {
    container.addTextDisplayComponents(new TextDisplayBuilder().setContent(texto));
  }

  if (bannerUrl) {
    container.addMediaGalleryComponents(
      new MediaGalleryBuilder().addItems(new MediaGalleryItemBuilder().setURL(bannerUrl))
    );
  }

  return { components: [container], flags: MessageFlags.IsComponentsV2 };
}

// ── Paineis de controle ───────────────────────────────────────────────────────

function painelPrincipal(guildId, notice = '') {
  const gs  = guildState(guildId);
  const cor = embedColor(guildId);

  const embed = new EmbedBuilder()
    .setColor(cor)
    .setTitle('GERENCIADOR DE AVISOS')
    .setDescription(
      'Gerencie os avisos automáticos do servidor. ' +
      'Os avisos são enviados nos canais configurados e reenviados automaticamente no intervalo definido.\n\n' +
      `**Avisos cadastrados:** ${gs.avisos.length}`
    );

  if (notice) embed.addFields({ name: 'Última ação', value: notice });

  return painelV2FromEmbed(embed, [
    new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId('avisos:opcao')
        .setPlaceholder('Selecione uma opção')
        .addOptions(
          {
            label: 'Criar Aviso',
            value: 'criar',
            description: 'Cadastrar e enviar um novo aviso automático',
          },
          {
            label: 'Remover Aviso',
            value: 'remover',
            description: 'Excluir um aviso automático cadastrado',
          },
          {
            label: 'Editar Avisos',
            value: 'editar',
            description: 'Alterar um aviso automático existente',
          },
        ),
    ),
  ]);
}

function painelRemover(guildId) {
  const gs  = guildState(guildId);
  const cor = embedColor(guildId);
  const rows = [];

  const embed = new EmbedBuilder()
    .setColor(cor)
    .setTitle('REMOVER AVISO')
    .setDescription(gs.avisos.length === 0
      ? 'Nenhum aviso cadastrado.'
      : 'Selecione o aviso que deseja remover no menu abaixo.'
    );

  if (gs.avisos.length > 0) {
    rows.push(
      new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
          .setCustomId('avisos:remover_select')
          .setPlaceholder('Selecione o aviso que deseja remover')
          .addOptions(gs.avisos.slice(0, 25).map((a, i) => ({
            label:       String(a.titulo || `Aviso ${i + 1}`).slice(0, 100) || 'Sem título',
            value:       a.id,
            description: String(a.descricao || `${a.canais?.length || 0} canais • ${a.intervalo ? `${a.intervalo} min` : 'Envio único'}`)
              .replace(/\n+/g, ' ')
              .slice(0, 100) || 'Sem descrição',
          })))
      )
    );
  }

  rows.push(
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('avisos:voltar').setLabel('Voltar').setStyle(ButtonStyle.Secondary)
    )
  );

  return painelV2FromEmbed(embed, rows);
}

function painelEditar(guildId) {
  const gs  = guildState(guildId);
  const cor = embedColor(guildId);
  const rows = [];

  const embed = new EmbedBuilder()
    .setColor(cor)
    .setTitle('EDITAR AVISO')
    .setDescription(gs.avisos.length === 0
      ? 'Nenhum aviso cadastrado.'
      : 'Selecione o aviso que deseja editar no menu abaixo.'
    );

  if (gs.avisos.length > 0) {
    rows.push(
      new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
          .setCustomId('avisos:editar_select')
          .setPlaceholder('Selecione o aviso que deseja editar')
          .addOptions(gs.avisos.slice(0, 25).map((a, i) => ({
            label:       String(a.titulo || `Aviso ${i + 1}`).slice(0, 100) || 'Sem título',
            value:       a.id,
            description: String(a.descricao || `${a.canais?.length || 0} canais • ${a.intervalo ? `${a.intervalo} min` : 'Envio único'}`)
              .replace(/\n+/g, ' ')
              .slice(0, 100) || 'Sem descrição',
          })))
      )
    );
  }

  rows.push(
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('avisos:voltar').setLabel('Voltar').setStyle(ButtonStyle.Secondary)
    )
  );

  return painelV2FromEmbed(embed, rows);
}

function painelConfigAviso(guildId, draft, notice = '') {
  const cor        = embedColor(guildId);
  const intervText = draft.intervalo ? `${draft.intervalo} minuto(s)` : 'Não definido (envio único)';
  const canaisText = draft.canais?.length
    ? draft.canais.map((id) => `<#${id}>`).join(', ')
    : 'Nenhum canal selecionado';

  let desc = 'Configure o envio do aviso antes de publicar. Canais são obrigatórios.';
  if (notice) desc = `${notice}\n\n${desc}`;

  const embed = new EmbedBuilder()
    .setColor(cor)
    .setTitle('CONFIGURAR ENVIO DO AVISO')
    .setDescription(desc)
    .addFields(
      { name: 'Aviso',                value: `**${String(draft.titulo ?? '').slice(0, 256) || 'Sem título'}**` },
      { name: 'Intervalo de Reenvio', value: intervText },
      { name: 'Canais de Envio',      value: canaisText },
    );

  return painelV2FromEmbed(embed, [
    new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId('avisos:config_opcao')
        .setPlaceholder('Escolha uma opção para configurar')
        .addOptions(
          { label: 'Intervalo de Reenvio', value: 'intervalo', description: 'Define o tempo de reenvio automático' },
          { label: 'Canais de Envio',      value: 'canais',    description: 'Seleciona os canais onde o aviso será enviado' },
        )
    ),
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('avisos:config_voltar').setLabel('Voltar').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('avisos:enviar').setLabel('Enviar').setStyle(ButtonStyle.Success),
    ),
  ]);
}

// ── Modais ────────────────────────────────────────────────────────────────────

function modalCanais(draft = {}) {
  const modal = new ModalBuilder()
    .setCustomId('avisos:modal_canais')
    .setTitle('Canais de Envio');

  const canais = [...new Set(draft.canais ?? [])].slice(0, 25);
  const selectCanais = new ChannelSelectMenuBuilder()
    .setCustomId('canais_select')
    .setPlaceholder('Selecione os canais onde o aviso será enviado')
    .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement)
    .setMinValues(1)
    .setMaxValues(25);

  if (canais.length) {
    selectCanais.setDefaultChannels(canais);
  }

  modal.addLabelComponents(
    new LabelBuilder()
      .setLabel('Canais de Envio')
      .setDescription('Selecione de 1 a 25 canais onde o aviso será enviado')
      .setChannelSelectMenuComponent(selectCanais),
  );
  return modal;
}

function modalTexto(draft = {}) {
  const modal = new ModalBuilder()
    .setCustomId('avisos:modal_texto')
    .setTitle('Criar / Editar Aviso');

  const titulo = new TextInputBuilder()
    .setCustomId('titulo').setLabel('Título')
    .setStyle(TextInputStyle.Short)
    .setMinLength(1).setMaxLength(256).setRequired(true)
    .setPlaceholder('Título do aviso');
  if (draft.titulo) titulo.setValue(draft.titulo);

  const descricao = new TextInputBuilder()
    .setCustomId('descricao').setLabel('Descrição')
    .setStyle(TextInputStyle.Paragraph)
    .setMaxLength(2000).setRequired(false)
    .setPlaceholder('Corpo do aviso (opcional)');
  if (draft.descricao) descricao.setValue(draft.descricao);

  const rodape = new TextInputBuilder()
    .setCustomId('rodape').setLabel('Rodapé')
    .setStyle(TextInputStyle.Short)
    .setMaxLength(256).setRequired(false)
    .setPlaceholder('Texto pequeno no rodapé (opcional)');
  if (draft.rodape) rodape.setValue(draft.rodape);

  const banner = new TextInputBuilder()
    .setCustomId('banner').setLabel('Banner — URL da imagem no aviso')
    .setStyle(TextInputStyle.Short).setRequired(false)
    .setPlaceholder('https://... (opcional — imagem exibida no final do aviso)');
  if (draft.banner) banner.setValue(draft.banner);

  const thumbnail = new TextInputBuilder()
    .setCustomId('thumbnail').setLabel('Thumbnail — URL da miniatura lateral')
    .setStyle(TextInputStyle.Short).setRequired(false)
    .setPlaceholder('https://... (opcional — miniatura ao lado do texto)');
  if (draft.thumbnail) thumbnail.setValue(draft.thumbnail);

  modal.addComponents(
    new ActionRowBuilder().addComponents(titulo),
    new ActionRowBuilder().addComponents(descricao),
    new ActionRowBuilder().addComponents(rodape),
    new ActionRowBuilder().addComponents(banner),
    new ActionRowBuilder().addComponents(thumbnail),
  );
  return modal;
}

function modalIntervalo(draft = {}) {
  const modal = new ModalBuilder()
    .setCustomId('avisos:modal_intervalo')
    .setTitle('Intervalo de Reenvio');

  const campo = new TextInputBuilder()
    .setCustomId('intervalo')
    .setLabel('Intervalo em minutos (0 = uma vez)')
    .setStyle(TextInputStyle.Short).setRequired(true)
    .setPlaceholder('Ex: 60 para reenviar a cada 1 hora. Digite 0 para envio único.');
  if (draft.intervalo != null) campo.setValue(String(draft.intervalo));

  modal.addComponents(new ActionRowBuilder().addComponents(campo));
  return modal;
}

// ── Envio e agendamento ───────────────────────────────────────────────────────

async function enviarAviso(client, aviso, guildId) {
  if (!aviso || !aviso.id) return;
  const estadoKey = chaveAvisoEstado(guildId, aviso.id);
  if (enviosEmAndamento.has(estadoKey)) return;
  enviosEmAndamento.add(estadoKey);

  try {
    if (!aviso.mensagens) aviso.mensagens = {};
    const msg = buildAvisoMessage(aviso, guildId);

    // 1. Limpa mensagens antigas em canais que foram removidos do aviso
    for (const oldChannelId of Object.keys(aviso.mensagens ?? {})) {
      if (!aviso.canais?.includes(oldChannelId)) {
        try {
          const oldChan = await client.channels.fetch(oldChannelId).catch(() => null);
          if (oldChan) {
            const oldMsgId = aviso.mensagens[oldChannelId];
            if (oldMsgId) {
              const oldMsg = await oldChan.messages.fetch(oldMsgId).catch(() => null);
              if (oldMsg) await oldMsg.delete().catch(() => {});
            }
          }
        } catch (_) {}
        delete aviso.mensagens[oldChannelId];
      }
    }

    // 2. Envia nos canais configurados
    for (const channelId of (aviso.canais ?? [])) {
      try {
        const channel = await client.channels.fetch(channelId).catch(() => null);
        if (!channel) continue;

        // Apaga mensagem anterior neste canal
        const oldId = aviso.mensagens[channelId];
        if (oldId) {
          const old = await channel.messages.fetch(oldId).catch(() => null);
          if (old) await old.delete().catch(() => {});
        }

        const sent = await channel.send(msg);
        aviso.mensagens[channelId] = sent.id;
      } catch (e) {
        console.error(`[AVISOS] Erro ao enviar no canal ${channelId}:`, e.message);
      }
    }

    aviso.ultimoEnvio = Date.now();
    saveData();
  } finally {
    enviosEmAndamento.delete(estadoKey);
  }
}

function agendarReenvio(client, aviso, guildId) {
  if (!aviso || !aviso.id) return;
  const estadoKey = chaveAvisoEstado(guildId, aviso.id);
  const old = timers.get(estadoKey);
  if (old) { clearTimeout(old); timers.delete(estadoKey); }

  const ms = (Number(aviso.intervalo) || 0) * 60 * 1000;
  if (ms <= 0) return;

  const agora  = Date.now();
  const ultimo = aviso.ultimoEnvio ?? agora;
  const delay  = Math.max(ultimo + ms - agora, 0);

  const t = setTimeout(async () => {
    timers.delete(estadoKey);
    await enviarAviso(client, aviso, guildId);
    agendarReenvio(client, aviso, guildId);
  }, delay);

  timers.set(estadoKey, t);
}

function restaurarAvisos(client) {
  limparAvisosDuplicados();

  for (const [guildId, data] of Object.entries(state)) {
    for (const aviso of (data.avisos ?? [])) {
      if (!aviso.id) aviso.id = gerarId();
      agendarReenvio(client, aviso, guildId);
    }
  }
  console.log('[AVISOS] Timers de reenvio restaurados.');
}

// ── Handler principal ─────────────────────────────────────────────────────────

async function handleAvisos(interaction, client) {
  const { customId } = interaction;
  const guildId      = interaction.guildId;
  if (!guildId) return false;

  const isCommand = interaction.isChatInputCommand() && interaction.commandName === 'avisos';
  const isComponent = customId?.startsWith('avisos:');
  if (!isCommand && !isComponent) return false;

  // Verificação de permissões administrativas
  const member = interaction.member;
  const isAdm = member?.permissions?.has?.(PermissionFlagsBits.Administrator)
    || member?.permissions?.has?.(PermissionFlagsBits.ManageGuild);
  if (!isAdm) {
    const resp = { content: 'Apenas administradores podem gerenciar os avisos automáticos.', flags: MessageFlags.Ephemeral };
    if (interaction.deferred || interaction.replied) {
      await interaction.editReply(resp).catch(() => {});
    } else {
      await interaction.reply(resp).catch(() => {});
    }
    return true;
  }

  // ── /avisos ────────────────────────────────────────────────────────────────
  if (isCommand) {
    await interaction.reply({ flags: MessageFlags.Ephemeral, ...painelPrincipal(guildId) });
    return true;
  }

  const key = customId.slice(7);

  // ── Select: Ações principais ─────────────────────────────────────────────
  if (interaction.isStringSelectMenu() && key === 'opcao') {
    const opcao = interaction.values[0];

    if (opcao === 'criar') {
      const draft = draftVazio();
      sessoes.set(chaveSessao(guildId, interaction.user.id), { guildId, data: draft, editId: null });
      await interaction.showModal(modalTexto(draft));
      return true;
    }

    if (opcao === 'remover') {
      await interaction.deferUpdate();
      await interaction.editReply({ ...painelRemover(guildId) });
      return true;
    }

    if (opcao === 'editar') {
      await interaction.deferUpdate();
      await interaction.editReply({ ...painelEditar(guildId) });
      return true;
    }
  }

  // ── Voltar ao painel principal ─────────────────────────────────────────────
  if (interaction.isButton() && key === 'voltar') {
    sessoes.delete(chaveSessao(guildId, interaction.user.id));
    await interaction.deferUpdate();
    await interaction.editReply({ ...painelPrincipal(guildId) });
    return true;
  }

  // ── Select: Remover aviso ─────────────────────────────────────────────────
  if (interaction.isStringSelectMenu() && key === 'remover_select') {
    const avisoId = interaction.values[0];
    const gs      = guildState(guildId);
    const idx     = gs.avisos.findIndex((a) => a.id === avisoId);

    if (idx === -1) {
      await interaction.deferUpdate();
      await interaction.editReply({ ...painelPrincipal(guildId, 'Aviso não encontrado.') });
      return true;
    }

    const removed = gs.avisos.splice(idx, 1)[0];
    const timerKey = chaveAvisoEstado(guildId, avisoId);
    const t       = timers.get(timerKey);
    if (t) { clearTimeout(t); timers.delete(timerKey); }
    saveData();

    // Limpa mensagens nos canais
    if (removed.mensagens) {
      for (const [chId, msgId] of Object.entries(removed.mensagens)) {
        try {
          const ch = await client.channels.fetch(chId).catch(() => null);
          if (ch && msgId) {
            const m = await ch.messages.fetch(msgId).catch(() => null);
            if (m) await m.delete().catch(() => {});
          }
        } catch (_) {}
      }
    }

    await interaction.deferUpdate();
    await interaction.editReply({ ...painelPrincipal(guildId, `Aviso **${removed.titulo}** removido com sucesso.`) });
    return true;
  }

  // ── Select: Editar — escolher aviso ───────────────────────────────────────
  if (interaction.isStringSelectMenu() && key === 'editar_select') {
    const avisoId = interaction.values[0];
    const gs      = guildState(guildId);
    const aviso   = gs.avisos.find((a) => a.id === avisoId);

    if (!aviso) {
      await interaction.deferUpdate();
      await interaction.editReply({ ...painelPrincipal(guildId, 'Aviso não encontrado.') });
      return true;
    }

    sessoes.set(chaveSessao(guildId, interaction.user.id), { guildId, data: { ...aviso }, editId: avisoId });
    await interaction.showModal(modalTexto(aviso));
    return true;
  }

  // ── Modal: Texto ──────────────────────────────────────────────────────────
  if (interaction.isModalSubmit() && key === 'modal_texto') {
    const sessao = sessoes.get(chaveSessao(guildId, interaction.user.id));
    if (!sessao) {
      await interaction.reply({ content: 'Sessão expirada. Use `/avisos` novamente.', flags: MessageFlags.Ephemeral });
      return true;
    }

    sessao.data.titulo    = interaction.fields.getTextInputValue('titulo').trim();
    sessao.data.descricao = interaction.fields.getTextInputValue('descricao').trim();
    sessao.data.rodape    = interaction.fields.getTextInputValue('rodape').trim();
    sessao.data.banner    = validUrl(interaction.fields.getTextInputValue('banner'));
    sessao.data.thumbnail = validUrl(interaction.fields.getTextInputValue('thumbnail'));

    await interaction.deferUpdate();
    await interaction.editReply({ ...painelConfigAviso(sessao.guildId, sessao.data) });
    return true;
  }

  // ── Select: Opção de configuração ────────────────────────────────────────
  if (interaction.isStringSelectMenu() && key === 'config_opcao') {
    const sessao = sessoes.get(chaveSessao(guildId, interaction.user.id));
    if (!sessao) {
      await interaction.deferUpdate();
      await interaction.editReply({ ...painelPrincipal(guildId) });
      return true;
    }

    const opcao = interaction.values[0];

    if (opcao === 'intervalo') {
      await interaction.showModal(modalIntervalo(sessao.data));
    } else if (opcao === 'canais') {
      await interaction.showModal(modalCanais(sessao.data));
    }
    return true;
  }

  // ── Modal: Intervalo ───────────────────────────────────────────────────────
  if (interaction.isModalSubmit() && key === 'modal_intervalo') {
    const sessao = sessoes.get(chaveSessao(guildId, interaction.user.id));
    if (!sessao) {
      await interaction.reply({ content: 'Sessão expirada. Use `/avisos` novamente.', flags: MessageFlags.Ephemeral });
      return true;
    }

    const valor           = parseInt(interaction.fields.getTextInputValue('intervalo'), 10);
    sessao.data.intervalo = isNaN(valor) || valor < 0 ? 0 : valor;

    await interaction.deferUpdate();
    await interaction.editReply({
      ...painelConfigAviso(
        sessao.guildId,
        sessao.data,
        `Intervalo definido para ${sessao.data.intervalo ? `${sessao.data.intervalo} minuto(s)` : 'Envio único (sem reenvio)'}.`
      ),
    });
    return true;
  }

  // ── Modal: Canais ─────────────────────────────────────────────────────────
  if (interaction.isModalSubmit() && key === 'modal_canais') {
    const sessao = sessoes.get(chaveSessao(guildId, interaction.user.id));
    if (!sessao) {
      await interaction.reply({ content: 'Sessão expirada. Use `/avisos` novamente.', flags: MessageFlags.Ephemeral });
      return true;
    }

    try {
      const canaisSelecionados = interaction.fields.getSelectedChannels('canais_select');
      const canaisIds = canaisSelecionados
        ? (typeof canaisSelecionados.keys === 'function' ? [...canaisSelecionados.keys()] : Object.keys(canaisSelecionados))
        : [];
      sessao.data.canais = [...new Set(canaisIds)];
    } catch (_) {
      sessao.data.canais = [];
    }

    await interaction.deferUpdate();
    await interaction.editReply({
      ...painelConfigAviso(
        sessao.guildId,
        sessao.data,
        sessao.data.canais.length
          ? `Canais definidos: ${sessao.data.canais.map((id) => `<#${id}>`).join(', ')}.`
          : 'Nenhum canal selecionado.'
      ),
    });
    return true;
  }

  // ── Botão: Voltar ao Painel Principal a partir da Configuração ────────────
  if (interaction.isButton() && key === 'config_voltar') {
    sessoes.delete(chaveSessao(guildId, interaction.user.id));
    await interaction.deferUpdate();
    await interaction.editReply({ ...painelPrincipal(guildId) });
    return true;
  }

  // ── Botão: Enviar ─────────────────────────────────────────────────────────
  if (interaction.isButton() && key === 'enviar') {
    const sessao = sessoes.get(chaveSessao(guildId, interaction.user.id));
    if (!sessao) {
      await interaction.deferUpdate();
      await interaction.editReply({ ...painelPrincipal(guildId) });
      return true;
    }

    if (!sessao.data.canais?.length) {
      await interaction.deferUpdate();
      await interaction.editReply({
        ...painelConfigAviso(sessao.guildId, sessao.data, 'Selecione pelo menos um canal antes de enviar.'),
      });
      return true;
    }

    const gs = guildState(sessao.guildId);

    if (sessao.editId) {
      // ── Editar aviso existente ─────────────────────────────────────────────
      const idx = gs.avisos.findIndex((a) => a.id === sessao.editId);
      if (idx !== -1) {
        const old = gs.avisos[idx];
        const timerKey = chaveAvisoEstado(sessao.guildId, old.id);
        const t   = timers.get(timerKey);
        if (t) { clearTimeout(t); timers.delete(timerKey); }

        gs.avisos[idx] = {
          ...old,
          ...sessao.data,
          id:        old.id,
          mensagens: old.mensagens ?? {},
        };

        saveData();
        await enviarAviso(client, gs.avisos[idx], sessao.guildId);
        agendarReenvio(client, gs.avisos[idx], sessao.guildId);
        sessoes.delete(chaveSessao(guildId, interaction.user.id));

        await interaction.deferUpdate();
        await interaction.editReply({
          ...painelPrincipal(sessao.guildId, `Aviso **${gs.avisos[idx].titulo}** editado e reenviado com sucesso.`),
        });
      } else {
        sessoes.delete(chaveSessao(guildId, interaction.user.id));
        await interaction.deferUpdate();
        await interaction.editReply({ ...painelPrincipal(sessao.guildId, 'Aviso não encontrado para edição.') });
      }
    } else {
      // ── Criar novo aviso ───────────────────────────────────────────────────
      const duplicado = gs.avisos.find((aviso) => chaveAviso(aviso) === chaveAviso(sessao.data));
      if (duplicado) {
        sessoes.delete(chaveSessao(guildId, interaction.user.id));
        await interaction.deferUpdate();
        await interaction.editReply({
          ...painelPrincipal(sessao.guildId, 'Já existe um aviso igual cadastrado neste servidor.'),
        });
        return true;
      }

      const novo = { id: gerarId(), ...sessao.data, mensagens: {} };
      gs.avisos.push(novo);
      saveData();

      await enviarAviso(client, novo, sessao.guildId);
      agendarReenvio(client, novo, sessao.guildId);
      sessoes.delete(chaveSessao(guildId, interaction.user.id));

      await interaction.deferUpdate();
      await interaction.editReply({
        ...painelPrincipal(sessao.guildId, `Aviso **${novo.titulo}** criado e enviado com sucesso.`),
      });
    }
    return true;
  }

  return false;
}

module.exports = { handleAvisos, restaurarAvisos };

