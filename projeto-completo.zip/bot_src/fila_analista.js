'use strict';

// ── Sistema de Fila de Analistas ──────────────────────────────────────────────

const fs   = require('fs');
const path = require('path');

const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  MessageFlags,
} = require('discord.js');
const { painelV2FromEmbed, avatarDoServidor } = require('./visual');
const { mensagem: _msg } = require('./avisos_mensagens');
const { dataPath } = require('./data-path');

// ── Constantes ────────────────────────────────────────────────────────────────

const DATA_FILE  = dataPath('analistas_data.json');
const PREFIX     = 'fan:';           // fan = fila analista
const COR_FILA   = 0xf1c40f;        // amarelo — fila com analistas
const MAX_HIST   = 25;              // maximo de registros exibidos no historico

// ── Armazenamento ─────────────────────────────────────────────────────────────

function _lerDados() {
  try {
    return fs.existsSync(DATA_FILE)
      ? JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'))
      : {};
  } catch (e) {
    console.error('[ANALISTA] Falha ao ler dados:', e.message);
    return {};
  }
}

const _dados = _lerDados();
const paineisConfigOrigem = new Map();

let _saving = false;
let _savePending = false;
function _salvar() {
  if (_saving) {
    _savePending = true;
    return;
  }
  _saving = true;
  const tmp = `${DATA_FILE}.tmp`;
  try {
    fs.writeFile(tmp, JSON.stringify(_dados, null, 2), 'utf8', (err) => {
      if (!err) {
        fs.rename(tmp, DATA_FILE, () => {
          _saving = false;
          if (_savePending) {
            _savePending = false;
            _salvar();
          }
        });
      } else {
        _saving = false;
      }
    });
  } catch (e) {
    _saving = false;
  }
}

/**
 * Estrutura de dados por guild:
 * {
 *   fila:        string[],          // userIds em ordem FIFO
 *   wo:          WoRecord[],        // historico global de W.O. aplicados
 *   panelMsgId:  string | null,
 *   panelChanId: string | null,
 * }
 *
 * WoRecord: { analistaId, vencedorId, partidaId, data, modo, tipo, valor }
 */
function _guild(guildId) {
  if (!_dados[guildId]) {
    _dados[guildId] = {
      fila: [],
      wo: [],
      panelMsgId: null,
      panelChanId: null,
      titulo: 'PAINEL DE FILA DE ANALISTAS',
      descricao: 'Entre na fila para atender partidas e registrar análises.',
      thumbnail: null,
      banner: null,
    };
  }
  const d = _dados[guildId];
  const defaults = {
    titulo: 'PAINEL DE FILA DE ANALISTAS',
    descricao: 'Entre na fila para atender partidas e registrar análises.',
    thumbnail: null,
    banner: null,
  };
  for (const [key, value] of Object.entries(defaults)) {
    if (!Object.prototype.hasOwnProperty.call(d, key)) d[key] = value;
  }
  if (!Array.isArray(d.fila)) d.fila = [];
  if (!Array.isArray(d.wo))   d.wo   = [];
  return d;
}

// ── Utilitarios ───────────────────────────────────────────────────────────────

function _corConfig(guildId) {
  try {
    return require('./configurar').getConfig(guildId)?.embedColor ?? 0x2f3136;
  } catch (_) {
    return 0x2f3136;
  }
}

/**
 * Cor do painel: amarelo quando ha analistas na fila, padrao quando vazia.
 */
function _corPainel(guildId) {
  return _guild(guildId).fila.length > 0 ? COR_FILA : _corConfig(guildId);
}

function _cargoAnalista(guildId) {
  try {
    return require('./configurar').getConfig(guildId)?.roles?.analista ?? null;
  } catch (_) {
    return null;
  }
}

async function _ehAnalista(interaction) {
  if (interaction.user.bot) return false;
  const roleId = _cargoAnalista(interaction.guildId);
  const membro = await interaction.guild?.members
    ?.fetch(interaction.user.id)
    .catch(() => interaction.member);
  if (!membro) return false;
  if (membro.permissions?.has?.('Administrator') || membro.permissions?.has?.('ManageGuild')) return true;
  if (!roleId) return true;
  return Boolean(membro?.roles?.cache?.has(roleId));
}

function _mencoes(guildId) {
  const d = _guild(guildId);
  const woUsers = d.wo.map((r) => r.analistaId);
  return {
    parse:       [],
    users:       [...new Set([...d.fila, ...woUsers])],
    repliedUser: false,
  };
}

/** Data no formato YYYY-MM-DD no fuso horario de Brasilia. */
function _hoje() {
  return new Date()
    .toLocaleDateString('pt-BR', { timeZone: 'America/Sao_Paulo' })
    .split('/')
    .reverse()
    .join('-');
}

/** Formata ISO string para data/hora legivel. */
function _formatar(iso) {
  try {
    return new Date(iso).toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' });
  } catch (_) {
    return iso ?? '?';
  }
}

// ── Embeds ────────────────────────────────────────────────────────────────────

function _principalEmbed(guildId, aviso = null, guild = null) {
  const d = _guild(guildId);

  const lista = d.fila.length
    ? d.fila.map((id) => `• <@${String(id).trim()}>`).join('\n')
    : 'Nenhum analista disponivel na fila no momento.';

  const embed = new EmbedBuilder()
    .setColor(_corPainel(guildId))
    .setTitle(d.titulo)
    .setDescription(d.descricao)
    .addFields({ name: `Disponiveis — ${d.fila.length}`, value: lista });

  if (aviso) embed.setDescription(aviso);
  if (d.thumbnail) embed.setThumbnail(d.thumbnail);
  if (d.banner) embed.setImage(d.banner);

  return embed;
}

function _rankingEmbed(guildId) {
  const d    = _guild(guildId);
  const hoje = _hoje();

  // Apenas W.O. registrados hoje
  const woHoje = d.wo.filter((r) => {
    try {
      const dataRec = new Date(r.data)
        .toLocaleDateString('pt-BR', { timeZone: 'America/Sao_Paulo' })
        .split('/')
        .reverse()
        .join('-');
      return dataRec === hoje;
    } catch (_) {
      return false;
    }
  });

  // Contagem por analista
  const contagem = {};
  for (const r of woHoje) {
    contagem[r.analistaId] = (contagem[r.analistaId] ?? 0) + 1;
  }

  const ranking = Object.entries(contagem).sort(([, a], [, b]) => b - a);

  const dataFormatada = hoje.split('-').reverse().join('/');

  const texto = ranking.length
    ? ranking
        .map(([id, total], i) => `${i + 1}. <@${id}> — ${total} W.O.`)
        .join('\n')
    : 'Nenhum W.O. registrado hoje.';

  const embed = new EmbedBuilder()
    .setColor(_corConfig(guildId))
    .setTitle('Ranking W.O. do Dia')
    .setDescription(`${dataFormatada}\n\n${texto}`);
  return embed;
}

function _historicoEmbed(guildId) {
  const d = _guild(guildId);

  if (!d.wo.length) {
    const embed = new EmbedBuilder()
      .setColor(_corConfig(guildId))
      .setTitle('Historico de W.O.')
      .setDescription('Nenhum W.O. registrado ainda.');
    return embed;
  }

  // Mais recentes primeiro, limitado a MAX_HIST
  const registros = [...d.wo].reverse().slice(0, MAX_HIST);
  const total     = d.wo.length;

  const linhas = registros.map((r, i) => {
    const data    = _formatar(r.data);
    const modo    = [r.modo, r.tipo].filter(Boolean).join(' ') || 'Partida';
    const valor   = r.valor != null ? ` • R$ ${Number(r.valor).toFixed(2).replace('.', ',')}` : '';
    return `**${i + 1}.** <@${r.analistaId}>\n${data} — ${modo}${valor}\nVencedor: <@${r.vencedorId}>`;
  });

  const rodape = total > MAX_HIST
    ? `\n\n— Exibindo os ultimos ${MAX_HIST} de ${total} registros.`
    : '';

  const embed = new EmbedBuilder()
    .setColor(_corConfig(guildId))
    .setTitle(`Historico de W.O. — ${total} registro(s)`)
    .setDescription(linhas.join('\n\n') + rodape);
  return embed;
}

// ── Botoes ────────────────────────────────────────────────────────────────────

function _principalBotoes() {
  return [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`${PREFIX}entrar`)
        .setLabel('Entrar na Fila')
        .setStyle(ButtonStyle.Success),       // verde
      new ButtonBuilder()
        .setCustomId(`${PREFIX}sair`)
        .setLabel('Sair da Fila')
        .setStyle(ButtonStyle.Danger),        // vermelho
      new ButtonBuilder()
        .setCustomId(`${PREFIX}ranking`)
        .setLabel('Ranking Analistas')
        .setStyle(ButtonStyle.Secondary),     // cinza
      new ButtonBuilder()
        .setCustomId(`${PREFIX}historico`)
        .setLabel('Ver Historico')
        .setStyle(ButtonStyle.Secondary),     // cinza
    ),
  ];
}

function _botoesVoltar() {
  return [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`${PREFIX}principal`)
        .setLabel('Voltar')
        .setStyle(ButtonStyle.Secondary),
    ),
  ];
}

// ── Helpers de painel ─────────────────────────────────────────────────────────

function _montarPainel(embed, botoes = [], ephemeral = false, guild = null, options = {}) {
  const data = typeof embed?.toJSON === 'function' ? embed.toJSON() : {};
  return {
    ...painelV2FromEmbed(embed, botoes, {
      thumbnail: options.thumbnail ?? data.thumbnail?.url ?? avatarDoServidor(guild),
      image: options.image ?? data.image?.url,
    }),
    flags: MessageFlags.IsComponentsV2 | (ephemeral ? MessageFlags.Ephemeral : 0),
  };
}

async function _atualizar(interaction, embed, botoes, guildId) {
  await interaction.update({
    ..._montarPainel(embed, botoes, false, interaction.guild),
    allowedMentions: _mencoes(guildId),
  });
}

function _textoConfiguracao(guildId) {
  const panel = _guild(guildId);
  return [
    `Título: **${panel.titulo || 'Não configurado'}**`,
    `Descrição: **${panel.descricao || 'Não configurada'}**`,
    `Thumbnail: **${panel.thumbnail ? 'Configurada' : 'Usando o ícone do servidor'}**`,
    `Banner: **${panel.banner ? 'Configurado' : 'Nenhum'}**`,
  ].join('\n');
}

function painelConfiguracaoFilaAnalista(guildId, notice = null, guild = null) {
  const panel = _guild(guildId);
  const embed = new EmbedBuilder()
    .setColor(_corConfig(guildId))
    .setTitle('CONFIGURAÇÃO DO PAINEL DE FILA DE ANALISTAS')
    .setDescription(
      'Configure a aparência do painel antes de publicá-lo no canal atual.\n\n' +
      _textoConfiguracao(guildId) +
      (notice ? `\n\n**Resultado da última ação**\n${notice}` : ''),
    );
  if (panel.thumbnail) embed.setThumbnail(panel.thumbnail);
  if (panel.banner) embed.setImage(panel.banner);

  return _montarPainel(
    embed,
    [
      new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
          .setCustomId(`${PREFIX}config:opcoes`)
          .setPlaceholder('Selecione o que deseja configurar')
          .addOptions(
            { label: 'Título', value: 'titulo', description: 'Alterar o título do painel público' },
            { label: 'Descrição', value: 'descricao', description: 'Alterar o texto do painel público' },
            { label: 'Thumbnail', value: 'thumbnail', description: 'Alterar ou remover a imagem pequena' },
            { label: 'Banner', value: 'banner', description: 'Alterar ou remover a imagem principal' },
          ),
      ),
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`${PREFIX}config:enviar`).setLabel('Enviar').setStyle(ButtonStyle.Success),
      ),
    ],
    true,
    guild,
    { thumbnail: panel.thumbnail || avatarDoServidor(guild), image: panel.banner },
  );
}

function modalConfiguracaoFilaAnalista(tipo, panel) {
  const campos = {
    titulo: {
      customId: `${PREFIX}config_modal:titulo`,
      title: 'Alterar título do painel',
      label: 'Título do painel',
      placeholder: 'PAINEL DE FILA DE ANALISTAS',
      maxLength: 256,
      value: panel.titulo,
    },
    descricao: {
      customId: `${PREFIX}config_modal:descricao`,
      title: 'Alterar descrição do painel',
      label: 'Descrição do painel',
      placeholder: 'Texto exibido no painel público',
      maxLength: 4000,
      value: panel.descricao,
    },
    thumbnail: {
      customId: `${PREFIX}config_modal:thumbnail`,
      title: 'Alterar thumbnail do painel',
      label: 'URL da thumbnail',
      placeholder: 'URL pública direta da imagem; vazio remove',
      maxLength: 1000,
      value: panel.thumbnail || '',
      required: false,
    },
    banner: {
      customId: `${PREFIX}config_modal:banner`,
      title: 'Alterar banner do painel',
      label: 'URL do banner',
      placeholder: 'URL pública direta da imagem; vazio remove',
      maxLength: 1000,
      value: panel.banner || '',
      required: false,
    },
  }[tipo];

  if (!campos) return null;
  const campo = new TextInputBuilder()
    .setCustomId('valor')
    .setLabel(campos.label)
    .setPlaceholder(campos.placeholder)
    .setStyle(tipo === 'descricao' ? TextInputStyle.Paragraph : TextInputStyle.Short)
    .setMaxLength(campos.maxLength)
    .setRequired(campos.required !== false);
  if (campos.value) campo.setValue(campos.value);

  return new ModalBuilder()
    .setCustomId(campos.customId)
    .setTitle(campos.title)
    .addComponents(new ActionRowBuilder().addComponents(campo));
}

// ── Acoes dos botoes ──────────────────────────────────────────────────────────

async function _entrar(interaction) {
  const guildId = interaction.guildId;
  const d       = _guild(guildId);

  if (!await _ehAnalista(interaction)) {
    await interaction.reply({
      content: _msg(guildId, 'analista_sem_cargo', 'Apenas usuários com o cargo Analista podem entrar na fila.'),
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  if (!d.fila.includes(interaction.user.id)) {
    d.fila.push(interaction.user.id);
    _salvar();
  }

  await _atualizar(interaction, _principalEmbed(guildId), _principalBotoes(), guildId);
  await interaction.followUp({ content: _msg(guildId, 'analista_entrou', 'Você entrou na fila de analistas.'), flags: MessageFlags.Ephemeral });
}

async function _sair(interaction) {
  const guildId = interaction.guildId;
  const d       = _guild(guildId);

  if (d.fila.includes(interaction.user.id)) {
    d.fila = d.fila.filter((uid) => uid !== interaction.user.id);
    _salvar();
  }

  await _atualizar(interaction, _principalEmbed(guildId), _principalBotoes(), guildId);
  await interaction.followUp({ content: _msg(guildId, 'analista_saiu', 'Você saiu da fila de analistas.'), flags: MessageFlags.Ephemeral });
}

// ── Handler principal ─────────────────────────────────────────────────────────

async function handleFilaAnalista(interaction, client) {
  const guildId = interaction.guildId;
  if (!guildId) return false;

  const isFilaAnalistaCmd = interaction.isChatInputCommand() && (
    interaction.commandName === 'fila_analista' ||
    (interaction.commandName === 'fila' && interaction.options.getSubcommand(false) === 'analista')
  );

  // ── Comando /fila analista ou /fila_analista ──────────────────────────────
  if (isFilaAnalistaCmd) {
    paineisConfigOrigem.set(`${guildId}:${interaction.user.id}`, interaction);
    await interaction.reply(painelConfiguracaoFilaAnalista(guildId, null, interaction.guild));
    return true;
  }

  const id = interaction.customId ?? '';
  if (!id.startsWith(PREFIX)) return false;

  if (interaction.isStringSelectMenu() && id === `${PREFIX}config:opcoes`) {
    const tipo = interaction.values[0];
    const modal = modalConfiguracaoFilaAnalista(tipo, _guild(guildId));
    if (modal) await interaction.showModal(modal);
    return true;
  }

  if (interaction.isButton() && id === `${PREFIX}config:enviar`) {
    await interaction.deferUpdate();
    const message = await publicarPainelFilaAnalista(interaction.guild, interaction.channel);
    paineisConfigOrigem.delete(`${guildId}:${interaction.user.id}`);
    await interaction.editReply(
      painelConfiguracaoFilaAnalista(
        guildId,
        message ? `Painel enviado em <#${message.channelId}>.` : 'Não foi possível enviar o painel.',
        interaction.guild,
      ),
    );
    return true;
  }

  if (interaction.isModalSubmit() && id.startsWith(`${PREFIX}config_modal:`)) {
    const tipo = id.split(':').pop();
    const panel = _guild(guildId);
    const valor = interaction.fields.getTextInputValue('valor').trim();
    if (tipo === 'titulo') panel.titulo = valor || 'PAINEL DE FILA DE ANALISTAS';
    if (tipo === 'descricao') panel.descricao = valor || 'Entre na fila para atender partidas e registrar análises.';
    if (tipo === 'thumbnail') panel.thumbnail = valor || null;
    if (tipo === 'banner') panel.banner = valor || null;
    _salvar();

    await interaction.deferReply({ flags: MessageFlags.Ephemeral });
    const origem = paineisConfigOrigem.get(`${guildId}:${interaction.user.id}`);
    if (origem) {
      try {
        await origem.editReply(painelConfiguracaoFilaAnalista(guildId, 'Configuração atualizada automaticamente.', interaction.guild));
      } catch (error) {
        console.error('[ANALISTA] Falha ao atualizar painel de configuração:', error.message);
      }
    }
    await interaction.editReply({ content: '✅ Configuração atualizada.' });
    return true;
  }

  if (!interaction.isButton()) return false;

  // ── Entrar na Fila ─────────────────────────────────────────────────────────
  if (id === `${PREFIX}entrar`) {
    await _entrar(interaction);
    return true;
  }

  // ── Sair da Fila ──────────────────────────────────────────────────────────
  if (id === `${PREFIX}sair`) {
    await _sair(interaction);
    return true;
  }

  // ── Ranking W.O. do Dia — resposta efêmera privada ───────────────────────
  if (id === `${PREFIX}ranking`) {
    await interaction.reply({
      ..._montarPainel(_rankingEmbed(guildId), [], true, interaction.guild),
      flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
    });
    return true;
  }

  // ── Historico global de W.O. — resposta efêmera privada ───────────────────
  if (id === `${PREFIX}historico`) {
    await interaction.reply({
      ..._montarPainel(_historicoEmbed(guildId), [], true, interaction.guild),
      flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
    });
    return true;
  }

  // ── Voltar ao painel principal ─────────────────────────────────────────────
  if (id === `${PREFIX}principal`) {
    await _atualizar(interaction, _principalEmbed(guildId), _principalBotoes(), guildId);
    return true;
  }

  return false;
}

// ── API interna (usada por fila_mediador / partida) ───────────────────────────

/**
 * Remove e retorna o proximo analista elegivel da fila.
 * Atualiza o painel publico automaticamente.
 */
async function pegarAnalistaDaFila(guildId, guild, client = null) {
  if (!guild) return null;
  const roleId = _cargoAnalista(guildId);
  const d = _guild(guildId);
  if (!Array.isArray(d.fila) || d.fila.length === 0) return null;

  const invalidIndexes = [];
  for (let index = 0; index < d.fila.length; index += 1) {
    const userId = d.fila[index];
    const member = await guild.members.fetch(userId).catch(() => null);

    // A failed fetch is inconclusive (transient API error); keep it for retry
    if (!member) {
      // If member couldn't be fetched but is in queue, allow as fallback
      d.fila.splice(index, 1);
      _salvar();
      if (client) atualizarPainelFilaAnalista(guildId, client).catch(() => {});
      return userId;
    }

    if (member.user.bot || (roleId && !member.roles.cache.has(roleId) && !member.permissions?.has?.('Administrator'))) {
      invalidIndexes.push(index);
      continue;
    }

    d.fila.splice(index, 1);
    _salvar();
    if (client) atualizarPainelFilaAnalista(guildId, client).catch(() => {});
    return userId;
  }

  // Limpar membros que não possuem mais permissão
  for (let index = invalidIndexes.length - 1; index >= 0; index -= 1) {
    d.fila.splice(invalidIndexes[index], 1);
  }

  // Se restou algum na fila, remove e retorna
  if (d.fila.length > 0) {
    const fallbackId = d.fila.shift();
    _salvar();
    if (client) atualizarPainelFilaAnalista(guildId, client).catch(() => {});
    return fallbackId;
  }

  _salvar();
  if (client) atualizarPainelFilaAnalista(guildId, client).catch(() => {});
  return null;
}

/**
 * Edita o painel publico existente com o estado atual da fila.
 * Chamado apos mudancas externas (ex.: analista removido por uma partida).
 */
async function atualizarPainelFilaAnalista(guildId, client) {
  const d = _guild(guildId);
  if (!d.panelMsgId || !d.panelChanId) return false;

  const channel = await client.channels.fetch(d.panelChanId).catch(() => null);
  const message = channel?.messages
    ? await channel.messages.fetch(d.panelMsgId).catch(() => null)
    : null;

  if (!message) {
    d.panelMsgId  = null;
    d.panelChanId = null;
    _salvar();
    return false;
  }

  await message.edit({
    ..._montarPainel(_principalEmbed(guildId, null, channel.guild), _principalBotoes(), false, channel.guild, {
      thumbnail: d.thumbnail || avatarDoServidor(channel.guild),
      image: d.banner,
    }),
    allowedMentions: _mencoes(guildId),
  });
  return true;
}

async function publicarPainelFilaAnalista(guild, channel) {
  const guildId = guild.id;
  const d = _guild(guildId);
  if (d.panelChanId && d.panelChanId !== channel.id && d.panelMsgId) {
    const canalAnterior = await guild.client?.channels.fetch(d.panelChanId).catch(() => null);
    const mensagemAnterior = await canalAnterior?.messages.fetch(d.panelMsgId).catch(() => null);
    if (mensagemAnterior?.author?.id === guild.client?.user?.id) {
      await mensagemAnterior.delete().catch(() => {});
      console.log(`[ANALISTA] Painel antigo removido de #${canalAnterior.name} antes da migração.`);
    }
  }
  const payload = {
    ..._montarPainel(_principalEmbed(guildId, null, guild), _principalBotoes(), false, guild, {
      thumbnail: d.thumbnail || avatarDoServidor(guild),
      image: d.banner,
    }),
    allowedMentions: _mencoes(guildId),
  };

  let message = null;
  if (d.panelChanId === channel.id && d.panelMsgId) {
    message = await channel.messages.fetch(d.panelMsgId).catch(() => null);
  }
  if (message) await message.edit(payload);
  else message = await channel.send(payload);

  d.panelMsgId = message.id;
  d.panelChanId = channel.id;
  _salvar();
  return message;
}

async function removerDaFilaAnalista(guildId, userId, client) {
  const d = _guild(guildId);
  const antes = d.fila.length;
  d.fila = d.fila.filter((uid) => uid !== userId);
  if (d.fila.length === antes) return false;
  _salvar();
  if (client) await atualizarPainelFilaAnalista(guildId, client);
  return true;
}

/**
 * Registra um W.O. aplicado pelo analista.
 * Chamado ao fechar uma partida em partida.js.
 * So registra quando o resultado for "Vitoria por W.O".
 */
function registrarAnalise(guildId, partida) {
  if (!partida?.analistaId) return;
  if (partida.resultado?.tipo !== 'Vitória por W.O') return;

  const d = _guild(guildId);

  // Evita duplicatas
  if (d.wo.some((r) => r.partidaId === partida.id)) return;

  d.wo.push({
    analistaId: partida.analistaId,
    vencedorId: partida.resultado?.vencedorId ?? null,
    partidaId:  partida.id,
    data:       new Date().toISOString(),
    modo:       partida.modo  ?? null,
    tipo:       partida.tipo  ?? null,
    valor:      partida.valor ?? null,
  });
  _salvar();
}

/**
 * Restaura o painel publico de todas as guilds apos reinicializacao.
 */
async function restaurarPainelFilaAnalista(client) {
  for (const guildId of Object.keys(_dados)) {
    await atualizarPainelFilaAnalista(guildId, client).catch((e) => {
      console.error('[ANALISTA] Falha ao restaurar painel:', e.message);
    });
  }
}

module.exports = {
  handleFilaAnalista,
  publicarPainelFilaAnalista,
  atualizarPainelFilaAnalista,
  pegarAnalistaDaFila,
  registrarAnalise,
  restaurarPainelFilaAnalista,
  removerDaFilaAnalista,
};
