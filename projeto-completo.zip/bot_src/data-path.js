'use strict';

const path = require('path');

const DEFAULT_DATA_DIR = path.join(__dirname, '..', 'data');

function dataPath(fileName) {
  const root = process.env.BOT_DATA_DIR || DEFAULT_DATA_DIR;
  return path.join(root, fileName);
}

module.exports = { dataPath, DEFAULT_DATA_DIR };