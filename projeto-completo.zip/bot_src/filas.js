'use strict';

// ── Sistema de Filas Free Fire ─────────────────────────────────────────────────

const fs   = require('fs');
const path = require('path');

const {
  EmbedBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ChannelType,
  MessageFlags,
  PermissionFlagsBits,
} = require('discord.js');
const { painelV2FromEmbed } = require('./visual');
const { mensagem: _msg } = require('./avisos_mensagens');
const { dataPath } = require('./data-path');

// ── Armazenamento ─────────────────────────────────────────────────────────────

const DATA_FILE = dataPath('filas_data.json');

function _lerDados() {
  try {
    if (fs.existsSync(DATA_FILE)) return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
  } catch (e) { console.error('[FILAS] Falha ao ler dados:', e.message); }
  return {};
}

let _saving = false;
let _savePending = false;
function _salvarDados(dados) {
  if (_saving) {
    _savePending = true;
    return;
  }
  _saving = true;
  const tmp = DATA_FILE + '.tmp';
  try {
    fs.writeFile(tmp, JSON.stringify(dados, null, 2), 'utf8', (err) => {
      if (!err) {
        fs.rename(tmp, DATA_FILE, () => {
          _saving = false;
          if (_savePending) {
            _savePending = false;
            _salvarDados(_dados);
          }
        });
      } else {
        _saving = false;
      }
    });
  } catch (e) {
    _saving = false;
  }
}

const _dados = _lerDados();

function _guild(guildId) {
  if (!_dados[guildId]) {
    _dados[guildId] = {
      setup: {
        tipo: 'Mobile',
        modo: '2x2',
        titulo: 'Filas Free Fire',
        valores: [],
        banner: null,
        thumbnail: null,
      },
      paineis: [],
    };
  }
  return _dados[guildId];
}

function _salvar() { _salvarDados(_dados); }

// ── Constantes ────────────────────────────────────────────────────────────────

// Todas as filas formam uma partida com exatamente 2 jogadores,
// independentemente do modo ou do tipo selecionado no painel.
const VAGAS_POR_MODO = { '1x1': 2, '2x2': 2, '3x3': 2, '4x4': 2 };

function _valorCents(v) { return Math.round(v * 100); }
function _valorStr(v)   { return `R$ ${v.toFixed(2)}`; }

function _labelSubtipo(sub) {
  const mapa = {
    entrar:        'Fila',
    gelo_normal:   'Gelo Normal',
    gelo_infinito: 'Gelo Infinito',
    emu1:          '1 EMU',
    emu2:          '2 EMU',
    emu3:          '3 EMU',
  };
  return mapa[sub] ?? sub;
}

// ── Cor da embed ──────────────────────────────────────────────────────────────

function _cor(guildId) {
  try {
    const { getConfig } = require('./configurar');
    return getConfig(guildId)?.embedColor ?? 0x2f3136;
  } catch (_) { return 0x2f3136; }
}

// ─────────────────────────────────────────────────────────────────────────────
// PAINEL DE CONFIGURAÇÃO (/filas — ephemeral, admin)
// ─────────────────────────────────────────────────────────────────────────────

function _buildConfigEmbed(guildId, notice = null) {
  const g = _guild(guildId);
  const s = g.setup;

  const linhas = [
    `Tipo: **${s.tipo}**`,
    `Modo: **${s.modo}**`,
    `Titulo: **${s.titulo}**`,
    `Valores: **${s.valores.length === 0 ? 'Nenhum' : s.valores.map(_valorStr).join(', ')}**`,
    `Banner: **${s.banner ? 'Configurado' : 'Nenhum'}**`,
    `Thumbnail: **${s.thumbnail ? 'Configurada' : 'Nenhuma'}**`,
    `Coins por vitória: **${_coinsConfig(guildId).winner}**`,
    `Coins por derrota: **${_coinsConfig(guildId).loser}**`,
  ];

  return new EmbedBuilder()
    .setTitle('CONFIGURAÇÃO DE FILAS')
    .setColor(_cor(guildId))
    .setDescription(
      'Monte a estrutura das filas e publique os painéis no canal atual.\n\n' +
      (notice ? `**Identificação do canal**\n${notice}\n\n` : '') +
      linhas.join('\n'),
    );
}

function _buildConfigRows(tipo) {
  const modoOpcoes = [
    { label: '1x1', value: '1x1', description: 'Individual' },
    { label: '2x2', value: '2x2', description: 'Duplas' },
    { label: '3x3', value: '3x3', description: 'Trios' },
    { label: '4x4', value: '4x4', description: 'Quartetos' },
  ].filter(o => !(tipo === 'Misto' && o.value === '1x1'));

  const selTipo = new StringSelectMenuBuilder()
    .setCustomId('filas:tipo')
    .setPlaceholder('Selecione o Tipo')
    .addOptions(
      { label: 'Mobile',   value: 'Mobile',   description: 'Partidas Mobile' },
      { label: 'Emulador', value: 'Emulador', description: 'Partidas Emulador' },
      { label: 'Misto',    value: 'Misto',    description: 'Partidas Misto (1x1 indisponivel)' },
    );

  const selModo = new StringSelectMenuBuilder()
    .setCustomId('filas:modo')
    .setPlaceholder('Selecione o Modo')
    .addOptions(modoOpcoes);

  const rowBotoes1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('filas:titulo').setLabel('Titulo').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('filas:valores').setLabel('Valores').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('filas:banner').setLabel('Banner').setStyle(ButtonStyle.Secondary),
  );
  const rowBotoes2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('filas:thumbnail').setLabel('Thumbnail').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('filas:coins').setLabel('Coins').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('filas:enviar').setLabel('Enviar Filas').setStyle(ButtonStyle.Success),
  );

  return [
    new ActionRowBuilder().addComponents(selTipo),
    new ActionRowBuilder().addComponents(selModo),
    rowBotoes1,
    rowBotoes2,
  ];
}

function _coinsConfig(guildId) {
  try {
    return require('./configurar').getConfig(guildId).coins ?? { winner: 0, loser: 0 };
  } catch (_) {
    return { winner: 0, loser: 0 };
  }
}

function buildConfigPanel(guildId, notice = null) {
  return {
    ...painelV2FromEmbed(
      _buildConfigEmbed(guildId, notice),
      _buildConfigRows(_guild(guildId).setup.tipo),
    ),
    flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
  };
}

function _normalizarCredenciais(texto) {
  return String(texto ?? '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[_./\\|]+/g, ' ')
    .replace(/-/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function _extrairCredenciais(texto) {
  const normalizado = _normalizarCredenciais(texto);
  const compacto = normalizado.replace(/\s+/g, '');
  const modos = new Set();
  const tipos = new Set();

  const adicionarModo = (modo) => modos.add(modo);
  const adicionarTipo = (tipo) => tipos.add(tipo);

  // Formatos aceitos: 1x1, 1v1, 1 vs 1, 1-v-1, além dos nomes comuns.
  if (/(?:^|[^0-9])1\s*(?:x|v|vs)\s*1(?:$|[^0-9])/.test(normalizado)
    || /(?:^|\s)(?:solo|individual)(?:$|\s)/.test(normalizado)
    || /(?:^|\s)x1(?:$|\s)/.test(normalizado)) adicionarModo('1x1');
  if (/(?:^|[^0-9])2\s*(?:x|v|vs)\s*2(?:$|[^0-9])/.test(normalizado)
    || /(?:^|\s)(?:duo|dupla|duplas)(?:$|\s)/.test(normalizado)) adicionarModo('2x2');
  if (/(?:^|[^0-9])3\s*(?:x|v|vs)\s*3(?:$|[^0-9])/.test(normalizado)
    || /(?:^|\s)(?:trio|trios)(?:$|\s)/.test(normalizado)) adicionarModo('3x3');
  if (/(?:^|[^0-9])4\s*(?:x|v|vs)\s*4(?:$|[^0-9])/.test(normalizado)
    || /(?:^|\s)(?:squad|quarteto|quartetos)(?:$|\s)/.test(normalizado)) adicionarModo('4x4');

  const temMobile = /\b(?:mobile|celular|telefone|phone|android|ios)\b/.test(normalizado);
  const temEmulador = /\b(?:emu|emulador|emulator|pc|computador|desktop)\b/.test(normalizado);
  const temMisto = /\b(?:misto|mixed|hibrido|hibrida|hibrido)\b/.test(normalizado)
    || /(?:mobile|celular|phone|android|ios)\s*(?:\+|e|and|\/)\s*(?:emu|emulador|emulator|pc|computador|desktop)/.test(normalizado)
    || /(?:emu|emulador|emulator|pc|computador|desktop)\s*(?:\+|e|and|\/)\s*(?:mobile|celular|phone|android|ios)/.test(normalizado);

  if (temMisto || (temMobile && temEmulador)) adicionarTipo('Misto');
  else {
    if (temMobile) adicionarTipo('Mobile');
    if (temEmulador) adicionarTipo('Emulador');
  }

  return {
    modo: modos.size === 1 ? [...modos][0] : null,
    tipo: tipos.size === 1 ? [...tipos][0] : null,
    conflitoModo: modos.size > 1,
    conflitoTipo: tipos.size > 1,
    texto: normalizado,
  };
}

function identificarCredenciaisCanal(channel, guildId = null) {
  // Ignora se for o canal configurado para fila de streamers
  if (guildId) {
    try {
      const { getConfig } = require('./configurar');
      const cfg = getConfig(guildId);
      if (cfg?.channels?.filaStreamer && cfg.channels.filaStreamer === channel?.id) {
        return {
          modo: null,
          tipo: null,
          conflitoModo: false,
          conflitoTipo: false,
          reconhecido: false,
          alteracoes: [],
          mensagem: null,
        };
      }
    } catch (_) {}
  }

  // Não lê channel.topic para evitar que tópicos de streamers ou descrições misturem as configs
  const partes = [
    channel?.name,
    channel?.parent?.name,
  ].filter(Boolean);
  const encontrado = _extrairCredenciais(partes.join(' '));
  const alteracoes = [];
  const temConflito = encontrado.conflitoModo || encontrado.conflitoTipo;

  if (!encontrado.conflitoModo && encontrado.modo) alteracoes.push(`modo **${encontrado.modo}**`);
  if (!encontrado.conflitoTipo && encontrado.tipo) alteracoes.push(`tipo **${encontrado.tipo}**`);

  return {
    ...encontrado,
    reconhecido: !temConflito && alteracoes.length > 0,
    alteracoes,
    mensagem: alteracoes.length > 0
      && !temConflito
      ? `Credenciais reconhecidas: ${alteracoes.join(' e ')}.`
      : null,
  };
}

function adaptarConfiguracaoAoCanal(guildId, channel) {
  const encontrado = identificarCredenciaisCanal(channel, guildId);
  if (!encontrado.reconhecido) return encontrado;

  const setup = _guild(guildId).setup;
  if (encontrado.modo && !encontrado.conflitoModo) setup.modo = encontrado.modo;
  if (encontrado.tipo && !encontrado.conflitoTipo) setup.tipo = encontrado.tipo;
  if (setup.tipo === 'Misto' && setup.modo === '1x1') {
    setup.modo = '2x2';
    encontrado.alteracoes.push('modo ajustado para **2x2** porque Misto não permite 1x1');
  }
  _salvar();
  return encontrado;
}

function _snapshotConfiguracao(setup) {
  return {
    tipo: setup?.tipo || 'Mobile',
    modo: setup?.modo || '2x2',
    titulo: setup?.titulo || 'Filas Free Fire',
    banner: setup?.banner || null,
    thumbnail: setup?.thumbnail || null,
  };
}

function _configuracaoDoPainel(painel, setupFallback) {
  if (painel?.configuracao && typeof painel.configuracao === 'object' && painel.configuracao.tipo && painel.configuracao.modo) {
    return {
      tipo: painel.configuracao.tipo,
      modo: painel.configuracao.modo,
      titulo: painel.configuracao.titulo || setupFallback?.titulo || 'Filas Free Fire',
      banner: painel.configuracao.banner !== undefined ? painel.configuracao.banner : (setupFallback?.banner || null),
      thumbnail: painel.configuracao.thumbnail !== undefined ? painel.configuracao.thumbnail : (setupFallback?.thumbnail || null),
    };
  }
  return _snapshotConfiguracao(setupFallback);
}

// ─────────────────────────────────────────────────────────────────────────────
// PAINEL DE FILA (mensagem pública no canal)
// ─────────────────────────────────────────────────────────────────────────────

function _buildFilaEmbed(painel, setup, guildId, guild = null) {
  const configuracao = _configuracaoDoPainel(painel, setup);
  const { tipo, modo, titulo, banner, thumbnail } = configuracao;
  const vagas    = VAGAS_POR_MODO[modo] ?? 2;
  const ocupadas = (painel.jogadores || []).length;

  const embed = new EmbedBuilder()
    .setTitle(titulo || `${modo} | ${tipo}`)
    .setColor(_cor(guildId))
    .addFields(
      { name: 'Formato', value: `${modo} ${tipo}`, inline: false },
      { name: 'Preço', value: _valorStr(painel.valor), inline: false },
    );

  // A lista de jogadores: exibida apenas se houver pelo menos 1 jogador na fila
  if (ocupadas > 0) {
    const listaTexto = painel.jogadores
      .map((j) => {
        const id = String(j.id || '').trim();
        const tipoTexto = j.subtipo && j.subtipo !== 'entrar'
          ? ` | ${_labelSubtipo(j.subtipo)}`
          : '';
        return `• <@${id}>${tipoTexto}`;
      })
      .join('\n');
    embed.addFields({
      name: `Jogadores • ${ocupadas}/${vagas}`,
      value: listaTexto || 'Nenhum jogador',
      inline: false,
    });
  }

  const thumbnailUrl = _urlImagem(thumbnail);
  const bannerUrl = _urlImagem(banner);
  // A thumbnail ocupa o espaço quadrado do cartão. O banner continua sendo
  // exibido separadamente quando os dois foram configurados.
  if (thumbnailUrl || bannerUrl) embed.setThumbnail(thumbnailUrl || bannerUrl);
  if (bannerUrl && thumbnailUrl) embed.setImage(bannerUrl);

  return embed;
}

function _buildFilaRows(guildId, tipo, modo, valorCents) {
  const rows = [];

  if (modo === '1x1') {
    rows.push(new ActionRowBuilder().addComponents(
      _botaoFila(guildId, 'gelo_normal', `fq:in:${valorCents}:gelo_normal`, 'Gelo Normal', ButtonStyle.Primary),
      _botaoFila(guildId, 'gelo_infinito', `fq:in:${valorCents}:gelo_infinito`, 'Gelo Infinito', ButtonStyle.Primary),
      _botaoFila(guildId, 'sair', `fq:out:${valorCents}`, 'Sair da Fila', ButtonStyle.Danger),
    ));
  } else if (tipo === 'Misto') {
    const btns = [];
    if (modo === '2x2') {
      btns.push(_botaoFila(guildId, 'emu_1', `fq:in:${valorCents}:emu1`, '1 EMU', ButtonStyle.Primary));
    } else if (modo === '3x3') {
      btns.push(_botaoFila(guildId, 'emu_1', `fq:in:${valorCents}:emu1`, '1 EMU', ButtonStyle.Primary));
      btns.push(_botaoFila(guildId, 'emu_2', `fq:in:${valorCents}:emu2`, '2 EMU', ButtonStyle.Primary));
    } else if (modo === '4x4') {
      btns.push(_botaoFila(guildId, 'emu_1', `fq:in:${valorCents}:emu1`, '1 EMU', ButtonStyle.Primary));
      btns.push(_botaoFila(guildId, 'emu_2', `fq:in:${valorCents}:emu2`, '2 EMU', ButtonStyle.Primary));
      btns.push(_botaoFila(guildId, 'emu_3', `fq:in:${valorCents}:emu3`, '3 EMU', ButtonStyle.Primary));
    }
    btns.push(_botaoFila(guildId, 'sair', `fq:out:${valorCents}`, 'Sair da Fila', ButtonStyle.Danger));
    rows.push(new ActionRowBuilder().addComponents(...btns));
  } else {
    rows.push(new ActionRowBuilder().addComponents(
      _botaoFila(guildId, 'entrar_fila', `fq:in:${valorCents}:entrar`, 'Entrar na Fila', ButtonStyle.Primary),
      _botaoFila(guildId, 'sair', `fq:out:${valorCents}`, 'Sair da Fila', ButtonStyle.Danger),
    ));
  }

  return rows;
}

function _botaoFila(guildId, tipo, customId, label, estiloPadrao) {
  return new ButtonBuilder()
    .setCustomId(customId)
    .setLabel(label)
    .setStyle(estiloPadrao);
}

function _buildFilaAviso(titulo, mensagem, cor = 0x5865f2) {
  return new EmbedBuilder()
    .setTitle(titulo)
    .setDescription(mensagem)
    .setColor(cor);
}

function _urlImagem(valor) {
  const url = String(valor ?? '').trim();
  if (!url) return null;
  try {
    const parsed = new URL(url);
    return ['http:', 'https:'].includes(parsed.protocol) ? url : null;
  } catch (_) {
    return null;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// AUTO-REFRESH
// ─────────────────────────────────────────────────────────────────────────────

async function _refreshPainel(painel, setup, guildId, client, mensagemClicada = null) {
  const configuracao = _configuracaoDoPainel(painel, setup);
  const vc = _valorCents(painel.valor);
  const guildObj = client.guilds.cache.get(guildId) || null;
  const embed = _buildFilaEmbed(painel, configuracao, guildId, guildObj);
  const rows = _buildFilaRows(guildId, configuracao.tipo, configuracao.modo, vc);
  const cleanUsers = (painel.jogadores || []).map((j) => String(j.id || '').trim()).filter((id) => /^\d{16,22}$/.test(id));
  const payload = {
    ...painelV2FromEmbed(embed, rows),
    allowedMentions: { users: [...new Set(cleanUsers)] },
  };

  // Quando a atualização vem de um clique, edita diretamente a mensagem existente sem requisições adicionais
  if (mensagemClicada?.id === painel.msgId && typeof mensagemClicada.edit === 'function') {
    try {
      await mensagemClicada.edit(payload);
      return true;
    } catch (e) {
      if (e?.code === 10008) {
        const g = _guild(guildId);
        g.paineis = (g.paineis || []).filter((p) => p !== painel && p.msgId !== painel.msgId);
        _salvar();
        return false;
      }
    }
  }

  try {
    const canal = client.channels.cache.get(painel.chanId) || await client.channels.fetch(painel.chanId).catch(() => null);
    if (!canal) return false;
    const msg = canal.messages?.cache?.get(painel.msgId) || (canal.messages ? await canal.messages.fetch(painel.msgId).catch(() => null) : null);
    if (msg && typeof msg.edit === 'function') {
      await msg.edit(payload);
      return true;
    }
  } catch (e) {
    if (e?.code === 10008 || e?.code === 10003) {
      const g = _guild(guildId);
      g.paineis = (g.paineis || []).filter((p) => p !== painel && p.msgId !== painel.msgId);
      _salvar();
      return false;
    }
    console.error(`[FILAS] Falha ao editar painel ${painel.msgId}:`, e.message);
  }

  return false;
}

// ─────────────────────────────────────────────────────────────────────────────
// ENVIAR PAINEIS (um por valor, isolado por canal)
// ─────────────────────────────────────────────────────────────────────────────

async function _enviarPaineis(guildId, canal, client) {
  const g = _guild(guildId);
  if (!Array.isArray(g.paineis)) g.paineis = [];

  const snapshotAtual = _snapshotConfiguracao(g.setup);

  for (const valor of g.setup.valores) {
    const vc = _valorCents(valor);
    const configuracao = { ...snapshotAtual };
    const painel = {
      msgId: null,
      chanId: canal.id,
      valor,
      jogadores: [],
      configuracao,
    };

    const embed = _buildFilaEmbed(painel, configuracao, guildId, canal.guild);
    const rows  = _buildFilaRows(guildId, configuracao.tipo, configuracao.modo, vc);

    try {
      const msg = await canal.send({
        ...painelV2FromEmbed(embed, rows),
        allowedMentions: { parse: [] },
      });
      painel.msgId = msg.id;
      g.paineis.push(painel);
      console.log(`[FILAS] Painel enviado — ${configuracao.modo} ${configuracao.tipo} — ${_valorStr(valor)} — msg ${msg.id}`);
    } catch (e) {
      console.error('[FILAS] Erro ao enviar painel:', e.message);
    }
  }

  _salvar();
}

// ─────────────────────────────────────────────────────────────────────────────
// HANDLER PRINCIPAL: /filas e fq:*
// ─────────────────────────────────────────────────────────────────────────────

async function handleFilas(interaction, client) {
  const guildId = interaction.guildId;
  if (!guildId) return false;

  // ── Comando /filas ─────────────────────────────────────────────────────────
  if (interaction.isChatInputCommand() && interaction.commandName === 'filas') {
    if (!interaction.member?.permissions.has('ManageGuild')) {
      await interaction.reply({ content: '🔒 Apenas administradores podem usar este comando.', flags: MessageFlags.Ephemeral });
      return true;
    }
    const identificacao = adaptarConfiguracaoAoCanal(guildId, interaction.channel);
    await interaction.reply(buildConfigPanel(guildId, identificacao.mensagem));
    return true;
  }

  const id = interaction.customId ?? '';

  // ── Select: Tipo ──────────────────────────────────────────────────────────
  if (interaction.isStringSelectMenu() && id === 'filas:tipo') {
    const g = _guild(guildId);
    g.setup.tipo = interaction.values[0];
    if (g.setup.tipo === 'Misto' && g.setup.modo === '1x1') g.setup.modo = '2x2';
    _salvar();
    await interaction.deferUpdate();
    await interaction.editReply(buildConfigPanel(guildId));
    return true;
  }

  // ── Select: Modo ──────────────────────────────────────────────────────────
  if (interaction.isStringSelectMenu() && id === 'filas:modo') {
    const g = _guild(guildId);
    g.setup.modo = interaction.values[0];
    _salvar();
    await interaction.deferUpdate();
    await interaction.editReply(buildConfigPanel(guildId));
    return true;
  }

  // ── Botão: Titulo ─────────────────────────────────────────────────────────
  if (interaction.isButton() && id === 'filas:titulo') {
    const g     = _guild(guildId);
    const modal = new ModalBuilder().setCustomId('filas:modal:titulo').setTitle('Definir Titulo dos Paineis');
    const campo = new TextInputBuilder()
      .setCustomId('valor').setLabel('Titulo dos paineis de fila')
      .setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(100);
    if (g.setup.titulo) campo.setValue(g.setup.titulo);
    modal.addComponents(new ActionRowBuilder().addComponents(campo));
    await interaction.showModal(modal);
    return true;
  }

  // ── Modal: Titulo ─────────────────────────────────────────────────────────
  if (interaction.isModalSubmit() && id === 'filas:modal:titulo') {
    const g = _guild(guildId);
    g.setup.titulo = interaction.fields.getTextInputValue('valor').trim();
    _salvar();
    await interaction.deferUpdate();
    await interaction.editReply(buildConfigPanel(guildId));
    return true;
  }

  // ── Botão: Valores ────────────────────────────────────────────────────────
  if (interaction.isButton() && id === 'filas:valores') {
    const g     = _guild(guildId);
    const modal = new ModalBuilder().setCustomId('filas:modal:valores').setTitle('Definir Valores das Filas');
    const campo = new TextInputBuilder()
      .setCustomId('valor').setLabel('Um valor por linha (ex: 1.00)')
      .setStyle(TextInputStyle.Paragraph).setRequired(true)
      .setPlaceholder('1.00\n0.50\n0.30');
    if (g.setup.valores.length > 0) campo.setValue(g.setup.valores.join('\n'));
    modal.addComponents(new ActionRowBuilder().addComponents(campo));
    await interaction.showModal(modal);
    return true;
  }

  // ── Modal: Valores ────────────────────────────────────────────────────────
  if (interaction.isModalSubmit() && id === 'filas:modal:valores') {
    const g    = _guild(guildId);
    const raw  = interaction.fields.getTextInputValue('valor');
    const vals = raw
      .split('\n')
      .map(l => Number(l.trim().replace(',', '.')))
      .filter(v => Number.isFinite(v) && v > 0 && v <= 1000000)
      .map(v => Math.round(v * 100) / 100)
      .filter((v, index, all) => all.indexOf(v) === index)
      .sort((a, b) => b - a);
    g.setup.valores = vals.slice(0, 25);
    _salvar();
    await interaction.deferUpdate();
    await interaction.editReply(buildConfigPanel(guildId));
    return true;
  }

  // ── Botão: Coins ─────────────────────────────────────────────────────────
  if (interaction.isButton() && id === 'filas:coins') {
    const cfg = require('./configurar').getConfig(guildId);
    const modal = new ModalBuilder().setCustomId('filas:modal:coins').setTitle('Configurar Coins');
    const vencedor = new TextInputBuilder()
      .setCustomId('vencedor')
      .setLabel('Coins por vitória')
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setMaxLength(12)
      .setValue(String(Math.max(0, Math.floor(Number(cfg.coins?.winner) || 0))));
    const perdedor = new TextInputBuilder()
      .setCustomId('perdedor')
      .setLabel('Coins por derrota')
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setMaxLength(12)
      .setValue(String(Math.max(0, Math.floor(Number(cfg.coins?.loser) || 0))));
    modal.addComponents(
      new ActionRowBuilder().addComponents(vencedor),
      new ActionRowBuilder().addComponents(perdedor),
    );
    await interaction.showModal(modal);
    return true;
  }

  // ── Modal: Coins ──────────────────────────────────────────────────────────
  if (interaction.isModalSubmit() && id === 'filas:modal:coins') {
    const vencedor = Number(interaction.fields.getTextInputValue('vencedor').trim());
    const perdedor = Number(interaction.fields.getTextInputValue('perdedor').trim());
    if (!Number.isInteger(vencedor) || vencedor < 0 || !Number.isInteger(perdedor) || perdedor < 0) {
      await interaction.reply({ content: '⚠️ Informe valores inteiros de Coins iguais ou maiores que zero.', flags: MessageFlags.Ephemeral });
      return true;
    }
    const cfg = require('./configurar').getConfig(guildId);
    cfg.coins = { winner: vencedor, loser: perdedor };
    require('./configurar').salvarConfiguracoesLoja();
    await interaction.deferUpdate();
    await interaction.editReply(buildConfigPanel(guildId));
    return true;
  }

  // ── Botão: Banner ─────────────────────────────────────────────────────────
  if (interaction.isButton() && id === 'filas:banner') {
    const g     = _guild(guildId);
    const modal = new ModalBuilder().setCustomId('filas:modal:banner').setTitle('Definir Banner');
    const campo = new TextInputBuilder()
      .setCustomId('valor').setLabel('URL da imagem de banner')
      .setStyle(TextInputStyle.Short).setRequired(false)
      .setPlaceholder('https://...');
    if (g.setup.banner) campo.setValue(g.setup.banner);
    modal.addComponents(new ActionRowBuilder().addComponents(campo));
    await interaction.showModal(modal);
    return true;
  }

  // ── Modal: Banner ─────────────────────────────────────────────────────────
  if (interaction.isModalSubmit() && id === 'filas:modal:banner') {
    const g = _guild(guildId);
    const valor = interaction.fields.getTextInputValue('valor').trim();
    g.setup.banner = valor ? _urlImagem(valor) : null;
    _salvar();
    if (valor && !g.setup.banner) {
      await interaction.reply({
        content: _msg(guildId, 'fila_url_invalida', 'URL inválida. Use um link público começando com http:// ou https://.'),
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }
    await interaction.deferUpdate();
    await interaction.editReply(buildConfigPanel(guildId));
    return true;
  }

  // ── Botão: Thumbnail ──────────────────────────────────────────────────────
  if (interaction.isButton() && id === 'filas:thumbnail') {
    const g     = _guild(guildId);
    const modal = new ModalBuilder().setCustomId('filas:modal:thumbnail').setTitle('Definir Thumbnail');
    const campo = new TextInputBuilder()
      .setCustomId('valor').setLabel('URL da imagem thumbnail')
      .setStyle(TextInputStyle.Short).setRequired(false)
      .setPlaceholder('https://...');
    if (g.setup.thumbnail) campo.setValue(g.setup.thumbnail);
    modal.addComponents(new ActionRowBuilder().addComponents(campo));
    await interaction.showModal(modal);
    return true;
  }

  // ── Modal: Thumbnail ──────────────────────────────────────────────────────
  if (interaction.isModalSubmit() && id === 'filas:modal:thumbnail') {
    const g = _guild(guildId);
    const valor = interaction.fields.getTextInputValue('valor').trim();
    g.setup.thumbnail = valor ? _urlImagem(valor) : null;
    _salvar();
    if (valor && !g.setup.thumbnail) {
      await interaction.reply({
        content: _msg(guildId, 'fila_url_invalida', 'URL inválida. Use um link público começando com http:// ou https://.'),
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }
    await interaction.deferUpdate();
    await interaction.editReply(buildConfigPanel(guildId));
    return true;
  }

  // ── Botão: Enviar ─────────────────────────────────────────────────────────
  if (interaction.isButton() && id === 'filas:enviar') {
    const { getConfig } = require('./configurar');
    const cfg = getConfig(guildId);

    if (!cfg?.channels?.filas) {
      await interaction.reply({
        content: '❌ **Envio bloqueado**: O **Canal de Referência das Partidas (onde os tópicos são criados)** ainda não foi configurado.\n\nPor favor, utilize `/configurar` ➔ **Canais** e defina o canal antes de enviar as filas.',
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    const canalTopicos = await interaction.guild?.channels?.fetch(cfg.channels.filas).catch(() => null);
    if (!canalTopicos) {
      await interaction.reply({
        content: '❌ **Envio bloqueado**: O canal configurado para os tópicos das partidas não existe ou o bot não tem permissão para acessá-lo. Por favor, reconfigure o canal em `/configurar` ➔ **Canais**.',
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    const g = _guild(guildId);
    if (g.setup.valores.length === 0) {
      await interaction.reply({ content: _msg(guildId, 'fila_configurar_valores', 'Configure os valores antes de enviar.'), flags: MessageFlags.Ephemeral });
      return true;
    }

    await interaction.deferUpdate();

    // Usa o canal da interação diretamente — garante permissão de envio
    const canal = interaction.channel;
    if (!canal) {
      await interaction.followUp({ content: _msg(guildId, 'fila_canal_inacessivel', 'Não foi possível acessar o canal.'), flags: MessageFlags.Ephemeral });
      return true;
    }

    await _enviarPaineis(guildId, canal, client);

    const painel = buildConfigPanel(guildId);
    await interaction.editReply(painel);
    return true;
  }

  // ── Botão: Entrar na Fila ─────────────────────────────────────────────────
  if (interaction.isButton() && id.startsWith('fq:in:')) {
    const partes     = id.split(':');
    const valorCents = parseInt(partes[2]);
    const subtipo    = partes[3];
    const res = await _entrarFila(
      interaction.user.id,
      guildId,
      valorCents,
      subtipo,
      client,
      interaction.message,
      interaction.member,
    );
    const msgRetorno = res.ok
      ? _msg(guildId, 'fila_entrou', 'Você entrou na fila.')
      : _msg(guildId, res.chave, res.msg);

    if (interaction.deferred) {
      await interaction.followUp({ content: msgRetorno, flags: MessageFlags.Ephemeral }).catch(() => {});
    } else {
      await interaction.reply({ content: msgRetorno, flags: MessageFlags.Ephemeral }).catch(() => {});
    }
    return true;
  }

  // ── Botão: Sair da Fila ───────────────────────────────────────────────────
  if (interaction.isButton() && id.startsWith('fq:out:')) {
    const valorCents = parseInt(id.split(':')[2]);
    const res = await _sairFila(
      interaction.user.id,
      guildId,
      valorCents,
      client,
      interaction.message,
    );
    const msgRetorno = res.ok
      ? _msg(guildId, 'fila_saiu', 'Você saiu da fila.')
      : _msg(guildId, res.chave, res.msg);

    if (interaction.deferred) {
      await interaction.followUp({ content: msgRetorno, flags: MessageFlags.Ephemeral }).catch(() => {});
    } else {
      await interaction.reply({ content: msgRetorno, flags: MessageFlags.Ephemeral }).catch(() => {});
    }
    return true;
  }

  return false;
}

// ─────────────────────────────────────────────────────────────────────────────
// ENTRAR NA FILA
// ─────────────────────────────────────────────────────────────────────────────

async function _entrarFila(userId, guildId, valorCents, subtipo, client, mensagemClicada = null, memberObj = null) {
  const g = _guild(guildId);
  const chanId = mensagemClicada?.channelId;
  let painel = null;
  const uid = String(userId).trim();

  if (mensagemClicada?.id) {
    painel = g.paineis.find((p) => p.msgId === mensagemClicada.id);
  }
  if (!painel && !mensagemClicada?.id && chanId) {
    painel = g.paineis.find((p) => p.chanId === chanId && _valorCents(p.valor) === valorCents);
  }
  if (!painel && mensagemClicada) {
    let tipo = g.setup.tipo || 'Mobile';
    let modo = g.setup.modo || '2x2';
    let titulo = g.setup.titulo || 'Filas Free Fire';
    let banner = g.setup.banner || null;
    let thumbnail = g.setup.thumbnail || null;

    const embed = mensagemClicada.embeds?.[0];
    if (embed) {
      if (embed.title) titulo = embed.title;
      if (embed.thumbnail?.url) thumbnail = embed.thumbnail.url;
      if (embed.image?.url) banner = embed.image.url;
      const formatoField = embed.fields?.find((f) => f.name?.toLowerCase().includes('formato'));
      if (formatoField?.value) {
        const cred = _extrairCredenciais(formatoField.value);
        if (cred.modo) modo = cred.modo;
        if (cred.tipo) tipo = cred.tipo;
      }
    }
    if (subtipo === 'gelo_normal' || subtipo === 'gelo_infinito') {
      modo = '1x1';
    } else if (subtipo === 'emu1' || subtipo === 'emu2' || subtipo === 'emu3') {
      tipo = 'Misto';
    }

    const valor = Number.isFinite(valorCents) ? valorCents / 100 : 1;
    painel = {
      msgId: mensagemClicada.id,
      chanId: mensagemClicada.channelId,
      valor,
      jogadores: [],
      configuracao: {
        tipo,
        modo,
        titulo,
        banner,
        thumbnail,
      },
    };
    g.paineis.push(painel);
  }
  if (!painel) {
    return { ok: false, chave: 'fila_nao_encontrada', msg: 'Fila não encontrada neste canal.' };
  }

  const setup = _configuracaoDoPainel(painel, g.setup);

  // Verificar se o jogador está na blacklist
  const { isUserBlacklisted } = require('./blacklist');
  const blCheck = isUserBlacklisted(guildId, userId);
  if (blCheck.blacklisted) {
    return {
      ok: false,
      chave: 'fila_blacklist',
      msg: 'Você está registrado na blacklist e não pode entrar em filas do servidor.',
    };
  }

  const { temMediador } = require('./fila_mediador');
  if (!temMediador(guildId)) {
    return { ok: false, chave: 'fila_sem_mediador', msg: 'Não há mediador disponível na fila de Mediadores no momento.' };
  }

  // Se já está no painel atual:
  if (painel.jogadores.some((j) => String(j.id).trim() === uid)) {
    return { ok: false, chave: 'fila_ja_esta', msg: 'Você já está nesta fila!' };
  }

  const vagas = VAGAS_POR_MODO[setup.modo] ?? 2;
  if (painel.jogadores.length >= vagas) {
    return { ok: false, chave: 'fila_cheia', msg: 'Esta fila está cheia.' };
  }

  // Obter o nome do jogador para exibição garantida
  const membro = memberObj
    || mensagemClicada?.guild?.members?.cache?.get(userId)
    || client.guilds.cache.get(guildId)?.members?.cache?.get(userId);
  const nomeJogador = membro?.displayName || membro?.user?.globalName || membro?.user?.username || null;

  painel.jogadores.push({
    id: uid,
    nome: nomeJogador,
    subtipo,
    timestamp: new Date().toISOString(),
  });
  _salvar();

  // Verificar match: contar jogadores do mesmo subtipo. Se não houver
  // mediador livre, a fila fica aguardando sem bloquear novas entradas.
  const grupoSubtipo = painel.jogadores.filter((j) => j.subtipo === subtipo);
  if (grupoSubtipo.length >= vagas) {
    const criada = await _criarPartida(guildId, painel, setup, subtipo, client);
    if (!criada) await _refreshPainel(painel, setup, guildId, client, mensagemClicada);
  } else {
    // Só atualiza a fila quando ela não fechou uma partida. Assim o painel
    // não exibe por um instante os jogadores que já serão removidos.
    await _refreshPainel(painel, setup, guildId, client, mensagemClicada);
  }

  return { ok: true };
}

async function removerJogadorDasFilas(guildId, userId, client) {
  const g = _guild(guildId);
  let alterado = false;
  const uid = String(userId).trim();
  for (const painel of g.paineis) {
    const antes = (painel.jogadores || []).length;
    painel.jogadores = (painel.jogadores || []).filter((j) => String(j.id).trim() !== uid);
    if (painel.jogadores.length !== antes) {
      alterado = true;
      await _refreshPainel(painel, _configuracaoDoPainel(painel, g.setup), guildId, client);
    }
  }
  if (alterado) _salvar();
  return alterado;
}

// ─────────────────────────────────────────────────────────────────────────────
// SAIR DA FILA
// ─────────────────────────────────────────────────────────────────────────────

async function _sairFila(userId, guildId, valorCents, client, mensagemClicada = null) {
  const g = _guild(guildId);
  const chanId = mensagemClicada?.channelId;
  let saiu = false;
  const uid = String(userId).trim();

  for (const painel of g.paineis) {
    const ehEstePainel = mensagemClicada?.id
      ? painel.msgId === mensagemClicada.id
      : (chanId && painel.chanId === chanId && _valorCents(painel.valor) === valorCents);

    const antes = (painel.jogadores || []).length;
    painel.jogadores = (painel.jogadores || []).filter((j) => String(j.id).trim() !== uid);
    if (painel.jogadores.length < antes) {
      saiu = true;
      await _refreshPainel(
        painel,
        _configuracaoDoPainel(painel, g.setup),
        guildId,
        client,
        ehEstePainel ? mensagemClicada : null
      );
    }
  }

  if (saiu) {
    _salvar();
    return { ok: true };
  }

  if (mensagemClicada?.id) {
    const p = g.paineis.find((x) => x.msgId === mensagemClicada.id);
    if (p) await _refreshPainel(p, _configuracaoDoPainel(p, g.setup), guildId, client, mensagemClicada);
  }

  return { ok: false, chave: 'fila_nao_esta', msg: 'Você não está na fila.' };
}

// ─────────────────────────────────────────────────────────────────────────────
// CRIAR CANAL DE PARTIDA
// ─────────────────────────────────────────────────────────────────────────────

async function _criarPartida(guildId, painel, setup, subtipo, client) {
  const vagas = VAGAS_POR_MODO[setup.modo] ?? 2;
  const jogadores = painel.jogadores.filter((j) => j.subtipo === subtipo).slice(0, vagas);

  const guild = client.guilds.cache.get(guildId) ?? await client.guilds.fetch(guildId).catch(() => null);
  if (!guild) {
    console.error(`[FILAS] Servidor ${guildId} não encontrado no cliente.`);
    return false;
  }

  // O canal configurado em /configurar define onde o tópico da partida será criado.
  const { getConfig } = require('./configurar');
  const parentId = getConfig(guildId)?.channels?.filas;
  let canalHost = null;
  if (parentId) {
    canalHost = await guild.channels.fetch(parentId).catch(() => null);
  }
  if (!canalHost && painel.chanId) {
    canalHost = await guild.channels.fetch(painel.chanId).catch(() => null);
  }
  if (!canalHost) {
    canalHost = guild.channels.cache.find((c) => c.type === ChannelType.GuildText) ?? null;
  }
  if (!canalHost) {
    console.error('[FILAS] Canal de referência para criar tópico não encontrado ou indisponível.');
    return false;
  }

  const {
    pegarMediador,
    atualizarPainelMediador,
  } = require('./fila_mediador');
  const mediadorId = pegarMediador(guildId);
  if (!mediadorId) {
    console.log('[FILAS] Fila completa aguardando um mediador disponível.');
    return false;
  }
  await atualizarPainelMediador(guildId, client);

  // Remover da fila e atualizar o painel antes das chamadas de criação do canal
  const idsJog = new Set(jogadores.map((j) => j.id));
  painel.jogadores = painel.jogadores.filter((j) => !idsJog.has(j.id));
  _salvar();
  await _refreshPainel(painel, setup, guildId, client);

  let canal = null;
  const nomeTopico = `confirmar-${(setup.modo || '1x1').toLowerCase()}-${(setup.tipo || 'mobile').toLowerCase()}`
    .replace(/[^a-z0-9-_]+/g, '-')
    .slice(0, 80);

  try {
    // 1. Tenta criar Thread no canalHost se ele for um canal de texto
    if (canalHost && typeof canalHost.threads?.create === 'function' && canalHost.type === ChannelType.GuildText) {
      try {
        canal = await canalHost.threads.create({
          name: nomeTopico,
          type: ChannelType.PrivateThread,
          invitable: false,
          autoArchiveDuration: 60,
          reason: `Partida ${setup.modo} ${setup.tipo}`,
        });
      } catch (errPrivado) {
        console.log('[FILAS] Tópico privado indisponível, tentando tópico público:', errPrivado.message);
        try {
          canal = await canalHost.threads.create({
            name: nomeTopico,
            type: ChannelType.PublicThread,
            autoArchiveDuration: 60,
            reason: `Partida ${setup.modo} ${setup.tipo}`,
          });
        } catch (errPublico) {
          console.log('[FILAS] Tópico público também falhou:', errPublico.message);
        }
      }
    }

    // 2. Se a criação de thread falhar (ou canalHost for categoria), cria canal de texto dedicado
    if (!canal) {
      console.log('[FILAS] Criando canal de texto dedicado para a partida...');
      const botId = client.user.id;
      const overwrites = [
        {
          id: guild.roles.everyone.id,
          deny: [PermissionFlagsBits.ViewChannel],
        },
        {
          id: botId,
          allow: [
            PermissionFlagsBits.ViewChannel,
            PermissionFlagsBits.SendMessages,
            PermissionFlagsBits.EmbedLinks,
            PermissionFlagsBits.AttachFiles,
            PermissionFlagsBits.ManageChannels,
            PermissionFlagsBits.ReadMessageHistory,
          ],
        },
      ];
      if (mediadorId) {
        overwrites.push({
          id: mediadorId,
          allow: [
            PermissionFlagsBits.ViewChannel,
            PermissionFlagsBits.SendMessages,
            PermissionFlagsBits.EmbedLinks,
            PermissionFlagsBits.AttachFiles,
            PermissionFlagsBits.ReadMessageHistory,
          ],
        });
      }
      for (const jogador of jogadores) {
        if (jogador.id) {
          overwrites.push({
            id: jogador.id,
            allow: [
              PermissionFlagsBits.ViewChannel,
              PermissionFlagsBits.SendMessages,
              PermissionFlagsBits.EmbedLinks,
              PermissionFlagsBits.AttachFiles,
              PermissionFlagsBits.ReadMessageHistory,
            ],
          });
        }
      }

      const parentCat = canalHost.type === ChannelType.GuildCategory ? canalHost.id : (canalHost.parentId || null);
      try {
        canal = await guild.channels.create({
          name: nomeTopico,
          type: ChannelType.GuildText,
          parent: parentCat,
          permissionOverwrites: overwrites,
          reason: `Partida ${setup.modo} ${setup.tipo}`,
        });
      } catch (errParent) {
        console.warn('[FILAS] Falha ao criar canal com categoria pai, tentando sem categoria:', errParent.message);
        canal = await guild.channels.create({
          name: nomeTopico,
          type: ChannelType.GuildText,
          parent: null,
          permissionOverwrites: overwrites,
          reason: `Partida ${setup.modo} ${setup.tipo}`,
        });
      }
    }

    if (!canal) {
      throw new Error('Não foi possível criar tópico nem canal para a partida.');
    }

    if (typeof canal.join === 'function') await canal.join().catch(() => {});
    if (canal.members && typeof canal.members.add === 'function') {
      if (mediadorId) await canal.members.add(mediadorId).catch(() => {});
      for (const jogador of jogadores) {
        if (jogador.id) await canal.members.add(jogador.id).catch(() => {});
      }
    }
  } catch (e) {
    console.error('[FILAS] Erro ao criar tópico/canal de partida:', e.message);
    if (mediadorId) {
      const { liberarMediador } = require('./fila_mediador');
      liberarMediador(guildId, mediadorId, client, { restaurarInicio: true });
    }
    for (const jogador of jogadores) {
      if (!painel.jogadores.some((item) => item.id === jogador.id)) painel.jogadores.push(jogador);
    }
    _salvar();
    await _refreshPainel(painel, setup, guildId, client);
    return false;
  }

  const { criarPartida } = require('./partida');
  const taxaBruta = parseFloat(String(getConfig(guildId)?.taxa ?? '0').replace(',', '.'));
  const taxa = Number.isFinite(taxaBruta) && taxaBruta > 0 ? taxaBruta : 0;
  const valorComTaxa = painel.valor + taxa;
  try {
    await criarPartida({
      guildId,
      canal,
      jogadores,
      mediadorId,
      setup,
      subtipo,
      valor: valorComTaxa,
      tipo: setup.tipo,
      modo: setup.modo,
      client,
    });
  } catch (error) {
    console.error('[FILAS] Erro ao enviar painel no canal:', error.message);
    if (mediadorId) {
      const { liberarMediador } = require('./fila_mediador');
      liberarMediador(guildId, mediadorId, client, { restaurarInicio: true });
    }
    for (const jogador of jogadores) {
      if (!painel.jogadores.some((item) => item.id === jogador.id)) {
        painel.jogadores.push(jogador);
      }
    }
    _salvar();
    await _refreshPainel(painel, setup, guildId, client);
    await canal.delete('Falha ao enviar o painel da partida').catch(() => {});
    return false;
  }
  console.log(`[FILAS] Canal de partida criado com sucesso: ${canal.name}`);
  return true;
}

async function tentarCriarPartidas(guildId, client) {
  const g = _guild(guildId);
  const tentadas = new Set();
  for (const painel of g.paineis) {
    const setup = _configuracaoDoPainel(painel, g.setup);
    const vagas = VAGAS_POR_MODO[setup.modo] ?? 2;
    const subtipos = [...new Set(painel.jogadores.map((j) => j.subtipo))];
    for (const subtipo of subtipos) {
      const grupo = painel.jogadores.filter((j) => j.subtipo === subtipo);
      if (grupo.length < vagas || tentadas.has(painel)) continue;
      tentadas.add(painel);
      await _criarPartida(guildId, painel, setup, subtipo, client);
    }
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// RESTAURAR PAINEIS AO REINICIAR
// ─────────────────────────────────────────────────────────────────────────────

async function restaurarPaineis(client) {
  for (const [guildId, g] of Object.entries(_dados)) {
    if (!g.paineis?.length) continue;
    const paineisValidos = [];

    for (const painel of g.paineis) {
      if (!painel.msgId) continue;
      try {
        const setup = _configuracaoDoPainel(painel, g.setup);
        if (!painel.configuracao) {
          painel.configuracao = setup;
        }
        const canal = await client.channels.fetch(painel.chanId).catch(() => null);
        if (!canal) {
          console.log(`[FILAS] Canal ${painel.chanId} não encontrado. Painel ${painel.msgId} descartado.`);
          continue;
        }
        const msg = await canal.messages.fetch(painel.msgId).catch(() => null);
        if (!msg) {
          console.log(`[FILAS] Mensagem ${painel.msgId} não encontrada. Painel descartado.`);
          continue;
        }

        const vc = _valorCents(painel.valor);
        const embed = _buildFilaEmbed(painel, setup, guildId, canal.guild);
        const rows = _buildFilaRows(guildId, setup.tipo, setup.modo, vc);
        const cleanUsers = (painel.jogadores || []).map((j) => String(j.id || '').trim()).filter((id) => /^\d{16,22}$/.test(id));
        await msg.edit({
          ...painelV2FromEmbed(embed, rows),
          allowedMentions: { users: [...new Set(cleanUsers)] },
        });
        paineisValidos.push(painel);
        console.log(`[FILAS] Painel restaurado: ${_valorStr(painel.valor)}`);
      } catch (e) {
        if (e?.code === 10008 || e?.code === 10003) {
          console.log(`[FILAS] Painel ${painel.msgId} removido pois não existe mais no Discord.`);
        } else {
          paineisValidos.push(painel);
          console.error('[FILAS] Falha ao restaurar painel:', e.message);
        }
      }
    }
    g.paineis = paineisValidos;
    _salvar();
  }
}

function removerPainelPorMsgId(msgId, guildId = null) {
  if (!msgId) return false;
  let alterado = false;
  if (guildId && _dados[guildId]) {
    const g = _dados[guildId];
    const antes = (g.paineis || []).length;
    g.paineis = (g.paineis || []).filter((p) => p.msgId !== msgId);
    if (g.paineis.length !== antes) alterado = true;
  } else {
    for (const g of Object.values(_dados)) {
      const antes = (g.paineis || []).length;
      g.paineis = (g.paineis || []).filter((p) => p.msgId !== msgId);
      if (g.paineis.length !== antes) alterado = true;
    }
  }
  if (alterado) {
    _salvar();
    console.log(`[FILAS] Painel apagado no Discord e removido do registro: ${msgId}`);
  }
  return alterado;
}

function removerPaineisDoCanal(chanId, guildId = null) {
  if (!chanId) return false;
  let alterado = false;
  if (guildId && _dados[guildId]) {
    const g = _dados[guildId];
    const antes = (g.paineis || []).length;
    g.paineis = (g.paineis || []).filter((p) => p.chanId !== chanId);
    if (g.paineis.length !== antes) alterado = true;
  } else {
    for (const g of Object.values(_dados)) {
      const antes = (g.paineis || []).length;
      g.paineis = (g.paineis || []).filter((p) => p.chanId !== chanId);
      if (g.paineis.length !== antes) alterado = true;
    }
  }
  if (alterado) {
    _salvar();
    console.log(`[FILAS] Painéis do canal apagado ${chanId} removidos do registro.`);
  }
  return alterado;
}

async function atualizarPaineisBotoes(guildId, client) {
  const g = _guild(guildId);
  for (const painel of g.paineis ?? []) {
    if (!painel.msgId) continue;
    await _refreshPainel(painel, _configuracaoDoPainel(painel, g.setup), guildId, client);
  }
}

function obterModeloPartida(guildId) {
  const setup = _guild(guildId).setup;
  return {
    tipo: setup.tipo || 'Mobile',
    modo: setup.modo || '2x2',
  };
}

module.exports = {
  handleFilas,
  restaurarPaineis,
  atualizarPaineisBotoes,
  tentarCriarPartidas,
  obterModeloPartida,
  identificarCredenciaisCanal,
  adaptarConfiguracaoAoCanal,
  removerJogadorDasFilas,
  removerPainelPorMsgId,
  removerPaineisDoCanal,
};
