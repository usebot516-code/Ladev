'use strict';

// ── Painéis e fluxo da partida ────────────────────────────────────────────────

const fs = require('fs');
const path = require('path');
const QRCode = require('qrcode');
const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  MessageFlags,
  PermissionFlagsBits,
} = require('discord.js');
const { painelV2FromEmbed } = require('./visual');
const { mensagem: _msg } = require('./avisos_mensagens');
const { dataPath } = require('./data-path');
const { criarSala } = require('./nixff');

const DATA_FILE = dataPath('partidas_data.json');

function _lerDados() {
  try {
    return fs.existsSync(DATA_FILE) ? JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')) : {};
  } catch (error) {
    console.error('[PARTIDA] Falha ao ler dados:', error.message);
    return {};
  }
}

const _dados = _lerDados();
const salasEmCriacao = new Set();

let _saving = false;
let _savePending = false;
function _salvar() {
  if (_saving) {
    _savePending = true;
    return;
  }
  _saving = true;
  const tmp = `${DATA_FILE}.tmp`;
  try {
    fs.writeFile(tmp, JSON.stringify(_dados, null, 2), 'utf8', (err) => {
      if (!err) {
        fs.rename(tmp, DATA_FILE, () => {
          _saving = false;
          if (_savePending) {
            _savePending = false;
            _salvar();
          }
        });
      } else {
        _saving = false;
      }
    });
  } catch (error) {
    _saving = false;
  }
}

function _guild(guildId) {
  if (!_dados[guildId]) _dados[guildId] = {};
  if (!Array.isArray(_dados[guildId].partidas)) _dados[guildId].partidas = [];
  return _dados[guildId];
}

function _config(guildId) {
  return require('./configurar').getConfig(guildId);
}

function _cor(guildId) {
  return _config(guildId)?.embedColor ?? 0x5865f2;
}

function _valor(v) {
  return `R$ ${Number(v ?? 0).toFixed(2).replace('.', ',')}`;
}

function _nomeTopicoPagamento(v) {
  return `pagar-${Number(v ?? 0).toFixed(2).replace('.', ',')}`;
}

async function _renomearPartida(canal, nome) {
  if (!canal || typeof canal.setName !== 'function') return;
  await canal.setName(nome).catch((error) => {
    console.error(`[PARTIDA] Falha ao renomear tópico para "${nome}":`, error.message);
  });
}

function _partida(guildId, partidaId) {
  return _guild(guildId).partidas.find((item) => item.id === partidaId) ?? null;
}

function _partidaDoCanal(guildId, channelId) {
  return _guild(guildId).partidas.find((item) => item.channelId === channelId) ?? null;
}

function obterPartidaStreamerAtiva(guildId, streamerId, partidaId = null) {
  const partidas = _guild(guildId).partidas.filter((item) => item.streamerId === streamerId);
  if (partidaId) return partidas.find((item) => item.id === partidaId) ?? null;
  return partidas[partidas.length - 1] ?? null;
}

function _jogador(partida, userId) {
  return partida.jogadores.find((item) => item.id === userId) ?? null;
}

function _podeConfirmar(partida, userId) {
  if (!userId) return false;
  const uid = String(userId).trim();
  const ehJogador = partida.jogadores.some((j) => String(j.id).trim() === uid);
  const ehStreamer = partida.streamerId && String(partida.streamerId).trim() === uid;
  return ehJogador || Boolean(ehStreamer);
}

function _participantesConfirmacao(partida) {
  const ids = partida.jogadores.map((j) => String(j.id).trim());
  if (partida.streamerId) {
    const sId = String(partida.streamerId).trim();
    if (sId && !ids.includes(sId)) {
      ids.push(sId);
    }
  }
  return ids;
}

function _nome(partida, id, guild = null) {
  const jogador = _jogador(partida, id);
  const membro = guild?.members?.cache?.get(id);
  const salvo = jogador?.nome && !/^\d{10,}$/.test(jogador.nome) ? jogador.nome : null;
  return membro?.displayName || salvo || membro?.user?.globalName || membro?.user?.username || (id === partida.streamerId ? 'Streamer' : `Jogador ${id.slice(-4)}`);
}

function _listaJogadores(partida, ids, guild = null, simbolo = '•') {
  return ids
    .map((id) => `${simbolo} <@${id}>`)
    .join('\n') || '— Nenhum';
}

function _participantes(partida, mediadorId = partida.mediadorId) {
  return [...new Set([
    mediadorId,
    partida.streamerId,
    ...partida.jogadores.map((j) => j.id),
  ].filter(Boolean))];
}

function _aviso(titulo, descricao, cor = 0xe74c3c) {
  return new EmbedBuilder()
    .setColor(cor)
    .setTitle(titulo)
    .setDescription(descricao);
}

function _marcaProgresso(atual, total) {
  const preenchidos = Math.min(10, Math.round((atual / Math.max(total, 1)) * 10));
  return `${'▰'.repeat(preenchidos)}${'▱'.repeat(10 - preenchidos)}  **${atual}/${total}**`;
}

function _confirmacaoEmbed(guildId, partida, guild = null) {
  const todosRequeridos = _participantesConfirmacao(partida);
  const confirmados = todosRequeridos.filter((id) => partida.confirmados.map(String).includes(id));
  const aguardando = todosRequeridos.filter((id) => !partida.confirmados.map(String).includes(id));
  const fields = [
    { name: 'Formato', value: `${partida.modo} ${partida.tipo}`, inline: false },
    { name: 'Preço', value: _valor(partida.valor), inline: false },
    { name: `Confirmados • ${confirmados.length}/${todosRequeridos.length}`, value: _listaJogadores(partida, confirmados, guild), inline: true },
    { name: `Aguardando • ${aguardando.length}`, value: _listaJogadores(partida, aguardando, guild), inline: true },
  ];

  if (partida.mediadorId) {
    fields.push({ name: 'Mediador', value: `<@${partida.mediadorId}>`, inline: false });
  }

  if (partida.streamerId) {
    fields.push({ name: 'Streamer', value: `<@${partida.streamerId}>`, inline: false });
  }

  const embed = new EmbedBuilder()
    .setColor(_cor(guildId))
    .setTitle(`${partida.modo} | ${partida.tipo}`)
    .addFields(fields);
  if (partida.descricaoPainel) embed.setDescription(partida.descricaoPainel.trim());
  return embed;
}

function _confirmacaoComponentes(partida) {
  return [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`partida:${partida.id}:confirmar`).setLabel('Confirmar').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId(`partida:${partida.id}:cancelar`).setLabel('Cancelar').setStyle(ButtonStyle.Danger),
    ),
  ];
}

function _gerenciamentoEmbed(guildId, partida, extra = '', guild = null) {
  const resultado = partida.resultado
    ? `${partida.resultado.vencedorId ? `<@${partida.resultado.vencedorId}>` : 'Não definido'}\n${partida.resultado.tipo}`
    : 'Ainda não definido';
  return new EmbedBuilder()
    .setColor(_cor(guildId))
    .setTitle(`${partida.modo} | ${partida.tipo}`)
    .setDescription(extra || partida.descricaoPainel || 'Gerenciamento da partida')
    .addFields(
      { name: 'Formato', value: `${partida.modo} ${partida.tipo}`, inline: false },
      { name: 'Preço', value: _valor(partida.valor), inline: false },
      { name: 'Jogadores', value: _listaJogadores(partida, partida.jogadores.map((j) => j.id), guild), inline: false },
      { name: 'Mediador', value: `<@${partida.mediadorId}>`, inline: false },
      ...(partida.streamerId
        ? [{ name: 'Streamer', value: `<@${partida.streamerId}>`, inline: false }]
        : []),
      { name: 'Resultado', value: resultado, inline: false },
      {
        name: 'Pagamentos',
        value: partida.jogadores.map((jogador) => (
          partida.pagamentosConfirmados?.[jogador.id]
            ? `✅ <@${jogador.id}> — confirmado`
            : `⏳ <@${jogador.id}> — aguardando \`pg nome sobrenome\``
        )).join('\n'),
        inline: false,
      },
    );
}

function _salaEmbed(guildId, partida) {
  const roomId = partida.sala?.roomId || 'N/A';
  const password = partida.sala?.password || 'N/A';
  return new EmbedBuilder()
    .setColor(_cor(guildId))
    .setTitle('A SALA FOI CRIADA!')
    .setDescription(
      `\`ID\`: ${roomId}\n\n` +
      `\`Senha\`: ${password}\n\n` +
      'A sala será iniciada quando todos os jogadores estiverem na sala.'
    );
}

function _salaComponentes(partida) {
  return [new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`partida:${partida.id}:copiar_sala_id`)
      .setLabel('Copiar ID')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(`partida:${partida.id}:copiar_sala_senha`)
      .setLabel('Copiar senha')
      .setStyle(ButtonStyle.Secondary),
  )];
}

function _gerenciamentoComponentes(partida) {
  const menu = new StringSelectMenuBuilder()
    .setCustomId(`partida:${partida.id}:gerenciar`)
    .setPlaceholder('Gerenciamento da partida')
    .addOptions([
      { label: 'Definir vencedor', value: 'vencedor', description: 'Escolher o jogador vencedor' },
      { label: 'Redefinir valor', value: 'valor', description: 'Alterar o valor da partida' },
      { label: 'Enviar sala', value: 'enviar_sala', description: 'Enviar ID e senha da sala para os jogadores' },
      { label: 'Chamar analista', value: 'analista', description: 'Adicionar o próximo analista disponível' },
      { label: 'Fechar partida', value: 'fechar_partida', description: 'Encerrar e fechar o tópico da partida' },
    ]);
  return [new ActionRowBuilder().addComponents(menu)];
}

function _vencedorComponentes(partida, guild = null) {
  const opcoes = partida.jogadores.map((j, index) => ({
    label: _nome(partida, j.id, guild).slice(0, 100) || `Jogador ${index + 1}`,
    value: j.id,
    description: 'Registrar este jogador como vencedor',
  }));
  if (partida.streamerId && !opcoes.some((o) => o.value === partida.streamerId)) {
    opcoes.push({
      label: `Streamer (${_nome(partida, partida.streamerId, guild)})`.slice(0, 100),
      value: partida.streamerId,
      description: 'Registrar o streamer como vencedor',
    });
  }
  const menu = new StringSelectMenuBuilder()
    .setCustomId(`partida:${partida.id}:vencedor`)
    .setPlaceholder('Selecione o vencedor')
    .addOptions(opcoes);
  return [new ActionRowBuilder().addComponents(menu)];
}

function _resultadoComponentes(partida) {
  return [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`partida:${partida.id}:wo`).setLabel('Vitória por W.O').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId(`partida:${partida.id}:normal`).setLabel('Vitória normal').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId(`partida:${partida.id}:cancelar_resultado`).setLabel('Cancelar escolha').setStyle(ButtonStyle.Secondary),
    ),
  ];
}

function _finalEmbed(guildId, partida, guild = null) {
  return new EmbedBuilder()
    .setColor(_cor(guildId))
    .setTitle(`${partida.modo} | ${partida.tipo}`)
    .setDescription(partida.descricaoPainel || 'Partida finalizada. O mediador pode fechar o canal.')
    .addFields(
      { name: 'Formato', value: `${partida.modo} ${partida.tipo}`, inline: false },
      { name: 'Preço', value: _valor(partida.valor), inline: false },
      { name: 'Vencedor', value: `<@${partida.resultado.vencedorId}>`, inline: false },
      { name: 'Resultado', value: partida.resultado.tipo, inline: false },
    );
}

function _finalComponentes(partida) {
  return [new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`partida:${partida.id}:fechar`).setLabel('Fechar').setStyle(ButtonStyle.Danger),
  )];
}

function _corQr(nome, fallback) {
  const mapa = {
    preto: '#000000', branco: '#FFFFFF', vermelho: '#E74C3C', azul: '#3498DB',
    verde: '#2ECC71', amarelo: '#F1C40F', roxo: '#9B59B6', cinza: '#95A5A6',
  };
  return mapa[String(nome ?? '').toLowerCase()] ?? fallback;
}

function _luminancia(hex) {
  const valor = String(hex).replace('#', '');
  if (!/^[0-9a-f]{6}$/i.test(valor)) return 0;
  const rgb = [0, 2, 4].map((pos) => Number.parseInt(valor.slice(pos, pos + 2), 16) / 255);
  const linear = rgb.map((canal) => (canal <= 0.03928 ? canal / 12.92 : ((canal + 0.055) / 1.055) ** 2.4));
  return (0.2126 * linear[0]) + (0.7152 * linear[1]) + (0.0722 * linear[2]);
}

function _corQrSegura(nome) {
  const configurada = _corQr(nome, '#111827');
  // QR branco não pode ter pontos claros: preserva a configuração apenas quando
  // há contraste suficiente para leitura em celular.
  return _luminancia(configurada) > 0.35 ? '#111827' : configurada;
}

function _pagamentoEmbed(guildId, partida, arquivoQr, pix = null) {
  const embed = new EmbedBuilder()
    .setColor(_cor(guildId))
    .setTitle('PAGAMENTO VIA PIX')
    .setDescription(`Escaneie o QR Code abaixo para pagar **${_valor(partida.valor)}**.\n\nA chave está disponível no botão **Copiar chave PIX**.`)
    .setImage(`attachment://${arquivoQr}`);

  if (pix) {
    embed.addFields(
      { name: 'Titular', value: pix.titular || 'Não informado', inline: true },
      { name: 'Cidade', value: pix.cidade || 'Não informada', inline: true },
      { name: 'Tipo de chave', value: pix.tipo || 'Não informado', inline: true },
      { name: 'Chave PIX', value: `\`${pix.chave || 'Não informada'}\``, inline: false },
    );
  }

  return embed;
}

async function _enviarPagamento(guildId, partida, canal, client) {
  const { obterPixMediador } = require('./fila_mediador');
  const pix = obterPixMediador(guildId, partida.mediadorId);
  if (!pix?.chave) {
    await canal.send({ content: _msg(guildId, 'partida_pix_nao_configurado', 'O mediador designado ainda não possui uma chave PIX cadastrada.') });
    return;
  }

  const cfg = _config(guildId);
  const qr = cfg.qrCode ?? {};
  try {
    const buffer = await QRCode.toBuffer(pix.chave, {
      type: 'png',
      width: 480,
      margin: 4,
      errorCorrectionLevel: 'H',
      color: {
        dark: _corQrSegura(qr.corCentral),
        light: '#FFFFFF',
      },
    });
    const arquivoQr = `pix-${partida.id}.png`;
    const mensagem = await canal.send({
      ...painelV2FromEmbed(
        _pagamentoEmbed(guildId, partida, arquivoQr, pix),
        [new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId(`partida:${partida.id}:copiar`).setLabel('Copiar chave PIX').setStyle(ButtonStyle.Secondary),
        )],
      ),
      files: [{ attachment: buffer, name: arquivoQr }],
    });
    partida.pagamentoMsgId = mensagem.id;
  } catch (error) {
    console.error('[PARTIDA] Falha ao gerar QR Code:', error.message);
    await canal.send({
      content:
        _msg(guildId, 'partida_pagamento_falhou', 'Pagamento da partida') + '\n' +
        `Titular: ${pix.titular || 'Não informado'}\n` +
        `Cidade: ${pix.cidade || 'Não informada'}\n` +
        `Tipo de chave: ${pix.tipo || 'Não informado'}\n` +
        `Chave PIX: ${pix.chave}`,
    });
  }

  if (cfg.avisos) {
    if (cfg.avisosTipo === 'embed') {
      const embedAviso = new EmbedBuilder()
        .setColor(cfg.embedColor || 0x5865F2)
        .setDescription(cfg.avisos);
      await canal.send({ embeds: [embedAviso] }).catch((err) => console.error('[AVISO] Falha ao enviar embed de aviso:', err.message));
    } else {
      await canal.send({ content: cfg.avisos }).catch((err) => console.error('[AVISO] Falha ao enviar mensagem de aviso:', err.message));
    }
  }
  _salvar();
}

async function _log(guild, channelId, embed) {
  if (!channelId) return;
  const canal = await guild.channels.fetch(channelId).catch(() => null);
  if (canal) await canal.send({ embeds: [embed] }).catch(() => {});
}

async function _enviarPainelMediador(guildId, partida, canal, client) {
  const participantes = _participantes(partida);
  const mensagem = await canal.send({
    ...painelV2FromEmbed(
      _gerenciamentoEmbed(guildId, partida, '', canal.guild),
      _gerenciamentoComponentes(partida),
    ),
    allowedMentions: { users: participantes },
  });
  partida.mediadorMsgId = mensagem.id;
  partida.estado = 'mediador';
  _salvar();
  await _enviarPagamento(guildId, partida, canal, client);
}

async function _atualizarConfirmacao(guildId, partida, canal) {
  const conteudo = painelV2FromEmbed(
    _confirmacaoEmbed(guildId, partida, canal.guild),
    _confirmacaoComponentes(partida),
  );

  if (!partida.confirmacaoMsgId) {
    const novaMensagem = await canal.send(conteudo);
    partida.confirmacaoMsgId = novaMensagem.id;
    _salvar();
    return;
  }

  const msg = canal.messages?.cache?.get(partida.confirmacaoMsgId) || (canal.messages ? await canal.messages.fetch(partida.confirmacaoMsgId).catch(() => null) : null);
  if (msg && typeof msg.edit === 'function') {
    await msg.edit(conteudo).catch(() => {});
  }
}

async function _atualizarMediador(guildId, partida, canal, extra = '') {
  if (!partida.mediadorMsgId) return;
  const msg = canal.messages?.cache?.get(partida.mediadorMsgId) || (canal.messages ? await canal.messages.fetch(partida.mediadorMsgId).catch(() => null) : null);
  if (msg && typeof msg.edit === 'function') {
    await msg.edit({
      ...painelV2FromEmbed(
        _gerenciamentoEmbed(guildId, partida, extra, canal.guild),
        _gerenciamentoComponentes(partida),
      ),
      allowedMentions: { users: _participantes(partida) },
    }).catch(() => {});
  }
}

function _pagamentoStatusEmbed(guildId, partida, titulo, descricao, cor = null) {
  return new EmbedBuilder()
    .setColor(cor ?? _cor(guildId))
    .setTitle(titulo)
    .setDescription(descricao)
    .addFields({
      name: 'Status dos jogadores',
      value: partida.jogadores.map((jogador) => (
        partida.pagamentosConfirmados?.[jogador.id]
          ? `✅ <@${jogador.id}> — confirmado`
          : `⏳ <@${jogador.id}> — aguardando`
      )).join('\n'),
    });
}

async function _responderPagamento(message, embed) {
  const resposta = await message.reply({
    ...painelV2FromEmbed(embed),
    allowedMentions: { users: [] },
  }).catch(() => null);
  if (resposta) setTimeout(() => resposta.delete().catch(() => {}), 12000);
  await message.delete().catch(() => {});
  return resposta;
}

async function _atualizarPainelSala(guildId, partida, canal) {
  if (!partida.sala || !canal) return null;
  const payload = {
    ...painelV2FromEmbed(_salaEmbed(guildId, partida), _salaComponentes(partida)),
    allowedMentions: { users: [] },
  };
  const mensagemId = partida.salaMsgId;
  const existente = mensagemId ? await canal.messages.fetch(mensagemId).catch(() => null) : null;
  if (existente && typeof existente.edit === 'function') {
    await existente.edit(payload);
    partida.salaMsgId = existente.id;
    _salvar();
    return existente;
  }
  const mensagem = await canal.send(payload);
  partida.salaMsgId = mensagem.id;
  _salvar();
  return mensagem;
}

async function _criarSalaAutomaticamente(guildId, partida, canal) {
  if (partida.sala?.roomId || salasEmCriacao.has(partida.id)) return Boolean(partida.sala?.roomId);
  salasEmCriacao.add(partida.id);
  try {
    partida.estado = 'criando_sala';
    _salvar();
    partida.sala = await criarSala({
      modo: partida.modo,
      tipo: partida.tipo,
      subtipo: partida.subtipo,
      partidaId: partida.id,
    });
    partida.salaPronta = true;
    partida.salaErro = null;
    partida.estado = 'sala_criada';
    _salvar();
    await _atualizarPainelSala(guildId, partida, canal);
    return true;
  } catch (error) {
    partida.estado = 'pagamentos_confirmados';
    partida.salaPronta = false;
    partida.salaErro = error.message;
    _salvar();
    console.error(`[PARTIDA] Falha ao criar sala pela Nixff.vip: ${error.message}`);
    return false;
  } finally {
    salasEmCriacao.delete(partida.id);
  }
}

async function processarPrintComIA(partida, imageUrl) {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || !imageUrl) return;
  try {
    const { GoogleGenAI } = require('@google/genai');
    const ai = new GoogleGenAI({ apiKey });

    const res = await fetch(imageUrl);
    if (!res.ok) return;
    const arrayBuffer = await res.arrayBuffer();
    const base64Data = Buffer.from(arrayBuffer).toString('base64');
    const mimeType = res.headers.get('content-type') || 'image/png';

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: [
        {
          role: 'user',
          parts: [
            { text: 'Extraia as informações do print de vitória/partida (como pontuação, estatísticas, abates ou detalhes visíveis). Responda apenas em texto simples e direto, sem emojis.' },
            { inlineData: { mimeType, data: base64Data } },
          ],
        },
      ],
    });

    if (response?.text) {
      const texto = response.text.trim();
      if (texto) {
        partida.printInfo = texto;
        _salvar();
      }
    }
  } catch (err) {
    console.warn('[GEMINI PRINT OCR] Análise do print ignorada:', err.message);
  }
}

async function enviarMuralVitoria(guildId, partida, client) {
  if (partida.muralEnviado) return;
  partida.muralEnviado = true;
  _salvar();

  const cfg = _config(guildId);
  const canalMuralId = cfg?.channels?.muralPartidas;
  if (!canalMuralId) return;

  const canalMural = await client.channels.fetch(canalMuralId).catch(() => null);
  if (!canalMural) return;

  const vencedorId = partida.resultado?.vencedorId;
  if (!vencedorId) return;

  const perdedores = (partida.jogadores || [])
    .filter((j) => j.id !== vencedorId)
    .map((j) => `<@${j.id}>`);
  const derrotadosTexto = perdedores.length > 0 ? perdedores.join(', ') : 'Não informado';

  const mediadorTexto = partida.mediadorId ? `<@${partida.mediadorId}>` : 'Não definido';

  const now = new Date();
  const dia = String(now.getDate()).padStart(2, '0');
  const mes = String(now.getMonth() + 1).padStart(2, '0');
  const ano = now.getFullYear();
  const horas = String(now.getHours()).padStart(2, '0');
  const minutos = String(now.getMinutes()).padStart(2, '0');
  const dataHoraFormatada = `${dia}/${mes}/${ano} as ${horas}:${minutos}`;

  const tipoRaw = String(partida.resultado?.tipo || 'normal').toLowerCase();
  const tipoFormatado = tipoRaw.includes('wo') || tipoRaw.includes('w.o')
    ? 'vitória por w.o'
    : 'vitória normal';

  let descricao = `# WIN\n\nGanhou -> <@${vencedorId}>\n\nDerrotado -> ${derrotadosTexto}\n\nMediador -> ${mediadorTexto}\n\nData e hora -> ${dataHoraFormatada}\n\nTipo de vitória -> ${tipoFormatado}\n\nPrint:`;

  if (partida.printInfo) {
    descricao += `\n\n${partida.printInfo}`;
  }

  const embed = new EmbedBuilder()
    .setColor(_cor(guildId))
    .setDescription(descricao);

  if (partida.printUrl) {
    embed.setImage(partida.printUrl);
  }

  const payload = painelV2FromEmbed(embed);

  const mencoes = [vencedorId, ...(partida.jogadores || []).map((j) => j.id), partida.mediadorId].filter(Boolean);
  await canalMural.send({
    ...payload,
    allowedMentions: { users: mencoes },
  }).catch((err) => console.error('[MURAL] Erro ao enviar painel no mural de partidas:', err.message));
}

/**
 * Processa somente `pg Nome Sobrenome` ou `pago Nome Sobrenome` dentro de
 * uma partida. Quando os pagamentos são confirmados, a sala é criada usando
 * o subtipo escolhido pelos jogadores nessa fila.
 */
async function handlePartidaMessage(message) {
  if (!message?.guild || message.author?.bot) return false;

  const partida = _partidaDoCanal(message.guildId, message.channelId);

  // Captura discreta de print de vitória enviado no tópico/canal da partida
  if (partida) {
    let printUrl = null;
    if (message.attachments && message.attachments.size > 0) {
      const att = message.attachments.find((a) =>
        (a.contentType && a.contentType.startsWith('image/')) ||
        /\.(png|jpe?g|webp|gif)$/i.test(a.name || a.url || '')
      );
      if (att) printUrl = att.url;
    }
    if (!printUrl && typeof message.content === 'string') {
      const urlMatch = message.content.match(/https?:\/\/\S+\.(?:png|jpe?g|webp|gif)(?:\?\S*)?/i);
      if (urlMatch) printUrl = urlMatch[0];
    }
    if (printUrl) {
      partida.printUrl = printUrl;
      partida.printAuthorId = message.author.id;
      partida.printTimestamp = Date.now();
      partida.ultimaAtividade = Date.now();
      _salvar();
      processarPrintComIA(partida, printUrl).catch(() => {});
    }
  }

  const texto = String(message.content ?? '').trim();
  const match = texto.match(/^(?:pg|pago)\s+(.+)$/i);
  if (!match) return false;

  const { verificarPlanoAtivo } = require('./plano_check');
  const plano = verificarPlanoAtivo(message.guildId, message.member);
  if (!plano.ativo) {
    await message.reply('❌ Este servidor não possui um plano ativo para gerenciar partidas e pagamentos.').catch(() => {});
    return true;
  }

  if (!partida || !['mediador', 'pagamentos_confirmados', 'sala_criada'].includes(partida.estado)) return false;

  if (!_jogador(partida, message.author.id)) {
    await _responderPagamento(
      message,
      _pagamentoStatusEmbed(
        message.guildId,
        partida,
        'PAGAMENTO NÃO VINCULADO',
        'Somente os jogadores desta partida podem confirmar um pagamento.',
        0xe74c3c,
      ),
    );
    return true;
  }

  const nomeTitular = match[1].trim().slice(0, 160);
  if (nomeTitular.split(/\s+/).filter(Boolean).length < 2) {
    await _responderPagamento(
      message,
      _pagamentoStatusEmbed(
        message.guildId,
        partida,
        'NOME INCOMPLETO',
        'Envie somente neste formato: `pg Carla Joelma`.',
        0xe74c3c,
      ),
    );
    return true;
  }

  partida.titularInformado ??= {};
  partida.titularInformado[message.author.id] = nomeTitular;
  partida.ultimaTentativaPagamento ??= {};
  const agora = Date.now();
  partida.ultimaAtividade = agora;
  const ultima = Number(partida.ultimaTentativaPagamento[message.author.id] ?? 0);
  if (agora - ultima < 10000) {
    await _responderPagamento(
      message,
      _pagamentoStatusEmbed(
        message.guildId,
        partida,
        'AGUARDE UM MOMENTO',
        'A consulta automática foi limitada temporariamente. O bot também checa a cada 10 segundos automaticamente.',
        0xf1c40f,
      ),
    );
    return true;
  }
  partida.ultimaTentativaPagamento[message.author.id] = agora;
  _salvar();

  if (partida.pagamentosConfirmados?.[message.author.id]) {
    if (partida.estado === 'pagamentos_confirmados' && !partida.sala?.roomId) {
      await _criarSalaAutomaticamente(message.guildId, partida, message.channel);
    }
    await _responderPagamento(
      message,
      _pagamentoStatusEmbed(
        message.guildId,
        partida,
        'PAGAMENTO JÁ CONFIRMADO',
        'Seu pagamento já foi confirmado.',
        0x2ecc71,
      ),
    );
    return true;
  }

  const { verificarPagamentoMediador } = require('./fila_mediador');
  const resultado = await verificarPagamentoMediador(message.guildId, partida.mediadorId, {
    valor: partida.valor,
    nome: nomeTitular,
    since: partida.criadoEm ?? agora,
  });

  if (!resultado.ok) {
    await _responderPagamento(
      message,
      _pagamentoStatusEmbed(
        message.guildId,
        partida,
        'PAGAMENTO NÃO CONFIRMADO',
        resultado.reason || 'Não encontramos um pagamento aprovado com esse valor e titular. Confira os dados e tente novamente.',
        0xe74c3c,
      ),
    );
    return true;
  }

  partida.pagamentosConfirmados ??= {};
  partida.pagamentosConfirmados[message.author.id] = {
    nomeTitular,
    provider: resultado.provider ?? null,
    paymentId: resultado.paymentId ?? null,
    confirmadoEm: new Date().toISOString(),
  };
  const todosConfirmados = partida.jogadores.every((item) => partida.pagamentosConfirmados[item.id]);
  if (todosConfirmados) partida.estado = 'pagamentos_confirmados';
  _salvar();
  const salaCriada = todosConfirmados
    ? await _criarSalaAutomaticamente(message.guildId, partida, message.channel)
    : false;
  if (salaCriada) {
    // Reutiliza a mensagem do mediador como painel da sala. Isso evita enviar
    // painéis extras e impede que o painel antigo sobrescreva ID e senha.
    await _atualizarPainelSala(message.guildId, partida, message.channel);
  } else {
    await _atualizarMediador(
      message.guildId,
      partida,
      message.channel,
      todosConfirmados
        ? 'Os dois pagamentos foram confirmados, mas não foi possível criar a sala agora. Tente confirmar novamente em alguns segundos.'
        : 'Pagamento confirmado. Aguardando o outro jogador.',
    );
  }
  await _responderPagamento(
    message,
    _pagamentoStatusEmbed(
      message.guildId,
      partida,
      todosConfirmados ? 'PAGAMENTOS CONFIRMADOS' : 'PAGAMENTO CONFIRMADO',
      todosConfirmados
        ? salaCriada
          ? 'Os dois jogadores foram confirmados. Consulte o painel abaixo para acessar a sala.'
          : 'Os dois jogadores foram confirmados, mas a sala ainda não pôde ser criada. Envie `pg nome sobrenome` novamente para tentar.'
        : 'Seu pagamento foi confirmado. O outro jogador ainda precisa enviar `pg nome sobrenome`.',
      0x2ecc71,
    ),
  );
  return true;
}

function _partidaAcessivel(interaction, partida) {
  return Boolean(partida && interaction.channelId === partida.channelId);
}

async function criarPartida({ guildId, canal, jogadores, mediadorId, setup, subtipo, valor, tipo, modo, client }) {
  const partida = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    channelId: canal.id,
    confirmacaoMsgId: null,
    mediadorMsgId: null,
    pagamentoMsgId: null,
    modo,
    tipo,
    subtipo: subtipo ?? null,
    valor,
    mediadorId,
    jogadores: jogadores.map((j, index) => {
      const membro = canal.guild?.members?.cache?.get(j.id);
      return {
        id: j.id,
        nome: membro?.displayName || membro?.user?.globalName || membro?.user?.username || `Jogador ${index + 1}`,
      };
    }),
    confirmados: [],
    estado: 'confirmacao',
    resultado: null,
    analistaId: null,
    streamerId: setup.streamerId ?? null,
    descricaoPainel: setup.partidaDescricao ?? null,
    criadoEm: Date.now(),
    ultimaAtividade: Date.now(),
    pagamentosConfirmados: {},
    ultimaTentativaPagamento: {},
    salaPronta: false,
  };
  const g = _guild(guildId);
  g.partidas.push(partida);
  _salvar();

  let mensagem;
  try {
    const participantes = _participantes(partida, mediadorId);
    const mencoes = participantes.map((id) => `<@${id}>`).join(' ');

    mensagem = await canal.send(
      painelV2FromEmbed(
        _confirmacaoEmbed(guildId, partida, canal.guild),
        _confirmacaoComponentes(partida),
      ),
    );

    if (mencoes) {
      await canal.send({
        content: mencoes,
        allowedMentions: { users: participantes },
      }).catch((err) => console.error('[PARTIDA] Falha ao enviar menções no tópico:', err.message));
    }
  } catch (error) {
    const gAtual = _guild(guildId);
    gAtual.partidas = gAtual.partidas.filter((item) => item.id !== partida.id);
    _salvar();
    throw error;
  }
  partida.confirmacaoMsgId = mensagem.id;
  _salvar();
  return partida;
}

async function _cancelar(guildId, partida, canal, client) {
  const g = _guild(guildId);
  g.partidas = g.partidas.filter((item) => item.id !== partida.id);
  _salvar();
  if (partida.mediadorId) {
    const { liberarMediador } = require('./fila_mediador');
    liberarMediador(guildId, partida.mediadorId, client, { restaurarInicio: true });
  }
  await _renomearPartida(canal, 'partida-cancelada');
  const mensagem = await canal.messages.fetch(partida.confirmacaoMsgId).catch(() => null);
  if (mensagem) {
    await mensagem.edit(painelV2FromEmbed(
      _aviso('Partida cancelada', 'Esta partida foi cancelada.'),
    )).catch(() => {});
  }
  if (partida.streamerId) {
    await require('./fila_streamer').liberarPartidaStreamer(guildId, partida, client);
  }
}

async function _confirmar(guildId, partida, interaction, client) {
  const userId = String(interaction.user.id).trim();
  if (!_podeConfirmar(partida, userId)) return false;
  if (!partida.confirmados.map(String).includes(userId)) {
    partida.confirmados.push(userId);
  }
  _salvar();
  await interaction.deferUpdate();
  const canal = interaction.channel;
  const todosRequeridos = _participantesConfirmacao(partida);
  const faltamConfirmar = todosRequeridos.filter((id) => !partida.confirmados.map(String).includes(id));
  if (faltamConfirmar.length > 0) {
    await _atualizarConfirmacao(guildId, partida, canal);
    return true;
  }

  const { getConfig } = require('./configurar');
  const cfg = getConfig(guildId);

  partida.estado = 'mediador';
  _salvar();
  await _renomearPartida(canal, _nomeTopicoPagamento(partida.valor));
  const antigo = await canal.messages.fetch(partida.confirmacaoMsgId).catch(() => null);
  if (antigo) await antigo.delete().catch(() => {});
  const guild = interaction.guild;
  await _log(guild, cfg.channels?.logsConfirmadas,
    new EmbedBuilder()
      .setTitle('PARTIDA CONFIRMADA')
      .setColor(_cor(guildId))
      .setDescription(`**${partida.modo} ${partida.tipo}**  •  **${_valor(partida.valor)}**`)
      .addFields({ name: 'Jogadores', value: todosRequeridos.map((jId) => `• <@${jId}>`).join('\n') }));
  await _enviarPainelMediador(guildId, partida, canal, client);
  return true;
}

async function _definirResultado(guildId, partida, interaction, tipo) {
  if (interaction.user.id !== partida.mediadorId || !partida.resultado) return false;
  partida.resultado.tipo = tipo;
  partida.estado = 'final';
  _salvar();
  await interaction.update(painelV2FromEmbed(
    _finalEmbed(guildId, partida, interaction.guild),
    _finalComponentes(partida),
  ));
  return true;
}

async function _fecharPartida(guildId, partida, canal, client, interaction = null, motivo = 'finalizada') {
  if (partida.callRoom?.id) {
    try {
      const { finalizarSalaCall } = require('./team_ryze_calls');
      finalizarSalaCall(partida.callRoom.id, motivo === 'inatividade' ? 'Partida encerrada por inatividade' : 'Partida finalizada').catch(() => {});
    } catch (_) {}
  }
  const { registrarPartidaMediada, liberarMediador } = require('./fila_mediador');
  if (partida.mediadorId) {
    registrarPartidaMediada(guildId, partida.mediadorId);
    liberarMediador(guildId, partida.mediadorId, client);
  }
  require('./fila_analista').registrarAnalise(guildId, partida);
  if (partida.streamerId) {
    require('./fila_streamer').registrarPartidaStreamer(guildId, partida);
  }
  // Registrar a partida para todos os jogadores do perfil do servidor se houver vencedor.
  if (partida.resultado?.vencedorId) {
    require('./perfil').registrarPartida(
      guildId,
      partida.jogadores.map((jogador) => jogador.id),
      partida.resultado.vencedorId,
      partida.resultado.tipo,
    );
    require('./loja').registrarRecompensas(
      guildId,
      partida.resultado.vencedorId,
      partida.jogadores.map((jogador) => jogador.id),
      partida.id,
    );
    if (client) {
      await enviarMuralVitoria(guildId, partida, client).catch((errMural) => {
        console.error('[MURAL] Falha ao enviar para mural de partidas:', errMural.message);
      });
    }
  }

  const cfg = _config(guildId);
  const guild = canal?.guild || client?.guilds?.cache?.get(guildId);
  if (guild) {
    const fields = [
      { name: 'Valor', value: _valor(partida.valor), inline: true },
    ];
    if (partida.resultado?.vencedorId) {
      fields.unshift(
        { name: 'Vencedor', value: `<@${partida.resultado.vencedorId}>`, inline: true },
        { name: 'Resultado', value: partida.resultado.tipo || 'Vitória normal', inline: true },
      );
    } else if (motivo === 'inatividade') {
      fields.push({ name: 'Motivo', value: 'Encerrada por inatividade', inline: true });
    } else if (motivo === 'mediador_select') {
      fields.push({ name: 'Motivo', value: 'Encerrada pelo mediador', inline: true });
    }

    await _log(guild, cfg.channels?.logsEncerradas,
      new EmbedBuilder()
        .setTitle('PARTIDA ENCERRADA')
        .setColor(_cor(guildId))
        .setDescription(
          motivo === 'inatividade'
            ? 'A partida foi encerrada automaticamente por inatividade.'
            : 'A partida foi finalizada e o mediador foi liberado.'
        )
        .addFields(fields)
    ).catch(() => {});
  }

  const g = _guild(guildId);
  g.partidas = g.partidas.filter((item) => item.id !== partida.id);
  _salvar();

  if (interaction && !interaction.replied && !interaction.deferred) {
    await interaction.reply({
      content: _msg(guildId, 'partida_encerrada', 'Partida encerrada. O canal será fechado agora.'),
      flags: MessageFlags.Ephemeral,
    }).catch(() => {});
  }

  if (partida.streamerId && client) {
    await require('./fila_streamer').liberarPartidaStreamer(guildId, partida, client).catch(() => {});
  }
  if (canal && typeof canal.delete === 'function') {
    await canal.delete('Partida encerrada').catch(() => {});
  }
}

async function handlePartida(interaction, client) {
  const id = interaction.customId ?? '';
  if (!id.startsWith('partida:')) return false;
  const [, partidaId, acao] = id.split(':');
  const partida = _partida(interaction.guildId, partidaId);
  if (!_partidaAcessivel(interaction, partida)) return false;

  partida.ultimaAtividade = Date.now();
  _salvar();

  if (acao === 'confirmar') {
    if (!_podeConfirmar(partida, interaction.user.id)) {
      await interaction.reply({ content: _msg(interaction.guildId, 'partida_jogadores_confirmar', 'Somente os jogadores e o streamer desta partida podem confirmar.'), flags: MessageFlags.Ephemeral });
      return true;
    }
    return _confirmar(interaction.guildId, partida, interaction, client);
  }

  if (acao === 'cancelar') {
    if (!_podeConfirmar(partida, interaction.user.id)) {
      await interaction.reply({ content: _msg(interaction.guildId, 'partida_jogadores_cancelar', 'Somente os jogadores e o streamer desta partida podem cancelar.'), flags: MessageFlags.Ephemeral });
      return true;
    }
    await interaction.reply({ content: _msg(interaction.guildId, 'partida_cancelada', 'Partida cancelada. O canal será fechado agora.'), flags: MessageFlags.Ephemeral });
    await _cancelar(interaction.guildId, partida, interaction.channel, client);
    return true;
  }

  if (acao === 'copiar') {
    const { obterPixMediador } = require('./fila_mediador');
    const pix = obterPixMediador(interaction.guildId, partida.mediadorId);
    await interaction.reply({
      content: pix?.chave || _msg(interaction.guildId, 'partida_pix_nao_configurado', 'Chave PIX não configurada.'),
      flags: MessageFlags.Ephemeral,
    });
    return true;
  }

  if (acao === 'copiar_sala_id' || acao === 'copiar_sala_senha') {
    const valorSala = acao === 'copiar_sala_id' ? partida.sala?.roomId : partida.sala?.password;
    await interaction.reply({
      content: valorSala ? String(valorSala) : 'A sala ainda não está disponível.',
      flags: MessageFlags.Ephemeral,
    });
    return true;
  }

  if (interaction.user.id !== partida.mediadorId) {
    await interaction.reply({ content: _msg(interaction.guildId, 'partida_mediador_restrito', 'Somente o mediador designado pode usar este painel.'), flags: MessageFlags.Ephemeral });
    return true;
  }

  if (acao === 'gerenciar' && interaction.isStringSelectMenu()) {
    const escolha = interaction.values[0];
    if (escolha === 'vencedor') {
      await interaction.reply({
        ...painelV2FromEmbed(
          _gerenciamentoEmbed(interaction.guildId, partida, 'Selecione o vencedor da partida.', interaction.guild),
          _vencedorComponentes(partida, interaction.guild),
        ),
        flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
      });
    } else if (escolha === 'valor') {
      const modal = new ModalBuilder().setCustomId(`partida:${partida.id}:modal_valor`).setTitle('Redefinir valor');
      modal.addComponents(new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('novo_valor').setLabel('Novo valor da partida').setStyle(TextInputStyle.Short)
          .setPlaceholder('Ex: 10,00').setRequired(true),
      ));
      await interaction.showModal(modal);
    } else if (escolha === 'enviar_sala') {
      const modal = new ModalBuilder()
        .setCustomId(`partida:${partida.id}:modal_sala`)
        .setTitle('Enviar sala');

      const idInput = new TextInputBuilder()
        .setCustomId('sala_id')
        .setLabel('ID da sala')
        .setPlaceholder('Digite o ID da sala')
        .setStyle(TextInputStyle.Short)
        .setRequired(true);
      if (partida.sala?.roomId) {
        idInput.setValue(String(partida.sala.roomId));
      }

      const senhaInput = new TextInputBuilder()
        .setCustomId('sala_senha')
        .setLabel('Senha da sala')
        .setPlaceholder('Digite a senha da sala')
        .setStyle(TextInputStyle.Short)
        .setRequired(true);
      if (partida.sala?.password) {
        senhaInput.setValue(String(partida.sala.password));
      }

      modal.addComponents(
        new ActionRowBuilder().addComponents(idInput),
        new ActionRowBuilder().addComponents(senhaInput),
      );
      await interaction.showModal(modal);
    } else if (escolha === 'analista') {
      await interaction.deferUpdate().catch(() => {});
      let analistaId = null;
      try {
        analistaId = await require('./fila_mediador').pegarAnalista(interaction.guildId, interaction.guild, client);
      } catch (errFila) {
        console.error('[PARTIDA] Erro ao pegar analista da fila:', errFila.message);
      }

      if (!analistaId) {
        await interaction.followUp({
          content: _msg(interaction.guildId, 'partida_analista_indisponivel', 'Não há analistas disponíveis na fila no momento.'),
          flags: MessageFlags.Ephemeral,
        }).catch(() => {});
        return true;
      }

      partida.analistaId = analistaId;
      if (interaction.channel.isThread?.()) {
        await interaction.channel.members.add(analistaId).catch(() => {});
      } else if (interaction.channel.permissionOverwrites) {
        await interaction.channel.permissionOverwrites.edit(analistaId, { ViewChannel: true, SendMessages: true }).catch(() => {});
      }
      _salvar();

      // Obter nome do analista
      const analistaMember = await interaction.guild.members.fetch(analistaId).catch(() => null);
      const analistaNome = analistaMember?.displayName || analistaMember?.user?.globalName || analistaMember?.user?.username || 'Analista';

      // Obter nomes dos jogadores
      const timeA = partida.jogadores[0]?.nome || 'Jogador 1';
      const timeB = partida.jogadores[1]?.nome || 'Jogador 2';

      // 1. Enviar aviso de que o analista foi chamado
      const msgAviso = _msg(interaction.guildId, 'partida_analista_chamado', `<@${analistaId}> foi chamado para esta partida.`);
      try {
        await interaction.channel.send({
          content: msgAviso,
          allowedMentions: { users: [analistaId] },
        });
      } catch (errAviso) {
        console.warn('[PARTIDA] Aviso via channel.send falhou, usando followUp:', errAviso.message);
        await interaction.followUp({
          content: msgAviso,
          allowedMentions: { users: [analistaId] },
        }).catch(() => {});
      }

      // 2. Chamar API Team Ryze Calls para criar sala de chamada/transmissão
      const { criarSalaCall, painelCall } = require('./team_ryze_calls');
      let room = null;
      try {
        room = await criarSalaCall({
          title: `${timeA} vs ${timeB}`,
          mode: partida.modo || '2x2',
          type: partida.tipo || 'Mobile',
          value: Number(partida.valor) || 0,
          analyst: {
            id: analistaId,
            name: analistaNome,
          },
          expiresIn: 7200,
          maxParticipants: partida.modo === '4x4' ? 10 : 8,
        });
      } catch (err) {
        console.error('[RYZE CALLS] Erro ao criar sala:', err.message);
      }

      if (!room) {
        const fallbackId = `ryze_${Math.random().toString(36).slice(2, 10)}`;
        room = {
          id: fallbackId,
          title: `${timeA} vs ${timeB}`,
          mode: partida.modo || '2x2',
          type: partida.tipo || 'Mobile',
          value: Number(partida.valor) || 0,
          url: `https://calls.teamryze.com/room/${fallbackId}`,
          analyst: { id: analistaId, name: analistaNome },
        };
      }

      partida.callRoom = room;
      _salvar();

      const mencoesUsers = [...(partida.jogadores || []).map((j) => j.id), partida.mediadorId, analistaId].filter(Boolean);
      const painelObj = painelCall(interaction.guildId, partida, room, analistaId, partida.mediadorId);

      // 3. Enviar o painel da sala com link direto
      try {
        await interaction.channel.send({
          ...painelObj,
          allowedMentions: { users: mencoesUsers },
        });
      } catch (errPainel) {
        console.error('[RYZE CALLS] Envio via Components V2 falhou, tentando Embed clássico:', errPainel.message);
        try {
          await interaction.channel.send({
            content: painelObj.content,
            embeds: painelObj.embeds,
            components: painelObj.componentsClassic,
            allowedMentions: { users: mencoesUsers },
          });
        } catch (errFallback) {
          console.error('[RYZE CALLS] Envio fallback clássico falhou, enviando texto direto:', errFallback.message);
          await interaction.channel.send({
            content: `**[SALA DE CHAMADA & TRANSMISSÃO 60 FPS]**\nAnalista <@${analistaId}> e jogadores, entrem no link da chamada:\n🔗 **${room.url}**`,
            allowedMentions: { users: mencoesUsers },
          }).catch(() => {});
        }
      }
    } else if (escolha === 'fechar_partida') {
      await _fecharPartida(interaction.guildId, partida, interaction.channel, client, interaction, 'mediador_select');
      return true;
    }
    return true;
  }

  if (acao === 'vencedor' && interaction.isStringSelectMenu()) {
    partida.resultado = { vencedorId: interaction.values[0], tipo: 'Aguardando tipo de vitória' };
    _salvar();
    await interaction.update(painelV2FromEmbed(
      _gerenciamentoEmbed(interaction.guildId, partida, 'Escolha como a vitória foi registrada.', interaction.guild),
      _resultadoComponentes(partida),
    ));
    return true;
  }

  if ((acao === 'wo' || acao === 'normal') && interaction.isButton()) {
    return _definirResultado(interaction.guildId, partida, interaction, acao === 'wo' ? 'Vitória por W.O' : 'Vitória normal');
  }

  if (acao === 'cancelar_resultado' && interaction.isButton()) {
    partida.resultado = null;
    _salvar();
    await interaction.update(painelV2FromEmbed(
      _gerenciamentoEmbed(interaction.guildId, partida, 'Escolha cancelada. O resultado ainda não foi definido.', interaction.guild),
      _gerenciamentoComponentes(partida),
    ));
    return true;
  }

  if (acao === 'modal_valor' && interaction.isModalSubmit()) {
    const bruto = interaction.fields.getTextInputValue('novo_valor').trim().replace(',', '.');
    const valor = Number.parseFloat(bruto);
    if (!Number.isFinite(valor) || valor < 0) {
      await interaction.reply({ content: _msg(interaction.guildId, 'partida_valor_invalido', 'Informe um valor numérico válido.'), flags: MessageFlags.Ephemeral });
      return true;
    }
    partida.valor = valor;
    _salvar();
    await _renomearPartida(interaction.channel, _nomeTopicoPagamento(valor));
    await interaction.reply({ content: _msg(interaction.guildId, 'partida_valor_atualizado', `O valor da partida agora é ${_valor(valor)}.`), flags: MessageFlags.Ephemeral });
    await _atualizarMediador(interaction.guildId, partida, interaction.channel);
    const pagamento = partida.pagamentoMsgId ? await interaction.channel.messages.fetch(partida.pagamentoMsgId).catch(() => null) : null;
    if (pagamento) {
      const arquivoQr = `pix-${partida.id}.png`;
      await pagamento.edit(painelV2FromEmbed(
        _pagamentoEmbed(
          interaction.guildId,
          partida,
          arquivoQr,
          require('./fila_mediador').obterPixMediador(interaction.guildId, partida.mediadorId),
        ),
        [new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId(`partida:${partida.id}:copiar`).setLabel('Copiar chave PIX').setStyle(ButtonStyle.Secondary),
        )],
      )).catch(() => {});
    }
    return true;
  }

  if (acao === 'modal_sala' && interaction.isModalSubmit()) {
    const roomId = interaction.fields.getTextInputValue('sala_id').trim();
    const password = interaction.fields.getTextInputValue('sala_senha').trim();

    if (!roomId || !password) {
      await interaction.reply({
        content: '⚠️ Preencha tanto o ID quanto a senha da sala.',
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    partida.sala = {
      roomId,
      password,
    };
    partida.salaPronta = true;
    partida.salaErro = null;
    partida.estado = 'sala_criada';
    _salvar();

    await interaction.reply({
      content: '✅ Informações da sala enviadas com sucesso no canal.',
      flags: MessageFlags.Ephemeral,
    });

    await _atualizarPainelSala(interaction.guildId, partida, interaction.channel);
    return true;
  }

  if (acao === 'fechar' && interaction.isButton()) {
    if (!partida.resultado?.tipo || partida.resultado.tipo === 'Aguardando tipo de vitória') {
      await interaction.reply({ content: _msg(interaction.guildId, 'partida_resultado_pendente', 'Defina o tipo de vitória antes de fechar.'), flags: MessageFlags.Ephemeral });
      return true;
    }
    await _fecharPartida(interaction.guildId, partida, interaction.channel, client, interaction, 'finalizada');
    return true;
  }

  return false;
}

let _intervaloInatividade = null;
let _intervaloPagamentos = null;

function iniciarMonitoramentoPagamentos(client) {
  if (_intervaloPagamentos) return;
  _intervaloPagamentos = setInterval(async () => {
    try {
      for (const [guildId, guildData] of Object.entries(_dados)) {
        const partidasAguardando = (guildData.partidas ?? []).filter(
          (p) => p.estado === 'mediador' && p.mediadorId,
        );
        if (partidasAguardando.length === 0) continue;

        const { obterConfiguracaoPagamento, verificarPagamentoMediador } = require('./fila_mediador');

        for (const partida of partidasAguardando) {
          const config = obterConfiguracaoPagamento(guildId, partida.mediadorId);
          if (!config || config.provider === 'pix') continue;

          const pendentes = (partida.jogadores ?? []).filter(
            (j) => !partida.pagamentosConfirmados?.[j.id],
          );
          if (pendentes.length === 0) continue;

          const guild = client.guilds?.cache?.get(guildId);

          for (const jogador of pendentes) {
            const membro = guild?.members?.cache?.get(jogador.id);
            const nomesCandidatos = [
              partida.titularInformado?.[jogador.id],
              jogador.nome,
              membro?.displayName,
              membro?.user?.globalName,
              membro?.user?.username,
            ].filter(Boolean);

            const resultado = await verificarPagamentoMediador(guildId, partida.mediadorId, {
              valor: partida.valor,
              nomes: nomesCandidatos,
              since: partida.criadoEm || (Date.now() - 30 * 60 * 1000),
            }).catch(() => ({ ok: false }));

            if (resultado && resultado.ok) {
              const jaUsado = Object.values(partida.pagamentosConfirmados || {}).some(
                (p) => p.paymentId && p.paymentId === resultado.paymentId,
              );
              if (jaUsado) continue;

              partida.pagamentosConfirmados ??= {};
              partida.pagamentosConfirmados[jogador.id] = {
                nomeTitular: resultado.nomePagador || jogador.nome,
                provider: resultado.provider ?? null,
                paymentId: resultado.paymentId ?? null,
                confirmadoEm: new Date().toISOString(),
              };

              const todosConfirmados = partida.jogadores.every((item) => partida.pagamentosConfirmados[item.id]);
              if (todosConfirmados) partida.estado = 'pagamentos_confirmados';
              partida.ultimaAtividade = Date.now();
              _salvar();

              const canal = await client.channels.fetch(partida.channelId).catch(() => null);
              if (canal) {
                const salaCriada = todosConfirmados
                  ? await _criarSalaAutomaticamente(guildId, partida, canal)
                  : false;

                if (salaCriada) {
                  await _atualizarPainelSala(guildId, partida, canal);
                } else {
                  await _atualizarMediador(
                    guildId,
                    partida,
                    canal,
                    todosConfirmados
                      ? 'Os dois pagamentos foram confirmados via API. Sala em preparação...'
                      : `Pagamento de <@${jogador.id}> confirmado via API. Aguardando o outro jogador.`,
                  );
                }

                await canal.send({
                  embeds: [
                    _pagamentoStatusEmbed(
                      guildId,
                      partida,
                      todosConfirmados ? 'PAGAMENTOS CONFIRMADOS AUTOMATICAMENTE' : 'PAGAMENTO CONFIRMADO AUTOMATICAMENTE',
                      todosConfirmados
                        ? salaCriada
                          ? `✅ Pagamento de <@${jogador.id}> confirmado via **${resultado.provider}**!\n🎮 Ambos os pagamentos confirmados e sala criada!`
                          : `✅ Pagamento de <@${jogador.id}> confirmado via **${resultado.provider}**!\n🎮 Ambos os pagamentos confirmados!`
                        : `✅ Pagamento de <@${jogador.id}> (R$ ${Number(partida.valor || 0).toFixed(2).replace('.', ',')}) confirmado via **${resultado.provider}**.\n⏳ Aguardando confirmação do outro jogador...`,
                      0x2ecc71,
                    ),
                  ],
                }).catch(() => {});
              }
            }
          }
        }
      }
    } catch (errLoop) {
      console.error('[PAGAMENTOS-10S] Erro no loop de verificação de pagamentos:', errLoop.message);
    }
  }, 10000);
}

function iniciarMonitoramentoInatividade(client) {
  if (_intervaloInatividade) return;
  _intervaloInatividade = setInterval(async () => {
    try {
      const agora = Date.now();
      for (const [guildId, guildData] of Object.entries(_dados)) {
        const cfg = _config(guildId);
        const tempoLimiteMinutos = cfg?.tempoInatividade;
        if (!tempoLimiteMinutos || tempoLimiteMinutos <= 0) continue;
        const limiteMs = tempoLimiteMinutos * 60 * 1000;

        const partidasParaExcluir = [];
        for (const partida of guildData.partidas ?? []) {
          const ultima = partida.ultimaAtividade || partida.criadoEm || 0;
          if (agora - ultima > limiteMs) {
            partidasParaExcluir.push(partida);
          }
        }

        for (const partida of partidasParaExcluir) {
          try {
            const canal = await client.channels.fetch(partida.channelId).catch(() => null);
            if (canal) {
              await canal.send({
                content: `⚠️ Esta partida foi encerrada automaticamente por inatividade (${tempoLimiteMinutos} minutos sem atividade).`,
              }).catch(() => {});
            }
            await _fecharPartida(guildId, partida, canal, client, null, 'inatividade');
          } catch (err) {
            console.error(`[INATIVIDADE] Erro ao encerrar partida ${partida.id}:`, err.message);
          }
        }
      }
    } catch (err) {
      console.error('[INATIVIDADE] Erro no loop de monitoramento de inatividade:', err.message);
    }
  }, 30000);
}

async function restaurarPartidas(client) {
  iniciarMonitoramentoInatividade(client);
  iniciarMonitoramentoPagamentos(client);
  for (const [guildId, guildData] of Object.entries(_dados)) {
    for (const partida of guildData.partidas ?? []) {
      try {
        const canal = await client.channels.fetch(partida.channelId).catch(() => null);
        if (!canal) continue;
        if (partida.estado === 'confirmacao') {
          await _atualizarConfirmacao(guildId, partida, canal);
        }
        if (partida.estado === 'mediador' && partida.mediadorMsgId) {
          await _atualizarMediador(guildId, partida, canal);
        }
        if (partida.estado === 'final' && partida.mediadorMsgId) {
          const msg = await canal.messages.fetch(partida.mediadorMsgId).catch(() => null);
          if (msg && typeof msg.edit === 'function') {
            await msg.edit({
              ...painelV2FromEmbed(
                _finalEmbed(guildId, partida, canal.guild),
                _finalComponentes(partida),
              ),
              allowedMentions: { users: _participantes(partida) },
            });
          }
        }
        if (partida.sala) await _atualizarPainelSala(guildId, partida, canal);
      } catch (error) {
        console.error(`[PARTIDA] Falha ao restaurar partida ${partida.id}:`, error.message);
      }
    }
  }
}

function _partidasConfirmadasMediador(guildId, userId) {
  const todasPartidas = _guild(guildId).partidas || [];
  return todasPartidas.filter(
    (p) => p.mediadorId === userId && p.estado !== 'confirmacao'
  );
}

function painelAuxInicial(guildId, userId, guild = null) {
  const partidas = _partidasConfirmadasMediador(guildId, userId);
  if (partidas.length === 0) {
    return {
      content: 'ℹ️ Você não possui nenhuma partida ativa ou confirmada sob sua mediação no momento.',
      flags: MessageFlags.Ephemeral,
    };
  }

  const opcoes = partidas.slice(0, 25).map((p) => {
    const timeA = p.jogadores[0]?.nome || 'Time A';
    const timeB = p.jogadores[1]?.nome || 'Time B';
    const duelo = p.jogadores.length >= 2 ? `${timeA} vs ${timeB}` : (p.jogadores[0]?.nome || 'Partida');
    const label = `${p.modo} ${p.tipo} - ${_valor(p.valor)}`.slice(0, 100);
    const desc = `${duelo} | ID: ${p.id}`.slice(0, 100);

    return {
      label,
      description: desc,
      value: p.id,
    };
  });

  const row = new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId('aux:select:partida')
      .setPlaceholder('Selecione a partida confirmada')
      .addOptions(opcoes)
  );

  const embed = new EmbedBuilder()
    .setColor(_cor(guildId))
    .setTitle('PAINEL AUXILIAR DO MEDIADOR')
    .setDescription(
      `Selecione no menu abaixo a partida confirmada que você deseja gerenciar (**${partidas.length}** partida(s) ativa(s)):`
    );

  return {
    ...painelV2FromEmbed(embed, [row]),
    flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
  };
}

function painelAuxTipo(guildId, partida, guild = null) {
  const embed = new EmbedBuilder()
    .setColor(_cor(guildId))
    .setTitle(`AUXILIAR MEDIADOR | ${partida.modo} ${partida.tipo}`)
    .setDescription('Selecione o tipo de resultado para esta partida:')
    .addFields(
      { name: 'Formato', value: `${partida.modo} ${partida.tipo}`, inline: true },
      { name: 'Valor', value: _valor(partida.valor), inline: true },
      { name: 'Jogadores', value: _listaJogadores(partida, partida.jogadores.map((j) => j.id), guild), inline: false },
    );

  const rowBotoes = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`aux:${partida.id}:tipo:normal`)
      .setLabel('vitória normal')
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(`aux:${partida.id}:tipo:wo`)
      .setLabel('vitória por w.o')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('aux:voltar:inicio')
      .setLabel('voltar')
      .setStyle(ButtonStyle.Secondary),
  );

  return {
    ...painelV2FromEmbed(embed, [rowBotoes]),
    flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
  };
}

function painelAuxVencedor(guildId, partida, tipo, guild = null) {
  const tipoFormatado = tipo === 'wo' ? 'Vitória por W.O' : 'Vitória normal';

  const opcoes = partida.jogadores.map((j, index) => ({
    label: _nome(partida, j.id, guild).slice(0, 100) || `Jogador ${index + 1}`,
    value: j.id,
    description: `Definir este jogador como vencedor (${tipoFormatado})`.slice(0, 100),
  }));

  if (partida.streamerId && !opcoes.some((o) => o.value === partida.streamerId)) {
    opcoes.push({
      label: `Streamer (${_nome(partida, partida.streamerId, guild)})`.slice(0, 100),
      value: partida.streamerId,
      description: `Definir o streamer como vencedor (${tipoFormatado})`.slice(0, 100),
    });
  }

  const rowSelect = new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId(`aux:${partida.id}:vencedor:${tipo}`)
      .setPlaceholder('Escolha o jogador que venceu a partida')
      .addOptions(opcoes)
  );

  const rowVoltar = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`aux:${partida.id}:voltar:tipo`)
      .setLabel('voltar')
      .setStyle(ButtonStyle.Secondary)
  );

  const embed = new EmbedBuilder()
    .setColor(_cor(guildId))
    .setTitle('AUXILIAR MEDIADOR | ESCOLHER VENCEDOR')
    .setDescription(`Tipo de resultado selecionado: **${tipoFormatado}**\n\nSelecione no menu abaixo o jogador vencedor da partida:`)
    .addFields(
      { name: 'Formato', value: `${partida.modo} ${partida.tipo}`, inline: true },
      { name: 'Valor', value: _valor(partida.valor), inline: true },
    );

  return {
    ...painelV2FromEmbed(embed, [rowSelect, rowVoltar]),
    flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
  };
}

function painelAuxFinalizar(guildId, partida, vencedorId, tipo, guild = null) {
  const tipoFormatado = tipo === 'wo' ? 'Vitória por W.O' : 'Vitória normal';
  const nomeVencedor = _nome(partida, vencedorId, guild);

  const embed = new EmbedBuilder()
    .setColor(_cor(guildId))
    .setTitle('AUXILIAR MEDIADOR | FINALIZAR PARTIDA')
    .setDescription(
      `Confira os dados da partida antes de encerrar:\n\n` +
      `🏆 **Vencedor:** <@${vencedorId}> (${nomeVencedor})\n` +
      `📋 **Resultado:** ${tipoFormatado}\n` +
      `💰 **Valor:** ${_valor(partida.valor)}\n` +
      `🎮 **Formato:** ${partida.modo} ${partida.tipo}\n\n` +
      `Clique no botão **finalizar** abaixo para encerrar a partida e liberar o canal.`
    );

  const rowBotoes = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`aux:${partida.id}:finalizar`)
      .setLabel('finalizar')
      .setStyle(ButtonStyle.Success),
  );

  return {
    ...painelV2FromEmbed(embed, [rowBotoes]),
    flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
  };
}

async function handleAux(interaction, client) {
  if (interaction.isChatInputCommand() && interaction.commandName === 'aux') {
    const painel = painelAuxInicial(interaction.guildId, interaction.user.id, interaction.guild);
    await interaction.reply(painel);
    return true;
  }

  const customId = interaction.customId ?? '';
  if (!customId.startsWith('aux:') && !customId.startsWith('aux_')) return false;

  const guildId = interaction.guildId;
  const userId = interaction.user.id;

  // Botão voltar para a lista inicial de partidas
  if (customId === 'aux:voltar:inicio') {
    const painel = painelAuxInicial(guildId, userId, interaction.guild);
    await interaction.update(painel);
    return true;
  }

  // Seleção de partida no menu inicial
  if (interaction.isStringSelectMenu() && customId === 'aux:select:partida') {
    const partidaId = interaction.values[0];
    const partida = _partida(guildId, partidaId);
    if (!partida) {
      await interaction.update({
        content: '🚫 Esta partida não foi encontrada ou já foi encerrada.',
        components: [],
        embeds: [],
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }
    if (partida.mediadorId !== userId) {
      await interaction.update({
        content: '🔒 Somente o mediador designado pode gerenciar esta partida.',
        components: [],
        embeds: [],
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    const painel = painelAuxTipo(guildId, partida, interaction.guild);
    await interaction.update(painel);
    return true;
  }

  // Ações de formato aux:${partidaId}:${acao}:${param}
  const partes = customId.split(':');
  const partidaId = partes[1];
  const acao = partes[2];
  const param = partes[3];

  const partida = _partida(guildId, partidaId);
  if (!partida && acao !== 'finalizar') {
    await interaction.update({
      content: '🚫 Esta partida não foi encontrada ou já foi encerrada.',
      components: [],
      embeds: [],
      flags: MessageFlags.Ephemeral,
    });
    return true;
  }

  if (partida && partida.mediadorId !== userId) {
    await interaction.reply({
      content: '🔒 Somente o mediador designado pode gerenciar esta partida.',
      flags: MessageFlags.Ephemeral,
    });
    return true;
  }

  // Voltar para a seleção de tipo de vitória (Passo 2)
  if (acao === 'voltar' && param === 'tipo') {
    const painel = painelAuxTipo(guildId, partida, interaction.guild);
    await interaction.update(painel);
    return true;
  }

  // Voltar para a seleção de vencedor (Passo 3)
  if (acao === 'voltar' && param === 'vencedor') {
    const tipo = partes[4] || 'normal';
    const painel = painelAuxVencedor(guildId, partida, tipo, interaction.guild);
    await interaction.update(painel);
    return true;
  }

  // Escolha do tipo: vitória normal ou vitória por w.o
  if (acao === 'tipo' && interaction.isButton()) {
    const tipo = param; // 'normal' ou 'wo'
    const painel = painelAuxVencedor(guildId, partida, tipo, interaction.guild);
    await interaction.update(painel);
    return true;
  }

  // Escolha do vencedor no select menu
  if (acao === 'vencedor' && interaction.isStringSelectMenu()) {
    const tipo = param; // 'normal' ou 'wo'
    const vencedorId = interaction.values[0];
    const tipoStr = tipo === 'wo' ? 'Vitória por W.O' : 'Vitória normal';

    partida.resultado = { vencedorId, tipo: tipoStr };
    _salvar();

    const painel = painelAuxFinalizar(guildId, partida, vencedorId, tipo, interaction.guild);
    await interaction.update(painel);
    return true;
  }

  // Botão finalizar
  if (acao === 'finalizar' && interaction.isButton()) {
    if (!partida) {
      await interaction.update({
        content: '🚫 Esta partida já foi encerrada.',
        components: [],
        embeds: [],
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    if (!partida.resultado?.vencedorId) {
      await interaction.reply({
        content: '⚠️ O vencedor da partida ainda não foi definido.',
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    partida.estado = 'final';
    _salvar();

    let canal = null;
    if (partida.channelId) {
      canal = await client.channels.fetch(partida.channelId).catch(() => null);
    }

    await interaction.update({
      content: `🏁 A partida **${partida.modo} ${partida.tipo}** foi finalizada com sucesso! O canal da partida foi encerrado.`,
      components: [],
      embeds: [],
      flags: MessageFlags.Ephemeral,
    });

    await _fecharPartida(guildId, partida, canal, client, null, 'finalizada');
    return true;
  }

  return false;
}

module.exports = {
  criarPartida,
  handlePartida,
  handlePartidaMessage,
  handleAux,
  restaurarPartidas,
  obterPartidaStreamerAtiva,
};