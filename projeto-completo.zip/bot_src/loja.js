'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const QRCode = require('qrcode');
const {
  EmbedBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  RoleSelectMenuBuilder,
  ChannelSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ChannelType,
  MessageFlags,
  PermissionFlagsBits,
} = require('discord.js');
const { getConfig, salvarConfiguracoesLoja, painelPrincipal } = require('./configurar');
const { painelV2FromEmbed } = require('./visual');
const { dataPath } = require('./data-path');
const { botManager, isBotsOwner } = require('./bots');

const DATA_FILE = dataPath('loja_data.json');
const MAX_PRODUCTS = 25;
const state = readData();
const pendingRoleProducts = new Map();
const pendingClosures = new Map();
const pendingPurchases = new Set();
const paymentWatchers = new Map();
const planExpiryWatchers = new Map();
const pendingLicenseRedeems = new Set();

const LICENSE_DEFAULTS = {
  appearance: {
    title: 'Acesso Premium ao Bot',
    description: 'Adquira seu bot e receba a chave de ativação após a confirmação do pagamento.',
    banner: null,
    thumbnail: null,
    color: 0x5865f2,
    button: {
      label: 'Comprar',
      style: 'Success',
      emoji: null,
    },
  },
  shop: {
    price: 10,
    topicChannelId: null,
    logChannelId: null,
    qrDark: '#111827',
    qrLight: '#ffffff',
    mpToken: null,
  },
  sales: [],
  panels: [],
};

function readData() {
  try {
    return fs.existsSync(DATA_FILE) ? JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')) : {};
  } catch (error) {
    console.error('[LOJA] Falha ao ler dados:', error.message);
    return {};
  }
}

let _saving = false;
let _savePending = false;
function saveData() {
  if (_saving) {
    _savePending = true;
    return;
  }
  _saving = true;
  const tmp = `${DATA_FILE}.tmp`;
  try {
    fs.mkdir(path.dirname(DATA_FILE), { recursive: true }, () => {
      fs.writeFile(tmp, JSON.stringify(state, null, 2), 'utf8', (err) => {
        if (!err) {
          fs.rename(tmp, DATA_FILE, () => {
            _saving = false;
            if (_savePending) {
              _savePending = false;
              saveData();
            }
          });
        } else {
          _saving = false;
        }
      });
    });
  } catch (error) {
    _saving = false;
  }
}

function defaultGuild() {
  return {
    appearance: {
      title: 'Loja de Coins',
      description: 'Selecione um produto para realizar sua compra.',
      banner: null,
      thumbnail: null,
    },
    products: [],
    panels: [],
    balances: {},
    history: [],
    purchases: [],
    topics: [],
    license: JSON.parse(JSON.stringify(LICENSE_DEFAULTS)),
  };
}

function guildState(guildId) {
  if (!state[guildId]) state[guildId] = defaultGuild();
  const data = state[guildId];
  data.appearance = {
    ...defaultGuild().appearance,
    ...(data.appearance ?? {}),
  };
  data.appearance.title = String(data.appearance.title || 'Loja de Coins').slice(0, 256);
  data.appearance.description = String(data.appearance.description || 'Selecione um produto para realizar sua compra.').slice(0, 4000);
  if (!Array.isArray(data.products)) data.products = [];
  if (!Array.isArray(data.panels)) data.panels = [];
  if (!data.balances || typeof data.balances !== 'object') data.balances = {};
  if (!Array.isArray(data.history)) data.history = [];
  if (!Array.isArray(data.purchases)) data.purchases = [];
  if (!Array.isArray(data.topics)) data.topics = [];
  data.license = {
    ...JSON.parse(JSON.stringify(LICENSE_DEFAULTS)),
    ...(data.license ?? {}),
    appearance: {
      ...LICENSE_DEFAULTS.appearance,
      ...(data.license?.appearance ?? {}),
      button: {
        ...LICENSE_DEFAULTS.appearance.button,
        ...(data.license?.appearance?.button ?? {}),
      },
    },
    shop: {
      ...LICENSE_DEFAULTS.shop,
      ...(data.license?.shop ?? {}),
    },
  };
  if (!Array.isArray(data.license.sales)) data.license.sales = [];
  if (!Array.isArray(data.license.panels)) data.license.panels = [];
  data.license.shop.price = Math.max(0.01, Number(data.license.shop.price) || LICENSE_DEFAULTS.shop.price);
  data.products = data.products.filter(Boolean).map((product) => ({
    id: String(product.id || `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`),
    type: product.type === 'role' ? 'role' : 'custom',
    name: String(product.name || 'Produto').slice(0, 100),
    description: String(product.description || 'Produto da loja.').slice(0, 1000),
    price: Math.max(0, Math.floor(Number(product.price) || 0)),
    roleId: product.roleId ? String(product.roleId) : null,
  }));
  return data;
}

function secretKey() {
  const secret = process.env.SESSION_SECRET;
  return secret ? crypto.createHash('sha256').update(secret).digest() : null;
}

function encryptSecret(value) {
  const key = secretKey();
  if (!key) throw new Error('SESSION_SECRET não configurado.');
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const data = Buffer.concat([cipher.update(String(value), 'utf8'), cipher.final()]);
  return { iv: iv.toString('base64'), tag: cipher.getAuthTag().toString('base64'), data: data.toString('base64') };
}

function decryptSecret(value) {
  if (!value?.iv || !value?.tag || !value?.data) return '';
  const key = secretKey();
  if (!key) return '';
  try {
    const decipher = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(value.iv, 'base64'));
    decipher.setAuthTag(Buffer.from(value.tag, 'base64'));
    return Buffer.concat([
      decipher.update(Buffer.from(value.data, 'base64')),
      decipher.final(),
    ]).toString('utf8');
  } catch {
    return '';
  }
}

function mpToken(guildId) {
  return decryptSecret(guildState(guildId).license.shop.mpToken) || process.env.MERCADOPAGO_ACCESS_TOKEN || '';
}

function safeHex(value, fallback) {
  const text = String(value ?? '').trim();
  return /^#[0-9a-f]{6}$/i.test(text) ? text : fallback;
}

function color(guildId) {
  return getConfig(guildId)?.embedColor ?? 0x5865f2;
}

function truncate(value, max = 1000) {
  const text = String(value ?? '');
  return text.length > max ? `${text.slice(0, max - 3)}...` : text;
}

function productById(guildId, productId) {
  return guildState(guildId).products.find((product) => product.id === productId) ?? null;
}

function coins(guildId, userId) {
  return Number(guildState(guildId).balances[userId] ?? 0);
}

function changeCoins(guildId, userId, amount, reason, metadata = {}) {
  const data = guildState(guildId);
  const before = coins(guildId, userId);
  const after = before + Math.floor(Number(amount) || 0);
  if (after < 0) return { ok: false, before, after };
  data.balances[userId] = after;
  data.history.push({
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    userId,
    amount: Math.floor(Number(amount) || 0),
    before,
    after,
    reason: String(reason || 'Movimentação de Coins').slice(0, 200),
    metadata,
    date: new Date().toISOString(),
  });
  saveData();
  return { ok: true, before, after };
}

function registrarRecompensas(guildId, vencedorId, perdedores, partidaId) {
  const cfg = getConfig(guildId);
  const winnerCoins = Math.max(0, Math.floor(Number(cfg.coins?.winner) || 0));
  const loserCoins = Math.max(0, Math.floor(Number(cfg.coins?.loser) || 0));
  if (vencedorId) changeCoins(guildId, vencedorId, winnerCoins, 'Recompensa por vitória', { partidaId });
  for (const userId of [...new Set((perdedores ?? []).filter((id) => id && id !== vencedorId))]) {
    changeCoins(guildId, userId, loserCoins, 'Recompensa por derrota', { partidaId });
  }
  if (winnerCoins || loserCoins) {
    console.log(`[LOJA] Recompensas registradas — guild=${guildId} vencedor=${winnerCoins} perdedor=${loserCoins} partida=${partidaId}`);
  }
}

function configPanel(guildId, notice = '') {
  const cfg = getConfig(guildId);
  const roleIds = cfg.roles.lojaAtendimento ?? [];
  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle('CONFIGURAÇÃO DA LOJA DE COINS')
    .setDescription(`${notice ? `${notice}\n\n` : ''}Defina os cargos de atendimento e o canal-pai dos tópicos personalizados.`)
    .addFields(
      { name: 'Cargo de Atendimento', value: roleIds.length ? roleIds.map((id) => `<@&${id}>`).join(', ') : 'Não definido' },
      { name: 'Canal dos Tópicos', value: cfg.channels.lojaTopicos ? `<#${cfg.channels.lojaTopicos}>` : 'Não definido' },
    );
  return painelV2FromEmbed(embed, [
    new ActionRowBuilder().addComponents(
      new RoleSelectMenuBuilder().setCustomId('loja:config:roles').setPlaceholder('Cargo de Atendimento').setMinValues(0).setMaxValues(5),
    ),
    new ActionRowBuilder().addComponents(
      new ChannelSelectMenuBuilder().setCustomId('loja:config:channel').setPlaceholder('Canal dos Tópicos').setChannelTypes([ChannelType.GuildText, ChannelType.GuildAnnouncement]),
    ),
    new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('loja:config:back').setLabel('Voltar').setStyle(ButtonStyle.Secondary)),
  ]);
}

function mainPanel(guildId, notice = '') {
  const data = guildState(guildId);
  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle('LOJA DE COINS')
    .setDescription(`${notice ? `${notice}\n\n` : ''}Gerencie produtos, aparência e publicação da Loja de Coins.`)
    .addFields(
      { name: 'Produtos', value: `${data.products.length}/${MAX_PRODUCTS} cadastrados` },
      { name: 'Aparência', value: data.appearance.title },
    );
  return {
    ...painelV2FromEmbed(embed, [
      new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder().setCustomId('loja:menu').setPlaceholder('Selecione uma seção').addOptions(
          { label: 'Produtos', value: 'products', description: 'Criar, remover e visualizar produtos' },
          { label: 'Aparência', value: 'appearance', description: 'Título, descrição e imagens' },
        ),
      ),
      new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('loja:send').setLabel('Enviar').setStyle(ButtonStyle.Success)),
    ]),
    flags: MessageFlags.IsComponentsV2,
  };
}

function productPanel(guildId, notice = '') {
  const data = guildState(guildId);
  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle('PRODUTOS DA LOJA')
    .setDescription(`${notice ? `${notice}\n\n` : ''}Crie, remova ou consulte os produtos disponíveis.`)
    .addFields({ name: 'Produtos cadastrados', value: data.products.length ? data.products.map((p) => `• ${p.name} — ${p.price} Coins`).join('\n').slice(0, 1024) : 'Nenhum produto cadastrado' });
  return painelV2FromEmbed(embed, [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('loja:product:create').setLabel('Criar Produto').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId('loja:product:remove').setLabel('Remover Produto').setStyle(ButtonStyle.Danger),
      new ButtonBuilder().setCustomId('loja:product:view').setLabel('Ver Produtos').setStyle(ButtonStyle.Secondary),
    ),
    new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('loja:back:main').setLabel('Voltar').setStyle(ButtonStyle.Secondary)),
  ]);
}

function appearancePanel(guildId, notice = '') {
  const appearance = guildState(guildId).appearance;
  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle('APARÊNCIA DA LOJA')
    .setDescription(`${notice ? `${notice}\n\n` : ''}Configure o conteúdo visual do painel público.`)
    .addFields(
      { name: 'Título', value: truncate(appearance.title, 1024) },
      { name: 'Descrição', value: truncate(appearance.description, 1024) },
      { name: 'Imagens', value: `Banner: ${appearance.banner ? 'Configurado' : 'Não definido'}\nThumbnail: ${appearance.thumbnail ? 'Configurada' : 'Não definida'}` },
    );
  return painelV2FromEmbed(embed, [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('loja:appearance:title').setLabel('Título').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('loja:appearance:description').setLabel('Descrição').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('loja:appearance:images').setLabel('Imagens').setStyle(ButtonStyle.Secondary),
    ),
    new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('loja:back:main').setLabel('Voltar').setStyle(ButtonStyle.Secondary)),
  ]);
}

function imagesPanel(guildId, notice = '') {
  const appearance = guildState(guildId).appearance;
  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle('IMAGENS DA LOJA')
    .setDescription(`${notice ? `${notice}\n\n` : ''}Informe URLs públicas diretas para as imagens.`)
    .addFields(
      { name: 'Banner', value: truncate(appearance.banner || 'Não definido') },
      { name: 'Thumbnail', value: truncate(appearance.thumbnail || 'Não definida') },
    );
  return painelV2FromEmbed(embed, [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('loja:images:banner').setLabel('Banner').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('loja:images:thumbnail').setLabel('Thumbnail').setStyle(ButtonStyle.Secondary),
    ),
    new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('loja:back:appearance').setLabel('Voltar').setStyle(ButtonStyle.Secondary)),
  ]);
}

function textModal(customId, title, fieldId, label, value, style = TextInputStyle.Paragraph, maxLength = 1000) {
  const modal = new ModalBuilder().setCustomId(customId).setTitle(title);
  const input = new TextInputBuilder().setCustomId(fieldId).setLabel(label).setStyle(style).setMaxLength(maxLength).setRequired(false);
  if (value) input.setValue(String(value).slice(0, maxLength));
  modal.addComponents(new ActionRowBuilder().addComponents(input));
  return modal;
}

function createProductTypePanel(guildId) {
  return painelV2FromEmbed(
    new EmbedBuilder().setColor(color(guildId)).setTitle('CRIAR PRODUTO').setDescription('Escolha o tipo de produto.'),
    [
      new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder().setCustomId('loja:product:type').setPlaceholder('Tipo de produto').addOptions(
          { label: 'Cargo', value: 'role', description: 'Entrega um cargo automaticamente' },
          { label: 'Personalizado', value: 'custom', description: 'Cria um tópico para atendimento' },
        ),
      ),
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('loja:back:products').setLabel('Voltar').setStyle(ButtonStyle.Secondary),
      ),
    ],
  );
}

function productModal(type) {
  const modal = new ModalBuilder().setCustomId(`loja:product:modal:${type}`).setTitle(`Criar Produto ${type === 'role' ? 'Cargo' : 'Personalizado'}`);
  modal.addComponents(
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('name').setLabel('Nome').setStyle(TextInputStyle.Short).setMaxLength(100).setRequired(true)),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('description').setLabel('Descrição').setStyle(TextInputStyle.Paragraph).setMaxLength(1000).setRequired(true)),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('price').setLabel('Preço em Coins').setStyle(TextInputStyle.Short).setMaxLength(12).setRequired(true)),
  );
  return modal;
}

function publicPanel(guildId) {
  const data = guildState(guildId);
  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle(data.appearance.title)
    .setDescription(data.appearance.description);
  if (data.appearance.banner) embed.setImage(data.appearance.banner);
  if (data.appearance.thumbnail) embed.setThumbnail(data.appearance.thumbnail);
  const options = (data.products || []).map((product) => ({
    label: product.name.slice(0, 100),
    value: product.id,
    description: `${truncate(product.description, 70)} • ${product.price} Coins`,
  }));
  const components = [];
  if (options.length) {
    components.push(new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder().setCustomId('loja:public:product').setPlaceholder('Selecione um produto').addOptions(options),
    ));
  }
  return painelV2FromEmbed(embed, components);
}

function licenseData(guildId) {
  return guildState(guildId).license;
}

async function logLicenseEvent(client, guildId, title, fields = []) {
  const channelId = licenseData(guildId).shop.logChannelId;
  if (!channelId) return;
  const channel = await client.channels.fetch(channelId).catch(() => null);
  if (!channel?.send) return;
  await channel.send({
    embeds: [
      new EmbedBuilder()
        .setColor(color(guildId))
        .setTitle(`TEAM RYZE E-SPORTS • ${title}`)
        .addFields(fields.map((field) => ({
          name: String(field.name).slice(0, 256),
          value: String(field.value).slice(0, 1024),
          inline: Boolean(field.inline),
        })))
        .setTimestamp(),
    ],
    allowedMentions: { parse: [] },
  }).catch((error) => {
    console.error(`[LOJA] Falha ao enviar log — guild=${guildId}:`, error.message);
  });
}

function licenseStock(guildId) {
  const rows = botManager.stockSnapshot();
  const available = rows.filter((row) =>
    row.slot !== 0 && row.state === 'online' && row.stockStatus === 'disponivel' && row.id,
  ).length;
  return { rows, available };
}

function licenseButtonEmoji(value) {
  const emoji = String(value ?? '').trim();
  if (!emoji) return null;
  const custom = emoji.match(/^<(a?):([A-Za-z0-9_]+):(\d+)>$/);
  if (custom) {
    return { id: custom[3], name: custom[2], animated: Boolean(custom[1]) };
  }
  return emoji.slice(0, 32);
}

function licenseButtonStyle(value) {
  const styles = {
    Primary: ButtonStyle.Primary,
    Secondary: ButtonStyle.Secondary,
    Success: ButtonStyle.Success,
    Danger: ButtonStyle.Danger,
  };
  return styles[String(value)] ?? ButtonStyle.Success;
}

function licenseBuyButton(guildId, disabled = false) {
  const button = licenseData(guildId).appearance.button;
  const builder = new ButtonBuilder()
    .setCustomId('lic:public:buy')
    .setLabel(String(button.label || 'Comprar').slice(0, 80))
    .setStyle(licenseButtonStyle(button.style))
    .setDisabled(disabled);
  const emoji = licenseButtonEmoji(button.emoji);
  if (emoji) builder.setEmoji(emoji);
  return builder;
}

function licensePublicPanel(guildId) {
  const data = licenseData(guildId);
  const stock = licenseStock(guildId);
  const appearance = data.appearance;
  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle(appearance.title)
    .setDescription(appearance.description)
    .addFields(
      { name: 'Valor', value: `R$ ${Number(data.shop.price).toFixed(2).replace('.', ',')}`, inline: true },
      { name: 'Estoque', value: `${stock.available} bot(s) disponível(is)`, inline: true },
    );
  if (appearance.banner) embed.setImage(appearance.banner);
  if (appearance.thumbnail) embed.setThumbnail(appearance.thumbnail);
  return painelV2FromEmbed(embed, [
    new ActionRowBuilder().addComponents(
      licenseBuyButton(guildId, stock.available < 1),
    ),
  ]);
}

function licenseAdminPanel(guildId, notice = '') {
  const data = licenseData(guildId);
  const stock = licenseStock(guildId);
  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle('CONFIGURAÇÃO DA LOJA DE ACESSO')
    .setDescription(`${notice ? `${notice}\n\n` : ''}Escolha uma seção para configurar o painel público de venda de chaves.`)
    .addFields(
      { name: 'Preço', value: `R$ ${Number(data.shop.price).toFixed(2).replace('.', ',')}`, inline: true },
      { name: 'Estoque online', value: `${stock.available}`, inline: true },
      { name: 'Token Mercado Pago', value: mpToken(guildId) ? 'Configurado' : 'Não configurado', inline: true },
      { name: 'Canal dos tópicos', value: data.shop.topicChannelId ? `<#${data.shop.topicChannelId}>` : 'Não definido', inline: false },
      { name: 'Canal de logs', value: data.shop.logChannelId ? `<#${data.shop.logChannelId}>` : 'Não definido', inline: false },
    );
  return {
    ...painelV2FromEmbed(embed, [
      new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder().setCustomId('lic:admin:menu').setPlaceholder('Selecione uma seção').addOptions(
          { label: 'Aparência', value: 'appearance', description: 'Configure a embed do painel público' },
          { label: 'Loja', value: 'shop', description: 'Preço, QR Code, canal e Mercado Pago' },
        ),
      ),
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('lic:publish').setLabel('Publicar painel').setStyle(ButtonStyle.Success),
      ),
    ]),
    flags: MessageFlags.IsComponentsV2,
  };
}

function licenseAppearancePanel(guildId, notice = '') {
  const data = licenseData(guildId);
  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle('APARÊNCIA DO PAINEL PÚBLICO')
    .setDescription(`${notice ? `${notice}\n\n` : ''}Configure título, descrição, imagens e cor da embed de venda.`)
    .addFields(
      { name: 'Título', value: truncate(data.appearance.title, 1024) },
      { name: 'Descrição', value: truncate(data.appearance.description, 1024) },
      { name: 'Imagens', value: `Banner: ${data.appearance.banner ? 'Configurado' : 'Não definido'}\nThumbnail: ${data.appearance.thumbnail ? 'Configurada' : 'Não definida'}` },
      { name: 'Cor das Embeds', value: `Usando a cor global configurada: #${Number(color(guildId)).toString(16).padStart(6, '0').toUpperCase()}` },
      { name: 'Botão Comprar', value: `${data.appearance.button.label} • ${data.appearance.button.style}${data.appearance.button.emoji ? ` • ${data.appearance.button.emoji}` : ''}` },
    );
  return painelV2FromEmbed(embed, [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('lic:appearance:title').setLabel('Título').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('lic:appearance:description').setLabel('Descrição').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('lic:appearance:images').setLabel('Imagens').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('lic:appearance:button').setLabel('Editar botão').setStyle(ButtonStyle.Primary),
    ),
    new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('lic:admin:back').setLabel('Voltar').setStyle(ButtonStyle.Secondary)),
  ]);
}

function licenseShopPanel(guildId, notice = '') {
  const data = licenseData(guildId);
  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setTitle('CONFIGURAÇÃO DA LOJA')
    .setDescription(`${notice ? `${notice}\n\n` : ''}Configure cobrança Pix, estoque e os tópicos das compras.`)
    .addFields(
      { name: 'Preço', value: `R$ ${Number(data.shop.price).toFixed(2).replace('.', ',')}`, inline: true },
      { name: 'Cores do QR Code', value: `${data.shop.qrDark} / ${data.shop.qrLight}`, inline: true },
      { name: 'Canal dos tópicos', value: data.shop.topicChannelId ? `<#${data.shop.topicChannelId}>` : 'Não definido', inline: false },
      { name: 'Canal de logs', value: data.shop.logChannelId ? `<#${data.shop.logChannelId}>` : 'Não definido', inline: false },
      { name: 'Mercado Pago', value: mpToken(guildId) ? 'Token configurado' : 'Token não configurado', inline: true },
    );
  return painelV2FromEmbed(embed, [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('lic:shop:billing').setLabel('Preço e QR Code').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('lic:shop:channel').setLabel('Canal dos tópicos').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('lic:shop:logs').setLabel('Canal de logs').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('lic:shop:token').setLabel('Token MP').setStyle(ButtonStyle.Secondary),
    ),
    new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('lic:admin:back').setLabel('Voltar').setStyle(ButtonStyle.Secondary)),
  ]);
}

function licenseImagesPanel(guildId) {
  const data = licenseData(guildId);
  return painelV2FromEmbed(
    new EmbedBuilder().setColor(color(guildId)).setTitle('IMAGENS DO PAINEL PÚBLICO').setDescription('Informe URLs públicas diretas para as imagens.'),
    [
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('lic:images:banner').setLabel('Banner').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId('lic:images:thumbnail').setLabel('Thumbnail').setStyle(ButtonStyle.Secondary),
      ),
      new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('lic:appearance:back').setLabel('Voltar').setStyle(ButtonStyle.Secondary)),
    ],
  );
}

function licenseBillingModal(guildId) {
  const data = licenseData(guildId);
  return new ModalBuilder().setCustomId('lic:shop:modal:billing').setTitle('Preço e QR Code').addComponents(
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('price').setLabel('Preço em reais').setStyle(TextInputStyle.Short).setValue(String(data.shop.price)).setRequired(true)),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('qrDark').setLabel('Cor escura do QR (#RRGGBB)').setStyle(TextInputStyle.Short).setValue(data.shop.qrDark).setRequired(true)),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('qrLight').setLabel('Cor clara do QR (#RRGGBB)').setStyle(TextInputStyle.Short).setValue(data.shop.qrLight).setRequired(true)),
  );
}

function licenseTextModal(customId, title, label, value, style = TextInputStyle.Paragraph, maxLength = 1000) {
  const input = new TextInputBuilder()
    .setCustomId('value')
    .setLabel(label)
    .setStyle(style)
    .setMaxLength(maxLength)
    .setRequired(false);
  if (value) input.setValue(String(value).slice(0, maxLength));
  return new ModalBuilder().setCustomId(customId).setTitle(title)
    .addComponents(new ActionRowBuilder().addComponents(input));
}

function licenseButtonModal(guildId) {
  const button = licenseData(guildId).appearance.button;
  return new ModalBuilder().setCustomId('lic:appearance:modal:button').setTitle('Editar botão Comprar').addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder().setCustomId('buttonName').setLabel('Nome do botão').setStyle(TextInputStyle.Short).setValue(String(button.label || 'Comprar')).setRequired(true).setMaxLength(80),
    ),
    new ActionRowBuilder().addComponents(
      new TextInputBuilder().setCustomId('buttonColor').setLabel('Cor: Primary, Secondary, Success ou Danger').setStyle(TextInputStyle.Short).setValue(String(button.style || 'Success')).setRequired(true).setMaxLength(12),
    ),
    new ActionRowBuilder().addComponents(
      new TextInputBuilder().setCustomId('buttonEmoji').setLabel('Emoji Unicode ou <:nome:id>').setStyle(TextInputStyle.Short).setValue(String(button.emoji || '')).setRequired(false).setMaxLength(100),
    ),
  );
}

function licenseTokenModal() {
  return new ModalBuilder().setCustomId('lic:shop:modal:token').setTitle('Token do Mercado Pago').addComponents(
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('token').setLabel('Access Token do Mercado Pago').setStyle(TextInputStyle.Paragraph).setRequired(true).setMaxLength(500)),
  );
}

function licenseTopicPanel(sale, notice = '') {
  const embed = new EmbedBuilder()
    .setColor(color(sale.guildId))
    .setDescription(
      `${notice ? `> ${notice}\n\n` : ''}` +
      'Sua reserva está pronta. Confirme abaixo para gerar o pagamento Pix.',
    )
    .addFields(
      { name: 'RESERVA', value: 'Bot reservado exclusivamente para esta compra.', inline: false },
      { name: 'VALOR', value: `**R$ ${Number(sale.price).toFixed(2).replace('.', ',')}**`, inline: true },
      { name: 'COMPRADOR', value: `<@${sale.buyerId}>`, inline: true },
      { name: 'STATUS', value: `\`${String(sale.status).toUpperCase()}\``, inline: true },
    );
  return painelV2FromEmbed(embed, [new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`lic:topic:confirm:${sale.id}`).setLabel('Confirmar').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId(`lic:topic:cancel:${sale.id}`).setLabel('Cancelar').setStyle(ButtonStyle.Danger),
    )]);
}

async function licensePaymentPanel(guildId, sale) {
  const rows = [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`lic:copy:${sale.id}`).setLabel('Copia e cola').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId(`lic:topic:cancel:${sale.id}`).setLabel('Cancelar').setStyle(ButtonStyle.Danger),
    ),
  ];
  const embed = new EmbedBuilder()
    .setColor(color(guildId))
    .setDescription(
      'Escaneie o QR Code completo abaixo ou use o botão **COPIA E COLA**.\n' +
      'A confirmação é automática após a aprovação do Mercado Pago.',
    )
    .addFields(
      { name: 'VALOR DA COMPRA', value: `**R$ ${Number(sale.price).toFixed(2).replace('.', ',')}**`, inline: true },
      { name: 'STATUS', value: '`AGUARDANDO PAGAMENTO`', inline: true },
      { name: 'SEGURANÇA', value: 'O código Pix é original e não foi alterado.', inline: false },
    );
  const files = [];
  if (sale.copyPaste) {
    try {
      const qrBuffer = await QRCode.toBuffer(sale.copyPaste, {
        type: 'png',
        errorCorrectionLevel: 'M',
        margin: 4,
        width: 700,
        color: {
          dark: '#000000',
          light: '#ffffff',
        },
      });
      files.push({ attachment: qrBuffer, name: 'pix-qrcode.png' });
      embed.setImage('attachment://pix-qrcode.png');
    } catch (error) {
      console.error('[LOJA] Falha ao preparar o QR Code:', error.message);
    }
  }
  return { ...painelV2FromEmbed(embed, rows), files };
}

function licenseDmPanel(sale) {
  const invite = `https://discord.com/oauth2/authorize?client_id=${encodeURIComponent(sale.botId)}&scope=bot%20applications.commands&permissions=8`;
  const isGrant = sale.grantType === 'plano';
  const durationText = sale.durationDays === 0
    ? 'Acesso infinito'
    : `${sale.durationDays} dia(s)`;
  const embed = new EmbedBuilder()
    .setColor(color(sale.guildId))
    .setTitle(isGrant ? 'Você recebeu um plano de acesso' : 'Seu acesso ao bot está pronto')
    .setDescription(isGrant
      ? 'Este acesso foi concedido pela equipe. Adicione o bot ao servidor e resgate seu plano usando os botões abaixo.'
      : 'Obrigado pela compra. Adicione o bot ao servidor e resgate sua licença usando os botões abaixo.')
    .addFields(
      { name: 'Nome da chave', value: `\`${truncate(sale.keyName || 'Acesso concedido', 100)}\``, inline: false },
      { name: 'Código da chave', value: `\`${licenseKeyValue(sale)}\``, inline: false },
      { name: 'Bot', value: `<@${sale.botId}>`, inline: true },
      { name: 'Validade', value: isGrant ? durationText : 'Licença permanente', inline: true },
    );
  return {
    ...painelV2FromEmbed(embed, [new ActionRowBuilder().addComponents(
      new ButtonBuilder().setLabel('Adicionar bot').setStyle(ButtonStyle.Link).setURL(invite),
      new ButtonBuilder().setCustomId(`lic:redeem:${sale.id}`).setLabel('Resgatar').setStyle(ButtonStyle.Success),
    )]),
  };
}

function redeemModal(saleId) {
  return new ModalBuilder().setCustomId(`lic:redeem:modal:${saleId}`).setTitle('Resgatar licença').addComponents(
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('guildId').setLabel('ID do servidor Discord').setStyle(TextInputStyle.Short).setPlaceholder('Ex: 123456789012345678').setRequired(true).setMaxLength(30)),
  );
}

function makeLicenseKey() {
  return `BOT-${crypto.randomBytes(18).toString('hex').toUpperCase()}`;
}

function licenseKeyValue(sale) {
  return sale?.key || decryptSecret(sale?.keyEncrypted) || '';
}

function findLicenseSale(saleId) {
  for (const guildId of Object.keys(state)) {
    const sale = guildState(guildId).license.sales.find((item) => item.id === saleId);
    if (sale) return { guildId, sale };
  }
  return null;
}

function licenseExpired(sale) {
  return Boolean(sale?.expiresAt && Date.now() >= new Date(sale.expiresAt).getTime());
}

async function expireGrantedPlan(client, sale) {
  if (sale.grantType !== 'plano' || sale.status !== 'ativado' || !licenseExpired(sale)) return;
  const removed = await botManager.removeSlotFromGuild(sale.slot, sale.activatedGuildId);
  sale.status = 'expirado';
  sale.expiredAt = new Date().toISOString();
  saveData();
  await logLicenseEvent(client, sale.guildId, 'PLANO EXPIRADO', [
    { name: 'Nome da chave', value: `\`${sale.keyName || 'Acesso concedido'}\``, inline: true },
    { name: 'Membro', value: `<@${sale.buyerId}>`, inline: true },
    { name: 'Servidor', value: `\`${sale.activatedGuildId}\``, inline: true },
    { name: 'Remoção do bot', value: removed ? 'Bot removido do servidor.' : 'Não foi possível remover automaticamente.' },
  ]);
}

function watchPlanExpiry(client, sale) {
  if (sale.grantType !== 'plano' || !sale.expiresAt || sale.status !== 'ativado' || planExpiryWatchers.has(sale.id)) return;
  const timer = setInterval(async () => {
    const current = findLicenseSale(sale.id)?.sale;
    if (!current || ['expirado', 'cancelado'].includes(current.status)) {
      clearInterval(timer);
      planExpiryWatchers.delete(sale.id);
      return;
    }
    if (licenseExpired(current)) {
      clearInterval(timer);
      planExpiryWatchers.delete(sale.id);
      await expireGrantedPlan(client, current);
    }
  }, 30000);
  timer.unref?.();
  planExpiryWatchers.set(sale.id, timer);
  if (licenseExpired(sale)) {
    clearInterval(timer);
    planExpiryWatchers.delete(sale.id);
    expireGrantedPlan(client, sale).catch((error) => console.error('[PLANO] Falha ao expirar plano:', error.message));
  }
}

async function darPlano(interaction, client) {
  if (!licenseCanManage(interaction)) {
    await interaction.reply({ content: 'Apenas o cargo de dono configurado pode conceder planos.', flags: MessageFlags.Ephemeral });
    return true;
  }

  const keyName = interaction.options.getString('nome_da_chave', true).trim();
  const durationDays = interaction.options.getInteger('duracao', true);
  const member = interaction.options.getUser('membro', true);
  if (!keyName) {
    await interaction.reply({ content: 'Informe um nome para a chave.', flags: MessageFlags.Ephemeral });
    return true;
  }
  if (member.bot) {
    await interaction.reply({ content: 'Não é possível conceder um plano para outro bot.', flags: MessageFlags.Ephemeral });
    return true;
  }

  const sale = {
    id: `${Date.now()}-${crypto.randomBytes(4).toString('hex')}`,
    guildId: interaction.guildId,
    buyerId: member.id,
    keyName: keyName.slice(0, 100),
    durationDays,
    grantType: 'plano',
    status: 'reservando_estoque',
    date: new Date().toISOString(),
    grantedAt: new Date().toISOString(),
    expiresAt: durationDays > 0
      ? new Date(Date.now() + durationDays * 24 * 60 * 60 * 1000).toISOString()
      : null,
  };
  const reservation = botManager.reserveAvailable({
    saleId: sale.id,
    guildId: interaction.guildId,
    buyerId: member.id,
  });
  if (!reservation.ok) {
    await interaction.reply({ content: reservation.message, flags: MessageFlags.Ephemeral });
    return true;
  }
  Object.assign(sale, {
    slot: reservation.slot,
    botId: reservation.botId,
    botTag: reservation.tag,
    keyEncrypted: encryptSecret(makeLicenseKey()),
    status: 'entrega_pendente',
  });
  const confirmed = botManager.confirmSale(sale.slot, {
    saleId: sale.id,
    guildId: interaction.guildId,
    buyerId: member.id,
    botId: sale.botId,
  });
  if (!confirmed.ok) {
    botManager.releaseReservation(sale.slot, sale.id);
    await interaction.reply({ content: 'A entrega foi interrompida porque o bot reservado não pôde ser confirmado no estoque.', flags: MessageFlags.Ephemeral });
    return true;
  }
  const sales = licenseData(interaction.guildId).sales;
  sales.push(sale);
  saveData();

  const user = await client.users.fetch(member.id).catch(() => null);
  const dmSent = user
    ? await user.send(licenseDmPanel(sale)).then(() => true).catch((error) => {
      console.error('[PLANO] Não foi possível enviar o plano por DM:', error.message);
      return false;
    })
    : false;
  if (!dmSent) {
    await interaction.reply({ content: 'O bot foi reservado, mas não foi possível enviar a DM para esse membro. A entrega ficou pendente para nova tentativa.', flags: MessageFlags.Ephemeral });
    return true;
  }
  sale.status = 'entregue';
  saveData();
  await logLicenseEvent(client, interaction.guildId, 'PLANO CONCEDIDO', [
    { name: 'Nome da chave', value: `\`${sale.keyName}\``, inline: true },
    { name: 'Membro', value: `<@${member.id}>`, inline: true },
    { name: 'Duração', value: durationDays === 0 ? 'Infinita' : `${durationDays} dia(s)`, inline: true },
    { name: 'Bot', value: sale.botTag ? `\`${sale.botTag}\`` : `<@${sale.botId}>`, inline: false },
  ]);
  await interaction.reply({ content: `Plano **${sale.keyName}** enviado por DM para <@${member.id}>. Duração: **${durationDays === 0 ? 'infinita' : `${durationDays} dia(s)`}**.`, flags: MessageFlags.Ephemeral });
  return true;
}

function licenseCanManage(interaction) {
  return isBotsOwner(interaction.member);
}

function licenseCanManageMember(member) {
  return isBotsOwner(member);
}

async function mpRequest(guildId, method, url, body, extraHeaders = {}) {
  const token = mpToken(guildId);
  if (!token) return { ok: false, message: 'O token do Mercado Pago ainda não foi configurado no painel.' };
  const response = await fetch(url, {
    method,
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
      Accept: 'application/json',
      ...extraHeaders,
    },
    ...(body ? { body: JSON.stringify(body) } : {}),
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    console.error(`[LOJA] Mercado Pago HTTP ${response.status}:`, payload?.message || 'resposta inválida');
    return { ok: false, message: 'O Mercado Pago recusou a operação. Confira o token e tente novamente.' };
  }
  return { ok: true, payload };
}

async function createPixPayment(guildId, sale) {
  const payerEmail = `discord-${sale.buyerId}@example.com`;
  const idempotencyKey = crypto.createHash('sha256')
    .update(`discord-license-pix:${guildId}:${sale.id}`)
    .digest('hex');
  const result = await mpRequest(guildId, 'POST', 'https://api.mercadopago.com/v1/payments', {
    transaction_amount: Number(sale.price),
    description: `Acesso ao bot Discord — ${sale.id}`,
    payment_method_id: 'pix',
    external_reference: sale.id,
    payer: { email: payerEmail },
  }, { 'X-Idempotency-Key': idempotencyKey });
  if (!result.ok) return result;
  const payment = result.payload;
  const transaction = payment?.point_of_interaction?.transaction_data;
  const copyPaste = transaction?.qr_code;
  if (!payment?.id || !copyPaste) {
    return { ok: false, message: 'O Mercado Pago não retornou os dados do Pix.' };
  }
  const data = licenseData(guildId);
  let qrBuffer;
  try {
    qrBuffer = await QRCode.toBuffer(copyPaste, {
      type: 'png',
      color: {
        dark: safeHex(data.shop.qrDark, '#111827'),
        light: safeHex(data.shop.qrLight, '#ffffff'),
      },
      margin: 2,
      width: 700,
    });
  } catch (error) {
    console.error('[LOJA] Falha ao gerar QR Code:', error.message);
  }
  sale.paymentId = String(payment.id);
  sale.copyPaste = copyPaste;
  sale.status = 'aguardando_pagamento';
  sale.updatedAt = new Date().toISOString();
  delete sale.qrBuffer;
  saveData();
  return { ok: true };
}

async function getPayment(guildId, paymentId) {
  return mpRequest(guildId, 'GET', `https://api.mercadopago.com/v1/payments/${encodeURIComponent(paymentId)}`);
}

async function finalizeLicenseSale(client, guildId, sale) {
  if (sale.status === 'pago' || sale.status === 'entregue') return;
  const confirm = botManager.confirmSale(sale.slot, {
    saleId: sale.id,
    guildId,
    buyerId: sale.buyerId,
    botId: sale.botId,
  });
  if (!confirm.ok) {
    sale.status = 'erro_estoque';
    saveData();
    await logLicenseEvent(client, guildId, 'ERRO NO ESTOQUE', [
      { name: 'Venda', value: `\`${sale.id}\`` },
      { name: 'Comprador', value: `<@${sale.buyerId}>`, inline: true },
      { name: 'Motivo', value: 'O bot reservado não pôde ser confirmado.', inline: true },
    ]);
    return;
  }
  const key = licenseKeyValue(sale) || makeLicenseKey();
  sale.keyEncrypted = encryptSecret(key);
  delete sale.key;
  sale.status = 'pago';
  sale.paidAt = new Date().toISOString();
  saveData();
  const user = await client.users.fetch(sale.buyerId).catch(() => null);
  if (!user) {
    sale.status = 'entrega_pendente';
    saveData();
    console.error(`[LOJA] Comprador não encontrado para entrega da venda ${sale.id}.`);
    await logLicenseEvent(client, guildId, 'ENTREGA PENDENTE', [
      { name: 'Venda', value: `\`${sale.id}\`` },
      { name: 'Comprador', value: `<@${sale.buyerId}>`, inline: true },
      { name: 'Motivo', value: 'Usuário não encontrado para envio da licença por DM.', inline: true },
    ]);
    return;
  }
  const dmSent = await user.send(licenseDmPanel(sale)).then(() => true).catch((error) => {
    console.error('[LOJA] Não foi possível enviar a licença por DM:', error.message);
    return false;
  });
  if (!dmSent) {
    sale.status = 'entrega_pendente';
    saveData();
    await logLicenseEvent(client, guildId, 'ENTREGA PENDENTE', [
      { name: 'Venda', value: `\`${sale.id}\`` },
      { name: 'Comprador', value: `<@${sale.buyerId}>`, inline: true },
      { name: 'Motivo', value: 'Não foi possível enviar a licença por mensagem direta.', inline: true },
    ]);
    return;
  }
  sale.status = 'entregue';
  saveData();
  await logLicenseEvent(client, guildId, 'PAGAMENTO APROVADO', [
    { name: 'Venda', value: `\`${sale.id}\`` },
    { name: 'Comprador', value: `<@${sale.buyerId}>`, inline: true },
    { name: 'Bot', value: sale.botTag ? `\`${sale.botTag}\`` : `<@${sale.botId}>`, inline: true },
    { name: 'Status', value: 'Licença enviada por DM.' },
  ]);
  const channel = sale.threadId ? await client.channels.fetch(sale.threadId).catch(() => null) : null;
  if (channel?.delete) await channel.delete('Pagamento aprovado e licença entregue').catch(() => {});
}

function watchPayment(client, guildId, sale) {
  if (paymentWatchers.has(sale.id)) return;
  const timer = setInterval(async () => {
    const current = findLicenseSale(sale.id)?.sale;
    if (!current || ['cancelado', 'entregue', 'erro_estoque'].includes(current.status)) {
      clearInterval(timer);
      paymentWatchers.delete(sale.id);
      return;
    }
    const result = await getPayment(guildId, current.paymentId);
    const status = result.payload?.status;
    if (result.ok && status === 'approved') {
      clearInterval(timer);
      paymentWatchers.delete(sale.id);
      await finalizeLicenseSale(client, guildId, current);
    } else if (result.ok && ['cancelled', 'rejected', 'refunded', 'charged_back'].includes(status)) {
      current.status = `pagamento_${status}`;
      botManager.releaseReservation(current.slot, current.id);
      saveData();
      await logLicenseEvent(client, guildId, 'PAGAMENTO RECUSADO', [
        { name: 'Venda', value: `\`${current.id}\`` },
        { name: 'Comprador', value: `<@${current.buyerId}>`, inline: true },
        { name: 'Status Mercado Pago', value: `\`${status}\``, inline: true },
      ]);
      clearInterval(timer);
      paymentWatchers.delete(sale.id);
    }
  }, 8000);
  timer.unref?.();
  paymentWatchers.set(sale.id, timer);
}

async function createLicenseTopic(interaction, client) {
  if (!secretKey()) {
    return { ok: false, message: 'A loja exige `SESSION_SECRET` configurada no host para proteger a chave de licença.' };
  }
  const data = licenseData(interaction.guildId);
  const channelId = data.shop.topicChannelId;
  const parent = channelId ? await interaction.guild.channels.fetch(channelId).catch(() => null) : null;
  if (!parent?.threads?.create) return { ok: false, message: 'O canal dos tópicos da loja ainda não foi configurado.' };
  const sale = {
    id: `${Date.now()}-${crypto.randomBytes(4).toString('hex')}`,
    guildId: interaction.guildId,
    buyerId: interaction.user.id,
    price: Number(data.shop.price),
    status: 'reservando_estoque',
    date: new Date().toISOString(),
  };
  const reservation = botManager.reserveAvailable({
    saleId: sale.id,
    guildId: interaction.guildId,
    buyerId: interaction.user.id,
  });
  if (!reservation.ok) return reservation;
  Object.assign(sale, {
    slot: reservation.slot,
    botId: reservation.botId,
    botTag: reservation.tag,
  });
  const thread = await parent.threads.create({
    name: `compra-${interaction.user.username}`.toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 70),
    type: ChannelType.PrivateThread,
    invitable: false,
    autoArchiveDuration: 1440,
    reason: 'Compra de acesso ao bot',
  }).catch(() => null);
  if (!thread) {
    botManager.releaseReservation(sale.slot, sale.id);
    return { ok: false, message: 'Não foi possível criar o tópico da compra.' };
  }
  await thread.join().catch(() => {});
  await thread.members.add(interaction.user.id).catch(() => {});
  sale.threadId = thread.id;
  try {
    await thread.send(licenseTopicPanel(sale));
  } catch (error) {
    botManager.releaseReservation(sale.slot, sale.id);
    await thread.delete('Não foi possível enviar o painel da compra').catch(() => {});
    console.error('[LOJA] Falha ao enviar o painel no tópico:', error.message);
    return { ok: false, message: 'O tópico foi criado, mas não foi possível enviar o painel da compra. A reserva foi liberada; tente novamente.' };
  }
  data.sales.push({ ...sale });
  saveData();
  await logLicenseEvent(client, interaction.guildId, 'RESERVA CRIADA', [
    { name: 'Venda', value: `\`${sale.id}\`` },
    { name: 'Comprador', value: `<@${sale.buyerId}>`, inline: true },
    { name: 'Valor', value: `R$ ${Number(sale.price).toFixed(2).replace('.', ',')}`, inline: true },
    { name: 'Bot reservado', value: sale.botTag ? `\`${sale.botTag}\`` : `<@${sale.botId}>` },
  ]);
  return { ok: true, sale, thread };
}

function licenseCanOperateTopic(interaction, sale) {
  if (interaction.user.id === sale.buyerId) return true;
  if (interaction.member?.permissions?.has(PermissionFlagsBits.ManageThreads)) return true;
  return licenseCanManage(interaction);
}

async function publishLicensePanel(interaction, client) {
  await interaction.update(painelV2FromEmbed(
    new EmbedBuilder().setColor(color(interaction.guildId)).setTitle('PUBLICAR PAINEL DE ACESSO').setDescription('Selecione o canal onde o painel público de compra será enviado.'),
    [new ActionRowBuilder().addComponents(
      new ChannelSelectMenuBuilder().setCustomId('lic:publish:channel').setPlaceholder('Selecione um canal').setChannelTypes([ChannelType.GuildText, ChannelType.GuildAnnouncement]),
    )],
  ));
}

async function handleLicenseMessage(message, client) {
  if (!message.guild || message.author.bot) return false;
  const text = typeof message.content === 'string' ? message.content.trim() : '';
  if (text.toLowerCase() !== '.loja') return false;
  if (!licenseCanManageMember(message.member)) {
    await message.reply('Apenas membros com o cargo de dono configurado podem abrir o painel da loja.');
    return true;
  }
  await message.reply(licenseAdminPanel(message.guildId));
  return true;
}

async function refreshLicensePanels(client, guildId) {
  const data = licenseData(guildId);
  const valid = [];
  for (const panel of data.panels) {
    const channel = await client.channels.fetch(panel.channelId).catch(() => null);
    const message = channel?.messages?.fetch
      ? await channel.messages.fetch(panel.messageId).catch(() => null)
      : null;
    if (message) {
      await message.edit(licensePublicPanel(guildId)).catch(() => {});
      valid.push(panel);
    }
  }
  data.panels = valid;
  saveData();
}

function restoreLicensePayments(client) {
  for (const guildId of Object.keys(state)) {
    for (const sale of licenseData(guildId).sales) {
      if (sale.status === 'aguardando_pagamento' && sale.paymentId) {
        watchPayment(client, guildId, sale);
      }
      if (sale.status === 'ativado' && sale.grantType === 'plano') {
        watchPlanExpiry(client, sale);
      }
    }
  }
}

function productsEmbed(guildId) {
  const data = guildState(guildId);
  const embed = new EmbedBuilder().setColor(color(guildId)).setTitle('PRODUTOS DA LOJA').setDescription(
    data.products.length
      ? data.products.map((p) => `**${p.name}**\nTipo: ${p.type === 'role' ? 'Cargo' : 'Personalizado'}\nDescrição: ${p.description}\nPreço: **${p.price} Coins**`).join('\n\n').slice(0, 4000)
      : 'Nenhum produto cadastrado.',
  );
  return {
    ...painelV2FromEmbed(embed, [
      new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('loja:back:products').setLabel('Voltar').setStyle(ButtonStyle.Secondary)),
    ]),
    flags: MessageFlags.IsComponentsV2,
  };
}

async function refreshPublishedPanels(client, guildId) {
  const data = guildState(guildId);
  const valid = [];
  for (const panel of data.panels) {
    const channel = await client.channels.fetch(panel.channelId).catch(() => null);
    const message = channel?.messages?.fetch ? await channel.messages.fetch(panel.messageId).catch(() => null) : null;
    if (message) {
      await message.edit(publicPanel(guildId)).catch(() => {});
      valid.push(panel);
    }
  }
  data.panels = valid;
  saveData();
}

async function createCustomTopic(interaction, client, product) {
  const cfg = getConfig(interaction.guildId);
  const parent = cfg.channels.lojaTopicos ? await interaction.guild.channels.fetch(cfg.channels.lojaTopicos).catch(() => null) : null;
  if (!parent?.threads?.create) return { ok: false, message: 'O Canal dos Tópicos da Loja não está configurado.' };
  const thread = await parent.threads.create({
    name: `loja-${product.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 70)}`,
    type: ChannelType.PrivateThread,
    invitable: false,
    autoArchiveDuration: 1440,
    reason: `Compra de ${product.name}`,
  }).catch(() => null);
  if (!thread) return { ok: false, message: 'Não foi possível criar o tópico da compra.' };
  await thread.join().catch(() => {});
  await thread.members.add(interaction.user.id).catch(() => {});
  const roleIds = cfg.roles.lojaAtendimento ?? [];
  for (const roleId of roleIds) {
    const role = interaction.guild.roles.cache.get(roleId);
    for (const member of role?.members?.values?.() ?? []) await thread.members.add(member.id).catch(() => {});
  }
  const purchase = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    guildId: interaction.guildId,
    productId: product.id,
    productName: product.name,
    buyerId: interaction.user.id,
    price: product.price,
    date: new Date().toISOString(),
    status: 'Aguardando entrega',
    threadId: thread.id,
  };
  const data = guildState(interaction.guildId);
  data.purchases.push(purchase);
  data.topics.push({ purchaseId: purchase.id, threadId: thread.id, closedAt: null });
  saveData();
  await thread.send({
    embeds: [purchaseEmbed(purchase, interaction.guildId)],
    components: [new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`loja:topic:close:${purchase.id}`).setLabel('Fechar').setStyle(ButtonStyle.Danger))],
    allowedMentions: { users: [interaction.user.id] },
  }).catch(() => {});
  return { ok: true, thread };
}

function purchaseEmbed(purchase, guildId) {
  return new EmbedBuilder().setColor(color(guildId)).setTitle('COMPRA DA LOJA').addFields(
    { name: 'Produto', value: purchase.productName, inline: false },
    { name: 'Comprador', value: `<@${purchase.buyerId}>`, inline: true },
    { name: 'Valor pago', value: `${purchase.price} Coins`, inline: true },
    { name: 'Data da compra', value: `<t:${Math.floor(new Date(purchase.date).getTime() / 1000)}:F>`, inline: false },
    { name: 'Status', value: purchase.status, inline: false },
  );
}

function canCloseTopic(interaction, purchase) {
  const cfg = getConfig(interaction.guildId);
  const roles = new Set(cfg.roles.lojaAtendimento ?? []);
  const memberRoles = interaction.member?.roles?.cache;
  return interaction.user.id === purchase.buyerId
    || Boolean(memberRoles?.some((role) => roles.has(role.id)))
    || interaction.member?.permissions?.has(PermissionFlagsBits.ManageThreads);
}

async function validarEntregaCargo(interaction, roleId) {
  const role = await interaction.guild.roles.fetch(roleId).catch(() => null);
  const member = await interaction.guild.members.fetch(interaction.user.id).catch(() => null);
  const botMember = interaction.guild.members.me
    ?? await interaction.guild.members.fetchMe().catch(() => null);

  if (!role) return { ok: false, message: 'O cargo deste produto não existe mais. Remova o produto e crie outro.' };
  if (role.managed) return { ok: false, message: 'Este produto usa um cargo gerenciado pelo Discord. Remova o produto e crie outro com um cargo comum.' };
  if (!member) return { ok: false, message: 'Não foi possível localizar seu membro no servidor.' };
  if (!botMember?.permissions?.has(PermissionFlagsBits.ManageRoles)) {
    return { ok: false, message: 'O bot precisa da permissão **Gerenciar cargos** para entregar este produto.' };
  }
  if (!role.editable || role.position >= botMember.roles.highest.position) {
    return { ok: false, message: `O cargo **${role.name}** precisa ficar abaixo do cargo mais alto do bot na hierarquia do servidor.` };
  }
  if (member.id === interaction.guild.ownerId) {
    return { ok: false, message: 'O dono do servidor não pode ter cargos alterados por um bot. A compra não pode ser entregue a este membro.' };
  }
  if (!member.manageable) {
    const memberHighest = member.roles.highest;
    const botHighest = botMember.roles.highest;
    return {
      ok: false,
      message: `O cargo mais alto do comprador é **${memberHighest.name}** e o cargo mais alto do bot é **${botHighest.name}**. Mova o cargo do bot acima do cargo do comprador na hierarquia do servidor.`,
    };
  }
  return { ok: true, role, member };
}

function closeModal(purchaseId) {
  const modal = new ModalBuilder().setCustomId(`loja:topic:closemodal:${purchaseId}`).setTitle('Fechar tópico');
  modal.addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('reason').setLabel('Motivo do fechamento (opcional)').setStyle(TextInputStyle.Paragraph).setRequired(false).setMaxLength(500)));
  return modal;
}

function transcriptHtml(channel, messages, reason = '') {
  const escape = (value) => String(value ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const body = messages.map((message) => `<article><strong>${escape(message.author?.username || 'Usuário')}</strong> <time>${new Date(message.createdTimestamp).toLocaleString('pt-BR')}</time><p>${escape(message.content)}</p></article>`).join('\n');
  return `<!doctype html><html lang="pt-BR"><meta charset="utf-8"><title>Transcript Loja</title><style>body{background:#313338;color:#dbdee1;font:15px Arial;padding:24px}article{padding:12px 0;border-bottom:1px solid #4e5058}time{color:#949ba4;font-size:12px}p{white-space:pre-wrap}</style><h1>Transcript da Loja</h1><p>Motivo: ${escape(reason || 'Não informado')}</p>${body}</html>`;
}

async function closeTopic(interaction, purchase, reason) {
  const data = guildState(interaction.guildId);
  const topic = data.topics.find((item) => item.purchaseId === purchase.id);
  const channel = topic ? await interaction.guild.channels.fetch(topic.threadId).catch(() => null) : null;
  if (!channel) return { ok: false, message: 'Tópico não encontrado.' };
  const messages = [];
  let before;
  for (let i = 0; i < 10; i += 1) {
    const batch = await channel.messages.fetch({ limit: 100, ...(before ? { before } : {}) }).catch(() => null);
    if (!batch?.size) break;
    messages.push(...batch.values());
    before = batch.last()?.id;
    if (batch.size < 100) break;
  }
  const cfg = getConfig(interaction.guildId);
  const logChannel = cfg.channels.ticketsLogs ? await interaction.guild.channels.fetch(cfg.channels.ticketsLogs).catch(() => null) : null;
  const html = transcriptHtml(channel, messages, reason);
  if (logChannel) await logChannel.send({ content: `Compra da Loja encerrada: ${purchase.productName}`, files: [{ attachment: Buffer.from(html, 'utf8'), name: `transcript-loja-${purchase.id}.html` }] }).catch(() => {});
  purchase.status = 'Encerrada';
  data.topics = data.topics.filter((item) => item.purchaseId !== purchase.id);
  saveData();
  await channel.delete('Compra da Loja encerrada').catch(() => {});
  return { ok: true };
}

async function handleLoja(interaction, client) {
  const id = interaction.customId ?? '';
  const guildId = interaction.guildId;

  // Fluxo que também pode acontecer por DM: resgate da licença.
  if (interaction.isButton() && id.startsWith('lic:redeem:')) {
    const found = findLicenseSale(id.split(':').pop());
    if (!found || found.sale.buyerId !== interaction.user.id || found.sale.status !== 'entregue' || licenseExpired(found.sale)) {
      await interaction.reply({ content: 'Esta licença não está disponível para sua conta.', flags: MessageFlags.Ephemeral });
      return true;
    }
    await interaction.showModal(redeemModal(found.sale.id));
    return true;
  }

  if (interaction.isModalSubmit() && id.startsWith('lic:redeem:modal:')) {
    const found = findLicenseSale(id.split(':').pop());
    if (!found || found.sale.buyerId !== interaction.user.id || found.sale.status !== 'entregue' || licenseExpired(found.sale)) {
      await interaction.reply({ content: 'Esta licença não está disponível para sua conta.', flags: MessageFlags.Ephemeral });
      return true;
    }
    if (pendingLicenseRedeems.has(found.sale.id)) {
      await interaction.reply({ content: 'Este resgate já está sendo processado. Aguarde alguns segundos.', flags: MessageFlags.Ephemeral });
      return true;
    }
    pendingLicenseRedeems.add(found.sale.id);
    try {
    const targetGuildId = interaction.fields.getTextInputValue('guildId').trim();
    if (!/^\d{15,25}$/.test(targetGuildId)) {
      await interaction.reply({ content: 'Informe um ID de servidor Discord válido.', flags: MessageFlags.Ephemeral });
      return true;
    }
    if (found.sale.activatedGuildId) {
      await interaction.reply({ content: `Esta licença já foi ativada no servidor \`${found.sale.activatedGuildId}\`.`, flags: MessageFlags.Ephemeral });
      return true;
    }
    if (!await botManager.isSlotInGuild(found.sale.slot, targetGuildId)) {
      await interaction.reply({ content: 'O bot desta licença não está adicionado ao servidor informado. Use **Adicionar bot** e tente novamente.', flags: MessageFlags.Ephemeral });
      return true;
    }
    found.sale.activatedGuildId = targetGuildId;
    found.sale.activatedAt = new Date().toISOString();
    found.sale.status = 'ativado';
    saveData();
    watchPlanExpiry(interaction.client, found.sale);
    await logLicenseEvent(interaction.client, found.guildId, 'LICENÇA ATIVADA', [
      { name: 'Venda', value: `\`${found.sale.id}\`` },
      { name: 'Comprador', value: `<@${found.sale.buyerId}>`, inline: true },
      { name: 'Servidor', value: `\`${targetGuildId}\``, inline: true },
    ]);
    await interaction.reply({ content: `Licença ativada com sucesso no servidor \`${targetGuildId}\`.`, flags: MessageFlags.Ephemeral });
    return true;
    } finally {
      pendingLicenseRedeems.delete(found.sale.id);
    }
  }

  if (interaction.isChatInputCommand() && interaction.commandName === 'coins') {
    const { handleCoins } = require('./coins');
    return handleCoins(interaction, client);
  }

  if (interaction.isChatInputCommand() && interaction.commandName === 'plano') {
    if (interaction.options.getSubcommand() !== 'dar') return false;
    return darPlano(interaction, client);
  }

  if (interaction.isChatInputCommand() && interaction.commandName === 'loja') {
    if (interaction.options.getSubcommand() !== 'coins') return false;
    if (!interaction.member?.permissions?.has(PermissionFlagsBits.ManageGuild)) {
      await interaction.reply({ content: 'Você precisa da permissão **Gerenciar servidor** para configurar a Loja de Coins.', flags: MessageFlags.Ephemeral });
      return true;
    }
    await interaction.reply({
      ...mainPanel(guildId),
      flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
    });
    return true;
  }
  if (!guildId) return false;

  if (id.startsWith('lic:')) {
    const publicAction = id === 'lic:public:buy'
      || id.startsWith('lic:topic:')
      || id.startsWith('lic:copy:');
    if (!publicAction && !licenseCanManage(interaction)) {
      await interaction.reply({ content: 'Apenas o cargo de dono configurado pode administrar a loja.', flags: MessageFlags.Ephemeral });
      return true;
    }

    if (interaction.isButton() && id === 'lic:public:buy') {
      const result = await createLicenseTopic(interaction, client);
      if (!result.ok) {
        await interaction.reply({ content: result.message, flags: MessageFlags.Ephemeral });
        return true;
      }
      await interaction.reply({ content: `Seu tópico de compra foi criado: <#${result.thread.id}>`, flags: MessageFlags.Ephemeral });
      return true;
    }

    if (interaction.isButton() && id === 'lic:publish') {
      await publishLicensePanel(interaction, client);
      return true;
    }

    if (interaction.isChannelSelectMenu() && id === 'lic:publish:channel') {
      const channel = await interaction.guild.channels.fetch(interaction.values[0]).catch(() => null);
      if (!channel?.send) {
        await interaction.reply({ content: 'Não foi possível acessar este canal.', flags: MessageFlags.Ephemeral });
        return true;
      }
      const message = await channel.send(licensePublicPanel(guildId));
      licenseData(guildId).panels.push({ channelId: channel.id, messageId: message.id });
      saveData();
      await interaction.update(licenseAdminPanel(guildId, 'Painel público publicado com sucesso.'));
      return true;
    }

    if (interaction.isStringSelectMenu() && id === 'lic:admin:menu') {
      await interaction.update(interaction.values[0] === 'appearance'
        ? licenseAppearancePanel(guildId)
        : licenseShopPanel(guildId));
      return true;
    }

    if (interaction.isButton() && id === 'lic:admin:back') {
      await interaction.update(licenseAdminPanel(guildId));
      return true;
    }
    if (interaction.isButton() && id === 'lic:appearance:back') {
      await interaction.update(licenseAppearancePanel(guildId));
      return true;
    }
    if (interaction.isButton() && id === 'lic:shop:back') {
      await interaction.update(licenseShopPanel(guildId));
      return true;
    }

    if (interaction.isButton() && id === 'lic:appearance:title') {
      await interaction.showModal(licenseTextModal('lic:appearance:modal:title', 'Título do painel', 'Título', licenseData(guildId).appearance.title, TextInputStyle.Short, 256));
      return true;
    }
    if (interaction.isButton() && id === 'lic:appearance:description') {
      await interaction.showModal(licenseTextModal('lic:appearance:modal:description', 'Descrição do painel', 'Descrição', licenseData(guildId).appearance.description));
      return true;
    }
    if (interaction.isButton() && id === 'lic:appearance:images') {
      await interaction.update(licenseImagesPanel(guildId));
      return true;
    }
    if (interaction.isButton() && id === 'lic:appearance:color') {
      const current = Number(licenseData(guildId).appearance.color).toString(16).padStart(6, '0');
      await interaction.showModal(licenseTextModal('lic:appearance:modal:color', 'Cor do painel', 'Hex (#RRGGBB)', `#${current}`, TextInputStyle.Short, 7));
      return true;
    }
    if (interaction.isButton() && id === 'lic:appearance:button') {
      await interaction.showModal(licenseButtonModal(guildId));
      return true;
    }
    if (interaction.isButton() && id === 'lic:images:banner') {
      await interaction.showModal(licenseTextModal('lic:images:modal:banner', 'Banner do painel', 'URL do banner', licenseData(guildId).appearance.banner, TextInputStyle.Short, 1000));
      return true;
    }
    if (interaction.isButton() && id === 'lic:images:thumbnail') {
      await interaction.showModal(licenseTextModal('lic:images:modal:thumbnail', 'Thumbnail do painel', 'URL da thumbnail', licenseData(guildId).appearance.thumbnail, TextInputStyle.Short, 1000));
      return true;
    }
    if (interaction.isModalSubmit() && id === 'lic:appearance:modal:button') {
      const label = interaction.fields.getTextInputValue('buttonName').trim();
      const style = interaction.fields.getTextInputValue('buttonColor').trim();
      const emoji = interaction.fields.getTextInputValue('buttonEmoji').trim();
      if (!label) {
        await interaction.reply({ content: 'Informe um nome para o botão.', flags: MessageFlags.Ephemeral });
        return true;
      }
      if (!['Primary', 'Secondary', 'Success', 'Danger'].includes(style)) {
        await interaction.reply({ content: 'A cor precisa ser `Primary`, `Secondary`, `Success` ou `Danger`.', flags: MessageFlags.Ephemeral });
        return true;
      }
      if (emoji && !/^<(a?):[A-Za-z0-9_]+:\d+>$/.test(emoji) && !/\p{Extended_Pictographic}/u.test(emoji)) {
        await interaction.reply({ content: 'Informe um emoji Unicode ou personalizado no formato `<:nome:id>`.', flags: MessageFlags.Ephemeral });
        return true;
      }
      const data = licenseData(guildId);
      data.appearance.button = { label: label.slice(0, 80), style, emoji: emoji || null };
      saveData();
      await refreshLicensePanels(client, guildId);
      await interaction.deferUpdate();
      await interaction.editReply(licenseAppearancePanel(guildId, 'Botão Comprar atualizado e painéis sincronizados.'));
      return true;
    }
    if (interaction.isModalSubmit() && (id.startsWith('lic:appearance:modal:') || id.startsWith('lic:images:modal:'))) {
      const key = id.split(':').pop();
      const value = interaction.fields.getTextInputValue('value').trim();
      const data = licenseData(guildId);
      if (key === 'color') {
        if (!/^#[0-9a-f]{6}$/i.test(value)) {
          await interaction.reply({ content: 'Informe uma cor no formato `#RRGGBB`.', flags: MessageFlags.Ephemeral });
          return true;
        }
        data.appearance.color = parseInt(value.slice(1), 16);
      } else if (key === 'title' || key === 'description') {
        data.appearance[key] = value || data.appearance[key];
      } else {
        data.appearance[key] = value || null;
      }
      saveData();
      await refreshLicensePanels(client, guildId);
      await interaction.deferUpdate();
      await interaction.editReply(licenseAppearancePanel(guildId, 'Aparência atualizada e painéis sincronizados.'));
      return true;
    }

    if (interaction.isButton() && id === 'lic:shop:billing') {
      await interaction.showModal(licenseBillingModal(guildId));
      return true;
    }
    if (interaction.isButton() && id === 'lic:shop:channel') {
      await interaction.update(painelV2FromEmbed(
        new EmbedBuilder().setColor(color(guildId)).setTitle('CANAL DOS TÓPICOS DE COMPRA').setDescription('Selecione o canal-pai dos tópicos privados.'),
        [
          new ActionRowBuilder().addComponents(new ChannelSelectMenuBuilder().setCustomId('lic:shop:channel:select').setPlaceholder('Canal-pai dos tópicos').setChannelTypes([ChannelType.GuildText, ChannelType.GuildAnnouncement])),
          new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('lic:shop:back').setLabel('Voltar').setStyle(ButtonStyle.Secondary)),
        ],
      ));
      return true;
    }
    if (interaction.isChannelSelectMenu() && id === 'lic:shop:channel:select') {
      licenseData(guildId).shop.topicChannelId = interaction.values[0];
      saveData();
      await interaction.update(licenseShopPanel(guildId, 'Canal dos tópicos atualizado.'));
      return true;
    }
    if (interaction.isButton() && id === 'lic:shop:logs') {
      await interaction.update(painelV2FromEmbed(
        new EmbedBuilder()
          .setColor(color(guildId))
          .setTitle('CANAL DE LOGS DA LOJA')
          .setDescription('Selecione o canal onde serão registrados eventos de reservas, pagamentos, entregas, cancelamentos e ativações. O código Pix e tokens nunca são enviados aos logs.')
          .addFields({
            name: 'Canal atual',
            value: licenseData(guildId).shop.logChannelId ? `<#${licenseData(guildId).shop.logChannelId}>` : 'Não definido',
          }),
        [
          new ActionRowBuilder().addComponents(
            new ChannelSelectMenuBuilder()
              .setCustomId('lic:shop:logs:select')
              .setPlaceholder('Selecione o canal de logs')
              .setChannelTypes([ChannelType.GuildText, ChannelType.GuildAnnouncement]),
          ),
          new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('lic:shop:back').setLabel('Voltar').setStyle(ButtonStyle.Secondary),
          ),
        ],
      ));
      return true;
    }
    if (interaction.isChannelSelectMenu() && id === 'lic:shop:logs:select') {
      licenseData(guildId).shop.logChannelId = interaction.values[0];
      saveData();
      await interaction.update(licenseShopPanel(guildId, 'Canal de logs atualizado.'));
      return true;
    }
    if (interaction.isButton() && id === 'lic:shop:token') {
      if (!secretKey()) {
        await interaction.reply({ content: 'Configure `SESSION_SECRET` antes de salvar o token do Mercado Pago.', flags: MessageFlags.Ephemeral });
        return true;
      }
      await interaction.showModal(licenseTokenModal());
      return true;
    }
    if (interaction.isModalSubmit() && id === 'lic:shop:modal:billing') {
      const price = Number(interaction.fields.getTextInputValue('price').replace(',', '.'));
      const dark = interaction.fields.getTextInputValue('qrDark').trim();
      const light = interaction.fields.getTextInputValue('qrLight').trim();
      if (!Number.isFinite(price) || price <= 0 || !/^#[0-9a-f]{6}$/i.test(dark) || !/^#[0-9a-f]{6}$/i.test(light)) {
        await interaction.reply({ content: 'Preço inválido ou cor fora do formato `#RRGGBB`.', flags: MessageFlags.Ephemeral });
        return true;
      }
      const data = licenseData(guildId);
      data.shop.price = Math.round(price * 100) / 100;
      data.shop.qrDark = dark;
      data.shop.qrLight = light;
      saveData();
      await refreshLicensePanels(client, guildId);
      await interaction.deferUpdate();
      await interaction.editReply(licenseShopPanel(guildId, 'Preço e QR Code atualizados.'));
      return true;
    }
    if (interaction.isModalSubmit() && id === 'lic:shop:modal:token') {
      const token = interaction.fields.getTextInputValue('token').trim();
      if (!token || /\s/.test(token)) {
        await interaction.reply({ content: 'Informe um Access Token válido, sem espaços.', flags: MessageFlags.Ephemeral });
        return true;
      }
      licenseData(guildId).shop.mpToken = encryptSecret(token);
      saveData();
      await interaction.deferUpdate();
      await interaction.editReply(licenseShopPanel(guildId, 'Token MP salvo de forma criptografada.'));
      return true;
    }

    if (interaction.isButton() && id.startsWith('lic:topic:')) {
      const sale = licenseData(guildId).sales.find((item) => item.id === id.split(':').pop());
      if (!sale || !licenseCanOperateTopic(interaction, sale)) {
        await interaction.reply({ content: 'Você não possui acesso a esta compra.', flags: MessageFlags.Ephemeral });
        return true;
      }
      if (id.startsWith('lic:topic:cancel:')) {
        sale.status = 'cancelado';
        botManager.releaseReservation(sale.slot, sale.id);
        saveData();
        await logLicenseEvent(client, guildId, 'COMPRA CANCELADA', [
          { name: 'Venda', value: `\`${sale.id}\`` },
          { name: 'Comprador', value: `<@${sale.buyerId}>`, inline: true },
          { name: 'Bot liberado', value: sale.botTag ? `\`${sale.botTag}\`` : `<@${sale.botId}>`, inline: true },
        ]);
        await interaction.update({ content: 'Compra cancelada. O bot voltou ao estoque.', embeds: [], components: [] });
        await interaction.channel?.delete('Compra cancelada').catch(() => {});
        return true;
      }
      if (id.startsWith('lic:topic:confirm:')) {
        if (sale.status !== 'reservando_estoque') {
          await interaction.reply({ content: 'Esta compra já foi processada.', flags: MessageFlags.Ephemeral });
          return true;
        }
        await interaction.deferUpdate();
        try {
          const payment = await createPixPayment(guildId, sale);
          if (!payment.ok) {
            await interaction.editReply(licenseTopicPanel(sale, payment.message));
            return true;
          }
          await interaction.editReply(await licensePaymentPanel(guildId, sale));
          await logLicenseEvent(client, guildId, 'PIX GERADO', [
            { name: 'Venda', value: `\`${sale.id}\`` },
            { name: 'Comprador', value: `<@${sale.buyerId}>`, inline: true },
            { name: 'Valor', value: `R$ ${Number(sale.price).toFixed(2).replace('.', ',')}`, inline: true },
          ]);
          watchPayment(client, guildId, sale);
          return true;
        } catch (error) {
          console.error(`[LOJA] Falha ao gerar Pix — sale=${sale.id}:`, error.message);
          await interaction.editReply(licenseTopicPanel(
            sale,
            'Não foi possível gerar o Pix agora. Tente clicar em **Confirmar** novamente.',
          ));
          return true;
        }
      }
    }

    if (interaction.isButton() && id.startsWith('lic:copy:')) {
      const sale = licenseData(guildId).sales.find((item) => item.id === id.split(':').pop());
      if (!sale?.copyPaste || !licenseCanOperateTopic(interaction, sale)) {
        await interaction.reply({ content: 'Código de pagamento indisponível.', flags: MessageFlags.Ephemeral });
        return true;
      }
      await interaction.reply({ content: sale.copyPaste, allowedMentions: { parse: [] } });
      return true;
    }
  }

  if (interaction.isRoleSelectMenu() && id === 'loja:config:roles') {
    const cfg = getConfig(guildId);
    cfg.roles.lojaAtendimento = [...new Set(interaction.values.map(String))];
    salvarConfiguracoesLoja();
    await interaction.update(configPanel(guildId, 'Cargos de atendimento atualizados.'));
    return true;
  }
  if (interaction.isChannelSelectMenu() && id === 'loja:config:channel') {
    const cfg = getConfig(guildId);
    cfg.channels.lojaTopicos = interaction.values[0];
    salvarConfiguracoesLoja();
    await interaction.update(configPanel(guildId, 'Canal dos tópicos atualizado.'));
    return true;
  }
  if (interaction.isButton() && id === 'loja:config:back') {
    await interaction.update(painelPrincipal(guildId));
    return true;
  }

  if (interaction.isStringSelectMenu() && id === 'loja:menu') {
    await interaction.update(interaction.values[0] === 'products' ? productPanel(guildId) : appearancePanel(guildId));
    return true;
  }
  if (interaction.isButton() && id === 'loja:send') {
    const data = guildState(guildId);
    if (!Array.isArray(data.products) || data.products.length === 0) {
      await interaction.reply({
        content: 'Para enviar o painel precisa de pelo menos 1 produto cadastrado',
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }
    await interaction.update(painelV2FromEmbed(
      new EmbedBuilder().setColor(color(guildId)).setTitle('ENVIAR LOJA').setDescription('Selecione o canal onde o painel público será enviado.'),
      [
        new ActionRowBuilder().addComponents(
          new ChannelSelectMenuBuilder().setCustomId('loja:send:channel').setPlaceholder('Selecione um canal').setChannelTypes([ChannelType.GuildText, ChannelType.GuildAnnouncement]),
        ),
        new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('loja:back:main').setLabel('Voltar').setStyle(ButtonStyle.Secondary),
        ),
      ],
    ));
    return true;
  }
  if (interaction.isChannelSelectMenu() && id === 'loja:send:channel') {
    const data = guildState(guildId);
    if (!Array.isArray(data.products) || data.products.length === 0) {
      await interaction.reply({
        content: 'Para enviar o painel precisa de pelo menos 1 produto cadastrado',
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }
    const channelId = interaction.values[0];
    const channel = await interaction.guild.channels.fetch(channelId).catch(() => null);
    if (!channel?.send) {
      await interaction.reply({ content: 'Não foi possível acessar este canal.', flags: MessageFlags.Ephemeral });
      return true;
    }
    const message = await channel.send(publicPanel(guildId));
    data.panels.push({ channelId, messageId: message.id });
    saveData();
    await interaction.update(mainPanel(guildId, `Painel público enviado com sucesso ao canal <#${channelId}>.`));
    return true;
  }
  if (interaction.isButton() && id === 'loja:product:create') {
    await interaction.update(createProductTypePanel(guildId));
    return true;
  }
  if (interaction.isStringSelectMenu() && id === 'loja:product:type') {
    await interaction.showModal(productModal(interaction.values[0]));
    return true;
  }
  if (interaction.isModalSubmit() && id.startsWith('loja:product:modal:')) {
    const type = id.split(':').pop();
    const data = guildState(guildId);
    if (data.products.length >= MAX_PRODUCTS) {
      await interaction.deferUpdate();
      await interaction.editReply(productPanel(guildId, `O Discord permite no máximo ${MAX_PRODUCTS} produtos neste menu.`));
      return true;
    }
    const name = interaction.fields.getTextInputValue('name').trim();
    const description = interaction.fields.getTextInputValue('description').trim();
    const price = Number(interaction.fields.getTextInputValue('price').replace(',', '.'));
    if (!name || !description || !Number.isInteger(price) || price < 0) {
      await interaction.deferUpdate();
      await interaction.editReply(productPanel(guildId, 'Informe nome, descrição e um preço inteiro de Coins válido.'));
      return true;
    }
    if (type === 'role') {
      pendingRoleProducts.set(`${guildId}:${interaction.user.id}`, { name, description, price });
      await interaction.deferUpdate();
      await interaction.editReply(painelV2FromEmbed(
        new EmbedBuilder().setColor(color(guildId)).setTitle('CARGO DO PRODUTO').setDescription('Selecione o cargo que será entregue ao comprador.'),
        [new ActionRowBuilder().addComponents(
          new RoleSelectMenuBuilder().setCustomId('loja:product:role').setPlaceholder('Selecione o cargo'),
        )],
      ));
    } else {
      data.products.push({ id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, type, name, description, price, roleId: null });
      saveData();
      await refreshPublishedPanels(client, guildId);
      await interaction.deferUpdate();
      await interaction.editReply(productPanel(guildId, 'Produto personalizado criado com sucesso.'));
    }
    return true;
  }
  if (interaction.isRoleSelectMenu() && id === 'loja:product:role') {
    const pending = pendingRoleProducts.get(`${guildId}:${interaction.user.id}`);
    if (!pending) {
      await interaction.deferUpdate();
      await interaction.editReply(productPanel(guildId, 'A sessão de criação expirou. Tente novamente.'));
      return true;
    }
    const role = await interaction.guild.roles.fetch(interaction.values[0]).catch(() => null);
    if (!role) {
      await interaction.deferUpdate();
      await interaction.editReply(productPanel(guildId, 'Não foi possível localizar esse cargo. Escolha um cargo comum do servidor.'));
      return true;
    }
    if (role.managed) {
      await interaction.deferUpdate();
      await interaction.editReply(productPanel(guildId, 'Cargos gerenciados pelo Discord não podem ser usados em produtos. Escolha um cargo comum do servidor.'));
      return true;
    }
    pendingRoleProducts.delete(`${guildId}:${interaction.user.id}`);
    const data = guildState(guildId);
    data.products.push({ id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, type: 'role', ...pending, roleId: interaction.values[0] });
    saveData();
    await refreshPublishedPanels(client, guildId);
    await interaction.update(productPanel(guildId, 'Produto de cargo criado com sucesso.'));
    return true;
  }
  if (interaction.isButton() && id === 'loja:product:remove') {
    const data = guildState(guildId);
    if (!data.products.length) {
      await interaction.update(productPanel(guildId, 'Não há produtos para remover.'));
      return true;
    }
    await interaction.update(painelV2FromEmbed(
      new EmbedBuilder().setColor(color(guildId)).setTitle('REMOVER PRODUTO').setDescription('Selecione o produto que será removido.'),
      [new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder().setCustomId('loja:product:remove:select').setPlaceholder('Selecione um produto').addOptions(data.products.map((p) => ({ label: p.name.slice(0, 100), value: p.id, description: `${p.price} Coins` }))),
      )],
    ));
    return true;
  }
  if (interaction.isStringSelectMenu() && id === 'loja:product:remove:select') {
    const data = guildState(guildId);
    data.products = data.products.filter((p) => p.id !== interaction.values[0]);
    saveData();
    await refreshPublishedPanels(client, guildId);
    await interaction.update(productPanel(guildId, 'Produto removido e painéis atualizados.'));
    return true;
  }
  if (interaction.isButton() && id === 'loja:product:view') {
    await interaction.update(productsEmbed(guildId));
    return true;
  }
  if (interaction.isButton() && id === 'loja:back:main') {
    await interaction.update(mainPanel(guildId));
    return true;
  }
  if (interaction.isButton() && id === 'loja:back:products') {
    await interaction.update(productPanel(guildId));
    return true;
  }
  if (interaction.isButton() && id === 'loja:back:appearance') {
    await interaction.update(appearancePanel(guildId));
    return true;
  }
  if (interaction.isButton() && id === 'loja:appearance:images') {
    await interaction.update(imagesPanel(guildId));
    return true;
  }
  if (interaction.isButton() && id === 'loja:appearance:title') {
    await interaction.showModal(textModal('loja:appearance:modal:title', 'Título da Loja', 'value', 'Título', guildState(guildId).appearance.title, TextInputStyle.Short, 256));
    return true;
  }
  if (interaction.isButton() && id === 'loja:appearance:description') {
    await interaction.showModal(textModal('loja:appearance:modal:description', 'Descrição da Loja', 'value', 'Descrição', guildState(guildId).appearance.description));
    return true;
  }
  if (interaction.isButton() && id === 'loja:images:banner') {
    await interaction.showModal(textModal('loja:images:modal:banner', 'Banner da Loja', 'value', 'URL do Banner', guildState(guildId).appearance.banner, TextInputStyle.Short, 1000));
    return true;
  }
  if (interaction.isButton() && id === 'loja:images:thumbnail') {
    await interaction.showModal(textModal('loja:images:modal:thumbnail', 'Thumbnail da Loja', 'value', 'URL da Thumbnail', guildState(guildId).appearance.thumbnail, TextInputStyle.Short, 1000));
    return true;
  }
  if (interaction.isModalSubmit() && id.startsWith('loja:appearance:modal:')) {
    const key = id.split(':').pop();
    guildState(guildId).appearance[key === 'title' ? 'title' : 'description'] = interaction.fields.getTextInputValue('value').trim();
    saveData();
    await refreshPublishedPanels(client, guildId);
    await interaction.deferUpdate();
    await interaction.editReply(appearancePanel(guildId, 'Aparência atualizada e painéis refreshados.'));
    return true;
  }
  if (interaction.isModalSubmit() && id.startsWith('loja:images:modal:')) {
    const key = id.split(':').pop();
    guildState(guildId).appearance[key] = interaction.fields.getTextInputValue('value').trim() || null;
    saveData();
    await refreshPublishedPanels(client, guildId);
    await interaction.deferUpdate();
    await interaction.editReply(imagesPanel(guildId, 'Imagem atualizada e painéis refreshados.'));
    return true;
  }
  if (interaction.isStringSelectMenu() && id === 'loja:public:product') {
    const product = productById(guildId, interaction.values[0]);
    if (!product) {
      await interaction.reply({ content: 'Este produto não está mais disponível.', flags: MessageFlags.Ephemeral });
      return true;
    }
    if (coins(guildId, interaction.user.id) < product.price) {
      await interaction.reply({ content: `Você possui ${coins(guildId, interaction.user.id)} Coins e precisa de ${product.price}.`, flags: MessageFlags.Ephemeral });
      return true;
    }
    await interaction.reply({
      embeds: [new EmbedBuilder().setColor(color(guildId)).setTitle('CONFIRMAÇÃO DA COMPRA').setDescription(`Produto: **${product.name}**\nValor: **${product.price} Coins**\nSeu saldo: **${coins(guildId, interaction.user.id)} Coins**`)],
      components: [new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`loja:buy:confirm:${product.id}`).setLabel('Confirmar Compra').setStyle(ButtonStyle.Success), new ButtonBuilder().setCustomId('loja:buy:cancel').setLabel('Cancelar').setStyle(ButtonStyle.Danger))],
      flags: MessageFlags.Ephemeral,
    });
    return true;
  }
  if (interaction.isButton() && id === 'loja:buy:cancel') {
    await interaction.update({ content: 'Compra cancelada.', embeds: [], components: [] });
    return true;
  }
  if (interaction.isButton() && id.startsWith('loja:buy:confirm:')) {
    const product = productById(guildId, id.split(':').pop());
    if (!product || coins(guildId, interaction.user.id) < product.price) {
      await interaction.update({ content: 'Produto indisponível ou Coins insuficientes.', embeds: [], components: [] });
      return true;
    }
    let entrega = null;
    if (product.type === 'role') {
      entrega = await validarEntregaCargo(interaction, product.roleId);
      if (!entrega.ok) {
        await interaction.update({ content: `Compra não realizada. ${entrega.message} Nenhuma Coin foi descontada.`, embeds: [], components: [] });
        return true;
      }
    }
    const purchaseLock = `${guildId}:${interaction.user.id}:${product.id}`;
    if (pendingPurchases.has(purchaseLock)) {
      await interaction.update({ content: 'Esta compra já está sendo processada.', embeds: [], components: [] });
      return true;
    }
    pendingPurchases.add(purchaseLock);
    try {
    const debit = changeCoins(guildId, interaction.user.id, -product.price, `Compra: ${product.name}`, { productId: product.id });
    if (!debit.ok) {
      await interaction.update({ content: 'Não foi possível debitar suas Coins.', embeds: [], components: [] });
      return true;
    }
    const data = guildState(guildId);
    if (product.type === 'role') {
      const purchase = {
        id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        productId: product.id,
        productName: product.name,
        buyerId: interaction.user.id,
        price: product.price,
        date: new Date().toISOString(),
        status: 'Cargo entregue',
      };
      data.purchases.push(purchase);
      saveData();
      let roleError = null;
      try {
        await entrega.member.roles.add(entrega.role, `Compra da Loja: ${product.name}`);
      } catch (error) {
        roleError = error;
        console.error(`[LOJA] Falha ao entregar cargo — guild=${guildId} user=${interaction.user.id} role=${product.roleId} code=${error.code ?? 'desconhecido'} message=${error.message}`);
      }
      if (roleError) {
        purchase.status = 'Estornada';
        saveData();
        changeCoins(guildId, interaction.user.id, product.price, 'Estorno: falha ao entregar cargo', { productId: product.id });
        await interaction.update({ content: `Não foi possível entregar o cargo. Suas Coins foram estornadas. Motivo técnico: ${roleError.message || 'permissão ou hierarquia do servidor'}.`, embeds: [], components: [] });
        return true;
      }
      await interaction.update({ content: `Compra concluída. O cargo <@&${entrega.role.id}> foi entregue. Saldo: **${debit.after} Coins**.`, embeds: [], components: [] });
    } else {
      const result = await createCustomTopic(interaction, client, product);
      if (!result.ok) {
        changeCoins(guildId, interaction.user.id, product.price, 'Estorno: tópico indisponível', { productId: product.id });
        await interaction.update({ content: result.message, embeds: [], components: [] });
        return true;
      }
      await interaction.update({ content: `Compra confirmada. Seu tópico foi criado em <#${result.thread.id}>. Saldo: **${debit.after} Coins**.`, embeds: [], components: [] });
    }
    return true;
    } finally {
      pendingPurchases.delete(purchaseLock);
    }
  }
  if (interaction.isButton() && id.startsWith('loja:topic:close:')) {
    const purchase = guildState(guildId).purchases.find((item) => item.id === id.split(':').pop());
    if (!purchase || !canCloseTopic(interaction, purchase)) {
      await interaction.reply({ content: 'Você não possui permissão para fechar este tópico.', flags: MessageFlags.Ephemeral });
      return true;
    }
    await interaction.showModal(closeModal(id.split(':').pop()));
    return true;
  }
  if (interaction.isModalSubmit() && id.startsWith('loja:topic:closemodal:')) {
    const purchaseId = id.split(':').pop();
    pendingClosures.set(`${guildId}:${interaction.user.id}:${purchaseId}`, interaction.fields.getTextInputValue('reason').trim());
    await interaction.reply({ embeds: [new EmbedBuilder().setColor(color(guildId)).setTitle('CONFIRMAÇÃO DO FECHAMENTO').setDescription('Gerar transcript, enviar aos logs e encerrar o tópico?')], components: [new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`loja:topic:confirm:${purchaseId}`).setLabel('Confirmar').setStyle(ButtonStyle.Success), new ButtonBuilder().setCustomId(`loja:topic:cancel:${purchaseId}`).setLabel('Cancelar').setStyle(ButtonStyle.Danger))], flags: MessageFlags.Ephemeral });
    return true;
  }
  if (interaction.isButton() && (id.startsWith('loja:topic:confirm:') || id.startsWith('loja:topic:cancel:'))) {
    const purchaseId = id.split(':').pop();
    const key = `${guildId}:${interaction.user.id}:${purchaseId}`;
    if (id.includes(':cancel:')) {
      pendingClosures.delete(key);
      await interaction.update({ content: 'Fechamento cancelado.', embeds: [], components: [] });
      return true;
    }
    const purchase = guildState(guildId).purchases.find((item) => item.id === purchaseId);
    const reason = pendingClosures.get(key) || '';
    pendingClosures.delete(key);
    const result = purchase ? await closeTopic(interaction, purchase, reason) : { ok: false, message: 'Compra não encontrada.' };
    await interaction.update({ content: result.ok ? 'Tópico encerrado e transcript enviado.' : result.message, embeds: [], components: [] });
    return true;
  }
  return false;
}

async function restorePanels(client) {
  for (const guildId of Object.keys(state)) {
    await refreshPublishedPanels(client, guildId);
    await refreshLicensePanels(client, guildId);
  }
  restoreLicensePayments(client);
}

module.exports = {
  handleLoja,
  handleLicenseMessage,
  configPanel,
  restorePanels,
  registrarRecompensas,
  coins,
};