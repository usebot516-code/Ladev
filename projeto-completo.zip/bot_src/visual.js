'use strict';

const {
  ContainerBuilder,
  TextDisplayBuilder,
  MediaGalleryBuilder,
  MediaGalleryItemBuilder,
  SectionBuilder,
  ThumbnailBuilder,
  MessageFlags,
} = require('discord.js');

const EMOJI_PAINEL = '';

// The Discord client owns the actual corner radius. Components V2 gives us the
// closest supported equivalent to a single square-cornered panel with its
// controls inside the same visual surface.
function stripEmoji(value) {
  return String(value ?? '')
    .replace(/<a?:[A-Za-z0-9_~]+:\d+>/g, '')
    .replace(/[\p{Extended_Pictographic}\uFE0F\u200D]/gu, '')
    .replace(/[ \t]{2,}/g, ' ')
    .trim();
}

function _textoEmbed(embed) {
  const data = typeof embed?.toJSON === 'function' ? embed.toJSON() : (embed ?? {});
  const linhas = [];
  const title = stripEmoji(data.title);

  if (title) linhas.push(`## ${title}`);
  if (data.description) linhas.push(stripEmoji(data.description));

  for (const field of data.fields ?? []) {
    const name = stripEmoji(field.name);
    const value = stripEmoji(field.value);
    if (name || value) linhas.push(`**${name || 'Informação'}**\n${value}`);
  }

  return linhas.join('\n\n');
}

function _imagemUrl(data, key) {
  const value = data?.[key]?.url ?? data?.[key];
  return typeof value === 'string' && value.trim() ? value.trim() : null;
}

function avatarDoServidor(guild) {
  if (!guild || !guild.icon) return null;
  const url = guild.iconURL?.({ extension: 'png', size: 256 })
    ?? guild.iconURL?.({ size: 256 })
    ?? (guild.id && guild.icon
      ? `https://cdn.discordapp.com/icons/${guild.id}/${guild.icon}.${String(guild.icon).startsWith('a_') ? 'gif' : 'png'}?size=256`
      : null);
  return typeof url === 'string' && url.trim() ? url.trim() : null;
}

function renovarUrlImagem(url) {
  if (typeof url !== 'string' || !url.trim()) return null;
  const limpo = url.trim();
  if (limpo.startsWith('attachment://')) return limpo;
  try {
    const parsed = new URL(limpo);
    if (!['http:', 'https:'].includes(parsed.protocol)) return null;

    // Se for CDN do Discord ou qualquer URL com query params/assinatura, adicionamos/atualizamos um timestamp de ciclo (a cada 30 minutos)
    // O timestamp muda a cada bloco de 30 minutos (1800000ms)
    const slot30m = Math.floor(Date.now() / (30 * 60 * 1000));
    parsed.searchParams.set('_t', String(slot30m));
    return parsed.toString();
  } catch (_) {
    return null;
  }
}

function painelV2FromEmbed(embed, rows = [], options = {}) {
  const data = typeof embed?.toJSON === 'function' ? embed.toJSON() : (embed ?? {});
  const container = new ContainerBuilder()
    .setAccentColor(Number.isInteger(data.color) ? data.color : 0x2f3136);
  const texto = _textoEmbed(embed);
  const rawThumbnail = options.thumbnail !== undefined ? options.thumbnail : _imagemUrl(data, 'thumbnail');
  const thumbnail = typeof rawThumbnail === 'string' && rawThumbnail.trim() ? renovarUrlImagem(rawThumbnail) : null;
  const rawImage = options.image !== undefined ? options.image : _imagemUrl(data, 'image');
  const image = typeof rawImage === 'string' && rawImage.trim() ? renovarUrlImagem(rawImage) : null;

  if (thumbnail) {
    container.addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(new TextDisplayBuilder().setContent(texto))
        .setThumbnailAccessory(new ThumbnailBuilder().setURL(thumbnail)),
    );
  } else {
    container.addTextDisplayComponents(new TextDisplayBuilder().setContent(texto));
  }

  if (image) {
    const item = new MediaGalleryItemBuilder().setURL(image);
    container.addMediaGalleryComponents(
      new MediaGalleryBuilder().addItems(item),
    );
  }

  if (rows.length > 0) {
    container.addActionRowComponents(...rows);
  }

  const result = {
    components: [container],
    flags: MessageFlags.IsComponentsV2,
  };

  if (options.files && Array.isArray(options.files) && options.files.length > 0) {
    result.files = options.files;
  }
  if (options.content) {
    result.content = options.content;
  }

  return result;
}

function getEmbedColor(guildId) {
  try {
    const { getConfig } = require('./configurar');
    const cfg = getConfig(guildId);
    if (cfg && Number.isInteger(cfg.embedColor)) {
      return cfg.embedColor;
    }
  } catch (_) {}
  return 0x5865f2;
}

module.exports = { painelV2FromEmbed, avatarDoServidor, stripEmoji, EMOJI_PAINEL, getEmbedColor };