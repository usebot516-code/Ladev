'use strict';

const crypto = require('crypto');

const NIXFF_BASE_URL = 'https://salas.nixbot.vip';

const CONFIG_TYPES = {
  gelo_infinito: 'gelo_inf',
  gelo_normal: 'ap_padrao',
  emu1: 'ap_padrao',
  emu2: 'ap_padrao',
  emu3: 'ap_padrao',
  ap_padrao: 'ap_padrao',
  ap_fullcapa: 'ap_fullcapa',
  tatico: 'tatico',
  capa_3: 'capa_3',
  ap_uxd: 'ap_uxd',
  ap_7r: 'ap_7r',
  br_padrao: 'br_padrao',
};

function configTypeForMatch(subtipo, modo = '', tipo = '') {
  const escolhido = String(subtipo ?? '').trim().toLowerCase();
  if (CONFIG_TYPES[escolhido]) return CONFIG_TYPES[escolhido];

  // Filas sem subtipo explícito continuam funcionando com o template padrão,
  // mas nunca transformam uma escolha de outra partida em gelo infinito.
  const contexto = `${String(modo)} ${String(tipo)}`.toLowerCase();
  if (contexto.includes('battle royale') || contexto.includes('br_padrao')) return 'br_padrao';
  return 'ap_padrao';
}

function _senhaSala() {
  return String(crypto.randomInt(100000, 1000000));
}

async function _request(pathname, options = {}) {
  const token = process.env.NIXFF_API_KEY;
  if (!token) throw new Error('NIXFF_API_KEY não configurada.');

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 15000);
  try {
    const response = await fetch(`${NIXFF_BASE_URL}${pathname}`, {
      ...options,
      signal: controller.signal,
      headers: {
        Accept: 'application/json',
        Authorization: `Bearer ${token}`,
        ...(options.headers ?? {}),
      },
    });
    const body = await response.json().catch(() => ({}));
    if (!response.ok) {
      const detail = body?.detail || body?.message || `HTTP ${response.status}`;
      throw new Error(`Nixff.vip recusou a criação da sala: ${detail}`);
    }
    return body;
  } finally {
    clearTimeout(timer);
  }
}

async function criarSala({ modo, tipo, subtipo, partidaId }) {
  const configType = configTypeForMatch(subtipo, modo, tipo);
  const body = await _request('/rooms', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      password: _senhaSala(),
      start_delay_minutes: 10,
      config_type: configType,
      room_name: `Ryze ${modo} ${subtipo || tipo || 'partida'}${partidaId ? ` ${String(partidaId).slice(-6)}` : ''}`.slice(0, 100),
      map_name: 'Bermuda',
      '1500_ouro': false,
    }),
  });

  if (body?.session_id == null || body?.room_id == null || body?.password == null) {
    throw new Error('A resposta da Nixff.vip não trouxe session_id, room_id e password.');
  }

  return {
    sessionId: String(body.session_id),
    roomId: String(body.room_id),
    password: String(body.password),
    configType,
    roomName: body.room_name ? String(body.room_name) : null,
    status: body.status ? String(body.status) : 'active',
    expiresAt: body.expires_at ? String(body.expires_at) : null,
  };
}

module.exports = { criarSala, configTypeForMatch };