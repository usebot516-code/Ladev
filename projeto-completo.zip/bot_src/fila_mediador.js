'use strict';

// ── Sistema de Fila de Mediadores ─────────────────────────────────────────────

const fs   = require('fs');
const path = require('path');

const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  MessageFlags,
} = require('discord.js');
const { painelV2FromEmbed, avatarDoServidor } = require('./visual');
const { mensagem: _msg } = require('./avisos_mensagens');
const { dataPath } = require('./data-path');
const { encryptSecret, decryptSecret, hasSecret } = require('./segredos');

// ── Armazenamento ─────────────────────────────────────────────────────────────

const DATA_FILE = dataPath('mediadores_data.json');

function _lerDados() {
  try {
    if (fs.existsSync(DATA_FILE)) return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
  } catch (e) { console.error('[MED] Falha ao ler dados:', e.message); }
  return {};
}

let _saving = false;
let _savePending = false;
function _salvarDados(dados) {
  if (_saving) {
    _savePending = true;
    return;
  }
  _saving = true;
  const tmp = DATA_FILE + '.tmp';
  try {
    fs.writeFile(tmp, JSON.stringify(dados, null, 2), 'utf8', (err) => {
      if (!err) {
        fs.rename(tmp, DATA_FILE, () => {
          _saving = false;
          if (_savePending) {
            _savePending = false;
            _salvarDados(_dados);
          }
        });
      } else {
        _saving = false;
      }
    });
  } catch (e) {
    _saving = false;
  }
}

const _dados = _lerDados();
const processingGuilds = new Set();
const paineisConfigOrigem = new Map();
const paineisPagamentoOrigem = new Map();

const PROVEDORES_PAGAMENTO = {
  asaas: {
    label: 'Asaas',
    description: 'Consulta cobranças recebidas pela API Asaas',
    fields: [['apiKey', 'API Key', 'Cole a API Key do Asaas']],
  },
  mercadopago: {
    label: 'Mercado Pago',
    description: 'Consulta pagamentos aprovados pela API do Mercado Pago',
    fields: [['accessToken', 'Access Token', 'Cole o Access Token do Mercado Pago']],
  },
  pagbank: {
    label: 'PagBank',
    description: 'Consulta cobranças pagas pela API PagBank',
    fields: [['token', 'Token de autenticação', 'Cole o Token de autenticação do PagBank']],
  },
  bancointer: {
    label: 'Banco Inter',
    description: 'Consulta Pix recebidos pela API do Banco Inter',
    fields: [
      ['clientId', 'Client ID', 'Cole o Client ID do Banco Inter'],
      ['clientSecret', 'Client Secret', 'Cole o Client Secret do Banco Inter'],
    ],
  },
  efibank: {
    label: 'Efí Bank',
    description: 'Consulta Pix recebidos pela API Efí Bank',
    fields: [
      ['clientId', 'Client ID', 'Cole o Client ID do Efí Bank'],
      ['clientSecret', 'Client Secret', 'Cole o Client Secret do Efí Bank'],
    ],
  },
};

const PROVEDOR_ALIASES = {
  asaas: 'asaas',
  mercadopago: 'mercadopago',
  pagbank: 'pagbank',
  bancointer: 'bancointer',
  efibank: 'efibank',
};

/**
 * Estrutura por guild:
 * {
 *   fila: ["userId1", "userId2", ...],   // FIFO — apenas os que estao aguardando
 *   registro: {                           // historico de todos que ja usaram o sistema
 *     "userId": { pix: "...", partidasMediadas: 0 }
 *   },
 *   panelMsgId:  "...",
 *   panelChanId: "..."
 * }
 */
function _guild(guildId) {
  if (!_dados[guildId]) {
    _dados[guildId] = {
      fila: [],
      registro: {},
      panelMsgId: null,
      panelChanId: null,
      titulo: 'PAINEL DE FILA DE MEDIADORES',
      descricao: 'Entre na fila para receber partidas automaticamente.',
      thumbnail: null,
      banner: null,
    };
  }
  const defaults = {
    titulo: 'PAINEL DE FILA DE MEDIADORES',
    descricao: 'Entre na fila para receber partidas automaticamente.',
    thumbnail: null,
    banner: null,
  };
  for (const [key, value] of Object.entries(defaults)) {
    if (!Object.prototype.hasOwnProperty.call(_dados[guildId], key)) _dados[guildId][key] = value;
  }
  // Garantir que a fila seja SEMPRE um array plano de User IDs limpos em formato string
  if (!Array.isArray(_dados[guildId].fila)) {
    _dados[guildId].fila = [];
  } else {
    _dados[guildId].fila = Array.from(
      new Set(
        _dados[guildId].fila
          .map((m) => (typeof m === 'object' && m !== null ? String(m.id || '') : String(m || '')))
          .map((s) => s.trim())
          .filter((s) => /^\d{16,22}$/.test(s)),
      ),
    );
  }
  if (!_dados[guildId].registro) _dados[guildId].registro = {};
  for (const registro of Object.values(_dados[guildId].registro)) {
    if (typeof registro.pix === 'string') {
      registro.pix = {
        titular: '',
        cidade: '',
        tipo: '',
        chave: registro.pix,
      };
    }
  }
  return _dados[guildId];
}

function _salvar() { _salvarDados(_dados); }

function _chavePix(registro) {
  if (typeof registro?.pix === 'string') return registro.pix;
  return registro?.pix?.chave ?? '';
}

function _pixFormatado(registro) {
  if (!registro?.pix) return null;
  if (typeof registro.pix === 'string') {
    return { titular: 'Não informado', cidade: 'Não informada', tipo: 'Não informado', chave: registro.pix };
  }
  return {
    titular: registro.pix.titular || 'Não informado',
    cidade: registro.pix.cidade || 'Não informada',
    tipo: registro.pix.tipo || 'Não informado',
    chave: registro.pix.chave || 'Não informada',
  };
}

function _normalizarNome(value) {
  return String(value ?? '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .trim()
    .replace(/\s+/g, ' ');
}

function _mascarar(value) {
  const texto = String(value ?? '');
  if (!texto) return 'Não configurado';
  if (texto.length <= 8) return '••••••••';
  return `${texto.slice(0, 4)}••••${texto.slice(-4)}`;
}

function _registroPagamento(guildId, userId) {
  return _guild(guildId).registro[userId]?.pagamento ?? null;
}

function obterConfiguracaoPagamento(guildId, userId) {
  const salvo = _registroPagamento(guildId, userId);
  if (!salvo?.provider || salvo.provider === 'pix') {
    return salvo?.provider === 'pix'
      ? { provider: 'pix', credentials: {} }
      : null;
  }
  const provider = PROVEDORES_PAGAMENTO[salvo.provider] ? salvo.provider : null;
  if (!provider) return null;
  const credentials = Object.fromEntries(
    Object.entries(salvo.credentials ?? {}).map(([key, value]) => [key, decryptSecret(value)]),
  );
  return { provider, credentials, updatedAt: salvo.updatedAt ?? null };
}

function obterResumoConfiguracaoPagamento(guildId, userId) {
  const config = obterConfiguracaoPagamento(guildId, userId);
  const pix = _pixFormatado(_guild(guildId).registro[userId]);
  if (config?.provider && PROVEDORES_PAGAMENTO[config.provider]) {
    const labelsMap = {
      apiKey: 'API Key',
      accessToken: 'Access Token',
      token: 'Token de autenticação',
      clientId: 'Client ID',
      clientSecret: 'Client Secret',
      pixKey: 'Chave Pix da conta',
    };
    const campos = Object.entries(config.credentials ?? {})
      .filter(([, value]) => value)
      .map(([key, value]) => `${labelsMap[key] || key}: **${_mascarar(value)}**`);
    if (pix?.chave && !campos.some((c) => c.startsWith('Chave Pix'))) {
      campos.push(`Chave Pix vinculada: **${_mascarar(pix.chave)}**`);
    }
    return `Provedor automático: **${PROVEDORES_PAGAMENTO[config.provider].label}**\n${campos.join('\n') || 'Credenciais incompletas.'}`;
  }
  if (pix?.chave) {
    return `Modo atual: **Chave Pix manual** (sem provedor configurado)\nChave: **${_mascarar(pix.chave)}**\nTitular: **${pix.titular || 'Não informado'}**\nA confirmação é feita de forma manual pelo mediador.`;
  }
  return 'Nenhum método de confirmação configurado.';
}

function salvarConfiguracaoPagamento(guildId, userId, provider, credentials) {
  const definition = PROVEDORES_PAGAMENTO[provider];
  if (!definition) throw new Error('Provedor de pagamento inválido.');
  if (!hasSecret()) throw new Error('SESSION_SECRET não configurado.');
  const g = _guild(guildId);
  if (!g.registro[userId]) g.registro[userId] = { pix: null, partidasMediadas: 0 };
  const anterior = g.registro[userId].pagamento?.credentials ?? {};
  const encrypted = {};
  for (const [key, value] of Object.entries(credentials ?? {})) {
    const texto = String(value ?? '').trim();
    if (texto) encrypted[key] = encryptSecret(texto);
    else if (anterior[key]) encrypted[key] = anterior[key];
  }
  g.registro[userId].pagamento = {
    provider,
    credentials: encrypted,
    updatedAt: new Date().toISOString(),
  };
  _salvar();
  return obterConfiguracaoPagamento(guildId, userId);
}

function selecionarMetodoPix(guildId, userId) {
  const g = _guild(guildId);
  if (!g.registro[userId]) g.registro[userId] = { pix: null, partidasMediadas: 0 };
  g.registro[userId].pagamento = { provider: 'pix', credentials: {}, updatedAt: new Date().toISOString() };
  _salvar();
}

function _validarNomeTitular(nome) {
  if (!nome) return false;
  const normalizado = _normalizarNome(nome);
  return Boolean(normalizado && normalizado.split(' ').filter(Boolean).length >= 2);
}

async function _fetchJson(url, options = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 9000);
  try {
    const response = await fetch(url, {
      ...options,
      signal: controller.signal,
      headers: { Accept: 'application/json', ...(options.headers ?? {}) },
    });
    const body = await response.json().catch(() => ({}));
    if (!response.ok) return { ok: false, status: response.status, body };
    return { ok: true, body };
  } catch (error) {
    return { ok: false, status: 0, body: {}, error };
  } finally {
    clearTimeout(timer);
  }
}

function _valorCentavos(value) {
  if (value === null || value === undefined) return null;
  const str = String(value).replace(',', '.').replace(/[^\d.]/g, '');
  const number = Number.parseFloat(str);
  return Number.isFinite(number) ? Math.round(number * 100) : null;
}

function _mesmoValor(value, esperado) {
  const recebido = _valorCentavos(value);
  const alvo = _valorCentavos(esperado);
  return recebido !== null && alvo !== null && recebido === alvo;
}

function _mesmoNome(candidato, procurado) {
  const a = _normalizarNome(candidato);
  const b = _normalizarNome(procurado);
  if (!a || !b) return false;
  if (a === b || a.includes(b) || b.includes(a)) return true;
  const partesA = a.split(' ').filter(Boolean);
  const partesB = b.split(' ').filter(Boolean);
  if (partesA.length >= 2 && partesB.length >= 2) {
    if (partesA[0] === partesB[0] && partesA[partesA.length - 1] === partesB[partesB.length - 1]) {
      return true;
    }
  }
  return false;
}

function _correspondeNome(candidato, procurado) {
  if (!procurado || (Array.isArray(procurado) && procurado.length === 0)) return true;
  if (Array.isArray(procurado)) {
    return procurado.some((p) => _mesmoNome(candidato, p));
  }
  return _mesmoNome(candidato, procurado);
}

function _dataRecente(item, since) {
  const date = item?.date_approved || item?.date_created || item?.paymentDate || item?.created_at || item?.createdAt || item?.horario;
  if (!date || !since) return true;
  const time = Date.parse(date);
  return !Number.isFinite(time) || time >= since - 24 * 60 * 60 * 1000;
}

const _tokenCache = new Map();

async function _obterTokenOAuthInter(clientId, clientSecret) {
  const cacheKey = `inter:${clientId}:${clientSecret}`;
  const cached = _tokenCache.get(cacheKey);
  if (cached && cached.expiresAt > Date.now() + 60000) {
    return cached.token;
  }
  const body = new URLSearchParams({
    client_id: clientId,
    client_secret: clientSecret,
    grant_type: 'client_credentials',
    scope: 'pix.read',
  });
  const res = await _fetchJson('https://cdpj.partners.bancointer.com.br/oauth/v2/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: body.toString(),
  });
  if (res.ok && res.body?.access_token) {
    const expiresAt = Date.now() + (Number(res.body.expires_in) || 3600) * 1000;
    _tokenCache.set(cacheKey, { token: res.body.access_token, expiresAt });
    return res.body.access_token;
  }
  throw new Error(res.body?.error_description || res.body?.error || 'Falha ao autenticar no Banco Inter');
}

async function _obterTokenOAuthEfi(clientId, clientSecret) {
  const cacheKey = `efi:${clientId}:${clientSecret}`;
  const cached = _tokenCache.get(cacheKey);
  if (cached && cached.expiresAt > Date.now() + 60000) {
    return cached.token;
  }
  const basicAuth = Buffer.from(`${clientId}:${clientSecret}`).toString('base64');
  let res = await _fetchJson('https://pix.api.efipay.com.br/oauth/v2/token', {
    method: 'POST',
    headers: {
      Authorization: `Basic ${basicAuth}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ grant_type: 'client_credentials' }),
  });
  if (!res.ok || !res.body?.access_token) {
    res = await _fetchJson('https://api-pix.gerencianet.com.br/oauth/v2/token', {
      method: 'POST',
      headers: {
        Authorization: `Basic ${basicAuth}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ grant_type: 'client_credentials' }),
    });
  }
  if (res.ok && res.body?.access_token) {
    const expiresAt = Date.now() + (Number(res.body.expires_in) || 3600) * 1000;
    _tokenCache.set(cacheKey, { token: res.body.access_token, expiresAt });
    return res.body.access_token;
  }
  throw new Error(res.body?.error_description || res.body?.mensagem || 'Falha ao autenticar no Efí Bank');
}

async function _verificarAsaas(credentials, valor, nome, since) {
  const apiKey = credentials.apiKey || credentials.accessToken;
  const headers = { access_token: apiKey };
  const resposta = await _fetchJson('https://api.asaas.com/v3/payments?status=RECEIVED&limit=100&offset=0', { headers });
  let pagamentos = resposta.body?.data ?? [];
  if (pagamentos.length === 0) {
    const respConf = await _fetchJson('https://api.asaas.com/v3/payments?status=CONFIRMED&limit=100&offset=0', { headers });
    pagamentos = respConf.body?.data ?? [];
  }
  for (const pagamento of pagamentos) {
    if (!_mesmoValor(pagamento.value, valor) || !_dataRecente(pagamento, since)) continue;
    const nomes = [pagamento.description || ''];
    if (pagamento.customer) {
      const customer = await _fetchJson(`https://api.asaas.com/v3/customers/${encodeURIComponent(pagamento.customer)}`, { headers });
      if (customer.body?.name) nomes.push(customer.body.name);
    }
    const nomePagador = nomes.filter(Boolean).join(' ');
    if (_correspondeNome(nomePagador, nome)) {
      return { ok: true, paymentId: String(pagamento.id), nomePagador: nomes.find(Boolean) || nomePagador };
    }
  }
  return { ok: false };
}

async function _verificarMercadoPago(credentials, valor, nome, since) {
  const token = credentials.accessToken;
  const resposta = await _fetchJson(
    'https://api.mercadopago.com/v1/payments/search?sort=date_created&criteria=desc&limit=100&status=approved',
    { headers: { Authorization: `Bearer ${token}` } },
  );
  for (const pagamento of resposta.body?.results ?? []) {
    const pagador = [
      pagamento.payer?.first_name,
      pagamento.payer?.last_name,
      pagamento.payer?.name,
      pagamento.point_of_interaction?.transaction_data?.bank_info?.payer?.account_holder_name,
      pagamento.additional_info?.payer?.first_name,
      pagamento.additional_info?.payer?.last_name,
      pagamento.description,
    ].filter(Boolean).join(' ');
    if (_mesmoValor(pagamento.transaction_amount, valor) && _dataRecente(pagamento, since)) {
      if (_correspondeNome(pagador, nome)) {
        return { ok: true, paymentId: String(pagamento.id), nomePagador: pagador };
      }
    }
  }
  return { ok: false };
}

async function _verificarPagBank(credentials, valor, nome, since) {
  const token = credentials.token || credentials.accessToken;
  const resposta = await _fetchJson('https://api.pagseguro.com/charges?status=PAID&limit=100', {
    headers: { Authorization: `Bearer ${token}` },
  });
  for (const pagamento of resposta.body?.charges ?? []) {
    const pagador = [
      pagamento.customer?.name,
      pagamento.holder?.name,
      pagamento.customer?.email,
      pagamento.description,
    ].filter(Boolean).join(' ');
    const valorPago = pagamento.amount?.value ? Number(pagamento.amount.value) / 100 : null;
    if (_mesmoValor(valorPago, valor) && _dataRecente(pagamento, since)) {
      if (_correspondeNome(pagador, nome)) {
        return { ok: true, paymentId: String(pagamento.id), nomePagador: pagador };
      }
    }
  }
  return { ok: false };
}

async function _verificarBancoInter(credentials, valor, nome, since) {
  let token = credentials.accessToken;
  if (!token && credentials.clientId && credentials.clientSecret) {
    token = await _obterTokenOAuthInter(credentials.clientId, credentials.clientSecret);
  }
  if (!token) {
    return { ok: false, reason: 'Credenciais do Banco Inter inválidas ou incompletas.' };
  }
  const inicio = new Date(Math.max(0, (since || Date.now()) - 24 * 60 * 60 * 1000)).toISOString();
  const fim = new Date(Date.now() + 60 * 1000).toISOString();
  const url = `https://cdpj.partners.bancointer.com.br/pix/v2/pix?inicio=${encodeURIComponent(inicio)}&fim=${encodeURIComponent(fim)}`;
  const resposta = await _fetchJson(url, { headers: { Authorization: `Bearer ${token}` } });
  const pagamentos = resposta.body?.pix ?? resposta.body?.items ?? [];
  for (const pagamento of pagamentos) {
    const valorPago = pagamento.valor?.original ?? pagamento.valor ?? pagamento.amount?.value;
    const pagador = [
      pagamento.pagador?.nome,
      pagamento.devolucoes?.[0]?.pagador?.nome,
      pagamento.txid,
      pagamento.infoPagador,
    ].filter(Boolean).join(' ');
    if (_mesmoValor(valorPago, valor)) {
      if (_correspondeNome(pagador, nome)) {
        return { ok: true, paymentId: String(pagamento.endToEndId || pagamento.txid), nomePagador: pagamento.pagador?.nome || pagador };
      }
    }
  }
  return { ok: false };
}

async function _verificarEfiBank(credentials, valor, nome, since) {
  let token = credentials.accessToken;
  if (!token && credentials.clientId && credentials.clientSecret) {
    token = await _obterTokenOAuthEfi(credentials.clientId, credentials.clientSecret);
  }
  if (!token) {
    return { ok: false, reason: 'Credenciais do Efí Bank inválidas ou incompletas.' };
  }
  const inicio = new Date(Math.max(0, (since || Date.now()) - 24 * 60 * 60 * 1000)).toISOString();
  const fim = new Date(Date.now() + 60 * 1000).toISOString();
  const url = `https://pix.api.efipay.com.br/v2/pix?inicio=${encodeURIComponent(inicio)}&fim=${encodeURIComponent(fim)}`;
  const resposta = await _fetchJson(url, { headers: { Authorization: `Bearer ${token}` } });
  const pagamentos = resposta.body?.pix ?? resposta.body?.items ?? [];
  for (const pagamento of pagamentos) {
    const valorPago = pagamento.valor?.original ?? pagamento.valor ?? pagamento.amount?.value;
    const pagador = [
      pagamento.pagador?.nome,
      pagamento.devolucoes?.[0]?.pagador?.nome,
      pagamento.txid,
      pagamento.infoPagador,
    ].filter(Boolean).join(' ');
    if (_mesmoValor(valorPago, valor)) {
      if (_correspondeNome(pagador, nome)) {
        return { ok: true, paymentId: String(pagamento.endToEndId || pagamento.txid), nomePagador: pagamento.pagador?.nome || pagador };
      }
    }
  }
  return { ok: false };
}

async function verificarPagamentoMediador(guildId, userId, { valor, nome, nomes, since = Date.now() } = {}) {
  const alvoNomes = nomes || (nome ? [nome] : null);
  if (!nomes && nome && !_validarNomeTitular(nome)) {
    return { ok: false, reason: 'Informe nome e sobrenome do titular. Exemplo: `pg Carla Joelma`.' };
  }
  const config = obterConfiguracaoPagamento(guildId, userId);
  if (!config || config.provider === 'pix') {
    return {
      ok: false,
      reason: 'Este mediador está usando apenas uma chave Pix. Para confirmar automaticamente, configure um provedor de API em **config mediador**.',
    };
  }
  const definition = PROVEDORES_PAGAMENTO[config.provider];
  if (!definition) return { ok: false, reason: 'Provedor de pagamento inválido.' };

  const required = definition.fields.map(([key]) => key);
  const creds = config.credentials || {};
  const hasCreds = required.every((key) => {
    if (creds[key]) return true;
    if (config.provider === 'asaas' && (creds.apiKey || creds.accessToken)) return true;
    if (config.provider === 'pagbank' && (creds.token || creds.accessToken)) return true;
    if ((config.provider === 'bancointer' || config.provider === 'efibank') && (creds.accessToken || (creds.clientId && creds.clientSecret))) return true;
    return false;
  });

  if (!hasCreds) {
    return { ok: false, reason: `A configuração do ${definition.label} está incompleta. Abra **config mediador** e preencha os dados.` };
  }

  try {
    if (config.provider === 'asaas') {
      return { ...(await _verificarAsaas(config.credentials, valor, alvoNomes, since)), provider: definition.label };
    }
    if (config.provider === 'mercadopago') {
      return { ...(await _verificarMercadoPago(config.credentials, valor, alvoNomes, since)), provider: definition.label };
    }
    if (config.provider === 'pagbank') {
      return { ...(await _verificarPagBank(config.credentials, valor, alvoNomes, since)), provider: definition.label };
    }
    if (config.provider === 'bancointer') {
      return { ...(await _verificarBancoInter(config.credentials, valor, alvoNomes, since)), provider: definition.label };
    }
    if (config.provider === 'efibank') {
      return { ...(await _verificarEfiBank(config.credentials, valor, alvoNomes, since)), provider: definition.label };
    }
    return { ok: false, reason: `Provedor ${definition.label} não suportado.` };
  } catch (err) {
    return { ok: false, reason: `Não foi possível consultar o ${definition.label} agora (${err.message}). Confira as credenciais e tente novamente.` };
  }
}

function criarModalPix(customId, registro = null) {
  const pix = _pixFormatado(registro) ?? { titular: '', cidade: '', tipo: '', chave: '' };
  const campos = [
    ['titular', 'Nome do titular', 'Nome completo do titular da conta'],
    ['cidade', 'Cidade', 'Cidade onde o titular reside'],
    ['tipo', 'Tipo de chave', 'Email, CPF, CNPJ, telefone ou aleatória'],
    ['chave', 'Chave PIX', 'Digite a chave exatamente como cadastrada'],
  ].map(([fieldId, label, placeholder]) => {
    const campo = new TextInputBuilder()
      .setCustomId(fieldId)
      .setLabel(label)
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setPlaceholder(placeholder);
    if (pix[fieldId]) campo.setValue(pix[fieldId]);
    return new ActionRowBuilder().addComponents(campo);
  });
  return new ModalBuilder()
    .setCustomId(customId)
    .setTitle('Cadastrar dados do PIX')
    .addComponents(...campos);
}

function salvarPixMediador(guildId, userId, pix) {
  const g = _guild(guildId);
  if (!g.registro[userId]) g.registro[userId] = { pix: null, partidasMediadas: 0 };
  g.registro[userId].pix = {
    titular: String(pix?.titular ?? '').trim(),
    cidade: String(pix?.cidade ?? '').trim(),
    tipo: String(pix?.tipo ?? '').trim(),
    chave: String(pix?.chave ?? '').trim(),
  };
  _salvar();
  return g.registro[userId].pix;
}

async function abrirModalPix(interaction, customId = 'fmed:modal:pix') {
  const g = _guild(interaction.guildId);
  await interaction.showModal(criarModalPix(customId, g.registro[interaction.user.id]));
}

function _buildAviso(titulo, mensagem, cor = 0x5865f2) {
  return new EmbedBuilder()
    .setTitle(titulo)
    .setDescription(mensagem)
    .setColor(cor);
}

// ── Cor ───────────────────────────────────────────────────────────────────────

function _cor(guildId) {
  try {
    const { getConfig } = require('./configurar');
    return getConfig(guildId)?.embedColor ?? 0x2f3136;
  } catch (_) { return 0x2f3136; }
}

// ─────────────────────────────────────────────────────────────────────────────
// PAINEL DE MEDIADORES
// ─────────────────────────────────────────────────────────────────────────────

function _buildPainelEmbed(guildId, guild = null) {
  const g    = _guild(guildId);
  const fila = Array.isArray(g.fila) ? g.fila : [];

  const embed = new EmbedBuilder()
    .setTitle(g.titulo || 'PAINEL DE FILA DE MEDIADORES')
    .setColor(_cor(guildId))
    .setDescription(g.descricao || 'Entre na fila para receber partidas automaticamente.')
    .addFields({ name: 'Informação', value: 'A ordem da fila é respeitada. Cadastre o PIX antes de entrar.' });

  const listaFormatada = fila.length > 0
    ? fila
        .map((id, i) => {
          const cleanId = String(id).trim();
          return `${i + 1}. <@${cleanId}>`;
        })
        .join('\n')
    : 'Nenhum mediador na fila no momento.';

  embed.addFields({
    name: `Mediadores na fila • ${fila.length}`,
    value: listaFormatada,
  });

  if (g.thumbnail) embed.setThumbnail(g.thumbnail);
  if (g.banner) embed.setImage(g.banner);
  return embed;
}

function _buildPainelRows(guildId) {
  return [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('fmed:in').setLabel('Entrar na Fila').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId('fmed:out').setLabel('Sair da Fila').setStyle(ButtonStyle.Danger),
      new ButtonBuilder().setCustomId('fmed:pix').setLabel('Config mediador').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('fmed:ranking').setLabel('Ranking Mediadores').setStyle(ButtonStyle.Secondary),
    ),
  ];
}

async function _refreshPainel(guildId, client, mensagemClicada = null) {
  try {
    const g = _guild(guildId);
    if (mensagemClicada?.id && mensagemClicada?.channelId) {
      g.panelMsgId = mensagemClicada.id;
      g.panelChanId = mensagemClicada.channelId;
      _salvar();
    }

    if (!g.panelMsgId || !g.panelChanId) return;

    const guildObj = client?.guilds?.cache?.get(guildId) || (client?.guilds ? await client.guilds.fetch(guildId).catch(() => null) : null);
    const cleanUsers = (Array.isArray(g.fila) ? g.fila : [])
      .map((id) => (typeof id === 'object' && id !== null ? id.id : id))
      .map(String)
      .map((s) => s.trim())
      .filter((id) => /^\d{16,22}$/.test(id));

    const payload = {
      ...painelV2FromEmbed(_buildPainelEmbed(guildId, guildObj), _buildPainelRows(guildId), {
        thumbnail: g.thumbnail || (guildObj ? avatarDoServidor(guildObj) : null),
        image: g.banner,
      }),
      allowedMentions: { users: [...new Set(cleanUsers)] },
    };

    if (mensagemClicada && typeof mensagemClicada.edit === 'function') {
      await mensagemClicada.edit(payload).catch(() => {});
      return;
    }

    const canal = client?.channels?.cache?.get(g.panelChanId) || (client?.channels ? await client.channels.fetch(g.panelChanId).catch(() => null) : null);
    if (!canal) return;
    const msg = canal.messages?.cache?.get(g.panelMsgId) || (canal.messages ? await canal.messages.fetch(g.panelMsgId).catch(() => null) : null);
    if (!msg) return;

    await msg.edit(payload).catch((err) => {
      console.error('[MED] Erro ao editar mensagem do painel:', err.message);
    });
  } catch (e) {
    console.error('[MED] Falha ao atualizar painel:', e.message);
  }
}

async function atualizarPainelMediador(guildId, client) {
  return _refreshPainel(guildId, client);
}

// ─────────────────────────────────────────────────────────────────────────────
// RANKING
// ─────────────────────────────────────────────────────────────────────────────

function _buildRankingEmbed(guildId) {
  const g = _guild(guildId);

  // Apenas mediadores com ao menos 1 partida mediada
  const classificados = Object.entries(g.registro)
    .filter(([, r]) => (r.partidasMediadas ?? 0) > 0)
    .sort(([, a], [, b]) => b.partidasMediadas - a.partidasMediadas);

  const lista = classificados.length === 0
    ? 'Nenhum mediador com partidas registradas ainda.'
    : classificados
        .map(([id, r], i) => `${i + 1}. <@${id}> — ${r.partidasMediadas} partida(s)`)
        .join('\n');

  const embed = new EmbedBuilder()
    .setTitle('RANKING DE MEDIADORES')
    .setColor(_cor(guildId))
    .setDescription(lista);
  return embed;
}

function _textoConfiguracao(guildId) {
  const panel = _guild(guildId);
  return [
    `Título: **${panel.titulo || 'Não configurado'}**`,
    `Descrição: **${panel.descricao || 'Não configurada'}**`,
    `Thumbnail: **${panel.thumbnail ? 'Configurada' : 'Usando o ícone do servidor'}**`,
    `Banner: **${panel.banner ? 'Configurado' : 'Nenhum'}**`,
  ].join('\n');
}

function _painelPagamentoEmbed(guildId, userId, guild = null, notice = null) {
  const embed = new EmbedBuilder()
    .setColor(_cor(guildId))
    .setTitle('CONFIG MEDIADOR')
    .setDescription(
      'Escolha como os pagamentos deste mediador serão consultados.\n\n' +
      obterResumoConfiguracaoPagamento(guildId, userId) +
      (notice ? `\n\n**Resultado da última ação**\n${notice}` : ''),
    );
  return painelV2FromEmbed(embed, [
    new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId('fmed:pagamento:opcoes')
        .setPlaceholder('Selecione o método de confirmação')
        .addOptions(
          { label: 'Asaas', value: 'asaas', description: PROVEDORES_PAGAMENTO.asaas.description },
          { label: 'Mercado Pago', value: 'mercadopago', description: PROVEDORES_PAGAMENTO.mercadopago.description },
          { label: 'PagBank', value: 'pagbank', description: PROVEDORES_PAGAMENTO.pagbank.description },
          { label: 'Banco Inter', value: 'bancointer', description: PROVEDORES_PAGAMENTO.bancointer.description },
          { label: 'Efí Bank', value: 'efibank', description: PROVEDORES_PAGAMENTO.efibank.description },
          { label: 'Chave Pix (Manual)', value: 'pix', description: 'Usar apenas Chave Pix manual (quando não configurou nenhum provedor)' },
        ),
    ),
  ], { thumbnail: avatarDoServidor(guild) });
}

function _modalConfiguracaoPagamento(provider, guildId, userId) {
  const definition = PROVEDORES_PAGAMENTO[provider];
  if (!definition) return null;
  const config = obterConfiguracaoPagamento(guildId, userId);
  const existing = config?.provider === provider ? config.credentials : {};
  const pixAtual = _pixFormatado(_guild(guildId).registro[userId]);

  const rows = definition.fields.map(([key, label, placeholder]) => {
    const campo = new TextInputBuilder()
      .setCustomId(key)
      .setLabel(label)
      .setPlaceholder(placeholder)
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(true)
      .setMaxLength(4000);
    if (existing[key]) campo.setValue(existing[key]);
    return new ActionRowBuilder().addComponents(campo);
  });

  // Campo adicional obrigatório para a chave PIX vinculada à conta
  const campoPix = new TextInputBuilder()
    .setCustomId('chave_pix')
    .setLabel('Chave Pix da conta')
    .setPlaceholder('Chave Pix cadastrada na sua conta deste banco/provedor')
    .setStyle(TextInputStyle.Short)
    .setRequired(false)
    .setMaxLength(255);
  if (pixAtual?.chave && pixAtual.chave !== 'Não informada') {
    campoPix.setValue(pixAtual.chave);
  }
  rows.push(new ActionRowBuilder().addComponents(campoPix));

  return new ModalBuilder()
    .setCustomId(`fmed:pagamento:modal:${provider}`)
    .setTitle(`Configurar ${definition.label}`)
    .addComponents(...rows);
}

function _pagamentoPermitidoParaFila(guildId, userId) {
  // O método da API confirma o recebimento, mas o canal ainda precisa exibir
  // um destino de pagamento para os jogadores. A chave Pix existente continua
  // sendo obrigatória para publicar o QR Code e a chave da partida.
  return Boolean(_chavePix(_guild(guildId).registro[userId]));
}

function painelConfiguracaoFilaMediador(guildId, notice = null, guild = null) {
  const panel = _guild(guildId);
  const embed = new EmbedBuilder()
    .setColor(_cor(guildId))
    .setTitle('CONFIGURAÇÃO DO PAINEL DE FILA DE MEDIADORES')
    .setDescription(
      'Configure a aparência do painel antes de publicá-lo no canal atual.\n\n' +
      _textoConfiguracao(guildId) +
      (notice ? `\n\n**Resultado da última ação**\n${notice}` : ''),
    );
  if (panel.thumbnail) embed.setThumbnail(panel.thumbnail);
  if (panel.banner) embed.setImage(panel.banner);

  return {
    ...painelV2FromEmbed(
      embed,
      [
        new ActionRowBuilder().addComponents(
          new StringSelectMenuBuilder()
            .setCustomId('fmed:config:opcoes')
            .setPlaceholder('Selecione o que deseja configurar')
            .addOptions(
              { label: 'Título', value: 'titulo', description: 'Alterar o título do painel público' },
              { label: 'Descrição', value: 'descricao', description: 'Alterar o texto do painel público' },
              { label: 'Thumbnail', value: 'thumbnail', description: 'Alterar ou remover a imagem pequena' },
              { label: 'Banner', value: 'banner', description: 'Alterar ou remover a imagem principal' },
            ),
        ),
        new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('fmed:config:enviar').setLabel('Enviar').setStyle(ButtonStyle.Success),
        ),
      ],
      { thumbnail: panel.thumbnail || avatarDoServidor(guild), image: panel.banner },
    ),
    flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
  };
}

function modalConfiguracaoFilaMediador(tipo, panel) {
  const campos = {
    titulo: {
      customId: 'fmed:config_modal:titulo',
      title: 'Alterar título do painel',
      label: 'Título do painel',
      placeholder: 'PAINEL DE FILA DE MEDIADORES',
      maxLength: 256,
      value: panel.titulo,
    },
    descricao: {
      customId: 'fmed:config_modal:descricao',
      title: 'Alterar descrição do painel',
      label: 'Descrição do painel',
      placeholder: 'Texto exibido no painel público',
      maxLength: 4000,
      value: panel.descricao,
    },
    thumbnail: {
      customId: 'fmed:config_modal:thumbnail',
      title: 'Alterar thumbnail do painel',
      label: 'URL da thumbnail',
      placeholder: 'URL pública direta da imagem; vazio remove',
      maxLength: 1000,
      value: panel.thumbnail || '',
      required: false,
    },
    banner: {
      customId: 'fmed:config_modal:banner',
      title: 'Alterar banner do painel',
      label: 'URL do banner',
      placeholder: 'URL pública direta da imagem; vazio remove',
      maxLength: 1000,
      value: panel.banner || '',
      required: false,
    },
  }[tipo];

  if (!campos) return null;
  const campo = new TextInputBuilder()
    .setCustomId('valor')
    .setLabel(campos.label)
    .setPlaceholder(campos.placeholder)
    .setStyle(tipo === 'descricao' ? TextInputStyle.Paragraph : TextInputStyle.Short)
    .setMaxLength(campos.maxLength)
    .setRequired(campos.required !== false);
  if (campos.value) campo.setValue(campos.value);

  return new ModalBuilder()
    .setCustomId(campos.customId)
    .setTitle(campos.title)
    .addComponents(new ActionRowBuilder().addComponents(campo));
}

// ─────────────────────────────────────────────────────────────────────────────
// HANDLER PRINCIPAL
// ─────────────────────────────────────────────────────────────────────────────

async function handleFilaMediador(interaction, client) {
  const guildId = interaction.guildId;
  if (!guildId) return false;

  // ── Comando /fila mediador ─────────────────────────────────────────────────
  if (interaction.isChatInputCommand() && interaction.commandName === 'fila') {
    const sub = interaction.options.getSubcommand(false);
    if (sub !== 'mediador') return false;

    paineisConfigOrigem.set(`${guildId}:${interaction.user.id}`, interaction);
    await interaction.reply(painelConfiguracaoFilaMediador(guildId, null, interaction.guild));
    return true;
  }

  const id = interaction.customId ?? '';
  if (!id.startsWith('fmed:')) return false;

  if (interaction.isStringSelectMenu() && id === 'fmed:config:opcoes') {
    const tipo = interaction.values[0];
    const modal = modalConfiguracaoFilaMediador(tipo, _guild(guildId));
    if (modal) await interaction.showModal(modal);
    return true;
  }

  if (interaction.isStringSelectMenu() && id === 'fmed:pagamento:opcoes') {
    const provider = interaction.values[0];
    if (!paineisPagamentoOrigem.has(`${guildId}:${interaction.user.id}`)) {
      paineisPagamentoOrigem.set(`${guildId}:${interaction.user.id}`, interaction);
    }
    if (provider === 'pix') {
      await abrirModalPix(interaction);
    } else {
      const modal = _modalConfiguracaoPagamento(provider, guildId, interaction.user.id);
      if (modal) await interaction.showModal(modal);
    }
    return true;
  }

  if (interaction.isButton() && id === 'fmed:config:enviar') {
    await interaction.deferUpdate();
    const message = await publicarPainelMediador(interaction.guild, interaction.channel);
    paineisConfigOrigem.delete(`${guildId}:${interaction.user.id}`);
    await interaction.editReply(
      painelConfiguracaoFilaMediador(
        guildId,
        message ? `Painel enviado em <#${message.channelId}>.` : 'Não foi possível enviar o painel.',
        interaction.guild,
      ),
    );
    return true;
  }

  if (interaction.isModalSubmit() && id.startsWith('fmed:config_modal:')) {
    const tipo = id.split(':').pop();
    const panel = _guild(guildId);
    const valor = interaction.fields.getTextInputValue('valor').trim();
    if (tipo === 'titulo') panel.titulo = valor || 'PAINEL DE FILA DE MEDIADORES';
    if (tipo === 'descricao') panel.descricao = valor || 'Entre na fila para receber partidas automaticamente.';
    if (tipo === 'thumbnail') panel.thumbnail = valor || null;
    if (tipo === 'banner') panel.banner = valor || null;
    _salvar();
    _refreshPainel(guildId, client).catch(() => {});

    await interaction.deferReply({ flags: MessageFlags.Ephemeral });
    const origem = paineisConfigOrigem.get(`${guildId}:${interaction.user.id}`);
    if (origem) {
      try {
        await origem.editReply(painelConfiguracaoFilaMediador(guildId, 'Configuração atualizada automaticamente.', interaction.guild));
      } catch (error) {
        console.error('[MED] Falha ao atualizar painel de configuração:', error.message);
      }
    }
    await interaction.editReply({ content: '✅ Configuração atualizada.' });
    return true;
  }

  if (interaction.isModalSubmit() && id.startsWith('fmed:pagamento:modal:')) {
    const provider = id.split(':').pop();
    const definition = PROVEDORES_PAGAMENTO[provider];
    if (!definition) return true;
    const credentials = Object.fromEntries(
      definition.fields.map(([key]) => [key, interaction.fields.getTextInputValue(key).trim()]),
    );
    let chavePixInformada = null;
    try {
      chavePixInformada = interaction.fields.getTextInputValue('chave_pix')?.trim();
    } catch (_) {}

    try {
      salvarConfiguracaoPagamento(guildId, interaction.user.id, provider, credentials);
      if (chavePixInformada) {
        const pixAtual = _guild(guildId).registro[interaction.user.id]?.pix || {};
        salvarPixMediador(guildId, interaction.user.id, {
          titular: pixAtual.titular || interaction.user.username,
          cidade: pixAtual.cidade || 'Brasil',
          tipo: pixAtual.tipo || 'aleatória',
          chave: chavePixInformada,
        });
      }
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      const origem = paineisPagamentoOrigem.get(`${guildId}:${interaction.user.id}`);
      if (origem) {
        try {
          await origem.editReply({
            ..._painelPagamentoEmbed(
              guildId,
              interaction.user.id,
              interaction.guild,
              `${definition.label} configurado automaticamente. As credenciais foram protegidas.`,
            ),
            flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
          });
        } catch (err) {
          console.error('[MED] Falha ao atualizar painel de pagamento do mediador:', err.message);
        }
      }
      await interaction.editReply({
        content: `✅ ${definition.label} configurado com sucesso. As credenciais e a Chave Pix foram salvas com segurança.`,
      });
    } catch (error) {
      await interaction.reply({
        content: error.message.includes('SESSION_SECRET')
          ? '🔒 Não foi possível salvar: a proteção de sessão do bot não está configurada.'
          : '❌ Não foi possível salvar a configuração deste provedor.',
        flags: MessageFlags.Ephemeral,
      });
    }
    return true;
  }

  // ── Entrar na fila ────────────────────────────────────────────────────────
  if (id === 'fmed:in') {
    const g = _guild(guildId);
    const userId = String(interaction.user.id).trim();

    if (processingGuilds.has(guildId)) {
      await interaction.reply({
        content: _msg(guildId, 'mediador_aguarde', 'A fila está sendo atualizada. Tente novamente em alguns segundos.'),
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    // 1. Verificar cargo de mediador
    const { getConfig } = require('./configurar');
    const cfg = getConfig(guildId);
    const mediadorRoleId = cfg?.roles?.mediador;
    if (!mediadorRoleId) {
      await interaction.reply({
        content: _msg(
          guildId,
          'mediador_cargo_nao_configurado',
          'O cargo de mediador ainda não foi configurado. Um administrador deve usar `/configurar` e definir o Cargo Mediador antes de liberar esta fila.',
        ),
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }
    if (!interaction.member?.roles?.cache?.has(mediadorRoleId)) {
      await interaction.reply({
        content: _msg(guildId, 'mediador_sem_cargo', 'Você não possui o cargo de mediador.'),
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    // 2. Verificar PIX cadastrado
    if (!_pagamentoPermitidoParaFila(guildId, userId)) {
      await interaction.reply({
        content: _msg(guildId, 'mediador_pix_necessario', 'Configure seus dados de PIX antes de entrar na fila.'),
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    // 3. Verificar se ja esta na fila
    if (g.fila.includes(userId)) {
      await interaction.reply({
        content: _msg(guildId, 'mediador_ja_esta', 'Você já está na fila. Não é necessário clicar novamente.'),
        flags: MessageFlags.Ephemeral,
      });
      await _refreshPainel(guildId, client, interaction.message);
      return true;
    }

    processingGuilds.add(guildId);
    try {
      if (!g.fila.includes(userId)) {
        g.fila.push(userId);
        _salvar();
      }
      await _refreshPainel(guildId, client, interaction.message);
      const { tentarCriarPartidas } = require('./filas');
      tentarCriarPartidas(guildId, client).catch((err) => console.error('[MED] Falha em tentarCriarPartidas:', err.message));
      await interaction.reply({ content: _msg(guildId, 'mediador_entrou', 'Você entrou na fila de mediadores.'), flags: MessageFlags.Ephemeral }).catch(() => {});
    } finally {
      processingGuilds.delete(guildId);
    }
    return true;
  }

  // ── Sair da fila ──────────────────────────────────────────────────────────
  if (id === 'fmed:out') {
    const g      = _guild(guildId);
    const userId = String(interaction.user.id).trim();
    const antes  = g.fila.length;
    g.fila = g.fila.filter(uid => String(uid).trim() !== userId);
    const saiu = g.fila.length < antes;
    if (saiu) {
      _salvar();
    }
    await _refreshPainel(guildId, client, interaction.message);
    const msgRetorno = !saiu
      ? _msg(guildId, 'mediador_nao_esta', 'Você não está na fila. Não há nada para remover.')
      : _msg(guildId, 'mediador_saiu', 'Você saiu da fila de mediadores.');
    await interaction.reply({ content: msgRetorno, flags: MessageFlags.Ephemeral }).catch(() => {});
    return true;
  }

  // ── Ranking ───────────────────────────────────────────────────────────────
  if (id === 'fmed:ranking') {
    await interaction.reply({
       ...painelV2FromEmbed(_buildRankingEmbed(guildId), [], { thumbnail: avatarDoServidor(interaction.guild) }),
      flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
    });
    return true;
  }

  // ── Cadastrar PIX ─────────────────────────────────────────────────────────
  if (id === 'fmed:pix') {
    // Verificar cargo antes de permitir cadastro
    const { getConfig } = require('./configurar');
    const mediadorRoleId = getConfig(guildId)?.roles?.mediador;
    if (!mediadorRoleId) {
      await interaction.reply({
        content: _msg(
          guildId,
          'mediador_cargo_nao_configurado',
          'O cargo de mediador ainda não foi configurado. Um administrador deve usar `/configurar` e definir o Cargo Mediador antes de cadastrar o PIX.',
        ),
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }
    if (!interaction.member?.roles?.cache?.has(mediadorRoleId)) {
      await interaction.reply({
        content: _msg(guildId, 'mediador_sem_cargo', 'Você não possui o cargo de mediador.'),
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    paineisPagamentoOrigem.set(`${guildId}:${interaction.user.id}`, interaction);
    await interaction.reply({
      ..._painelPagamentoEmbed(guildId, interaction.user.id, interaction.guild),
      flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
    });
    return true;
  }

  // ── Modal PIX ─────────────────────────────────────────────────────────────
  if (interaction.isModalSubmit() && id === 'fmed:modal:pix') {
    const pix = {
      titular: interaction.fields.getTextInputValue('titular').trim(),
      cidade: interaction.fields.getTextInputValue('cidade').trim(),
      tipo: interaction.fields.getTextInputValue('tipo').trim(),
      chave: interaction.fields.getTextInputValue('chave').trim(),
    };
    salvarPixMediador(guildId, interaction.user.id, pix);
    selecionarMetodoPix(guildId, interaction.user.id);

    await interaction.deferReply({ flags: MessageFlags.Ephemeral });
    const origem = paineisPagamentoOrigem.get(`${guildId}:${interaction.user.id}`);
    if (origem) {
      try {
        await origem.editReply({
          ..._painelPagamentoEmbed(
            guildId,
            interaction.user.id,
            interaction.guild,
            _msg(guildId, 'mediador_pix_salvo', 'Seus dados de pagamento foram cadastrados com sucesso.'),
          ),
          flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
        });
      } catch (err) {
        console.error('[MED] Falha ao atualizar painel de pagamento do mediador:', err.message);
      }
    }
    await interaction.editReply({
      content: '✅ Chave Pix cadastrada e atualizada com sucesso no painel de configuração.',
    });
    return true;
  }

  // ── Visualizar PIX ────────────────────────────────────────────────────────
  if (id === 'fmed:viewpix') {
    const g   = _guild(guildId);
    const reg = g.registro[interaction.user.id];
    const pix = _pixFormatado(reg);
    if (!pix || !_chavePix(reg)) {
      await interaction.reply({
        content: _msg(guildId, 'mediador_pix_nao_cadastrado', 'PIX não cadastrado. Use “Cadastrar PIX” para preencher os quatro dados.'),
        flags: MessageFlags.Ephemeral,
      });
    } else {
      const embed = new EmbedBuilder()
        .setTitle('SEUS DADOS DO PIX')
        .setColor(_cor(guildId))
        .setDescription('Confira abaixo os dados usados para receber os pagamentos das partidas.')
        .addFields(
          { name: 'Nome do titular', value: pix.titular, inline: true },
          { name: 'Cidade', value: pix.cidade, inline: true },
          { name: 'Tipo de chave', value: pix.tipo, inline: true },
          { name: 'Chave', value: `\`${pix.chave}\``, inline: false },
        );
      await interaction.reply({
        ...painelV2FromEmbed(embed),
        flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
      });
    }
    return true;
  }

  return false;
}

async function removerDaFilaMediador(guildId, userId, client) {
  const g = _guild(guildId);
  const cleanId = String(userId ?? '').trim();
  const antes = g.fila.length;
  g.fila = g.fila.filter((uid) => String(uid).trim() !== cleanId);
  if (g.fila.length === antes) return false;
  _salvar();
  if (client) await _refreshPainel(guildId, client);
  return true;
}

// ─────────────────────────────────────────────────────────────────────────────
// EXPORTS PARA filas.js
// ─────────────────────────────────────────────────────────────────────────────

/** Retorna true se houver ao menos um mediador aguardando. */
function temMediador(guildId) {
  const g = _guild(guildId);
  return Array.isArray(g.fila) && g.fila.length > 0;
}

/**
 * Remove e retorna o userId do próximo mediador (FIFO).
 * No modo rodízio, rotaciona o mediador para o final da fila sem removê-lo do painel.
 * Incrementa partidasMediadas no registro histórico.
 */
function pegarMediador(guildId) {
  const g = _guild(guildId);
  if (!Array.isArray(g.fila) || g.fila.length === 0) return null;

  const { getConfig } = require('./configurar');
  const modo = getConfig(guildId)?.mediationMode || 'rodizio';

  let userId = null;
  if (modo === 'rodizio') {
    userId = String(g.fila.shift()).trim();
    if (userId) {
      g.fila.push(userId);
    }
  } else {
    userId = String(g.fila.shift()).trim();
  }

  if (!userId) return null;
  if (!g.registro[userId]) g.registro[userId] = { pix: null, partidasMediadas: 0 };
  _salvar();
  return userId;
}

function liberarMediador(guildId, userId, client = null, { colocarNoFim = false, restaurarInicio = false } = {}) {
  if (!userId) return;
  const cleanId = String(userId).trim();
  if (!/^\d{16,22}$/.test(cleanId)) return;
  const g = _guild(guildId);
  const { getConfig } = require('./configurar');
  const modo = getConfig(guildId)?.mediationMode || 'rodizio';

  if (restaurarInicio) {
    g.fila = g.fila.filter((uid) => String(uid).trim() !== cleanId);
    g.fila.unshift(cleanId);
    _salvar();
  } else if (!g.fila.includes(cleanId)) {
    if (colocarNoFim || modo === 'rodizio') {
      g.fila.push(cleanId);
      _salvar();
    }
  }
  if (client) _refreshPainel(guildId, client).catch(() => {});
}

function registrarPartidaMediada(guildId, userId) {
  if (!userId) return;
  const g = _guild(guildId);
  if (!g.registro[userId]) g.registro[userId] = { pix: null, partidasMediadas: 0 };
  g.registro[userId].partidasMediadas = (g.registro[userId].partidasMediadas ?? 0) + 1;
  _salvar();
}

function obterPixMediador(guildId, userId) {
  const registro = _guild(guildId).registro[userId];
  if (!registro?.pix) return null;
  if (typeof registro.pix === 'string') return { titular: '', cidade: '', tipo: '', chave: registro.pix };
  return { ...registro.pix, chave: registro.pix.chave ?? '' };
}

async function pegarAnalista(guildId, guild, client = null) {
  return require('./fila_analista').pegarAnalistaDaFila(guildId, guild, client);
}

async function publicarPainelMediador(guild, channel) {
  const guildId = guild.id;
  const g = _guild(guildId);
  if (g.panelChanId && g.panelChanId !== channel.id && g.panelMsgId) {
    const canalAnterior = await guild.client?.channels.fetch(g.panelChanId).catch(() => null);
    const mensagemAnterior = await canalAnterior?.messages.fetch(g.panelMsgId).catch(() => null);
    if (mensagemAnterior?.author?.id === guild.client?.user?.id) {
      await mensagemAnterior.delete().catch(() => {});
      console.log(`[MED] Painel antigo removido de #${canalAnterior.name} antes da migração.`);
    }
  }
  const payload = {
    ...painelV2FromEmbed(
      _buildPainelEmbed(guildId, guild),
      _buildPainelRows(guildId),
      { thumbnail: g.thumbnail || avatarDoServidor(guild), image: g.banner },
    ),
    allowedMentions: { users: [...new Set(g.fila)] },
  };

  let message = null;
  if (g.panelChanId === channel.id && g.panelMsgId) {
    message = await channel.messages.fetch(g.panelMsgId).catch(() => null);
  }
  if (message) await message.edit(payload);
  else message = await channel.send(payload);

  g.panelMsgId = message.id;
  g.panelChanId = channel.id;
  _salvar();
  return message;
}

// ─────────────────────────────────────────────────────────────────────────────
// RESTAURAR PAINEL AO REINICIAR
// ─────────────────────────────────────────────────────────────────────────────

async function restaurarPainelMediador(client) {
  for (const [guildId, g] of Object.entries(_dados)) {
    if (!g.panelMsgId || !g.panelChanId) continue;
    try {
      const canal = await client.channels.fetch(g.panelChanId).catch(() => null);
      if (!canal) continue;
      const msg = await canal.messages.fetch(g.panelMsgId).catch(() => null);
      if (!msg) continue;
      await msg.edit({
         ...painelV2FromEmbed(_buildPainelEmbed(guildId, canal.guild), _buildPainelRows(guildId), {
           thumbnail: g.thumbnail || avatarDoServidor(canal.guild),
           image: g.banner,
         }),
        allowedMentions: { users: [...new Set(g.fila)] },
      });
      console.log(`[MED] Painel restaurado em guild ${guildId}`);
    } catch (e) {
      console.error('[MED] Falha ao restaurar painel:', e.message);
    }
  }
}

module.exports = {
  handleFilaMediador,
  publicarPainelMediador,
  atualizarPainelMediador,
  temMediador,
  pegarMediador,
  liberarMediador,
  registrarPartidaMediada,
  obterPixMediador,
  criarModalPix,
  salvarPixMediador,
  abrirModalPix,
  pegarAnalista,
  restaurarPainelMediador,
  removerDaFilaMediador,
  obterConfiguracaoPagamento,
  obterResumoConfiguracaoPagamento,
  verificarPagamentoMediador,
  PROVEDORES_PAGAMENTO,
};
