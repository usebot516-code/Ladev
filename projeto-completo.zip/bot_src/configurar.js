'use strict';

const {
  EmbedBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  RoleSelectMenuBuilder,
  ChannelSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ChannelType,
} = require('discord.js');

const { carregarGuildConfigs, salvarGuildConfigs } = require('./storage');
const { painelV2FromEmbed } = require('./visual');

// ─── Paleta de Cores ─────────────────────────────────────────────────────────
const CORES = [
  { label: 'Vermelho',       value: 'vermelho',       hex: 0xE74C3C },
  { label: 'Rosa',           value: 'rosa',           hex: 0xE91E63 },
  { label: 'Roxo',           value: 'roxo',           hex: 0x9B59B6 },
  { label: 'Índigo',         value: 'indigo',         hex: 0x3F51B5 },
  { label: 'Azul',           value: 'azul',           hex: 0x3498DB },
  { label: 'Azul Claro',     value: 'azul_claro',     hex: 0x03A9F4 },
  { label: 'Ciano',          value: 'ciano',          hex: 0x00BCD4 },
  { label: 'Verde-água',     value: 'verde_agua',     hex: 0x1ABC9C },
  { label: 'Verde',          value: 'verde',          hex: 0x2ECC71 },
  { label: 'Verde Escuro',   value: 'verde_escuro',   hex: 0x27AE60 },
  { label: 'Amarelo',        value: 'amarelo',        hex: 0xF1C40F },
  { label: 'Dourado',        value: 'dourado',        hex: 0xF0B232 },
  { label: 'Laranja',        value: 'laranja',        hex: 0xFF9800 },
  { label: 'Laranja Escuro', value: 'laranja_escuro', hex: 0xFF5722 },
  { label: 'Marrom',         value: 'marrom',         hex: 0x795548 },
  { label: 'Cinza',          value: 'cinza',          hex: 0x95A5A6 },
  { label: 'Cinza Escuro',   value: 'cinza_escuro',   hex: 0x607D8B },
  { label: 'Preto',          value: 'preto',          hex: 0x23272A },
  { label: 'Discord',        value: 'discord',        hex: 0x5865F2 },
  { label: 'Coral',          value: 'coral',          hex: 0xFF6B6B },
  { label: 'Prata',          value: 'prata',          hex: 0xBDC3C7 },
  { label: 'Turquesa',       value: 'turquesa',       hex: 0x40E0D0 },
  { label: 'Lilás',          value: 'lilas',          hex: 0xC8A2C8 },
  { label: 'Salmão',         value: 'salmon',         hex: 0xFA8072 },
  { label: 'Teal',           value: 'teal',           hex: 0x008080 },
];
const CORES_MAP = Object.fromEntries(CORES.map((c) => [c.value, c.hex]));

// ─── Estado Persistente ───────────────────────────────────────────────────────
const guildConfig = carregarGuildConfigs();

function defaultConfig() {
  return {
    roles:    { admin: null, mediador: null, analista: null, streamer: null, mediadorStreamer: null, tickets: [], lojaAtendimento: [] },
    channels: { filas: null, filaStreamer: null, ponto: null, logsConfirmadas: null, logsEncerradas: null, tickets: null, ticketsLogs: null, lojaTopicos: null, exposed: null, muralPartidas: null },
    taxa:             null,
    tempoInatividade: null,
    avisos:           null,
    avisosTipo:       'mensagem_direta',
    embedColor:       0x5865F2,
    qrCode:           { corCentral: 'Preto', corBorda: 'Branco' },
    mediationMode:    'rodizio',
    coins:            { winner: 0, loser: 0 },
  };
}

function getConfig(guildId) {
  if (!guildConfig.has(guildId)) guildConfig.set(guildId, defaultConfig());
  const cfg = guildConfig.get(guildId);
  const defaults = defaultConfig();
  cfg.roles = { ...defaults.roles, ...(cfg.roles ?? {}) };
  cfg.channels = { ...defaults.channels, ...(cfg.channels ?? {}) };
  if (!Array.isArray(cfg.roles.tickets)) cfg.roles.tickets = [];
  if (!Array.isArray(cfg.roles.lojaAtendimento)) cfg.roles.lojaAtendimento = [];
  if (!cfg.qrCode) cfg.qrCode = defaults.qrCode;
  if (!cfg.avisosTipo) cfg.avisosTipo = defaults.avisosTipo;
  if (cfg.tempoInatividade === undefined) cfg.tempoInatividade = defaults.tempoInatividade;
  cfg.coins = { ...defaults.coins, ...(cfg.coins ?? {}) };
  return cfg;
}

function persistir() {
  salvarGuildConfigs(guildConfig);
}

function updateConfig(guildId, partial) {
  const cfg = getConfig(guildId);
  if (partial && typeof partial === 'object') {
    if (partial.roles) cfg.roles = { ...cfg.roles, ...partial.roles };
    if (partial.channels) cfg.channels = { ...cfg.channels, ...partial.channels };
    if (partial.plan) cfg.plan = { ...(cfg.plan ?? {}), ...partial.plan };
    if (partial.coins) cfg.coins = { ...(cfg.coins ?? {}), ...partial.coins };
    if (partial.qrCode) cfg.qrCode = { ...(cfg.qrCode ?? {}), ...partial.qrCode };
    for (const [key, val] of Object.entries(partial)) {
      if (!['roles', 'channels', 'plan', 'coins', 'qrCode'].includes(key)) {
        cfg[key] = val;
      }
    }
  }
  persistir();
  return cfg;
}

function salvarConfiguracoesLoja() {
  persistir();
}

function sessaoKey(interaction) {
  return `${interaction.guildId}:${interaction.user.id}`;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
function btnVoltar(customId = 'conf:voltar') {
  return new ButtonBuilder()
    .setCustomId(customId)
    .setLabel('Voltar')
    .setStyle(ButtonStyle.Secondary);
}

function nomeCor(guildId) {
  const hex = getConfig(guildId).embedColor;
  return CORES.find((c) => c.hex === hex)?.label ?? 'Personalizada';
}

const SEM_ARQUIVOS = { files: [], attachments: [] };

function decorarPainel(embed, rodape = null) {
  return embed;
}

// ─── Paineis ──────────────────────────────────────────────────────────────────

function painelPrincipal(guildId, rodape = null) {
  const cfg = getConfig(guildId);
  const embed = new EmbedBuilder()
    .setColor(cfg.embedColor)
    .setTitle('CENTRAL DE CONFIGURAÇÕES')
    .setDescription(
      'Escolha uma área para configurar. Cada área reúne apenas as opções relacionadas ' +
      'àquela função do bot.'
    );
  decorarPainel(embed, rodape);

  const select = new StringSelectMenuBuilder()
    .setCustomId('conf:menu_categorias')
    .setPlaceholder('Escolha uma área')
    .addOptions([
      { label: 'Filas', value: 'filas', description: 'Partidas, cargos, canais, avisos, cor e mediação' },
      { label: 'Tickets', value: 'tickets', description: 'Canais e cargos autorizados para tickets' },
      { label: 'Loja Coins', value: 'loja_coins', description: 'Cargos e canal da Loja de Coins' },
    ]);

  return painelV2FromEmbed(embed, [new ActionRowBuilder().addComponents(select)]);
}

function painelFilas(guildId, rodape = null) {
  const cfg            = getConfig(guildId);
  const tipoAviso = cfg.avisosTipo === 'embed' ? 'Embed' : 'Mensagem Direta';
  const tempoInatTexto = cfg.tempoInatividade ? `${cfg.tempoInatividade} minuto(s)` : 'Desativado';
  const info = [
    `Taxa de sala: ${cfg.taxa ?? 'Não definida'}`,
    `Tempo de inatividade: ${tempoInatTexto}`,
    `Modo de Mediação: ${cfg.mediationMode === 'rodizio' ? 'Rodízio' : 'Mediou Saiu'}`,
    `Cor das Embeds: ${nomeCor(guildId)}`,
    `QR Code — Cor Central: ${cfg.qrCode.corCentral} | Borda: ${cfg.qrCode.corBorda}`,
    `Aviso pós-confirmação: ${cfg.avisos ? `Configurado (${tipoAviso})` : 'Não definido'}`,
  ].join('\n');

  const embed = new EmbedBuilder()
    .setColor(cfg.embedColor)
    .setTitle('CONFIGURAÇÕES DE FILAS')
    .setDescription(
      'Configure os cargos, canais e regras usados pelas filas de partidas. ' +
      'Todas as alterações são salvas automaticamente e sobrevivem a reinicializações.'
    )
    .addFields(
      { name: 'Resumo das Configurações Atuais', value: info },
      {
        name:  'Categorias disponíveis',
        value:
      'Cargos — Define quais cargos possuem permissão de admin, mediador, analista, streamer e mediador de streamer.\n' +
          'Canais — Define os canais utilizados para filas, ponto e logs de partidas.\n' +
          'Taxa — Valor cobrado por sala de partida organizada pelo bot.\n' +
          'Tempo de Inatividade — Define o tempo para fechar o tópico da partida por inatividade.\n' +
          'Avisos — Mensagem automática enviada após a confirmação de uma partida.\n' +
          'Cor das Embeds — Cor da barra lateral usada em todas as embeds do bot neste servidor.\n' +
           'QR Code — Personalize as cores dos QR Codes.\n' +
           'Modo de Mediação — Controla se o mediador permanece ou sai da fila após ser designado.\n' +
           'Use o botão Voltar para retornar à seleção de áreas.',
      }
    )
    ;
  decorarPainel(embed, rodape);

  const select = new StringSelectMenuBuilder()
    .setCustomId('conf:menu_principal')
    .setPlaceholder('Escolha o que deseja configurar')
    .addOptions([
      { label: 'Cargos',               value: 'cargos',            description: 'Admin, Mediador, Analista e cargos de filas' },
      { label: 'Canais',               value: 'canais',            description: 'Filas, ponto (.p), logs de confirmadas e encerradas' },
      { label: 'Taxa de Sala',         value: 'taxa',              description: 'Valor cobrado por sala de partida' },
      { label: 'Tempo de Inatividade', value: 'tempo_inatividade', description: 'Tempo para fechar o tópico da partida por inatividade' },
      { label: 'Avisos',               value: 'avisos',            description: 'Mensagem enviada após confirmação da partida' },
      { label: 'Cor das Embeds',       value: 'cor_embeds',        description: 'Cor padrão de todas as embeds do bot' },
      { label: 'QR Code',              value: 'qrcode',            description: 'Cores dos QR Codes' },
      { label: 'Modo de Mediação',     value: 'modo_mediacao',     description: 'Alterne entre Rodízio e Mediou Saiu' },
    ]);

  return painelV2FromEmbed(embed, [
    new ActionRowBuilder().addComponents(select),
    new ActionRowBuilder().addComponents(btnVoltar('conf:categorias_voltar')),
  ]);
}

function painelCargos(guildId, rodape = null) {
  const cfg = getConfig(guildId);
  const r   = cfg.roles;

  const embed = new EmbedBuilder()
    .setColor(cfg.embedColor)
    .setTitle('CONFIGURAÇÃO DE CARGOS')
    .setDescription(
      'Aqui você define quais cargos do servidor correspondem a cada função do bot. ' +
      'Utilize os menus abaixo para selecionar o cargo adequado para cada função. ' +
      'Apenas membros com o cargo configurado terão acesso às funcionalidades correspondentes.'
    )
    .addFields(
      { name: 'Cargo Admin',                value: r.admin           ? `<@&${r.admin}>`            : 'Não definido — clique no menu abaixo para configurar', inline: false },
      { name: 'Cargo Mediador',             value: r.mediador        ? `<@&${r.mediador}>`         : 'Não definido — clique no menu abaixo para configurar', inline: false },
      { name: 'Cargo Analista',             value: r.analista        ? `<@&${r.analista}>`         : 'Não definido — clique no menu abaixo para configurar', inline: false },
    )
    ;
  decorarPainel(embed, rodape);

  return painelV2FromEmbed(embed, [
      new ActionRowBuilder().addComponents(new RoleSelectMenuBuilder().setCustomId('conf:cargo_admin').setPlaceholder('Cargo Admin')),
      new ActionRowBuilder().addComponents(new RoleSelectMenuBuilder().setCustomId('conf:cargo_mediador').setPlaceholder('Cargo Mediador')),
      new ActionRowBuilder().addComponents(new RoleSelectMenuBuilder().setCustomId('conf:cargo_analista').setPlaceholder('Cargo Analista')),
      new ActionRowBuilder().addComponents(
        btnVoltar('conf:filas_voltar'),
        new ButtonBuilder().setCustomId('conf:cargos_proximo').setLabel('Próximo').setStyle(ButtonStyle.Primary),
      ),
  ]);
}

function painelTickets(guildId, rodape = null) {
  const cfg = getConfig(guildId);
  const ch  = cfg.channels;
  const embed = new EmbedBuilder()
    .setColor(cfg.embedColor)
    .setTitle('CONFIGURAÇÃO DE TICKETS')
    .setDescription(
      'Configure os canais e cargos do sistema de tickets deste servidor. ' +
      'O canal dos tópicos define onde os tópicos de atendimento serão criados automaticamente. ' +
      'Os cargos determinam quem pode gerenciar e responder os tickets.'
    )
    .addFields(
      { name: 'Canal dos Tópicos de Tickets',     value: ch.tickets     ? `<#${ch.tickets}>`     : 'Não definido',             inline: false },
      { name: 'Canal de Logs de Tickets',         value: ch.ticketsLogs  ? `<#${ch.ticketsLogs}>` : 'Não definido',             inline: false },
      { name: 'Cargos Autorizados',               value: cfg.roles.tickets.length ? cfg.roles.tickets.map((id) => `<@&${id}>`).join(', ') : 'Nenhum cargo cadastrado', inline: false },
    );
  decorarPainel(embed, rodape);
  return painelV2FromEmbed(embed, [
    new ActionRowBuilder().addComponents(new ChannelSelectMenuBuilder().setCustomId('conf:tickets_canal').setPlaceholder('Canal dos Tópicos de Tickets').setChannelTypes([ChannelType.GuildText])),
    new ActionRowBuilder().addComponents(new ChannelSelectMenuBuilder().setCustomId('conf:tickets_canal_logs').setPlaceholder('Canal Logs de Tickets').setChannelTypes([ChannelType.GuildText])),
    new ActionRowBuilder().addComponents(new RoleSelectMenuBuilder().setCustomId('conf:tickets_cargo').setPlaceholder('Cargos autorizados').setMinValues(1).setMaxValues(10)),
    new ActionRowBuilder().addComponents(btnVoltar('conf:categorias_voltar')),
  ]);
}

function painelCargosAvancados(guildId, rodape = null) {
  const cfg = getConfig(guildId);
  const r = cfg.roles;
  const embed = new EmbedBuilder()
    .setColor(cfg.embedColor)
    .setTitle('CONFIGURAÇÃO DE CARGOS DE FILAS')
    .setDescription(
      'Defina os cargos usados nas filas de streamer deste servidor. ' +
      'Cada servidor mantém seus próprios cargos e permissões.'
    )
    .addFields(
      { name: 'Cargo Streamer', value: r.streamer ? `<@&${r.streamer}>` : 'Não definido', inline: false },
      { name: 'Cargo Mediador de Streamer', value: r.mediadorStreamer ? `<@&${r.mediadorStreamer}>` : 'Não definido', inline: false },
    );
  decorarPainel(embed, rodape);
  return painelV2FromEmbed(embed, [
    new ActionRowBuilder().addComponents(new RoleSelectMenuBuilder().setCustomId('conf:cargo_streamer').setPlaceholder('Cargo Streamer')),
    new ActionRowBuilder().addComponents(new RoleSelectMenuBuilder().setCustomId('conf:cargo_mediador_streamer').setPlaceholder('Cargo Mediador de Streamer')),
    new ActionRowBuilder().addComponents(btnVoltar('conf:cargos_avancados_voltar')),
  ]);
}

function painelCargosTickets(guildId, rodape = null) {
  const cfg = getConfig(guildId);
  const embed = new EmbedBuilder()
    .setColor(cfg.embedColor)
    .setTitle('CARGOS AUTORIZADOS PARA TICKETS')
    .setDescription(
      'Cadastre os cargos que poderão atender tickets. ' +
      'O sistema de tickets reutiliza exclusivamente esta lista ao definir responsáveis por categoria.'
    )
    .addFields({
      name: 'Cargos cadastrados',
      value: cfg.roles.tickets.length ? cfg.roles.tickets.map((id) => `<@&${id}>`).join(', ') : 'Nenhum cargo cadastrado',
    });
  decorarPainel(embed, rodape);
  return painelV2FromEmbed(embed, [
    new ActionRowBuilder().addComponents(
      new RoleSelectMenuBuilder()
        .setCustomId('conf:cargo_ticket')
        .setPlaceholder('Selecione os cargos autorizados')
        .setMinValues(1)
        .setMaxValues(10),
    ),
    new ActionRowBuilder().addComponents(btnVoltar('conf:cargos_voltar')),
  ]);
}

function painelCanais1(guildId, rodape = null) {
  const cfg = getConfig(guildId);
  const ch  = cfg.channels;

  const embed = new EmbedBuilder()
    .setColor(cfg.embedColor)
    .setTitle('CONFIGURAÇÃO DE CANAIS • 1/2')
    .setDescription(
      'Configure os canais principais utilizados pelo bot neste servidor. ' +
      'O canal de Filas é onde o bot gerencia as filas de partida. ' +
      'O canal de Fila Streamer é dedicado a partidas de streamers. ' +
      'O canal de Ponto (.p) é onde os mediadores registram presença. ' +
      'Use o botão Próximo para configurar os canais de logs.'
    )
    .addFields(
      { name: 'Canal de Referência das Partidas', value: ch.filas ? `<#${ch.filas}>` : 'Não definido', inline: false },
      { name: 'Canal de Fila Streamer', value: ch.filaStreamer ? `<#${ch.filaStreamer}>` : 'Não definido', inline: false },
      { name: 'Canal de Ponto (.p)',    value: ch.ponto       ? `<#${ch.ponto}>`        : 'Não definido', inline: false },
    )
    ;
  decorarPainel(embed, rodape);

  return painelV2FromEmbed(embed, [
      new ActionRowBuilder().addComponents(new ChannelSelectMenuBuilder().setCustomId('conf:canal_filas').setPlaceholder('Canal de Referência (Partidas)').setChannelTypes([ChannelType.GuildText, ChannelType.GuildAnnouncement])),
      new ActionRowBuilder().addComponents(new ChannelSelectMenuBuilder().setCustomId('conf:canal_fila_streamer').setPlaceholder('Canal Fila Streamer').setChannelTypes([ChannelType.GuildText])),
      new ActionRowBuilder().addComponents(new ChannelSelectMenuBuilder().setCustomId('conf:canal_ponto').setPlaceholder('Canal .p').setChannelTypes([ChannelType.GuildText])),
      new ActionRowBuilder().addComponents(
        btnVoltar('conf:filas_voltar'),
        new ButtonBuilder().setCustomId('conf:canais_pagina2').setLabel('Próximo').setStyle(ButtonStyle.Primary),
      ),
  ]);
}

function painelCanais2(guildId, rodape = null) {
  const cfg = getConfig(guildId);
  const ch  = cfg.channels;

  const embed = new EmbedBuilder()
    .setColor(cfg.embedColor)
    .setTitle('CONFIGURAÇÃO DE CANAIS • 2/2')
    .setDescription(
      'Configure os canais de log e utilitários utilizados pelo bot. ' +
      'O canal de Logs de Partidas Confirmadas recebe notificações de partidas confirmadas. ' +
      'O canal de Logs de Partidas Encerradas recebe relatórios finais de partidas. ' +
      'O canal de Registrar Exposed é onde os painéis oficiais de exposed e banimentos são publicados. ' +
      'O canal Mural de Partidas recebe a publicação oficial dos resultados e prints de vitória.'
    )
    .addFields(
      { name: 'Canal — Logs de Partidas Confirmadas', value: ch.logsConfirmadas ? `<#${ch.logsConfirmadas}>` : 'Não definido', inline: false },
      { name: 'Canal — Logs de Partidas Encerradas',  value: ch.logsEncerradas  ? `<#${ch.logsEncerradas}>`  : 'Não definido', inline: false },
      { name: 'Canal — Registrar Exposed',           value: ch.exposed         ? `<#${ch.exposed}>`         : 'Não definido', inline: false },
      { name: 'Canal — Mural de Partidas',           value: ch.muralPartidas   ? `<#${ch.muralPartidas}>`   : 'Não definido', inline: false },
    )
    ;
  decorarPainel(embed, rodape);

  return painelV2FromEmbed(embed, [
      new ActionRowBuilder().addComponents(new ChannelSelectMenuBuilder().setCustomId('conf:canal_logs_confirmadas').setPlaceholder('Canal Logs Confirmadas').setChannelTypes([ChannelType.GuildText])),
      new ActionRowBuilder().addComponents(new ChannelSelectMenuBuilder().setCustomId('conf:canal_logs_encerradas').setPlaceholder('Canal Logs Encerradas').setChannelTypes([ChannelType.GuildText])),
      new ActionRowBuilder().addComponents(new ChannelSelectMenuBuilder().setCustomId('conf:canal_exposed').setPlaceholder('Canal Registrar Exposed').setChannelTypes([ChannelType.GuildText, ChannelType.GuildAnnouncement])),
      new ActionRowBuilder().addComponents(new ChannelSelectMenuBuilder().setCustomId('conf:canal_mural_partidas').setPlaceholder('Canal Mural de Partidas').setChannelTypes([ChannelType.GuildText, ChannelType.GuildAnnouncement])),
      new ActionRowBuilder().addComponents(btnVoltar('conf:canais_pagina1')),
  ]);
}

function painelCorEmbeds(guildId, rodape = null) {
  const cfg = getConfig(guildId);

  const embed = new EmbedBuilder()
    .setColor(cfg.embedColor)
    .setTitle('COR DAS EMBEDS')
    .setDescription(
      'A cor selecionada será aplicada na barra lateral de todas as embeds enviadas pelo bot neste servidor. ' +
      `A cor atual é ${nomeCor(guildId)}. ` +
      'Selecione uma nova cor no menu abaixo para alterar imediatamente. ' +
      'A prévia da cor aparece na barra lateral desta própria embed assim que a alteração é feita.'
    )
    ;
  decorarPainel(embed, rodape);

  const select = new StringSelectMenuBuilder()
    .setCustomId('conf:cor_select')
    .setPlaceholder('Selecione uma cor')
    .addOptions(CORES.map((c) => ({
      label:       c.label,
      value:       c.value,
      description: `Hex: #${c.hex.toString(16).toUpperCase().padStart(6, '0')}`,
    })));

  return painelV2FromEmbed(embed, [
      new ActionRowBuilder().addComponents(select),
      new ActionRowBuilder().addComponents(btnVoltar('conf:filas_voltar')),
  ]);
}

function painelQRCode(guildId, rodape = null) {
  const cfg            = getConfig(guildId);
  const qr             = cfg.qrCode;

  const embed = new EmbedBuilder()
    .setColor(cfg.embedColor)
    .setTitle('APARÊNCIA DO QR CODE')
    .setDescription(
      'Aqui você personaliza a aparência dos QR Codes gerados pelo bot neste servidor. ' +
      'Você pode alterar a cor dos pontos centrais e a cor da borda/quadrados externos. ' +
      'Para manter a leitura, pontos claros são convertidos automaticamente para um tom escuro.'
    )
    .addFields(
      { name: 'Cor dos Pontos Centrais', value: qr.corCentral,  inline: true },
      { name: 'Cor da Borda/Quadrados',  value: qr.corBorda,    inline: true },
    )
    ;
  decorarPainel(embed, rodape);

  const select = new StringSelectMenuBuilder()
    .setCustomId('conf:qr_menu')
    .setPlaceholder('Escolha o que deseja configurar')
    .addOptions([
      { label: 'Cor dos Pontos Centrais', value: 'cor_central', description: 'Altera a cor dos pontos internos do QR Code'            },
      { label: 'Cor da Borda/Quadrados',  value: 'cor_borda',   description: 'Altera a cor dos quadrados e bordas externas do QR Code' },
    ]);

  return painelV2FromEmbed(embed, [
      new ActionRowBuilder().addComponents(select),
      new ActionRowBuilder().addComponents(btnVoltar('conf:filas_voltar')),
  ]);
}

function painelMediacao(guildId, rodape = null) {
  const cfg       = getConfig(guildId);
  const isRodizio = cfg.mediationMode === 'rodizio';

  const desc = isRodizio
    ? 'No modo Rodízio, o mediador permanece na fila mesmo após ser designado para uma partida. ' +
      'Isso significa que ele pode ser chamado novamente para a próxima partida sem precisar entrar na fila de novo. ' +
      'Ideal para cenários onde o mesmo mediador atende múltiplas partidas em sequência.'
    : 'No modo Mediou Saiu, o mediador é removido automaticamente da fila após ser designado para uma partida. ' +
      'Para mediar outra partida, ele precisará entrar na fila novamente. ' +
      'Ideal para cenários onde a carga de mediação deve ser distribuída igualmente entre todos os mediadores disponíveis.';

  const embed = new EmbedBuilder()
    .setColor(cfg.embedColor)
    .setTitle('MODO DE MEDIAÇÃO')
    .setDescription(
      `O modo atual é ${isRodizio ? 'Rodízio' : 'Mediou Saiu'}.\n\n${desc}\n\n` +
      'Clique no botão abaixo para alternar entre os modos de mediação. A mudança é aplicada imediatamente.'
    );
  decorarPainel(embed, rodape);

  return painelV2FromEmbed(embed, [
      new ActionRowBuilder().addComponents(
        btnVoltar('conf:filas_voltar'),
        new ButtonBuilder()
          .setCustomId('conf:mediacao_toggle')
          .setLabel(isRodizio ? 'Mediou Saiu' : 'Rodízio')
          .setStyle(ButtonStyle.Primary),
      ),
  ]);
}

function painelAvisos(guildId, rodape = null) {
  const cfg = getConfig(guildId);
  const tipoAtual = cfg.avisosTipo === 'embed' ? 'Embed' : 'Mensagem direta';
  const tipoDesc = cfg.avisosTipo === 'embed'
    ? 'O aviso é enviado com uma embed (borda com cor).'
    : 'O aviso é enviado como mensagem direta no canal (sem embed).';

  const embed = new EmbedBuilder()
    .setColor(cfg.embedColor)
    .setTitle('CONFIGURAÇÃO DE AVISOS')
    .setDescription(
      'Defina o formato de envio e o texto da mensagem automática que o bot enviará após a confirmação de uma partida.\n\n' +
      `**Formato atual:** ${tipoAtual}\n` +
      `*${tipoDesc}*\n\n` +
      `**Mensagem configurada:**\n${cfg.avisos ? `>>> ${cfg.avisos}` : '*Nenhuma mensagem definida ainda.*'}`
    )
    .addFields(
      { name: 'Formato de Envio', value: tipoAtual, inline: true },
      { name: 'Status do Texto', value: cfg.avisos ? 'Configurado' : 'Não definido', inline: true },
    );
  decorarPainel(embed, rodape);

  const select = new StringSelectMenuBuilder()
    .setCustomId('conf:avisos_tipo')
    .setPlaceholder('Escolha o formato do aviso')
    .addOptions([
      {
        label: 'Embed',
        value: 'embed',
        description: 'Envia o aviso em uma embed (com borda colorida)',
        default: cfg.avisosTipo === 'embed',
      },
      {
        label: 'Mensagem direta',
        value: 'mensagem_direta',
        description: 'Envia o aviso sem embed, apenas mensagem direta no canal',
        default: cfg.avisosTipo !== 'embed',
      },
    ]);

  return painelV2FromEmbed(embed, [
    new ActionRowBuilder().addComponents(select),
    new ActionRowBuilder().addComponents(
      btnVoltar('conf:filas_voltar'),
      new ButtonBuilder()
        .setCustomId('conf:avisos_definir_texto')
        .setLabel('Editar Mensagem')
        .setStyle(ButtonStyle.Primary),
    ),
  ]);
}

// ─── Modais ───────────────────────────────────────────────────────────────────

function modalTaxa() {
  const modal = new ModalBuilder().setCustomId('conf:modal_taxa').setTitle('Configurar Taxa de Sala');
  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('taxa_valor')
        .setLabel('Taxa cobrada por sala de partida')
        .setStyle(TextInputStyle.Short)
        .setPlaceholder('Ex: 10%, R$ 5,00, 2 reais por sala')
        .setRequired(true)
    )
  );
  return modal;
}

function modalTempoInatividade(valorAtual = null) {
  const modal = new ModalBuilder().setCustomId('conf:modal_inatividade').setTitle('Tempo de Inatividade');
  const input = new TextInputBuilder()
    .setCustomId('inatividade_minutos')
    .setLabel('Tempo para fechar a partida (em minutos)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('Ex: 5, 10, 15 (digite 0 para desativar)')
    .setRequired(true);
  if (valorAtual) {
    input.setValue(String(valorAtual));
  }
  modal.addComponents(
    new ActionRowBuilder().addComponents(input)
  );
  return modal;
}

function modalAvisos(textoAtual = '') {
  const modal = new ModalBuilder().setCustomId('conf:modal_avisos').setTitle('Configurar Mensagem de Aviso');
  const input = new TextInputBuilder()
    .setCustomId('aviso_texto')
    .setLabel('Mensagem enviada após confirmação de partida')
    .setStyle(TextInputStyle.Paragraph)
    .setPlaceholder('Digite a mensagem que será enviada automaticamente quando uma partida for confirmada...')
    .setMaxLength(1000)
    .setRequired(true);
  if (textoAtual && typeof textoAtual === 'string') {
    input.setValue(textoAtual);
  }
  modal.addComponents(
    new ActionRowBuilder().addComponents(input)
  );
  return modal;
}

function modalQRCentral() {
  const modal = new ModalBuilder().setCustomId('conf:modal_qr_central').setTitle('Cor dos Pontos Centrais do QR');
  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('cor_central')
        .setLabel('Nome da cor para os pontos centrais')
        .setStyle(TextInputStyle.Short)
        .setPlaceholder('Ex: preto, azul, vermelho, branco')
        .setRequired(true)
    )
  );
  return modal;
}

function modalQRBorda() {
  const modal = new ModalBuilder().setCustomId('conf:modal_qr_borda').setTitle('Cor da Borda/Quadrados do QR');
  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('cor_borda')
        .setLabel('Nome da cor para a borda e quadrados externos')
        .setStyle(TextInputStyle.Short)
        .setPlaceholder('Ex: branco, cinza, azul, transparente')
        .setRequired(true)
    )
  );
  return modal;
}

// ─── Handler Principal ────────────────────────────────────────────────────────

async function handleConfigurar(interaction) {
  const guildId = interaction.guildId;
  if (!guildId) return false;

  // ── Comando /configurar ───────────────────────────────────────────────────
  if (interaction.isChatInputCommand() && interaction.commandName === 'configurar') {
    await interaction.reply({ ephemeral: true, ...painelPrincipal(guildId) });
    return true;
  }

  if (!interaction.customId?.startsWith('conf:')) return false;

  const id = interaction.customId;

  // ── Select: Áreas principais ──────────────────────────────────────────────
  if (interaction.isStringSelectMenu() && id === 'conf:menu_categorias') {
    const val = interaction.values[0];
    await interaction.deferUpdate();
    if (val === 'filas') {
      await interaction.editReply(painelFilas(guildId));
    } else if (val === 'tickets') {
      await interaction.editReply(painelTickets(guildId));
    } else if (val === 'loja_coins') {
      await interaction.editReply(require('./loja').configPanel(guildId));
    }
    return true;
  }

  // ── Select: Configurações de Filas ───────────────────────────────────────
  if (interaction.isStringSelectMenu() && id === 'conf:menu_principal') {
    const val = interaction.values[0];
    if (val === 'taxa') { await interaction.showModal(modalTaxa()); return true; }
    if (val === 'tempo_inatividade') {
      const cfg = getConfig(guildId);
      await interaction.showModal(modalTempoInatividade(cfg.tempoInatividade));
      return true;
    }

    await interaction.deferUpdate();
    if      (val === 'cargos')        await interaction.editReply(painelCargos(guildId));
    else if (val === 'canais')        await interaction.editReply(painelCanais1(guildId));
    else if (val === 'avisos')        await interaction.editReply(painelAvisos(guildId));
    else if (val === 'cor_embeds')    await interaction.editReply(painelCorEmbeds(guildId));
    else if (val === 'qrcode')        await interaction.editReply(painelQRCode(guildId));
    else if (val === 'modo_mediacao') await interaction.editReply(painelMediacao(guildId));
    return true;
  }

  // ── Botão: Voltar para as áreas ──────────────────────────────────────────
  if (interaction.isButton() && id === 'conf:categorias_voltar') {
    await interaction.deferUpdate();
    await interaction.editReply(painelPrincipal(guildId));
    return true;
  }

  // ── Botão: Voltar para Filas ─────────────────────────────────────────────
  if (interaction.isButton() && id === 'conf:filas_voltar') {
    await interaction.deferUpdate();
    await interaction.editReply(painelFilas(guildId));
    return true;
  }

  // Compatibilidade com painéis antigos.
  if (interaction.isButton() && id === 'conf:voltar') {
    await interaction.deferUpdate();
    await interaction.editReply(painelFilas(guildId));
    return true;
  }

  if (interaction.isButton() && id === 'conf:cargos_tickets') {
    await interaction.deferUpdate();
    await interaction.editReply(painelCargosTickets(guildId));
    return true;
  }

  if (interaction.isButton() && (id === 'conf:cargos_proximo' || id === 'conf:cargos_avancados')) {
    await interaction.deferUpdate();
    await interaction.editReply(painelCargosAvancados(guildId));
    return true;
  }

  if (interaction.isButton() && id === 'conf:cargos_avancados_voltar') {
    await interaction.deferUpdate();
    await interaction.editReply(painelCargos(guildId));
    return true;
  }

  if (interaction.isButton() && id === 'conf:cargos_voltar') {
    await interaction.deferUpdate();
    await interaction.editReply(painelCargos(guildId));
    return true;
  }

  // ── Botão: Voltar ao painel QR Code ─────────────────────────────────────────
  if (interaction.isButton() && id === 'conf:qr_voltar') {
    await interaction.deferUpdate();
    await interaction.editReply(painelQRCode(guildId));
    return true;
  }

  // ── Botão: Canais — Página 2 ──────────────────────────────────────────────
  if (interaction.isButton() && id === 'conf:canais_pagina2') {
    await interaction.deferUpdate();
    await interaction.editReply(painelCanais2(guildId));
    return true;
  }

  // ── Botão: Canais — Página 1 ──────────────────────────────────────────────
  if (interaction.isButton() && id === 'conf:canais_pagina1') {
    await interaction.deferUpdate();
    await interaction.editReply(painelCanais1(guildId));
    return true;
  }

  // ── Role Select Menus ─────────────────────────────────────────────────────
  if (interaction.isRoleSelectMenu()) {
    const cfg    = getConfig(guildId);
    const selectedRoleIds = [...new Set(interaction.values.filter(Boolean))];
    const botHighestPosition = interaction.guild.members.me?.roles.highest?.position ?? -1;
    const validRoleIds = selectedRoleIds.filter((roleId) => {
      const role = interaction.guild.roles.cache.get(roleId);
      return role && !role.managed && role.position < botHighestPosition;
    });
    if (validRoleIds.length !== selectedRoleIds.length || validRoleIds.length === 0) {
      await interaction.reply({
        content: '⚠️ Selecione apenas cargos comuns que estejam abaixo do cargo mais alto do bot.',
        flags: require('discord.js').MessageFlags.Ephemeral,
      });
      return true;
    }
    const roleId = validRoleIds[0];
    let rodape   = null;

    if      (id === 'conf:cargo_admin')             { cfg.roles.admin           = roleId; rodape = 'Cargo de Administrador atualizado com sucesso.'; }
    else if (id === 'conf:cargo_mediador')          { cfg.roles.mediador        = roleId; rodape = 'Cargo de Mediador atualizado com sucesso.'; }
    else if (id === 'conf:cargo_analista')          { cfg.roles.analista        = roleId; rodape = 'Cargo de Analista atualizado com sucesso.'; }
    else if (id === 'conf:cargo_streamer')          { cfg.roles.streamer         = roleId; rodape = 'Cargo de Streamer atualizado com sucesso.'; }
    else if (id === 'conf:cargo_mediador_streamer') { cfg.roles.mediadorStreamer = roleId; rodape = 'Cargo de Mediador de Streamer atualizado com sucesso.'; }
    else if (id === 'conf:cargo_ticket') {
      cfg.roles.tickets = [...new Set([...cfg.roles.tickets, ...validRoleIds])].slice(0, 25);
      rodape = 'Cargos autorizados para Tickets atualizados com sucesso.';
    }
    else if (id === 'conf:tickets_cargo') {
      cfg.roles.tickets = [...new Set([...cfg.roles.tickets, ...validRoleIds])].slice(0, 25);
      rodape = 'Cargos autorizados para Tickets atualizados com sucesso.';
    }
    else return false;

    persistir();
    await interaction.deferUpdate();
    if      (id === 'conf:tickets_cargo')                                            await interaction.editReply(painelTickets(guildId, rodape));
    else if (id === 'conf:cargo_ticket')                                             await interaction.editReply(painelCargosTickets(guildId, rodape));
    else if (id === 'conf:cargo_streamer' || id === 'conf:cargo_mediador_streamer') await interaction.editReply(painelCargosAvancados(guildId, rodape));
    else                                                                              await interaction.editReply(painelCargos(guildId, rodape));
    return true;
  }

  // ── Channel Select Menus ──────────────────────────────────────────────────
  if (interaction.isChannelSelectMenu()) {
    const cfg       = getConfig(guildId);
    const channelId = interaction.values[0];
    let pagina      = 1;
    let rodape      = null;

    if      (id === 'conf:canal_filas')            { cfg.channels.filas           = channelId; rodape = 'Canal de Filas atualizado com sucesso.';                        pagina = 1; }
    else if (id === 'conf:canal_fila_streamer')    { cfg.channels.filaStreamer     = channelId; rodape = 'Canal de Fila Streamer atualizado com sucesso.';                pagina = 1; }
    else if (id === 'conf:canal_ponto')            { cfg.channels.ponto           = channelId; rodape = 'Canal de Ponto (.p) atualizado com sucesso.';                   pagina = 1; }
    else if (id === 'conf:canal_logs_confirmadas') { cfg.channels.logsConfirmadas = channelId; rodape = 'Canal de Logs de Partidas Confirmadas atualizado com sucesso.'; pagina = 2; }
    else if (id === 'conf:canal_logs_encerradas')  { cfg.channels.logsEncerradas  = channelId; rodape = 'Canal de Logs de Partidas Encerradas atualizado com sucesso.';  pagina = 2; }
    else if (id === 'conf:canal_exposed')          { cfg.channels.exposed          = channelId; rodape = 'Canal de Registrar Exposed atualizado com sucesso.';            pagina = 2; }
    else if (id === 'conf:canal_mural_partidas')   { cfg.channels.muralPartidas   = channelId; rodape = 'Canal Mural de Partidas atualizado com sucesso.';               pagina = 2; }
    else if (id === 'conf:canal_tickets')           { cfg.channels.tickets          = channelId; rodape = 'Canal-pai dos Tickets atualizado com sucesso.';    pagina = 1; }
    else if (id === 'conf:canal_tickets_logs')     { cfg.channels.ticketsLogs      = channelId; rodape = 'Canal de Logs de Tickets atualizado com sucesso.';  pagina = 2; }
    else if (id === 'conf:tickets_canal')          { cfg.channels.tickets          = channelId; rodape = 'Canal-pai dos Tickets atualizado com sucesso.';    pagina = 0; }
    else if (id === 'conf:tickets_canal_logs')     { cfg.channels.ticketsLogs      = channelId; rodape = 'Canal de Logs de Tickets atualizado com sucesso.';  pagina = 0; }
    else return false;

    persistir();
    await interaction.deferUpdate();
    if      (pagina === 0) await interaction.editReply(painelTickets(guildId, rodape));
    else if (pagina === 1) await interaction.editReply(painelCanais1(guildId, rodape));
    else                   await interaction.editReply(painelCanais2(guildId, rodape));
    return true;
  }

  // ── Select: Formato de Avisos ─────────────────────────────────────────────
  if (interaction.isStringSelectMenu() && id === 'conf:avisos_tipo') {
    const cfg = getConfig(guildId);
    const val = interaction.values[0];
    cfg.avisosTipo = val === 'embed' ? 'embed' : 'mensagem_direta';
    persistir();
    await interaction.deferUpdate();
    const nome = cfg.avisosTipo === 'embed' ? 'Embed' : 'Mensagem direta';
    await interaction.editReply(painelAvisos(guildId, `Formato de aviso alterado para: ${nome}.`));
    return true;
  }

  // ── Botão: Definir Texto de Avisos ─────────────────────────────────────────
  if (interaction.isButton() && id === 'conf:avisos_definir_texto') {
    const cfg = getConfig(guildId);
    await interaction.showModal(modalAvisos(cfg.avisos));
    return true;
  }

  // ── Select: Cor das Embeds ────────────────────────────────────────────────
  if (interaction.isStringSelectMenu() && id === 'conf:cor_select') {
    const cfg  = getConfig(guildId);
    const val  = interaction.values[0];
    cfg.embedColor = CORES_MAP[val] ?? cfg.embedColor;
    const nome = CORES.find((c) => c.value === val)?.label ?? val;
    persistir();
    await interaction.deferUpdate();
    await interaction.editReply(painelCorEmbeds(guildId, `Cor alterada com sucesso para ${nome}.`));
    return true;
  }

  // ── Select: QR Code Menu ──────────────────────────────────────────────────
  if (interaction.isStringSelectMenu() && id === 'conf:qr_menu') {
    const val = interaction.values[0];
    if (val === 'cor_central') { await interaction.showModal(modalQRCentral()); return true; }
    if (val === 'cor_borda')   { await interaction.showModal(modalQRBorda());   return true; }

    return true;
  }

  // ── Botão: Alternar Mediação ───────────────────────────────────────────────
  if (interaction.isButton() && id === 'conf:mediacao_toggle') {
    const cfg     = getConfig(guildId);
    cfg.mediationMode = cfg.mediationMode === 'rodizio' ? 'mediou_saiu' : 'rodizio';
    const novoModo    = cfg.mediationMode === 'rodizio' ? 'Rodízio' : 'Mediou Saiu';
    persistir();
    await interaction.deferUpdate();
    await interaction.editReply(painelMediacao(guildId, `Modo de mediação alterado com sucesso para ${novoModo}.`));
    return true;
  }

  // ── Modal: Taxa ───────────────────────────────────────────────────────────
  if (interaction.isModalSubmit() && id === 'conf:modal_taxa') {
    const cfg  = getConfig(guildId);
    cfg.taxa   = interaction.fields.getTextInputValue('taxa_valor');
    persistir();
    await interaction.deferUpdate();
    await interaction.editReply(painelFilas(guildId, `Taxa configurada com sucesso: ${cfg.taxa}`));
    return true;
  }

  // ── Modal: Tempo de Inatividade ───────────────────────────────────────────
  if (interaction.isModalSubmit() && id === 'conf:modal_inatividade') {
    const cfg = getConfig(guildId);
    const raw = interaction.fields.getTextInputValue('inatividade_minutos').trim();
    const minutos = Number.parseInt(raw, 10);
    if (!Number.isFinite(minutos) || minutos <= 0) {
      cfg.tempoInatividade = null;
      persistir();
      await interaction.deferUpdate();
      await interaction.editReply(painelFilas(guildId, 'Tempo de inatividade desativado com sucesso.'));
      return true;
    }
    cfg.tempoInatividade = minutos;
    persistir();
    await interaction.deferUpdate();
    await interaction.editReply(painelFilas(guildId, `Tempo de inatividade configurado para ${minutos} minuto(s).`));
    return true;
  }

  // ── Modal: Avisos ─────────────────────────────────────────────────────────
  if (interaction.isModalSubmit() && id === 'conf:modal_avisos') {
    const cfg   = getConfig(guildId);
    cfg.avisos  = interaction.fields.getTextInputValue('aviso_texto');
    persistir();
    await interaction.deferUpdate();
    await interaction.editReply(painelAvisos(guildId, 'Mensagem de aviso configurada com sucesso.'));
    return true;
  }

  // ── Modal: QR Cor Central ─────────────────────────────────────────────────
  if (interaction.isModalSubmit() && id === 'conf:modal_qr_central') {
    const cfg             = getConfig(guildId);
    cfg.qrCode.corCentral = interaction.fields.getTextInputValue('cor_central');
    persistir();
    await interaction.deferUpdate();
    await interaction.editReply(painelQRCode(guildId, `Cor dos pontos centrais atualizada para: ${cfg.qrCode.corCentral}.`));
    return true;
  }

  // ── Modal: QR Cor Borda ───────────────────────────────────────────────────
  if (interaction.isModalSubmit() && id === 'conf:modal_qr_borda') {
    const cfg           = getConfig(guildId);
    cfg.qrCode.corBorda = interaction.fields.getTextInputValue('cor_borda');
    persistir();
    await interaction.deferUpdate();
    await interaction.editReply(painelQRCode(guildId, `Cor da borda/quadrados atualizada para: ${cfg.qrCode.corBorda}.`));
    return true;
  }

  return false;
}

// ─── Exportar ─────────────────────────────────────────────────────────────────
module.exports = { handleConfigurar, getConfig, updateConfig, salvarConfiguracoesLoja, painelPrincipal };
