'use strict';

const fs = require('fs');
const path = require('path');
const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  UserSelectMenuBuilder,
  ContainerBuilder,
  TextDisplayBuilder,
  MediaGalleryBuilder,
  MediaGalleryItemBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  LabelBuilder,
  FileUploadBuilder,
  MessageFlags,
  PermissionFlagsBits,
} = require('discord.js');

const { dataPath } = require('./data-path');
const { stripEmoji } = require('./visual');
const { getConfig } = require('./configurar');
const { createCanvas, loadImage } = require('@napi-rs/canvas');

const EXPOSED_DATA_FILE = dataPath('exposed_data.json');
const BLACKLIST_DATA_FILE = dataPath('blacklist_data.json');

// Sessoes ativas de preparacao: chave = `${guildId}:${userId}`
const sessoesAtivas = new Map();

function lerDadosExposed() {
  try {
    if (fs.existsSync(EXPOSED_DATA_FILE)) {
      const raw = fs.readFileSync(EXPOSED_DATA_FILE, 'utf8').trim();
      if (raw) return JSON.parse(raw);
    }
  } catch (err) {
    console.error('[EXPOSED] Erro ao ler exposed_data.json:', err.message);
  }
  return {};
}

function salvarDadosExposed(dados, guildId = null) {
  try {
    const dir = path.dirname(EXPOSED_DATA_FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    const tmp = EXPOSED_DATA_FILE + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(dados, null, 2), 'utf8');
    fs.renameSync(tmp, EXPOSED_DATA_FILE);
    try {
      const { agendarSincronizacao } = require('./sincronizar_paineis');
      agendarSincronizacao(null, guildId);
    } catch (_) {}
  } catch (err) {
    console.error('[EXPOSED] Erro ao salvar exposed_data.json:', err.message);
  }
}

function registrarNaBlacklist(guildId, targetUserId, targetUserTag, idFreefire, motivo, autorId) {
  try {
    let blData = {};
    if (fs.existsSync(BLACKLIST_DATA_FILE)) {
      const raw = fs.readFileSync(BLACKLIST_DATA_FILE, 'utf8').trim();
      if (raw) blData = JSON.parse(raw);
    }
    if (!blData[guildId]) {
      blData[guildId] = {
        channelId: null,
        messageId: null,
        titulo: 'PAINEL DE BLACKLIST',
        descricao:
          'Sistema de verificacao e consulta de contas Free Fire em tempo real. ' +
          'Utilize os botoes abaixo para consultar o status de um jogador ou visualizar a lista de registros de seguranca.',
        thumbnail: null,
        banner: null,
        jogadores: [],
      };
    }
    if (!Array.isArray(blData[guildId].jogadores)) {
      blData[guildId].jogadores = [];
    }

    const agora = new Date().toISOString();
    const jaExiste = blData[guildId].jogadores.some(
      (j) => (targetUserId && j.discordId === targetUserId) || (idFreefire && j.id === idFreefire)
    );

    if (!jaExiste) {
      blData[guildId].jogadores.push({
        id: idFreefire || targetUserId,
        discordId: targetUserId || null,
        nome: targetUserTag || 'Membro Suspeito',
        motivo: stripEmoji(motivo || 'Exposed registrado'),
        autorId: autorId || null,
        adicionadoEm: agora,
        tipo: 'exposed',
      });
      const tmp = BLACKLIST_DATA_FILE + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify(blData, null, 2), 'utf8');
      fs.renameSync(tmp, BLACKLIST_DATA_FILE);
      console.log(`[EXPOSED] Registro sincronizado com a blacklist da guild ${guildId}.`);
    }
  } catch (err) {
    console.error('[EXPOSED] Falha ao sincronizar com blacklist:', err.message);
  }
}

function extrairUrlsImagens(texto, arrayUrls = []) {
  const result = [];
  if (Array.isArray(arrayUrls)) {
    for (const u of arrayUrls) {
      if (typeof u === 'string' && u.startsWith('http')) result.push(u);
    }
  }
  if (typeof texto === 'string') {
    const urlRegex = /(https?:\/\/[^\s<]+[^<.,:;"')\]\s])/gi;
    const matches = texto.match(urlRegex) || [];
    for (const url of matches) {
      const limpo = url.trim().replace(/^<|>$/g, '');
      if (
        /\.(png|jpe?g|webp|gif)(\?.*)?$/i.test(limpo) ||
        limpo.includes('cdn.discordapp.com') ||
        limpo.includes('media.discordapp.net') ||
        limpo.includes('imgur.com')
      ) {
        result.push(limpo);
      }
    }
  }
  return [...new Set(result)];
}

function formatarDataHora(data = new Date()) {
  return data.toLocaleString('pt-BR', {
    timeZone: 'America/Sao_Paulo',
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });
}

function obterSessao(guildId, userId) {
  const chave = `${guildId}:${userId}`;
  if (!sessoesAtivas.has(chave)) {
    sessoesAtivas.set(chave, {
      targetUserId: null,
      targetUserTag: null,
      motivo: '',
      prints: '',
      printsUrls: [],
      idFreefire: '',
      statusMensagem: null,
    });
  }
  return sessoesAtivas.get(chave);
}

function limparSessao(guildId, userId) {
  const chave = `${guildId}:${userId}`;
  sessoesAtivas.delete(chave);
}

function criarModalDados(sessao) {
  const modal = new ModalBuilder()
    .setCustomId('exposed:modal_submit')
    .setTitle('DADOS DO EXPOSED');

  const inputMotivo = new TextInputBuilder()
    .setCustomId('motivo')
    .setStyle(TextInputStyle.Paragraph)
    .setPlaceholder('Descreva detalhadamente o motivo do exposed...')
    .setMaxLength(1000)
    .setRequired(true);

  if (sessao?.motivo) inputMotivo.setValue(sessao.motivo);

  const labelMotivo = new LabelBuilder()
    .setLabel('Motivo do exposed')
    .setDescription('Descreva detalhadamente o motivo do exposed')
    .setTextInputComponent(inputMotivo);

  const temPrintsSalvos = Boolean((sessao?.printsUrls && sessao.printsUrls.length > 0) || sessao?.prints);

  const fileUpload = new FileUploadBuilder()
    .setCustomId('prints')
    .setMinValues(1)
    .setMaxValues(10)
    .setRequired(!temPrintsSalvos);

  const labelPrints = new LabelBuilder()
    .setLabel('Provas e Prints (Fotos/Arquivos)')
    .setDescription(temPrintsSalvos ? 'Anexe novas fotos ou mantenha as atuais' : 'Anexe fotos ou prints diretamente dos seus arquivos')
    .setFileUploadComponent(fileUpload);

  const inputIdFF = new TextInputBuilder()
    .setCustomId('id_freefire')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('Ex: 123456789 (deixe vazio se nao souber)')
    .setMaxLength(64)
    .setRequired(false);

  if (sessao?.idFreefire) inputIdFF.setValue(sessao.idFreefire);

  const labelIdFF = new LabelBuilder()
    .setLabel('ID da conta no Free Fire (opcional)')
    .setDescription('Opcional')
    .setTextInputComponent(inputIdFF);

  modal.addLabelComponents(labelMotivo, labelPrints, labelIdFF);

  return modal;
}

function construirPainelHistoricoExposed(guildId, analistaId, pagina = 1) {
  const dados = lerDadosExposed();
  const todosGuild = Array.isArray(dados[guildId]) ? dados[guildId] : [];
  
  const registros = analistaId
    ? todosGuild.filter((r) => r.autorId === analistaId)
    : todosGuild;

  // Ordena pelos mais recentes
  registros.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));

  const total = registros.length;
  const porPagina = 3;
  const totalPaginas = Math.max(1, Math.ceil(total / porPagina));
  const paginaAtual = Math.min(Math.max(1, pagina), totalPaginas);
  const inicio = (paginaAtual - 1) * porPagina;
  const itens = registros.slice(inicio, inicio + porPagina);

  let corpo =
    '# HISTÓRICO DE EXPOSEDS\n' +
    `**Analista:** <@${analistaId}>\n` +
    `**Total Registrado:** ${total} exposed(s)\n` +
    `**Página:** ${paginaAtual}/${totalPaginas}\n`;

  if (total === 0) {
    corpo += '\nNenhum exposed registrado por este analista até o momento.';
  } else {
    corpo += '\n';
    itens.forEach((reg, idx) => {
      const num = total - (inicio + idx);
      const dataHora = reg.dataHora || formatarDataHora(new Date(reg.timestamp || Date.now()));
      const idFf = reg.idFreefire ? reg.idFreefire : 'Não informado';
      corpo +=
        `**[Registro #${num}]**\n` +
        `\`Jogador\` -> <@${reg.targetUserId}>\n` +
        `\`ID no free fire\` -> ${idFf}\n` +
        `\`Motivo\` -> ${reg.motivo}\n` +
        `\`Data e hora\` -> ${dataHora}\n` +
        '\n';
    });
  }

  const container = new ContainerBuilder()
    .setAccentColor(0x5865F2)
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(corpo.trim()));

  const selectAnalista = new UserSelectMenuBuilder()
    .setCustomId('exposed:hist_select')
    .setPlaceholder('Filtrar histórico por outro analista')
    .setMinValues(1)
    .setMaxValues(1);

  container.addActionRowComponents(new ActionRowBuilder().addComponents(selectAnalista));

  const btnPrev = new ButtonBuilder()
    .setCustomId(`exposed:hist_prev:${analistaId}:${paginaAtual}`)
    .setLabel('Anterior')
    .setStyle(ButtonStyle.Secondary)
    .setDisabled(paginaAtual <= 1);

  const btnPagina = new ButtonBuilder()
    .setCustomId(`exposed:hist_num:${analistaId}:${paginaAtual}`)
    .setLabel(`${paginaAtual}/${totalPaginas}`)
    .setStyle(ButtonStyle.Secondary)
    .setDisabled(true);

  const btnNext = new ButtonBuilder()
    .setCustomId(`exposed:hist_next:${analistaId}:${paginaAtual}`)
    .setLabel('Próximo')
    .setStyle(ButtonStyle.Secondary)
    .setDisabled(paginaAtual >= totalPaginas);

  const btnAtualizar = new ButtonBuilder()
    .setCustomId(`exposed:hist_refresh:${analistaId}:${paginaAtual}`)
    .setLabel('Atualizar')
    .setStyle(ButtonStyle.Primary);

  container.addActionRowComponents(
    new ActionRowBuilder().addComponents(btnPrev, btnPagina, btnNext, btnAtualizar)
  );

  return {
    components: [container],
    flags: MessageFlags.IsComponentsV2,
  };
}

function construirPainelSelecaoMembro(guildId) {
  const cfg = getConfig(guildId);
  const canalExposedId = cfg.channels?.exposed;
  const canalTexto = canalExposedId ? `<#${canalExposedId}>` : 'Canal atual (configure em /configurar -> Filas -> Canais)';

  const corpo =
    '## REGISTRO DE EXPOSED\n' +
    'Selecione o membro no menu abaixo para iniciar o registro de exposed.\n\n' +
    '**Canal Oficial de Destino**\n' +
    `${canalTexto}`;

  const container = new ContainerBuilder()
    .setAccentColor(cfg.embedColor || 0x5865F2)
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(corpo));

  const selectMembro = new UserSelectMenuBuilder()
    .setCustomId('exposed:select_membro')
    .setPlaceholder('Selecione o membro para registrar exposed')
    .setMinValues(1)
    .setMaxValues(1);

  const rowSelect = new ActionRowBuilder().addComponents(selectMembro);
  container.addActionRowComponents(rowSelect);

  return {
    components: [container],
    flags: MessageFlags.IsComponentsV2,
  };
}

/**
 * Adapta e redimensiona a imagem para um tamanho pequeno e compacto no rodapé da mensagem
 * (evitando que a imagem ocupe a tela inteira de forma gigante, sem usar thumbnail).
 */
async function adaptarImagemParaTamanhoPequeno(urlOuBuffer, maxLargura = 360, maxAltura = 220) {
  try {
    let buf = urlOuBuffer;
    if (typeof urlOuBuffer === 'string' && urlOuBuffer.startsWith('http')) {
      const res = await fetch(urlOuBuffer, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) DiscordBot',
        },
        signal: AbortSignal.timeout(8000),
      });
      if (!res.ok) return null;
      const arrayBuffer = await res.arrayBuffer();
      buf = Buffer.from(arrayBuffer);
    }
    if (!buf) return null;

    const img = await loadImage(buf);
    if (!img.width || !img.height) return null;

    // Calcula a proporção mantendo o aspect ratio, limitado a no máximo 360x220
    const scale = Math.min(maxLargura / img.width, maxAltura / img.height, 1);
    const targetW = Math.max(1, Math.round(img.width * scale));
    const targetH = Math.max(1, Math.round(img.height * scale));

    const canvas = createCanvas(targetW, targetH);
    const ctx = canvas.getContext('2d');
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';

    // Arredondamento suave de cantos (6px) para acabamento profissional
    const r = Math.min(6, Math.floor(targetW / 8), Math.floor(targetH / 8));
    if (r > 0) {
      ctx.beginPath();
      if (typeof ctx.roundRect === 'function') {
        ctx.roundRect(0, 0, targetW, targetH, r);
      } else {
        ctx.moveTo(r, 0);
        ctx.lineTo(targetW - r, 0);
        ctx.quadraticCurveTo(targetW, 0, targetW, r);
        ctx.lineTo(targetW, targetH - r);
        ctx.quadraticCurveTo(targetW, targetH, targetW - r, targetH);
        ctx.lineTo(r, targetH);
        ctx.quadraticCurveTo(0, targetH, 0, targetH - r);
        ctx.lineTo(0, r);
        ctx.quadraticCurveTo(0, 0, r, 0);
        ctx.closePath();
      }
      ctx.clip();
    }

    ctx.drawImage(img, 0, 0, targetW, targetH);
    return canvas.toBuffer('image/png');
  } catch (err) {
    console.warn('[EXPOSED] Falha ao adaptar tamanho da imagem:', err.message);
    return null;
  }
}

async function construirPainelConfirmacao(guildId, sessao, statusExtra = null, autorId = null) {
  const cfg = getConfig(guildId);
  const canalExposedId = cfg.channels?.exposed;
  const canalTexto = canalExposedId ? `<#${canalExposedId}>` : 'Canal atual (configure em /configurar -> Filas -> Canais)';

  const analistaTexto = autorId ? `<@${autorId}>` : 'Você';
  const membroTexto = sessao?.targetUserId ? `<@${sessao.targetUserId}>` : 'Nenhum membro selecionado';
  const motivoTexto = sessao?.motivo ? sessao.motivo : 'Não informado';
  const idFfTexto = sessao?.idFreefire ? sessao.idFreefire : 'Não informado';
  const dataFormatada = formatarDataHora();

  let corpo =
    '# NOVO EXPOSED (PRÉVIA)\n' +
    '**Informações**\n' +
    `\`Analista\` -> ${analistaTexto}\n` +
    `\`Jogador\` -> ${membroTexto}\n` +
    `\`ID no free fire\` -> ${idFfTexto}\n` +
    `\`Motivo\` -> ${motivoTexto}\n` +
    `\`Data e hora\` -> ${dataFormatada}\n` +
    `*Canal de envio oficial:* ${canalTexto}`;

  if (statusExtra) {
    corpo += `\n**Aviso:** ${stripEmoji(statusExtra)}`;
  }

  const container = new ContainerBuilder()
    .setAccentColor(cfg.embedColor || 0x5865F2)
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(corpo));

  const urlsImagens = extrairUrlsImagens(sessao?.prints, sessao?.printsUrls);
  const files = [];

  if (urlsImagens.length > 0) {
    const galleryItems = [];
    for (let i = 0; i < urlsImagens.length && i < 4; i++) {
      const url = urlsImagens[i];
      const bufferCompacto = await adaptarImagemParaTamanhoPequeno(url, 360, 220);
      if (bufferCompacto) {
        const nomeArquivo = `prova_previa_${i + 1}.png`;
        files.push({ attachment: bufferCompacto, name: nomeArquivo });
        galleryItems.push(new MediaGalleryItemBuilder().setURL(`attachment://${nomeArquivo}`));
      } else {
        galleryItems.push(new MediaGalleryItemBuilder().setURL(url));
      }
    }
    if (galleryItems.length > 0) {
      container.addMediaGalleryComponents(
        new MediaGalleryBuilder().addItems(...galleryItems)
      );
    }
  }

  // 3 botoes: Voltar (cinza), Editar (azul) e Enviar (vermelho/perigo)
  const btnVoltar = new ButtonBuilder()
    .setCustomId('exposed:voltar')
    .setLabel('Voltar')
    .setStyle(ButtonStyle.Secondary);

  const btnEditar = new ButtonBuilder()
    .setCustomId('exposed:editar')
    .setLabel('Editar')
    .setStyle(ButtonStyle.Primary);

  const btnEnviar = new ButtonBuilder()
    .setCustomId('exposed:enviar')
    .setLabel('Enviar')
    .setStyle(ButtonStyle.Danger);

  const rowBotoes = new ActionRowBuilder().addComponents(btnVoltar, btnEditar, btnEnviar);
  container.addActionRowComponents(rowBotoes);

  const payload = {
    components: [container],
    flags: MessageFlags.IsComponentsV2,
  };
  if (files.length > 0) {
    payload.files = files;
  }
  return payload;
}

async function construirPainelOficialExposed(guildId, registro) {
  const cfg = getConfig(guildId);
  const dataFormatada = registro.dataHora || formatarDataHora(new Date(registro.timestamp || Date.now()));
  const idTexto = registro.idFreefire ? registro.idFreefire : 'Não informado';

  const corpo =
    '# NOVO EXPOSED\n' +
    '**Informações**\n' +
    `\`Analista\` -> <@${registro.autorId}>\n` +
    `\`Jogador\` -> <@${registro.targetUserId}>\n` +
    `\`ID no free fire\` -> ${idTexto}\n` +
    `\`Motivo\` -> ${registro.motivo}\n` +
    `\`Data e hora\` -> ${dataFormatada}`;

  const container = new ContainerBuilder()
    .setAccentColor(cfg.embedColor || 0xE74C3C)
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(corpo));

  const urlsImagens = extrairUrlsImagens(registro.prints, registro.printsUrls);
  const files = [];

  if (urlsImagens.length > 0) {
    const galleryItems = [];
    for (let i = 0; i < urlsImagens.length && i < 4; i++) {
      const url = urlsImagens[i];
      const bufferCompacto = await adaptarImagemParaTamanhoPequeno(url, 360, 220);
      if (bufferCompacto) {
        const nomeArquivo = `prova_${i + 1}.png`;
        files.push({ attachment: bufferCompacto, name: nomeArquivo });
        galleryItems.push(new MediaGalleryItemBuilder().setURL(`attachment://${nomeArquivo}`));
      } else {
        galleryItems.push(new MediaGalleryItemBuilder().setURL(url));
      }
    }
    if (galleryItems.length > 0) {
      container.addMediaGalleryComponents(
        new MediaGalleryBuilder().addItems(...galleryItems)
      );
    }
  }

  const payload = {
    components: [container],
    flags: MessageFlags.IsComponentsV2,
    allowedMentions: { users: [registro.targetUserId, registro.autorId] },
  };
  if (files.length > 0) {
    payload.files = files;
  }
  return payload;
}

async function handleRegistrar(interaction, client) {
  const guildId = interaction.guildId;
  if (!guildId) return false;

  // Validacao de permissao
  const isAdministrator = interaction.memberPermissions?.has(PermissionFlagsBits.Administrator);
  const cfg = getConfig(guildId);
  const roleAdminId = cfg.roles?.admin;
  const hasAdminRole = roleAdminId && interaction.member?.roles?.cache?.has(roleAdminId);

  if (!isAdministrator && !hasAdminRole) {
    const semPermissaoMsg = {
      content: 'Apenas administradores podem utilizar os comandos de registro.',
      flags: MessageFlags.Ephemeral,
    };
    if (interaction.deferred || interaction.replied) {
      await interaction.followUp(semPermissaoMsg);
    } else {
      await interaction.reply(semPermissaoMsg);
    }
    return true;
  }

  // Comando de barra: /exposed registrar e /exposed historico
  if (interaction.isChatInputCommand() && interaction.commandName === 'exposed') {
    const sub = interaction.options?.getSubcommand?.(false);
    if (sub === 'historico') {
      const targetAnalista = interaction.options.getUser('analista') || interaction.user;
      const payload = construirPainelHistoricoExposed(guildId, targetAnalista.id, 1);
      await interaction.reply({
        ephemeral: true,
        ...payload,
      });
      return true;
    }

    if (sub === 'registrar' || !sub) {
      limparSessao(guildId, interaction.user.id);
      const payload = construirPainelSelecaoMembro(guildId);
      await interaction.reply({
        ephemeral: true,
        ...payload,
      });
      return true;
    }
    return false;
  }

  const customId = interaction.customId || '';
  if (!customId.startsWith('exposed:')) return false;

  // Interações do Painel de Histórico
  if (interaction.isUserSelectMenu() && customId === 'exposed:hist_select') {
    const selectedUserId = interaction.values[0];
    if (selectedUserId) {
      await interaction.deferUpdate();
      const payload = construirPainelHistoricoExposed(guildId, selectedUserId, 1);
      await interaction.editReply(payload);
      return true;
    }
  }

  if (interaction.isButton() && customId.startsWith('exposed:hist_prev:')) {
    const [, , analistaId, pagStr] = customId.split(':');
    const targetAnalistaId = analistaId === 'all' ? null : analistaId;
    const pag = Math.max(1, (parseInt(pagStr, 10) || 1) - 1);
    await interaction.deferUpdate();
    const payload = construirPainelHistoricoExposed(guildId, targetAnalistaId, pag);
    await interaction.editReply(payload);
    return true;
  }

  if (interaction.isButton() && customId.startsWith('exposed:hist_next:')) {
    const [, , analistaId, pagStr] = customId.split(':');
    const targetAnalistaId = analistaId === 'all' ? null : analistaId;
    const pag = (parseInt(pagStr, 10) || 1) + 1;
    await interaction.deferUpdate();
    const payload = construirPainelHistoricoExposed(guildId, targetAnalistaId, pag);
    await interaction.editReply(payload);
    return true;
  }

  if (interaction.isButton() && customId.startsWith('exposed:hist_refresh:')) {
    const [, , analistaId, pagStr] = customId.split(':');
    const targetAnalistaId = analistaId === 'all' ? null : analistaId;
    const pag = parseInt(pagStr, 10) || 1;
    await interaction.deferUpdate();
    const payload = construirPainelHistoricoExposed(guildId, targetAnalistaId, pag);
    await interaction.editReply(payload);
    return true;
  }

  const sessao = obterSessao(guildId, interaction.user.id);

  // Selecao de membro no UserSelectMenu -> Abre o modal imediatamente
  if (interaction.isUserSelectMenu() && customId === 'exposed:select_membro') {
    const selectedUserId = interaction.values[0];
    if (selectedUserId) {
      sessao.targetUserId = selectedUserId;
      const targetUser = await client.users.fetch(selectedUserId).catch(() => null);
      sessao.targetUserTag = targetUser ? (targetUser.tag || targetUser.username) : selectedUserId;
    }

    const modal = criarModalDados(sessao);
    await interaction.showModal(modal);
    return true;
  }

  // Recebimento dos dados do modal -> Mostra painel de confirmacao com botoes Voltar e Enviar
  if (interaction.isModalSubmit() && customId === 'exposed:modal_submit') {
    const motivo = stripEmoji(interaction.fields.getTextInputValue('motivo') || '').trim();
    let idFreefire = '';
    try {
      idFreefire = stripEmoji(interaction.fields.getTextInputValue('id_freefire') || '').trim();
    } catch (_) {}

    let urlsArquivos = [];
    try {
      const uploaded = interaction.fields.getUploadedFiles('prints', false);
      if (uploaded) {
        if (Array.isArray(uploaded)) {
          urlsArquivos = uploaded.map((f) => f.url || f.proxyURL || f.name).filter(Boolean);
        } else if (typeof uploaded.values === 'function') {
          urlsArquivos = Array.from(uploaded.values()).map((f) => f.url || f.proxyURL || f.name).filter(Boolean);
        }
      }
    } catch (_) {}

    if (urlsArquivos.length === 0 && interaction.data?.resolved?.attachments) {
      urlsArquivos = Object.values(interaction.data.resolved.attachments).map((a) => a.url).filter(Boolean);
    }

    if (urlsArquivos.length === 0) {
      try {
        const txt = interaction.fields.getTextInputValue('prints');
        if (txt) urlsArquivos = extrairUrlsImagens(txt);
      } catch (_) {}
    }

    if (urlsArquivos.length > 0) {
      sessao.prints = urlsArquivos.join('\n');
      sessao.printsUrls = urlsArquivos;
    } else if (!sessao.prints) {
      sessao.prints = 'Fotos/prints de provas anexados';
    }

    sessao.motivo = motivo;
    sessao.idFreefire = idFreefire;

    await interaction.deferUpdate();
    const payload = await construirPainelConfirmacao(guildId, sessao, null, interaction.user.id);
    await interaction.editReply(payload);
    return true;
  }

  // Botao Editar -> Reabre o modal com os dados atuais preenchidos
  if (interaction.isButton() && customId === 'exposed:editar') {
    const modal = criarModalDados(sessao);
    await interaction.showModal(modal);
    return true;
  }

  // Botao Voltar -> Retorna ao painel de selecao de membro
  if (interaction.isButton() && customId === 'exposed:voltar') {
    limparSessao(guildId, interaction.user.id);
    await interaction.deferUpdate();
    const payload = construirPainelSelecaoMembro(guildId);
    await interaction.editReply(payload);
    return true;
  }

  // Botao Enviar -> Publica no canal configurado, expulsa e bane o jogador
  if (interaction.isButton() && customId === 'exposed:enviar') {
    if (!sessao.targetUserId) {
      await interaction.reply({
        content: 'Selecione um membro antes de enviar o exposed.',
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    if (!sessao.motivo || !sessao.prints) {
      await interaction.reply({
        content: 'Preencha o motivo e as provas antes de enviar o exposed.',
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    await interaction.deferUpdate();

    const targetUserId = sessao.targetUserId;
    const targetUserTag = sessao.targetUserTag || targetUserId;
    const motivo = sessao.motivo;
    const prints = sessao.prints;
    const idFreefire = sessao.idFreefire || '';
    const autorId = interaction.user.id;
    const timestamp = Date.now();
    const dataHora = formatarDataHora(new Date(timestamp));

    // Determina o canal de envio
    const targetChannelId = cfg.channels?.exposed || interaction.channelId;
    const targetChannel = interaction.guild?.channels?.cache?.get(targetChannelId) ||
      (await interaction.guild?.channels?.fetch(targetChannelId).catch(() => null));

    if (!targetChannel || !targetChannel.isTextBased?.()) {
      const payload = await construirPainelConfirmacao(guildId, sessao, 'Erro: Canal de destino nao encontrado ou invalido.', autorId);
      await interaction.editReply(payload);
      return true;
    }

    // Executa banimento e expulsao automatica
    let banStatus = 'Banimento aplicado com sucesso.';
    try {
      await interaction.guild.members.ban(targetUserId, {
        reason: `Exposed registrado por ${interaction.user.tag || interaction.user.id}: ${motivo.slice(0, 400)}`,
        deleteMessageSeconds: 0,
      });
    } catch (banErr) {
      console.warn(`[EXPOSED] Falha ao banir membro ${targetUserId}:`, banErr.message);
      banStatus = `Aviso: Nao foi possivel banir o membro automaticamente (${banErr.message}). O painel foi publicado normalmente.`;
    }

    // Monta o payload oficial
    const registro = {
      guildId,
      targetUserId,
      targetUserTag,
      idFreefire,
      motivo,
      prints,
      printsUrls: sessao.printsUrls || [],
      autorId,
      timestamp,
      dataHora,
    };

    const painelOficial = await construirPainelOficialExposed(guildId, registro);
    let msgPublicada = null;
    try {
      msgPublicada = await targetChannel.send(painelOficial);
      registro.messageId = msgPublicada?.id;
      registro.channelId = targetChannel.id;
    } catch (sendErr) {
      console.error('[EXPOSED] Falha ao enviar painel oficial:', sendErr.message);
      const payload = await construirPainelConfirmacao(guildId, sessao, `Falha ao enviar mensagem no canal: ${sendErr.message}`, autorId);
      await interaction.editReply(payload);
      return true;
    }

    // Persiste no banco de exposed
    const dados = lerDadosExposed();
    if (!dados[guildId]) dados[guildId] = [];
    dados[guildId].push(registro);
    salvarDadosExposed(dados);

    // Sincroniza com o modulo de blacklist
    registrarNaBlacklist(guildId, targetUserId, targetUserTag, idFreefire, motivo, autorId);

    // Limpa a sessao
    limparSessao(guildId, interaction.user.id);

    // Atualiza a resposta para o moderador
    const containerSucesso = new ContainerBuilder()
      .setAccentColor(0x2ECC71)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(
          '## EXPOSED REGISTRADO COM SUCESSO\n' +
          `O painel oficial de exposed foi publicado no canal <#${targetChannel.id}>.\n` +
          `**Jogador:** <@${targetUserId}>\n` +
          `**Status:** ${banStatus}\n` +
          `**Data:** ${dataHora}`
        )
      );

    await interaction.editReply({
      components: [containerSucesso],
      flags: MessageFlags.IsComponentsV2,
    });

    return true;
  }

  return false;
}

// Rotina de restauracao e auto-refresh dos paineis de exposed
async function restaurarPaineisExposed(client, targetGuildId = null) {
  try {
    const dados = lerDadosExposed();
    for (const [guildId, lista] of Object.entries(dados)) {
      if (targetGuildId && guildId !== targetGuildId) continue;
      if (!Array.isArray(lista)) continue;
      const guild = client.guilds.cache.get(guildId);
      if (!guild) continue;

      for (const registro of lista) {
        if (!registro.channelId || !registro.messageId) continue;
        try {
          const channel = guild.channels.cache.get(registro.channelId) ||
            (await guild.channels.fetch(registro.channelId).catch(() => null));
          if (!channel?.messages?.fetch) continue;

          const msg = await channel.messages.fetch(registro.messageId).catch(() => null);
          if (msg && msg.author?.id === client.user.id) {
            const payload = await construirPainelOficialExposed(guildId, registro);
            await msg.edit(payload).catch(() => {});
          }
        } catch (_) {}
      }
    }
  } catch (err) {
    console.error('[EXPOSED] Erro ao restaurar paineis exposed:', err.message);
  }
}

module.exports = {
  handleRegistrar,
  handleExposed: handleRegistrar,
  restaurarPaineisExposed,
  construirPainelOficialExposed,
  construirPainelSelecaoMembro,
  construirPainelConfirmacao,
  construirPainelHistoricoExposed,
};
