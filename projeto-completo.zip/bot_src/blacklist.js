'use strict';

const fs = require('fs');
const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  UserSelectMenuBuilder,
  ContainerBuilder,
  TextDisplayBuilder,
  MediaGalleryBuilder,
  MediaGalleryItemBuilder,
  MessageFlags,
  PermissionFlagsBits,
} = require('discord.js');
const http = require('http');
const { createCanvas, loadImage } = require('@napi-rs/canvas');
const { painelV2FromEmbed, avatarDoServidor } = require('./visual');
const { dataPath } = require('./data-path');

const DATA_FILE = dataPath('blacklist_data.json');
const CACHE_FILE = dataPath('blacklist_lookup_cache.json');
const state = readData();
const CONSULTA_CACHE_TTL = 12 * 60 * 60 * 1000; // 12 horas de cache para respostas rápidas
const consultaCache = new Map();
const consultasEmAndamento = new Map();
const paineisConfigOrigem = new Map();

// HTTP Agent com Keep-Alive para reuso de sockets e latência mínima
const httpAgent = new http.Agent({
  keepAlive: true,
  keepAliveMsecs: 60000,
  maxSockets: 50,
  timeout: 6000,
});

// Carrega cache persistente do disco na inicialização
(() => {
  try {
    if (fs.existsSync(CACHE_FILE)) {
      const raw = JSON.parse(fs.readFileSync(CACHE_FILE, 'utf8'));
      const now = Date.now();
      for (const [k, v] of Object.entries(raw)) {
        if (v && v.timestamp && now - v.timestamp < CONSULTA_CACHE_TTL) {
          consultaCache.set(k, v);
        }
      }
    }
  } catch (_) {}
})();

function salvarCacheEmDisco() {
  try {
    const obj = {};
    const now = Date.now();
    for (const [k, v] of consultaCache.entries()) {
      if (v && v.timestamp && now - v.timestamp < CONSULTA_CACHE_TTL) {
        obj[k] = v;
      }
    }
    fs.writeFileSync(CACHE_FILE, JSON.stringify(obj), 'utf8');
  } catch (_) {}
}

function readData() {
  try {
    return fs.existsSync(DATA_FILE) ? JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')) : {};
  } catch (error) {
    console.error('[BLACKLIST] Falha ao ler dados:', error.message);
    return {};
  }
}

let _saving = false;
let _savePending = false;
function saveData() {
  if (_saving) {
    _savePending = true;
    return;
  }
  _saving = true;
  try {
    const temp = `${DATA_FILE}.tmp`;
    fs.writeFile(temp, JSON.stringify(state, null, 2), 'utf8', (err) => {
      if (!err) {
        fs.rename(temp, DATA_FILE, () => {
          _saving = false;
          if (_savePending) {
            _savePending = false;
            saveData();
          }
        });
      } else {
        _saving = false;
      }
    });
  } catch (error) {
    _saving = false;
  }
}

function guildPanel(guildId) {
  if (!state[guildId]) {
    state[guildId] = {
      channelId: null,
      messageId: null,
      titulo: 'PAINEL DE BLACKLIST',
      descricao:
        'Sistema de verificacao e consulta de contas Free Fire em tempo real. ' +
        'Utilize os botoes abaixo para consultar o status de um jogador ou visualizar a lista de registros de seguranca.',
      thumbnail: null,
      banner: null,
      jogadores: [],
    };
  }
  const panel = state[guildId];
  if (!Object.prototype.hasOwnProperty.call(panel, 'titulo')) panel.titulo = 'PAINEL DE BLACKLIST';
  if (!Object.prototype.hasOwnProperty.call(panel, 'descricao')) {
    panel.descricao =
      'Sistema de verificacao e consulta de contas Free Fire em tempo real. ' +
      'Utilize os botoes abaixo para consultar o status de um jogador ou visualizar a lista de registros de seguranca.';
  }
  if (!Object.prototype.hasOwnProperty.call(panel, 'thumbnail')) panel.thumbnail = null;
  if (!Object.prototype.hasOwnProperty.call(panel, 'banner')) panel.banner = null;
  if (!Array.isArray(panel.jogadores)) panel.jogadores = [];
  return panel;
}

function getConfig(guildId) {
  try {
    return require('./configurar').getConfig(guildId) ?? {};
  } catch (_) {
    return { embedColor: 0x2f3136, roles: {} };
  }
}

function sanitizarUrl(url) {
  if (typeof url !== 'string') return null;
  const limpo = url.trim().replace(/^<|>$/g, '').trim();
  if (!limpo) return null;
  try {
    const parsed = new URL(limpo);
    if (!['http:', 'https:'].includes(parsed.protocol)) return null;
    return limpo;
  } catch (_) {
    return null;
  }
}

function _hexColor(color) {
  return `#${Number(color ?? 0x5865f2).toString(16).padStart(6, '0').slice(-6)}`;
}

function _roundRect(ctx, x, y, width, height, radius) {
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.arcTo(x + width, y, x + width, y + height, radius);
  ctx.arcTo(x + width, y + height, x, y + height, radius);
  ctx.arcTo(x, y + height, x, y, radius);
  ctx.arcTo(x, y, x + width, y, radius);
  ctx.closePath();
}

async function _carregarImagemSegura(url, timeoutMs = 4000) {
  if (!url) return null;
  try {
    const promise = loadImage(url);
    let timer;
    const timeout = new Promise((_, reject) => {
      timer = setTimeout(() => reject(new Error('Timeout')), timeoutMs);
    });
    const img = await Promise.race([promise, timeout]);
    clearTimeout(timer);
    return img;
  } catch (_) {
    return null;
  }
}

async function gerarImagemJogadoresBlacklist({ guild, jogadores, pagina, totalPaginas, totalTotal, color }) {
  const width = 1200;
  const height = 640;
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');
  const accent = _hexColor(color);

  // Fundo com gradiente no estilo do .p
  const background = ctx.createLinearGradient(0, 0, width, height);
  background.addColorStop(0, '#101827');
  background.addColorStop(1, '#172b45');
  ctx.fillStyle = background;
  ctx.fillRect(0, 0, width, height);

  // Efeito de brilho circular
  ctx.globalAlpha = 0.22;
  ctx.fillStyle = accent;
  ctx.beginPath();
  ctx.arc(width - 60, 42, 280, 0, Math.PI * 2);
  ctx.fill();
  ctx.globalAlpha = 1;

  // Moldura externa translúcida
  _roundRect(ctx, 42, 42, width - 84, height - 84, 28);
  ctx.fillStyle = 'rgba(5, 12, 24, 0.65)';
  ctx.fill();
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.12)';
  ctx.lineWidth = 2;
  ctx.stroke();

  // Barra de destaque vertical
  ctx.fillStyle = accent;
  _roundRect(ctx, 72, 70, 8, 56, 4);
  ctx.fill();

  // Título e cabeçalho
  ctx.fillStyle = '#f7fbff';
  ctx.font = '700 36px sans-serif';
  ctx.fillText('JOGADORES NA BLACKLIST', 96, 106);

  ctx.fillStyle = '#9fb2c8';
  ctx.font = '20px sans-serif';
  ctx.fillText(
    `Página ${pagina} de ${totalPaginas || 1} • ${totalTotal || 0} jogador(es) registrado(s)`,
    98,
    142,
  );

  // Badge no canto superior direito
  _roundRect(ctx, width - 266, 74, 194, 44, 12);
  ctx.fillStyle = 'rgba(239, 68, 68, 0.16)';
  ctx.fill();
  ctx.strokeStyle = '#ef4444';
  ctx.lineWidth = 1.5;
  ctx.stroke();
  ctx.fillStyle = '#fca5a5';
  ctx.font = '700 16px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('STATUS: BANIDO', width - 266 + 97, 102);
  ctx.textAlign = 'left';

  // Conteúdo dos jogadores
  if (!jogadores || jogadores.length === 0) {
    _roundRect(ctx, 72, 175, width - 144, 370, 20);
    ctx.fillStyle = 'rgba(255, 255, 255, 0.04)';
    ctx.fill();
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    ctx.fillStyle = '#f7fbff';
    ctx.font = '700 30px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('Nenhum jogador cadastrado na blacklist', width / 2, 330);

    ctx.fillStyle = '#9fb2c8';
    ctx.font = '19px sans-serif';
    ctx.fillText('Os jogadores registrados na blacklist deste servidor aparecerão listados aqui.', width / 2, 375);
    ctx.textAlign = 'left';
  } else {
    const cardW = 516;
    const cardH = 176;
    const cols = 2;

    for (let i = 0; i < jogadores.length; i++) {
      const p = jogadores[i];
      const col = i % cols;
      const row = Math.floor(i / cols);
      const cardX = 72 + col * (cardW + 24);
      const cardY = 175 + row * (cardH + 18);

      _roundRect(ctx, cardX, cardY, cardW, cardH, 18);
      ctx.fillStyle = 'rgba(255, 255, 255, 0.055)';
      ctx.fill();
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.10)';
      ctx.lineWidth = 2;
      ctx.stroke();

      const avatarCenterX = cardX + 64;
      const avatarCenterY = cardY + 70;
      const avatarRadius = 42;

      let avatarDrawn = false;
      if (p.avatarUrl) {
        const img = await _carregarImagemSegura(p.avatarUrl);
        if (img) {
          ctx.save();
          ctx.beginPath();
          ctx.arc(avatarCenterX, avatarCenterY, avatarRadius, 0, Math.PI * 2);
          ctx.clip();
          ctx.drawImage(img, avatarCenterX - avatarRadius, avatarCenterY - avatarRadius, avatarRadius * 2, avatarRadius * 2);
          ctx.restore();
          avatarDrawn = true;
        }
      }

      if (!avatarDrawn) {
        ctx.fillStyle = 'rgba(239, 68, 68, 0.2)';
        ctx.beginPath();
        ctx.arc(avatarCenterX, avatarCenterY, avatarRadius, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#fca5a5';
        ctx.font = '700 28px sans-serif';
        ctx.textAlign = 'center';
        const initial = String(p.nome || p.accountId || '?').trim().charAt(0).toUpperCase();
        ctx.fillText(initial || '?', avatarCenterX, avatarCenterY + 10);
        ctx.textAlign = 'left';
      }

      ctx.strokeStyle = '#ef4444';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(avatarCenterX, avatarCenterY, avatarRadius, 0, Math.PI * 2);
      ctx.stroke();

      const textX = cardX + 124;

      // Nome do jogador
      ctx.fillStyle = '#ffffff';
      ctx.font = '700 23px sans-serif';
      const displayName = String(p.nome || `Jogador ${p.accountId}`).slice(0, 22);
      ctx.fillText(displayName, textX, cardY + 48);

      // Badge com ID da conta Free Fire
      const idStr = `ID: ${p.accountId}`;
      _roundRect(ctx, textX, cardY + 62, 195, 32, 8);
      ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
      ctx.fill();
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.12)';
      ctx.lineWidth = 1;
      ctx.stroke();

      ctx.fillStyle = '#38bdf8';
      ctx.font = '700 16px monospace, sans-serif';
      ctx.fillText(idStr, textX + 12, cardY + 84);

      // Motivo / Tag
      ctx.fillStyle = '#f87171';
      ctx.font = '700 14px sans-serif';
      const motivo = p.motivo ? String(p.motivo).slice(0, 34) : 'Banido permanentemente';
      ctx.fillText(`• ${motivo}`, textX, cardY + 118);

      if (p.userId) {
        ctx.fillStyle = '#9fb2c8';
        ctx.font = '13px sans-serif';
        ctx.fillText(`Membro Discord: <@${p.userId}>`, textX, cardY + 142);
      } else if (p.data) {
        ctx.fillStyle = '#71859d';
        ctx.font = '13px sans-serif';
        const dateStr = new Date(p.data).toLocaleDateString('pt-BR');
        ctx.fillText(`Registrado em: ${dateStr}`, textX, cardY + 142);
      }
    }
  }

  // Rodapé removido conforme regras de layout
  return canvas.toBuffer('image/png');
}

async function montarPainelJogadoresBlacklist(guildId, guild, pagina = 1) {
  const panel = guildPanel(guildId);
  const cfg = getConfig(guildId);
  const color = cfg.embedColor || 0x2f3136;
  const jogadores = Array.isArray(panel.jogadores) ? panel.jogadores : [];
  const total = jogadores.length;
  const ITENS_POR_PAGINA = 4;
  const totalPaginas = Math.max(1, Math.ceil(total / ITENS_POR_PAGINA));
  const paginaAtual = Math.max(1, Math.min(totalPaginas, Number(pagina) || 1));

  const inicio = (paginaAtual - 1) * ITENS_POR_PAGINA;
  const paginaJogadores = jogadores.slice(inicio, inicio + ITENS_POR_PAGINA);

  const jogadoresComAvatar = await Promise.all(
    paginaJogadores.map(async (p) => {
      let avatarUrl = p.avatarUrl || null;
      let nome = p.nome;
      if (p.userId && guild) {
        const member = guild.members.cache.get(p.userId) ?? await guild.members.fetch(p.userId).catch(() => null);
        if (member) {
          avatarUrl = member.user.displayAvatarURL({ extension: 'png', size: 256 });
          nome = nome || member.displayName || member.user.username;
        }
      }
      return { ...p, avatarUrl, nome: nome || `Jogador ${p.accountId}` };
    })
  );

  const imageBuffer = await gerarImagemJogadoresBlacklist({
    guild: guild || { id: guildId },
    jogadores: jogadoresComAvatar,
    pagina: paginaAtual,
    totalPaginas,
    totalTotal: total,
    color,
  });

  const botoes = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`blacklist:jogadores_nav:${paginaAtual - 1}`)
      .setLabel('Anterior')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(paginaAtual <= 1),
    new ButtonBuilder()
      .setCustomId('blacklist:jogadores_pag')
      .setLabel(`Pagina ${paginaAtual}/${totalPaginas}`)
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(true),
    new ButtonBuilder()
      .setCustomId(`blacklist:jogadores_nav:${paginaAtual + 1}`)
      .setLabel('Proximo')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(paginaAtual >= totalPaginas),
  );

  const container = new ContainerBuilder()
    .setAccentColor(Number.isInteger(color) ? color : 0x2f3136)
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `## JOGADORES NA BLACKLIST\n\n${
          total > 0
            ? `Exibindo ${total} jogador(es) cadastrado(s) na blacklist deste servidor. Pagina ${paginaAtual} de ${totalPaginas}`
            : 'Nenhum jogador cadastrado na blacklist deste servidor no momento.'
        }`
      )
    )
    .addMediaGalleryComponents(
      new MediaGalleryBuilder().addItems(new MediaGalleryItemBuilder().setURL('attachment://blacklist-jogadores.png'))
    )
    .addActionRowComponents(botoes);

  return {
    components: [container],
    files: [{ attachment: imageBuffer, name: 'blacklist-jogadores.png' }],
    flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
  };
}

function painelBlacklist(guildId, message = null, guild = null) {
  const panel = guildPanel(guildId);
  const cfg = getConfig(guildId);
  const embed = new EmbedBuilder()
    .setColor(cfg.embedColor || 0x2f3136)
    .setTitle(panel.titulo)
    .setDescription(panel.descricao);
  if (message) embed.addFields({ name: 'Resultado', value: message, inline: false });
  
  const serverIcon = avatarDoServidor(guild);
  const thumbnail = (panel.thumbnail && typeof panel.thumbnail === 'string' && panel.thumbnail.trim())
    ? panel.thumbnail.trim()
    : (serverIcon || null);

  if (thumbnail) embed.setThumbnail(thumbnail);
  if (panel.banner) embed.setImage(panel.banner);
  return {
    ...painelV2FromEmbed(
      embed,
      [
        new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('blacklist:consultar').setLabel('Consultar').setStyle(ButtonStyle.Secondary),
          new ButtonBuilder().setCustomId('blacklist:jogadores').setLabel('Jogadores na blacklist').setStyle(ButtonStyle.Secondary),
        ),
      ],
      { thumbnail: thumbnail || undefined, image: panel.banner || undefined },
    ),
  };
}

function _textoConfiguracao(panel, guild = null) {
  const serverIcon = avatarDoServidor(guild);
  let thumbStatus = 'Nenhuma';
  if (panel.thumbnail) {
    thumbStatus = 'Configurada';
  } else if (serverIcon) {
    thumbStatus = 'Usando o ícone do servidor';
  }

  return [
    `Titulo: **${panel.titulo || 'Não configurado'}**`,
    `Descrição: **${panel.descricao || 'Não configurada'}**`,
    `Thumbnail: **${thumbStatus}**`,
    `Banner: **${panel.banner ? 'Configurado' : 'Nenhum'}**`,
  ].join('\n');
}

function painelConfiguracaoBlacklist(guildId, notice = null, guild = null) {
  const panel = guildPanel(guildId);
  const cfg = getConfig(guildId);
  const embed = new EmbedBuilder()
    .setColor(cfg.embedColor || 0x2f3136)
    .setTitle('CONFIGURAÇÃO DO PAINEL DE BLACKLIST')
    .setDescription(
      'Configure a aparência do painel antes de publicá-lo no canal atual.\n\n' +
      _textoConfiguracao(panel, guild) +
      (notice ? `\n\n**Resultado da última ação**\n${notice}` : ''),
    );
  const serverIcon = avatarDoServidor(guild);
  const thumbnail = (panel.thumbnail && typeof panel.thumbnail === 'string' && panel.thumbnail.trim())
    ? panel.thumbnail.trim()
    : (serverIcon || null);

  if (thumbnail) embed.setThumbnail(thumbnail);
  if (panel.banner) embed.setImage(panel.banner);

  return {
    ...painelV2FromEmbed(
      embed,
      [
        new ActionRowBuilder().addComponents(
          new StringSelectMenuBuilder()
            .setCustomId('blacklist:config:opcoes')
            .setPlaceholder('Selecione o que deseja configurar')
            .addOptions(
              { label: 'Título', value: 'titulo', description: 'Alterar o título do painel público' },
              { label: 'Descrição', value: 'descricao', description: 'Alterar o texto do painel público' },
              { label: 'Thumbnail', value: 'thumbnail', description: 'Alterar ou remover a imagem pequena' },
              { label: 'Banner', value: 'banner', description: 'Alterar ou remover a imagem principal' },
            ),
        ),
        new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('blacklist:config:enviar').setLabel('Enviar').setStyle(ButtonStyle.Success),
        ),
      ],
      { thumbnail: thumbnail || undefined, image: panel.banner || undefined },
    ),
    flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
  };
}

function modalConfiguracao(tipo, panel) {
  const campos = {
    titulo: {
      customId: 'blacklist:config_modal:titulo',
      title: 'Alterar título do painel',
      fieldId: 'valor',
      label: 'Título do painel',
      placeholder: 'PAINEL DE BLACKLIST',
      maxLength: 256,
      value: panel.titulo,
    },
    descricao: {
      customId: 'blacklist:config_modal:descricao',
      title: 'Alterar descrição do painel',
      fieldId: 'valor',
      label: 'Descrição do painel',
      placeholder: 'Texto exibido no painel público',
      maxLength: 4000,
      value: panel.descricao,
    },
    thumbnail: {
      customId: 'blacklist:config_modal:thumbnail',
      title: 'Alterar thumbnail do painel',
      fieldId: 'valor',
      label: 'URL da thumbnail',
      placeholder: 'URL pública direta da imagem; vazio remove',
      maxLength: 1000,
      value: panel.thumbnail || '',
      required: false,
    },
    banner: {
      customId: 'blacklist:config_modal:banner',
      title: 'Alterar banner do painel',
      fieldId: 'valor',
      label: 'URL do banner',
      placeholder: 'URL pública direta da imagem; vazio remove',
      maxLength: 1000,
      value: panel.banner || '',
      required: false,
    },
  }[tipo];

  const campo = new TextInputBuilder()
    .setCustomId(campos.fieldId)
    .setLabel(campos.label)
    .setPlaceholder(campos.placeholder)
    .setStyle(tipo === 'descricao' ? TextInputStyle.Paragraph : TextInputStyle.Short)
    .setMaxLength(campos.maxLength)
    .setRequired(campos.required !== false);
  if (campos.value) campo.setValue(campos.value);

  return new ModalBuilder()
    .setCustomId(campos.customId)
    .setTitle(campos.title)
    .addComponents(new ActionRowBuilder().addComponents(campo));
}

function chavePainelConfiguracao(guildId, userId) {
  return `${guildId}:${userId}`;
}

async function atualizarPainelConfiguracao(interaction, guildId, notice = null) {
  const origem = paineisConfigOrigem.get(chavePainelConfiguracao(guildId, interaction.user.id));
  if (!origem) return false;
  try {
    await origem.editReply(painelConfiguracaoBlacklist(guildId, notice, interaction.guild));
    return true;
  } catch (error) {
    console.error('[BLACKLIST] Falha ao atualizar painel de configuração:', error.message);
    return false;
  }
}

function modalConsultar() {
  return new ModalBuilder()
    .setCustomId('blacklist:modal_consultar')
    .setTitle('Consultar conta Free Fire')
    .addComponents(new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('uid')
        .setLabel('ID da conta Free Fire')
        .setPlaceholder('Digite o ID da conta Free Fire')
        .setStyle(TextInputStyle.Short)
        .setRequired(true),
    ));
}

function painelRemoverJogadorPrompt(guildId, guild = null) {
  const cfg = getConfig(guildId);
  const color = cfg.embedColor || 0x2f3136;
  const panel = guildPanel(guildId);
  const jogadores = Array.isArray(panel.jogadores) ? panel.jogadores : [];

  if (jogadores.length === 0) {
    const container = new ContainerBuilder()
      .setAccentColor(Number.isInteger(color) ? color : 0x2f3136)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(
          '## REMOVER JOGADOR DA BLACKLIST\n\nNenhum jogador está registrado na blacklist deste servidor no momento.'
        )
      );
    return {
      components: [container],
      flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
    };
  }

  // Limite de 25 opções do StringSelectMenu do Discord
  const opcoes = jogadores.slice(0, 25).map((p, idx) => {
    const idValor = String(p.id || p.accountId || p.userId || idx).slice(0, 100);
    const label = `${p.nome || 'Jogador'}`.slice(0, 80);
    const descParts = [];
    if (p.accountId && !p.accountId.startsWith('DISCORD_')) descParts.push(`FF: ${p.accountId}`);
    if (p.motivo) descParts.push(`Motivo: ${p.motivo}`);
    const desc = descParts.join(' | ').slice(0, 100) || 'Registrado na blacklist';

    return {
      label,
      description: desc,
      value: idValor,
    };
  });

  const rowSelect = new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId('blacklist:select_remover')
      .setPlaceholder('Selecione o jogador que deseja remover da blacklist')
      .setMinValues(1)
      .setMaxValues(1)
      .addOptions(opcoes)
  );

  const container = new ContainerBuilder()
    .setAccentColor(Number.isInteger(color) ? color : 0x2f3136)
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `## REMOVER JOGADOR DA BLACKLIST\n\nSelecione no menu abaixo o jogador que você deseja remover da blacklist do servidor (**${jogadores.length}** registrado(s)):`
      )
    )
    .addActionRowComponents(rowSelect);

  return {
    components: [container],
    flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
  };
}

function painelAdicionarJogadorPrompt(guildId, guild = null) {
  const cfg = getConfig(guildId);
  const color = cfg.embedColor || 0x2f3136;

  const rowMenu = new ActionRowBuilder().addComponents(
    new UserSelectMenuBuilder()
      .setCustomId('blacklist:select_membro_add')
      .setPlaceholder('Selecione o membro do Discord')
      .setMinValues(1)
      .setMaxValues(1),
  );

  const container = new ContainerBuilder()
    .setAccentColor(Number.isInteger(color) ? color : 0x2f3136)
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        '## ADICIONAR JOGADOR A BLACKLIST\n\nSelecione o membro do Discord no menu abaixo para prosseguir com a inclusao na blacklist.'
      )
    )
    .addActionRowComponents(rowMenu);

  return {
    components: [container],
    flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
  };
}

function modalAdicionarComMembro(memberId, memberName = 'Membro') {
  const title = `Adicionar: ${memberName}`.slice(0, 45);
  const rowId = new ActionRowBuilder().addComponents(
    new TextInputBuilder()
      .setCustomId('id_conta')
      .setLabel('ID da conta Free Fire (opcional)')
      .setPlaceholder('Ex: 123456789 (deixe vazio se não souber)')
      .setStyle(TextInputStyle.Short)
      .setRequired(false),
  );

  const rowMotivo = new ActionRowBuilder().addComponents(
    new TextInputBuilder()
      .setCustomId('motivo')
      .setLabel('Motivo do banimento / blacklist')
      .setPlaceholder('Informe o motivo da inclusão na blacklist')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(true),
  );

  return new ModalBuilder()
    .setCustomId(`blacklist:modal_confirm_add:${memberId}`)
    .setTitle(title)
    .addComponents(rowId, rowMotivo);
}

function modalAdicionarManual() {
  const rowMembro = new ActionRowBuilder().addComponents(
    new TextInputBuilder()
      .setCustomId('membro_input')
      .setLabel('Membro Discord (Nick, @menção ou ID)')
      .setPlaceholder('Ex: @usuario ou 123456789012345678 (opcional)')
      .setStyle(TextInputStyle.Short)
      .setRequired(false),
  );

  const rowId = new ActionRowBuilder().addComponents(
    new TextInputBuilder()
      .setCustomId('id_conta')
      .setLabel('ID da conta Free Fire (opcional)')
      .setPlaceholder('Ex: 123456789 (deixe vazio se não souber)')
      .setStyle(TextInputStyle.Short)
      .setRequired(false),
  );

  const rowMotivo = new ActionRowBuilder().addComponents(
    new TextInputBuilder()
      .setCustomId('motivo')
      .setLabel('Motivo do banimento / blacklist')
      .setPlaceholder('Informe o motivo da inclusão na blacklist')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(true),
  );

  return new ModalBuilder()
    .setCustomId('blacklist:modal_manual_add')
    .setTitle('Adicionar à Blacklist')
    .addComponents(rowMembro, rowId, rowMotivo);
}

function modalAdicionar(memberId) {
  return new ModalBuilder()
    .setCustomId(`blacklist:modal_adicionar:${memberId}`)
    .setTitle('Consultar membro selecionado')
    .addComponents(new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('uid')
        .setLabel('ID Free Fire do membro')
        .setPlaceholder('Digite o ID Free Fire do membro')
        .setStyle(TextInputStyle.Short)
        .setRequired(true),
    ));
}

function usuarioPodeAdministrar(interaction) {
  const cfg = getConfig(interaction.guildId);
  const adminRoleId = String(cfg?.roles?.admin ?? '').trim();
  const donoRoleId = String(cfg?.roles?.dono ?? '').trim();
  return interaction.user.id === interaction.guild?.ownerId
    || Boolean(interaction.member?.permissions?.has(PermissionFlagsBits.Administrator))
    || Boolean(interaction.member?.permissions?.has(PermissionFlagsBits.ManageGuild))
    || Boolean(adminRoleId && interaction.member?.roles?.cache?.has(adminRoleId))
    || Boolean(donoRoleId && interaction.member?.roles?.cache?.has(donoRoleId));
}

function verificarBlacklistLocal(uid, guildId = null) {
  if (!uid) return null;
  const uidStr = String(uid).trim();

  // 1. Verifica no servidor atual
  if (guildId && state[guildId]?.jogadores) {
    const achou = state[guildId].jogadores.find(
      (j) => String(j.idConta || '').trim() === uidStr || String(j.userId || '').trim() === uidStr
    );
    if (achou) {
      return {
        id: achou.idConta || uidStr,
        nickname: achou.nome || 'Jogador Registrado',
        is_banned: 1,
        motivo: achou.motivo || 'Registrado na blacklist do servidor',
        isLocal: true,
      };
    }
  }

  // 2. Verifica em qualquer servidor cadastrado
  for (const gId of Object.keys(state)) {
    if (Array.isArray(state[gId]?.jogadores)) {
      const achou = state[gId].jogadores.find(
        (j) => String(j.idConta || '').trim() === uidStr || String(j.userId || '').trim() === uidStr
      );
      if (achou) {
        return {
          id: achou.idConta || uidStr,
          nickname: achou.nome || 'Jogador Registrado',
          is_banned: 1,
          motivo: achou.motivo || 'Registrado na blacklist',
          isLocal: true,
        };
      }
    }
  }
  return null;
}

function consultarConta(uid, guildId = null) {
  // 1. Resposta ultra-rápida (0ms) se o jogador está na blacklist local
  const local = verificarBlacklistLocal(uid, guildId);
  if (local) {
    return Promise.resolve(local);
  }

  // 2. Resposta instantânea de cache se já foi consultado
  const cached = consultaCache.get(uid);
  if (cached && Date.now() - cached.timestamp < CONSULTA_CACHE_TTL) {
    return Promise.resolve(cached.data);
  }

  // 3. Reutiliza consulta concorrente em andamento
  if (consultasEmAndamento.has(uid)) return consultasEmAndamento.get(uid);

  const consulta = (async () => {
    // Consulta via HTTP nativo com agente keep-alive para máxima velocidade
    return new Promise((resolve) => {
      const timeoutMs = 6000;
      let finalizado = false;

      const timer = setTimeout(() => {
        if (!finalizado) {
          finalizado = true;
          // Se o backend demorar ou der timeout, retorna não encontrado de forma segura e rápida
          resolve({ notFound: true });
        }
      }, timeoutMs);

      try {
        const req = http.get(
          `http://raw.thug4ff.xyz/check_ban/${encodeURIComponent(uid)}/great`,
          {
            agent: httpAgent,
            headers: {
              Accept: 'application/json',
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
            },
            timeout: timeoutMs,
          },
          (res) => {
            if (res.statusCode === 404) {
              if (!finalizado) {
                finalizado = true;
                clearTimeout(timer);
                consultaCache.set(uid, { data: { notFound: true }, timestamp: Date.now() });
                salvarCacheEmDisco();
                resolve({ notFound: true });
              }
              return;
            }

            let rawData = '';
            res.setEncoding('utf8');
            res.on('data', (chunk) => {
              rawData += chunk;
            });

            res.on('end', () => {
              if (finalizado) return;
              finalizado = true;
              clearTimeout(timer);

              try {
                const payload = JSON.parse(rawData);
                if (
                  payload?.status === 204 ||
                  payload?.status === 404 ||
                  payload?.code === 404 ||
                  payload?.msg === 'no_content' ||
                  payload?.msg === 'not_found' ||
                  payload?.notFound ||
                  payload?.data?.notFound ||
                  (payload?.data && !payload?.data?.nickname && payload?.data?.is_banned === undefined && payload?.msg === 'no_content') ||
                  String(payload?.error || payload?.message || '').toLowerCase().includes('not found') ||
                  String(payload?.error || payload?.message || '').toLowerCase().includes('não encontrad')
                ) {
                  const data = { notFound: true };
                  consultaCache.set(uid, { data, timestamp: Date.now() });
                  salvarCacheEmDisco();
                  return resolve(data);
                }

                if (payload?.status === 200 && payload?.data) {
                  consultaCache.set(uid, { data: payload.data, timestamp: Date.now() });
                  salvarCacheEmDisco();
                  return resolve(payload.data);
                }

                const errText = String(payload?.message || payload?.error || payload?.msg || '').toLowerCase();
                if (errText.includes('invalid') || errText.includes('inexistente') || errText.includes('sem dados') || errText.includes('no_content')) {
                  const data = { notFound: true };
                  consultaCache.set(uid, { data, timestamp: Date.now() });
                  salvarCacheEmDisco();
                  return resolve(data);
                }

                // Resposta padrão
                resolve(payload.data || { notFound: true });
              } catch (_) {
                resolve({ notFound: true });
              }
            });
          }
        );

        req.on('error', () => {
          if (!finalizado) {
            finalizado = true;
            clearTimeout(timer);
            resolve({ notFound: true });
          }
        });

        req.on('timeout', () => {
          req.destroy();
          if (!finalizado) {
            finalizado = true;
            clearTimeout(timer);
            resolve({ notFound: true });
          }
        });
      } catch (_) {
        if (!finalizado) {
          finalizado = true;
          clearTimeout(timer);
          resolve({ notFound: true });
        }
      }
    }).finally(() => {
      consultasEmAndamento.delete(uid);
    });
  })();

  consultasEmAndamento.set(uid, consulta);
  return consulta;
}

async function consultarComTentativas(uid, guildId = null) {
  return await consultarConta(uid, guildId);
}

function statusBlacklist(data) {
  if (!data) return false;
  if (data.notFound) return false;
  const text = JSON.stringify(data).toLowerCase();
  const ban = data?.is_banned ?? data?.isBan ?? data?.banned ?? data?.ban ?? data?.blacklisted ?? data?.is_ban;
  if (typeof ban === 'boolean') return ban;
  if (typeof ban === 'number') return ban !== 0;
  if (typeof ban === 'string') return /true|yes|sim|ban|blacklist|banned|1/.test(ban.toLowerCase());
  return /"status"\s*:\s*"?(ban|blacklist|banned|true)/.test(text)
    || /"is_ban"\s*:\s*(true|1)/.test(text)
    || /"is_banned"\s*:\s*(true|1)/.test(text);
}

function statusContaInexistente(data) {
  if (!data) return false;
  if (data.notFound) return true;
  const text = JSON.stringify(data).toLowerCase();
  return text.includes('not found') || text.includes('não encontrada') || text.includes('inexistente') || text.includes('player_not_found') || text.includes('account_not_found');
}

async function responderConsulta(interaction, uid, prefix = '') {
  if (!/^\d+$/.test(uid)) {
    await interaction.reply({ content: '⚠️ Informe um ID Free Fire válido usando apenas números.', flags: MessageFlags.Ephemeral });
    return;
  }
  await interaction.reply({ content: '🔍 Consultando a conta...', flags: MessageFlags.Ephemeral });
  try {
    const data = await consultarComTentativas(uid, interaction.guildId);
    if (statusContaInexistente(data)) {
      await interaction.editReply({ content: `❓ ${prefix}<@${interaction.user.id}>, não encontrei a conta com o ID **${uid}**.` });
      setTimeout(() => interaction.deleteReply().catch(() => {}), 15000);
      return;
    }

    const banida = statusBlacklist(data);
    const texto = banida
      ? `🚫 ${prefix}<@${interaction.user.id}>, a conta **${uid}** está na blacklist.`
      : `✅ ${prefix}<@${interaction.user.id}>, a conta **${uid}** não está na blacklist.`;
    await interaction.editReply({ content: texto });
    setTimeout(() => interaction.deleteReply().catch(() => {}), 15000);
  } catch (_) {
    await interaction.editReply({ content: '⚠️ O serviço de consulta está temporariamente indisponível. Tente novamente mais tarde.' }).catch(() => null);
    setTimeout(() => interaction.deleteReply().catch(() => {}), 15000);
  }
}

async function publicarPainelBlacklist(guild, channel) {
  if (!channel || typeof channel.send !== 'function') return null;
  const registro = guildPanel(guild.id);
  if (registro.channelId && registro.channelId !== channel.id && registro.messageId) {
    const canalAnterior = await guild.client?.channels.fetch(registro.channelId).catch(() => null);
    const mensagemAnterior = await canalAnterior?.messages.fetch(registro.messageId).catch(() => null);
    if (mensagemAnterior?.author?.id === guild.client?.user?.id) {
      await mensagemAnterior.delete().catch(() => {});
      console.log(`[BLACKLIST] Painel antigo removido de #${canalAnterior.name} antes da migração.`);
    }
  }

  const payload = {
    ...painelBlacklist(guild.id, null, guild),
    flags: MessageFlags.IsComponentsV2,
    allowedMentions: { parse: [] },
  };
  let message = null;
  if (registro.channelId === channel.id && registro.messageId) {
    message = await channel.messages.fetch(registro.messageId).catch(() => null);
  }
  try {
    if (message) {
      await message.edit(payload);
    } else {
      message = await channel.send(payload);
    }
  } catch (error) {
    console.error('[BLACKLIST] Erro ao enviar painel:', error.message);
    return null;
  }

  registro.channelId = channel.id;
  registro.messageId = message.id;
  saveData();
  return message;
}

async function autoRefreshPainelPublico(clientOrGuild, guildId) {
  const registro = state[guildId];
  if (!registro || !registro.channelId || !registro.messageId) return;
  try {
    const client = clientOrGuild.client || clientOrGuild;
    const channel = await client.channels.fetch(registro.channelId).catch(() => null);
    if (!channel) return;
    const message = await channel.messages.fetch(registro.messageId).catch(() => null);
    if (!message) return;
    const guild = client.guilds?.cache?.get(guildId) ?? channel.guild;
    await message.edit({
      ...painelBlacklist(guildId, null, guild),
      flags: MessageFlags.IsComponentsV2,
      allowedMentions: { parse: [] },
    });
  } catch (err) {
    console.error('[BLACKLIST] Erro no Auto-Refresh do painel:', err.message);
  }
}

async function restaurarPainelBlacklist(client) {
  for (const [guildId, registro] of Object.entries(state)) {
    if (!registro.channelId || !registro.messageId) continue;
    await autoRefreshPainelPublico(client, guildId);
  }
}

async function handleBlacklist(interaction) {
  if (interaction.isChatInputCommand() && interaction.commandName === 'blacklist') {
    const sub = interaction.options.getSubcommand(false);

    if (sub === 'painel') {
      if (!usuarioPodeAdministrar(interaction)) {
        await interaction.reply({
          content: '🔒 Apenas administradores podem configurar e enviar o painel de blacklist.',
          flags: MessageFlags.Ephemeral,
        });
        return true;
      }
      paineisConfigOrigem.set(
        chavePainelConfiguracao(interaction.guildId, interaction.user.id),
        interaction,
      );
      await interaction.reply({
        ...painelConfiguracaoBlacklist(interaction.guildId, null, interaction.guild),
      });
      return true;
    }

    if (sub === 'adicionar') {
      if (!usuarioPodeAdministrar(interaction)) {
        await interaction.reply({
          content: '🔒 Apenas administradores podem adicionar jogadores à blacklist.',
          flags: MessageFlags.Ephemeral,
        });
        return true;
      }
      await interaction.reply(painelAdicionarJogadorPrompt(interaction.guildId, interaction.guild));
      return true;
    }

    if (sub === 'remover') {
      if (!usuarioPodeAdministrar(interaction)) {
        await interaction.reply({
          content: '🔒 Apenas administradores podem remover jogadores da blacklist.',
          flags: MessageFlags.Ephemeral,
        });
        return true;
      }
      await interaction.reply(painelRemoverJogadorPrompt(interaction.guildId, interaction.guild));
      return true;
    }
  }
  const id = interaction.customId ?? '';
  if (!id.startsWith('blacklist:')) return false;

  if (interaction.isStringSelectMenu() && id === 'blacklist:config:opcoes') {
    if (!usuarioPodeAdministrar(interaction)) {
      await interaction.reply({ content: '🔒 Apenas administradores podem configurar o painel.', flags: MessageFlags.Ephemeral });
      return true;
    }
    const tipo = interaction.values[0];
    await interaction.showModal(modalConfiguracao(tipo, guildPanel(interaction.guildId)));
    return true;
  }

  if (interaction.isButton() && id === 'blacklist:config:enviar') {
    if (!usuarioPodeAdministrar(interaction)) {
      await interaction.reply({ content: '🔒 Apenas administradores podem enviar o painel.', flags: MessageFlags.Ephemeral });
      return true;
    }
    await interaction.deferUpdate();
    const message = await publicarPainelBlacklist(interaction.guild, interaction.channel);
    paineisConfigOrigem.delete(chavePainelConfiguracao(interaction.guildId, interaction.user.id));
    await interaction.editReply(
      painelConfiguracaoBlacklist(
        interaction.guildId,
        message ? `Painel enviado com sucesso em <#${message.channelId}>.` : 'Não foi possível enviar o painel. Verifique as permissões do bot no canal.',
        interaction.guild,
      ),
    );
    return true;
  }

  if (interaction.isModalSubmit() && id.startsWith('blacklist:config_modal:')) {
    if (!usuarioPodeAdministrar(interaction)) {
      await interaction.reply({ content: '🔒 Apenas administradores podem alterar as configurações.', flags: MessageFlags.Ephemeral });
      return true;
    }
    const tipo = id.split(':').pop();
    const panel = guildPanel(interaction.guildId);
    const rawValor = interaction.fields.getTextInputValue('valor');
    let notice = 'Configuração atualizada com sucesso.';

    if (tipo === 'titulo') {
      panel.titulo = rawValor.trim() || 'PAINEL DE BLACKLIST';
    } else if (tipo === 'descricao') {
      panel.descricao = rawValor.trim() ||
        'Consulte o status de uma conta Free Fire pelo ID da conta. ' +
        'A verificação é feita em tempo real e nenhuma blacklist local é armazenada.';
    } else if (tipo === 'thumbnail' || tipo === 'banner') {
      const sanitized = sanitizarUrl(rawValor);
      if (rawValor.trim() && !sanitized) {
        notice = 'URL inválida informada. Utilize um link direto público começando com http:// ou https://.';
      } else {
        panel[tipo] = sanitized;
      }
    }
    saveData();

    if (typeof interaction.isFromMessage === 'function' && interaction.isFromMessage()) {
      await interaction.deferUpdate();
      await interaction.editReply(painelConfiguracaoBlacklist(interaction.guildId, notice, interaction.guild));
    } else {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      await atualizarPainelConfiguracao(interaction, interaction.guildId, notice);
      await interaction.editReply({ content: notice });
    }
    return true;
  }

  if (interaction.isButton() && id === 'blacklist:consultar') {
    await interaction.showModal(modalConsultar());
    return true;
  }

  // ── Botão: Jogadores Blacklist ─────────────────────────────────────────────
  if (interaction.isButton() && id === 'blacklist:jogadores') {
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });
    const payload = await montarPainelJogadoresBlacklist(interaction.guildId, interaction.guild, 1);
    await interaction.editReply(payload);
    return true;
  }

  // ── Navegação entre páginas de Jogadores Blacklist ──────────────────────────
  if (interaction.isButton() && id.startsWith('blacklist:jogadores_nav:')) {
    const pagina = parseInt(id.split(':').pop(), 10) || 1;
    await interaction.deferUpdate();
    const payload = await montarPainelJogadoresBlacklist(interaction.guildId, interaction.guild, pagina);
    await interaction.editReply(payload);
    return true;
  }

  if (interaction.isStringSelectMenu() && id === 'blacklist:select_remover') {
    if (!usuarioPodeAdministrar(interaction)) {
      await interaction.reply({
        content: '🔒 Apenas administradores podem remover jogadores da blacklist.',
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    const valorSelecionado = interaction.values[0];
    const panel = guildPanel(interaction.guildId);
    if (!Array.isArray(panel.jogadores)) panel.jogadores = [];

    const index = panel.jogadores.findIndex(
      (p) => p.id === valorSelecionado || p.accountId === valorSelecionado || p.userId === valorSelecionado
    );

    if (index === -1) {
      await interaction.reply({
        content: '⚠️ O jogador selecionado não foi encontrado na blacklist.',
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    const removido = panel.jogadores.splice(index, 1)[0];
    saveData();
    autoRefreshPainelPublico(interaction, interaction.guildId).catch(() => {});

    // Invalida cache de consulta
    if (removido.accountId) {
      consultaCache.delete(removido.accountId);
    }
    if (removido.userId) {
      consultaCache.delete(removido.userId);
    }
    salvarCacheEmDisco();

    const infoId = removido.accountId && !removido.accountId.startsWith('DISCORD_') ? ` (ID FF: ${removido.accountId})` : '';
    await interaction.reply({
      content: `✅ O jogador **${removido.nome}**${infoId} foi removido da blacklist com sucesso.`,
      flags: MessageFlags.Ephemeral,
    });

    // Envia mensagem direta (DM) para o jogador informando a liberação
    if (removido.userId && interaction.client) {
      try {
        const user = await interaction.client.users.fetch(removido.userId).catch(() => null);
        if (user) {
          const accInfo = removido.accountId && !removido.accountId.startsWith('DISCORD_') ? ` (Conta Free Fire: **${removido.accountId}**)` : '';
          await user.send({
            content:
              `🛡️ **SISTEMA DE SEGURANÇA**\n\n` +
              `Olá <@${removido.userId}>,\n\n` +
              `Você foi **removido da blacklist** do servidor${accInfo}.\n\n` +
              `Sua punição foi revogada e seu acesso a todas as filas e partidas do servidor já está totalmente liberado.`
          }).catch(() => {});
        }
      } catch (dmErr) {
        console.error(`[BLACKLIST] Não foi possível enviar DM para ${removido.userId}:`, dmErr.message);
      }
    }
    return true;
  }

  if (interaction.isUserSelectMenu() && id === 'blacklist:select_membro_add') {
    if (!usuarioPodeAdministrar(interaction)) {
      await interaction.reply({ content: '🔒 Apenas administradores podem adicionar membros à blacklist.', flags: MessageFlags.Ephemeral });
      return true;
    }
    const memberId = interaction.values[0];
    let memberName = 'Membro';
    if (interaction.guild) {
      const member = interaction.guild.members.cache.get(memberId) || await interaction.guild.members.fetch(memberId).catch(() => null);
      if (member) memberName = member.displayName || member.user?.username || 'Membro';
    }
    await interaction.showModal(modalAdicionarComMembro(memberId, memberName));
    return true;
  }

  if (interaction.isButton() && id === 'blacklist:btn_add_manual') {
    if (!usuarioPodeAdministrar(interaction)) {
      await interaction.reply({ content: '🔒 Apenas administradores podem adicionar membros à blacklist.', flags: MessageFlags.Ephemeral });
      return true;
    }
    await interaction.showModal(modalAdicionarManual());
    return true;
  }

  if (interaction.isModalSubmit() && id.startsWith('blacklist:modal_confirm_add:')) {
    if (!usuarioPodeAdministrar(interaction)) {
      await interaction.reply({
        content: '🔒 Apenas administradores podem adicionar jogadores à blacklist.',
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    const memberId = id.split(':').pop();
    let idConta = '';
    try {
      idConta = (interaction.fields.getTextInputValue('id_conta') || '').trim();
    } catch (_) {}

    let motivo = '';
    try {
      motivo = (interaction.fields.getTextInputValue('motivo') || '').trim();
    } catch (_) {}

    if (idConta && !/^\d+$/.test(idConta)) {
      await interaction.reply({
        content: '⚠️ O ID da conta Free Fire deve conter apenas números (ou deixe em branco se não souber).',
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    let member = null;
    if (memberId && interaction.guild) {
      member = interaction.guild.members.cache.get(memberId) ?? await interaction.guild.members.fetch(memberId).catch(() => null);
    }

    const nomeFinal = member?.displayName || member?.user?.username || (idConta ? `Jogador ${idConta}` : 'Jogador Desconhecido');
    const avatarUrl = member?.user?.displayAvatarURL({ extension: 'png', size: 256 }) || null;
    const accountIdFinal = idConta || `DISCORD_${memberId}`;

    const panel = guildPanel(interaction.guildId);
    if (!Array.isArray(panel.jogadores)) panel.jogadores = [];

    const indexExistente = panel.jogadores.findIndex(
      (p) => (idConta && p.accountId === idConta) || (memberId && p.userId === memberId)
    );

    const playerObj = {
      id: indexExistente >= 0 ? panel.jogadores[indexExistente].id : Date.now().toString(),
      accountId: accountIdFinal,
      userId: memberId || null,
      nome: nomeFinal,
      avatarUrl,
      motivo: motivo || 'Registrado na blacklist',
      data: new Date().toISOString(),
      adicionadoPor: interaction.user.id,
    };

    if (indexExistente >= 0) {
      panel.jogadores[indexExistente] = playerObj;
    } else {
      panel.jogadores.push(playerObj);
    }
    saveData();
    autoRefreshPainelPublico(interaction, interaction.guildId).catch(() => {});

    await interaction.reply({
      content: `🚫 O jogador **${nomeFinal}**${idConta ? ` (ID: ${idConta})` : ''} foi adicionado à blacklist com sucesso.`,
      flags: MessageFlags.Ephemeral,
    });
    return true;
  }

  if (interaction.isModalSubmit() && id === 'blacklist:modal_manual_add') {
    if (!usuarioPodeAdministrar(interaction)) {
      await interaction.reply({
        content: '🔒 Apenas administradores podem adicionar jogadores à blacklist.',
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    let membroInput = '';
    try {
      membroInput = (interaction.fields.getTextInputValue('membro_input') || '').trim();
    } catch (_) {}

    let idConta = '';
    try {
      idConta = (interaction.fields.getTextInputValue('id_conta') || '').trim();
    } catch (_) {}

    let motivo = '';
    try {
      motivo = (interaction.fields.getTextInputValue('motivo') || '').trim();
    } catch (_) {}

    if (idConta && !/^\d+$/.test(idConta)) {
      await interaction.reply({
        content: '⚠️ O ID da conta Free Fire deve conter apenas números (ou deixe em branco se não souber).',
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    if (!membroInput && !idConta) {
      await interaction.reply({
        content: '⚠️ Informe o membro do Discord ou o ID da conta Free Fire.',
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    // Tentar resolver membro a partir do input (mencao, id numerico ou username)
    let memberId = null;
    let member = null;
    const matchId = membroInput.match(/\d{16,20}/);
    if (matchId && interaction.guild) {
      memberId = matchId[0];
      member = interaction.guild.members.cache.get(memberId) ?? await interaction.guild.members.fetch(memberId).catch(() => null);
    } else if (membroInput && interaction.guild) {
      member = interaction.guild.members.cache.find(
        (m) => m.user.username.toLowerCase() === membroInput.toLowerCase() || m.displayName.toLowerCase() === membroInput.toLowerCase()
      );
      if (member) memberId = member.id;
    }

    const nomeFinal = member?.displayName || member?.user?.username || membroInput || (idConta ? `Jogador ${idConta}` : 'Jogador Desconhecido');
    const avatarUrl = member?.user?.displayAvatarURL({ extension: 'png', size: 256 }) || null;
    const accountIdFinal = idConta || (memberId ? `DISCORD_${memberId}` : Date.now().toString());

    const panel = guildPanel(interaction.guildId);
    if (!Array.isArray(panel.jogadores)) panel.jogadores = [];

    const indexExistente = panel.jogadores.findIndex(
      (p) => (idConta && p.accountId === idConta) || (memberId && p.userId === memberId)
    );

    const playerObj = {
      id: indexExistente >= 0 ? panel.jogadores[indexExistente].id : Date.now().toString(),
      accountId: accountIdFinal,
      userId: memberId || null,
      nome: nomeFinal,
      avatarUrl,
      motivo: motivo || 'Registrado na blacklist',
      data: new Date().toISOString(),
      adicionadoPor: interaction.user.id,
    };

    if (indexExistente >= 0) {
      panel.jogadores[indexExistente] = playerObj;
    } else {
      panel.jogadores.push(playerObj);
    }
    saveData();
    autoRefreshPainelPublico(interaction, interaction.guildId).catch(() => {});

    await interaction.reply({
      content: `🚫 O jogador **${nomeFinal}**${idConta ? ` (ID: ${idConta})` : ''} foi adicionado à blacklist com sucesso.`,
      flags: MessageFlags.Ephemeral,
    });
    return true;
  }

  if (interaction.isModalSubmit() && id === 'blacklist:modal_consultar') {
    await responderConsulta(interaction, interaction.fields.getTextInputValue('uid').trim());
    return true;
  }
  if (interaction.isModalSubmit() && id.startsWith('blacklist:modal_adicionar:')) {
    if (!usuarioPodeAdministrar(interaction)) {
      await interaction.reply({ content: '🔒 Apenas o dono do servidor ou o cargo de Administrador configurado pode usar esta opção.', flags: MessageFlags.Ephemeral });
      return true;
    }
    const memberId = id.split(':').pop();
    const uid = interaction.fields.getTextInputValue('uid').trim();
    await responderConsulta(interaction, uid, `<@${memberId}>: `);
    return true;
  }
  return false;
}

function isUserBlacklisted(guildId, userId, accountId = null) {
  if (!userId && !accountId) return { blacklisted: false };
  const uIdStr = userId ? String(userId).trim() : null;
  const accIdStr = accountId ? String(accountId).trim() : null;

  // 1. Checa na guilda atual
  if (guildId && Array.isArray(state[guildId]?.jogadores)) {
    const achou = state[guildId].jogadores.find((p) => {
      const matchUser = uIdStr && String(p.userId || '').trim() === uIdStr;
      const matchAcc = (accIdStr && String(p.accountId || '').trim() === accIdStr) || (uIdStr && String(p.accountId || '').trim() === uIdStr);
      return matchUser || matchAcc;
    });
    if (achou) {
      return {
        blacklisted: true,
        motivo: achou.motivo || 'Registrado na blacklist',
        jogador: achou,
        guildId,
      };
    }
  }

  // 2. Checa globalmente em qualquer guilda registrada
  for (const [gId, reg] of Object.entries(state)) {
    if (Array.isArray(reg?.jogadores)) {
      const achou = reg.jogadores.find((p) => {
        const matchUser = uIdStr && String(p.userId || '').trim() === uIdStr;
        const matchAcc = (accIdStr && String(p.accountId || '').trim() === accIdStr) || (uIdStr && String(p.accountId || '').trim() === uIdStr);
        return matchUser || matchAcc;
      });
      if (achou) {
        return {
          blacklisted: true,
          motivo: achou.motivo || 'Registrado na blacklist',
          jogador: achou,
          guildId: gId,
        };
      }
    }
  }

  return { blacklisted: false };
}

function consultarContaApiDireta(uid) {
  return new Promise((resolve) => {
    const timeoutMs = 7000;
    let finalizado = false;

    const timer = setTimeout(() => {
      if (!finalizado) {
        finalizado = true;
        resolve({ notFound: true });
      }
    }, timeoutMs);

    try {
      const req = http.get(
        `http://raw.thug4ff.xyz/check_ban/${encodeURIComponent(uid)}/great`,
        {
          agent: httpAgent,
          headers: {
            Accept: 'application/json',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
          },
          timeout: timeoutMs,
        },
        (res) => {
          let rawData = '';
          res.setEncoding('utf8');
          res.on('data', (chunk) => { rawData += chunk; });
          res.on('end', () => {
            if (finalizado) return;
            finalizado = true;
            clearTimeout(timer);
            try {
              const payload = JSON.parse(rawData);
              if (payload?.status === 200 && payload?.data) {
                return resolve(payload.data);
              }
              resolve(payload?.data || payload || { notFound: true });
            } catch (_) {
              resolve({ notFound: true });
            }
          });
        }
      );

      req.on('error', () => {
        if (!finalizado) {
          finalizado = true;
          clearTimeout(timer);
          resolve({ notFound: true });
        }
      });
      req.on('timeout', () => {
        req.destroy();
        if (!finalizado) {
          finalizado = true;
          clearTimeout(timer);
          resolve({ notFound: true });
        }
      });
    } catch (_) {
      if (!finalizado) {
        finalizado = true;
        clearTimeout(timer);
        resolve({ notFound: true });
      }
    }
  });
}

async function executarVerificacaoDiaria(client) {
  console.log('[BLACKLIST] Iniciando rotina diária de verificação de contas na blacklist...');
  let totalVerificados = 0;
  let totalLiberados = 0;

  for (const [guildId, reg] of Object.entries(state)) {
    if (!Array.isArray(reg?.jogadores) || reg.jogadores.length === 0) continue;

    const jogadores = [...reg.jogadores];
    let houveRemocao = false;

    for (const jogador of jogadores) {
      const accId = jogador.accountId;
      // Se não for ID numérico da conta Free Fire, não há como consultar a API externa de ban
      if (!accId || !/^\d+$/.test(accId)) continue;

      totalVerificados++;
      try {
        const data = await consultarContaApiDireta(accId);
        // Se a conta retornou e não está banida (is_banned: 0 / false)
        if (data && !statusBlacklist(data) && !statusContaInexistente(data)) {
          const idx = reg.jogadores.findIndex((p) => p.accountId === accId || p.id === jogador.id);
          if (idx !== -1) {
            reg.jogadores.splice(idx, 1);
            houveRemocao = true;
            totalLiberados++;
            console.log(`[BLACKLIST] Jogador ${jogador.nome} (${accId}) saiu da blacklist e foi liberado!`);

            // Invalida cache de consulta
            consultaCache.delete(accId);
            salvarCacheEmDisco();

            // Envia mensagem direta (DM) para o jogador informando a liberação
            if (jogador.userId && client) {
              try {
                const user = await client.users.fetch(jogador.userId).catch(() => null);
                if (user) {
                  await user.send({
                    content:
                      `**SISTEMA DE SEGURANÇA**\n\n` +
                      `Olá <@${jogador.userId}>,\n\n` +
                      `A verificação automática diária do sistema identificou que a sua conta Free Fire (ID: **${accId}**) **não consta mais na blacklist**.\n\n` +
                      `Sua punição foi revogada com sucesso e seu acesso a todas as filas e partidas do servidor já está totalmente liberado.`
                  }).catch(() => {});
                }
              } catch (dmErr) {
                console.error(`[BLACKLIST] Não foi possível enviar DM para ${jogador.userId}:`, dmErr.message);
              }
            }
          }
        }
      } catch (err) {
        console.error(`[BLACKLIST] Erro ao verificar conta ${accId}:`, err.message);
      }
    }

    if (houveRemocao) {
      saveData();
      if (client) {
        autoRefreshPainelPublico(client, guildId).catch(() => {});
      }
    }
  }

  console.log(`[BLACKLIST] Rotina diária concluída: ${totalVerificados} contas verificadas, ${totalLiberados} jogadores liberados.`);
  return { totalVerificados, totalLiberados };
}

let _rotinaDiariaTimer = null;
function iniciarRotinaVerificacaoDiaria(client) {
  if (_rotinaDiariaTimer) clearInterval(_rotinaDiariaTimer);

  // Executa uma checagem inicial após 12 segundos da inicialização do bot
  setTimeout(() => {
    executarVerificacaoDiaria(client).catch((e) => console.error('[BLACKLIST] Erro na rotina diária:', e.message));
  }, 12000);

  // Executa a cada 24 horas (24 * 60 * 60 * 1000 ms)
  _rotinaDiariaTimer = setInterval(() => {
    executarVerificacaoDiaria(client).catch((e) => console.error('[BLACKLIST] Erro na rotina diária:', e.message));
  }, 24 * 60 * 60 * 1000);
}

module.exports = {
  handleBlacklist,
  painelBlacklist,
  publicarPainelBlacklist,
  restaurarPainelBlacklist,
  montarPainelJogadoresBlacklist,
  isUserBlacklisted,
  consultarContaApiDireta,
  executarVerificacaoDiaria,
  iniciarRotinaVerificacaoDiaria,
};
