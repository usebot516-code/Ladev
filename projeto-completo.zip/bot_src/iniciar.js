'use strict';

const {
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ChannelSelectMenuBuilder,
  RoleSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ChannelType,
  ContainerBuilder,
  TextDisplayBuilder,
  MessageFlags,
  PermissionFlagsBits,
} = require('discord.js');

const { getConfig } = require('./configurar');
const { salvarGuildConfigs, carregarGuildConfigs } = require('./storage');

// ─── Cores Padronizadas ────────────────────────────────────────────────────────
const COLORS = {
  azul:         { label: 'Azul',         hex: 0x5865F2 },
  verde:        { label: 'Verde',        hex: 0x57F287 },
  amarelo:      { label: 'Amarelo',      hex: 0xFEE75C },
  laranja:      { label: 'Laranja',      hex: 0xE67E22 },
  vermelho:     { label: 'Vermelho',     hex: 0xED4245 },
  roxo:         { label: 'Roxo',         hex: 0x9B59B6 },
  rosa:         { label: 'Rosa',         hex: 0xEB459E },
  ciano:        { label: 'Ciano',        hex: 0x1ABC9C },
  turquesa:     { label: 'Turquesa',     hex: 0x00CED1 },
  esmeralda:    { label: 'Esmeralda',    hex: 0x2ECC71 },
  dourado:      { label: 'Dourado',      hex: 0xD4AF37 },
  magenta:      { label: 'Magenta',      hex: 0xE91E63 },
  coral:        { label: 'Coral',        hex: 0xFF6F61 },
  escarlate:    { label: 'Escarlate',    hex: 0xC0392B },
  azul_celeste: { label: 'Azul Celeste', hex: 0x3498DB },
  lavanda:      { label: 'Lavanda',      hex: 0xB57EDC },
  grafite:      { label: 'Grafite',      hex: 0x2C2F33 },
  preto:        { label: 'Preto',        hex: 0x23272A },
  branco:       { label: 'Branco',       hex: 0xF8F9FA },
  prata:        { label: 'Prata',        hex: 0x95A5A6 },
};

const PREDEFINED_PRICES = [
  '0.30',
  '0.50',
  '0.70',
  '1.00',
  '2.00',
  '3.00',
  '4.00',
  '5.00',
  '10.00',
  '20.00',
  '30.00',
];

const PRICE_REGEX = /^\d+(?:[.,]\d{1,2})?$/;
const FEE_REGEX = /^\d+(?:[.,]\d{1,2})?%?$/;

// ─── Helpers de Dados ─────────────────────────────────────────────────────────

function getIniciarConfig(guildId) {
  const cfg = getConfig(guildId);
  if (!cfg.iniciar) {
    cfg.iniciar = {
      color: cfg.embedColor || 0x5865F2,
      colorName: 'Azul',
      qrCenterColor: cfg.qrCode?.corCentral || 'Preto',
      qrBorderColor: cfg.qrCode?.corBorda || 'Branco',
      prices: [...PREDEFINED_PRICES],
      fee: '0',
      feeIsPercentage: false,
      adminRoleId: cfg.roles?.admin || null,
      mediatorRoleId: cfg.roles?.mediador || null,
      analystRoleId: cfg.roles?.analista || null,
      mediatorQueueChannelId: null,
      analystQueueChannelId: cfg.channels?.filaAnalista || null,
      matchThreadsChannelId: cfg.channels?.filas || null,
      rankingChannelId: cfg.channels?.ranking || null,
      stage: 1,
      completed: false,
    };
  }

  // Garantir que campos obrigatórios existam
  if (!Array.isArray(cfg.iniciar.prices) || cfg.iniciar.prices.length === 0) {
    cfg.iniciar.prices = [...PREDEFINED_PRICES];
  }
  if (cfg.iniciar.color === undefined) cfg.iniciar.color = cfg.embedColor || 0x5865F2;
  if (!cfg.iniciar.colorName) {
    const entry = Object.values(COLORS).find((c) => c.hex === cfg.iniciar.color);
    cfg.iniciar.colorName = entry ? entry.label : 'Azul';
  }
  if (!cfg.iniciar.qrCenterColor) cfg.iniciar.qrCenterColor = cfg.qrCode?.corCentral || 'Preto';
  if (!cfg.iniciar.qrBorderColor) cfg.iniciar.qrBorderColor = cfg.qrCode?.corBorda || 'Branco';
  if (cfg.iniciar.fee === undefined) cfg.iniciar.fee = '0';
  if (cfg.iniciar.adminRoleId === undefined) cfg.iniciar.adminRoleId = cfg.roles?.admin || null;
  if (cfg.iniciar.mediatorRoleId === undefined) cfg.iniciar.mediatorRoleId = cfg.roles?.mediador || null;
  if (cfg.iniciar.analystRoleId === undefined) cfg.iniciar.analystRoleId = cfg.roles?.analista || null;
  if (cfg.iniciar.stage === undefined) cfg.iniciar.stage = 1;
  if (cfg.iniciar.matchThreadsChannelId === undefined) cfg.iniciar.matchThreadsChannelId = cfg.channels?.filas || null;
  if (cfg.iniciar.analystQueueChannelId === undefined) cfg.iniciar.analystQueueChannelId = cfg.channels?.filaAnalista || null;
  if (cfg.iniciar.rankingChannelId === undefined) cfg.iniciar.rankingChannelId = cfg.channels?.ranking || null;

  return cfg.iniciar;
}

function salvarIniciar(guildId) {
  const cfg = getConfig(guildId);
  const inic = cfg.iniciar;
  if (inic) {
    // Sincroniza cores, taxas, cargos e canais com a configuração geral do servidor
    cfg.embedColor = inic.color;
    if (!cfg.qrCode) cfg.qrCode = {};
    if (inic.qrCenterColor) cfg.qrCode.corCentral = inic.qrCenterColor;
    if (inic.qrBorderColor) cfg.qrCode.corBorda = inic.qrBorderColor;
    if (inic.fee !== undefined) {
      cfg.taxa = inic.feeIsPercentage ? `${inic.fee}%` : (inic.fee !== '0' ? `R$ ${inic.fee}` : null);
    }
    if (!cfg.roles) cfg.roles = {};
    if (inic.adminRoleId !== undefined) {
      cfg.roles.admin = inic.adminRoleId;
    }
    if (inic.mediatorRoleId !== undefined) {
      cfg.roles.mediador = inic.mediatorRoleId;
    }
    if (inic.analystRoleId !== undefined) {
      cfg.roles.analista = inic.analystRoleId;
    }
    if (inic.matchThreadsChannelId) {
      cfg.channels.filas = inic.matchThreadsChannelId;
    }
    if (inic.analystQueueChannelId) {
      cfg.channels.filaAnalista = inic.analystQueueChannelId;
    }
    if (inic.rankingChannelId) {
      cfg.channels.ranking = inic.rankingChannelId;
    }
    if (inic.mediatorLogChannelId) {
      cfg.channels.ponto = inic.mediatorLogChannelId;
    }
  }
  try {
    const map = carregarGuildConfigs();
    map.set(guildId, cfg);
    salvarGuildConfigs(map);
  } catch (err) {
    console.error('[INICIAR] Erro ao salvar configurações:', err.message);
  }
}

function parsePrices(raw) {
  const pieces = String(raw)
    .split(/[,;\n\s]+/)
    .map((p) => p.trim())
    .filter(Boolean);

  if (pieces.length === 0) {
    throw new Error('⚠️ Informe pelo menos um preço.');
  }

  const values = [];
  for (const piece of pieces) {
    if (!PRICE_REGEX.test(piece)) {
      throw new Error(`⚠️ Preço inválido: ${piece}. Use valores positivos com até duas casas.`);
    }
    const num = Number.parseFloat(piece.replace(',', '.'));
    if (!Number.isFinite(num) || num <= 0) {
      throw new Error('⚠️ Os preços precisam ser maiores que zero.');
    }
    values.push(num);
  }

  const unique = [...new Set(values)].sort((a, b) => a - b);
  return unique.map((v) => v.toFixed(2));
}

function parseFee(raw) {
  const normalized = String(raw).trim();
  if (!FEE_REGEX.test(normalized)) {
    throw new Error('⚠️ Informe um número válido, com ou sem o sinal de porcentagem.');
  }
  const isPercentage = normalized.endsWith('%');
  const numStr = isPercentage ? normalized.slice(0, -1).trim() : normalized;
  const num = Number.parseFloat(numStr.replace(',', '.'));
  if (!Number.isFinite(num) || num < 0 || num > 100) {
    throw new Error('⚠️ A taxa deve estar entre 0 e 100.');
  }
  const formatted = num % 1 === 0 ? String(num) : num.toFixed(2).replace(/\.?0+$/, '');
  return { fee: formatted || '0', isPercentage };
}

function feeText(config) {
  if (!config.fee || config.fee === '0') {
    return 'Nenhuma taxa configurada.';
  }
  return config.feeIsPercentage ? `${config.fee}%` : `R$ ${config.fee}`;
}

function pricesText(config) {
  if (!config.prices || config.prices.length === 0) {
    return 'Nenhum preço cadastrado.';
  }
  return config.prices.join(', ');
}

function channelLabel(channelId) {
  return channelId ? `<#${channelId}>` : 'Nenhum canal selecionado.';
}

function roleLabel(roleId) {
  return roleId ? `<@&${roleId}>` : 'Nenhum cargo selecionado.';
}

// ─── Construtores de Painéis ──────────────────────────────────────────────────

function buildStage1(guildId) {
  const config = getIniciarConfig(guildId);

  const optionsCorEmbed = Object.entries(COLORS).map(([key, data]) => ({
    label: data.label,
    value: key,
  }));

  const QR_COLOR_CHOICES = [
    'Preto',
    'Branco',
    'Azul',
    'Verde',
    'Vermelho',
    'Amarelo',
    'Roxo',
    'Rosa',
    'Cinza',
  ];

  const optionsQrCentral = QR_COLOR_CHOICES.map((c) => ({
    label: c,
    value: c,
  }));

  const optionsQrBorda = QR_COLOR_CHOICES.map((c) => ({
    label: c,
    value: c,
  }));

  const colorSelect = new StringSelectMenuBuilder()
    .setCustomId('iniciar:cor')
    .setPlaceholder('Cor das embeds')
    .setMinValues(1)
    .setMaxValues(1)
    .addOptions(optionsCorEmbed);

  const qrCenterSelect = new StringSelectMenuBuilder()
    .setCustomId('iniciar:qr:central')
    .setPlaceholder('Cor central do QR CODE')
    .setMinValues(1)
    .setMaxValues(1)
    .addOptions(optionsQrCentral);

  const qrBorderSelect = new StringSelectMenuBuilder()
    .setCustomId('iniciar:qr:borda')
    .setPlaceholder('Cor da borda do QR CODE')
    .setMinValues(1)
    .setMaxValues(1)
    .addOptions(optionsQrBorda);

  const nextButton = new ButtonBuilder()
    .setCustomId('iniciar:etapa1:proximo')
    .setLabel('Próximo')
    .setStyle(ButtonStyle.Primary);

  const container = new ContainerBuilder()
    .setAccentColor(config.color)
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `# Aparência das filas\n` +
        `**Cor atual das embeds**\n${config.colorName}\n\n` +
        `**Cor central do QR Code**\n${config.qrCenterColor || 'Preto'}\n\n` +
        `**Cor da borda do QR Code**\n${config.qrBorderColor || 'Branco'}`
      )
    )
    .addActionRowComponents(new ActionRowBuilder().addComponents(colorSelect))
    .addActionRowComponents(new ActionRowBuilder().addComponents(qrCenterSelect))
    .addActionRowComponents(new ActionRowBuilder().addComponents(qrBorderSelect))
    .addActionRowComponents(new ActionRowBuilder().addComponents(nextButton));

  return {
    components: [container],
    flags: MessageFlags.IsComponentsV2,
  };
}

function buildStage2(guildId) {
  const config = getIniciarConfig(guildId);

  const feeButton = new ButtonBuilder()
    .setCustomId('iniciar:taxa')
    .setLabel('Configurar taxa')
    .setStyle(ButtonStyle.Secondary);

  const addPricesButton = new ButtonBuilder()
    .setCustomId('iniciar:precos:adicionar')
    .setLabel('Adicionar preços')
    .setStyle(ButtonStyle.Secondary);

  const currentPrices = Array.isArray(config.prices) && config.prices.length > 0
    ? config.prices
    : PREDEFINED_PRICES;

  const removePricesSelect = new StringSelectMenuBuilder()
    .setCustomId('iniciar:precos:remover')
    .setPlaceholder('Remover preços')
    .setMinValues(1)
    .setMaxValues(Math.max(1, currentPrices.length))
    .addOptions(
      currentPrices.map((price) => ({
        label: `R$ ${price}`,
        value: price,
      }))
    );

  const backButton = new ButtonBuilder()
    .setCustomId('iniciar:etapa2:voltar')
    .setLabel('Voltar')
    .setStyle(ButtonStyle.Secondary);

  const nextButton = new ButtonBuilder()
    .setCustomId('iniciar:etapa2:proximo')
    .setLabel('Próximo')
    .setStyle(ButtonStyle.Primary);

  const container = new ContainerBuilder()
    .setAccentColor(config.color)
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `# Valores e taxa\n` +
        `**Taxa configurada**\n${feeText(config)}\n\n` +
        `**Preços cadastrados**\n${pricesText(config)}`
      )
    )
    .addActionRowComponents(new ActionRowBuilder().addComponents(feeButton))
    .addActionRowComponents(new ActionRowBuilder().addComponents(addPricesButton))
    .addActionRowComponents(new ActionRowBuilder().addComponents(removePricesSelect))
    .addActionRowComponents(new ActionRowBuilder().addComponents(backButton, nextButton));

  return {
    components: [container],
    flags: MessageFlags.IsComponentsV2,
  };
}

function buildStage3(guildId) {
  const config = getIniciarConfig(guildId);
  const adminName = roleLabel(config.adminRoleId);
  const mediatorName = roleLabel(config.mediatorRoleId);
  const analystName = roleLabel(config.analystRoleId);

  const adminSelect = new RoleSelectMenuBuilder()
    .setCustomId('iniciar:cargo:admin')
    .setPlaceholder('Selecionar cargo admin')
    .setMinValues(1)
    .setMaxValues(1);

  const mediatorSelect = new RoleSelectMenuBuilder()
    .setCustomId('iniciar:cargo:mediador')
    .setPlaceholder('Selecionar cargo mediador')
    .setMinValues(1)
    .setMaxValues(1);

  const analystSelect = new RoleSelectMenuBuilder()
    .setCustomId('iniciar:cargo:analista')
    .setPlaceholder('Selecionar cargo analista')
    .setMinValues(1)
    .setMaxValues(1);

  const backButton = new ButtonBuilder()
    .setCustomId('iniciar:etapa3:voltar')
    .setLabel('Voltar')
    .setStyle(ButtonStyle.Secondary);

  const nextButton = new ButtonBuilder()
    .setCustomId('iniciar:etapa3:proximo')
    .setLabel('Próximo')
    .setStyle(ButtonStyle.Primary);

  const container = new ContainerBuilder()
    .setAccentColor(config.color)
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `# Cargos da equipe\n` +
        `**Selecionar cargo admin** (cargo responsável por mexer no bot)\n${adminName}\n\n` +
        `**Selecionar cargo mediador**\n${mediatorName}\n\n` +
        `**Selecionar cargo analista**\n${analystName}`
      )
    )
    .addActionRowComponents(new ActionRowBuilder().addComponents(adminSelect))
    .addActionRowComponents(new ActionRowBuilder().addComponents(mediatorSelect))
    .addActionRowComponents(new ActionRowBuilder().addComponents(analystSelect))
    .addActionRowComponents(new ActionRowBuilder().addComponents(backButton, nextButton));

  return {
    components: [container],
    flags: MessageFlags.IsComponentsV2,
  };
}

function buildStage4(guildId, completed = false) {
  const config = getIniciarConfig(guildId);
  const queueName = channelLabel(config.mediatorQueueChannelId);
  const analystQueueName = channelLabel(config.analystQueueChannelId);
  const matchThreadsName = channelLabel(config.matchThreadsChannelId);
  const rankingName = channelLabel(config.rankingChannelId);

  const queueSelect = new ChannelSelectMenuBuilder()
    .setCustomId('iniciar:canal:fila')
    .setPlaceholder('Selecionar canal da fila de mediadores')
    .setChannelTypes([ChannelType.GuildText, ChannelType.GuildAnnouncement]);

  const analystQueueSelect = new ChannelSelectMenuBuilder()
    .setCustomId('iniciar:canal:fila_analista')
    .setPlaceholder('Selecionar canal de fila de analista')
    .setChannelTypes([ChannelType.GuildText, ChannelType.GuildAnnouncement]);

  const matchThreadsSelect = new ChannelSelectMenuBuilder()
    .setCustomId('iniciar:canal:topicos')
    .setPlaceholder('Selecionar canal de tópicos de partidas')
    .setChannelTypes([ChannelType.GuildText, ChannelType.GuildAnnouncement]);

  const rankingSelect = new ChannelSelectMenuBuilder()
    .setCustomId('iniciar:canal:ranking')
    .setPlaceholder('Selecionar canal de ranking')
    .setChannelTypes([ChannelType.GuildText, ChannelType.GuildAnnouncement]);

  const backButton = new ButtonBuilder()
    .setCustomId('iniciar:etapa4:voltar')
    .setLabel('Voltar')
    .setStyle(ButtonStyle.Secondary);

  const finishButton = new ButtonBuilder()
    .setCustomId('iniciar:finalizar')
    .setLabel('Finalizar')
    .setStyle(ButtonStyle.Success);

  const statusText = completed ? '\n\n**Status**\nConfiguração finalizada e painéis públicos enviados!' : '';

  const container = new ContainerBuilder()
    .setAccentColor(config.color)
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `# Canais\n` +
        `**Canal fila mediador** (/fila mediador)\n${queueName}\n\n` +
        `**Canal fila analista** (/fila analista)\n${analystQueueName}\n\n` +
        `**Canal de tópicos** (onde serão abertos os tópicos de partidas)\n${matchThreadsName}\n\n` +
        `**Canal de ranking**\n${rankingName}` +
        statusText
      )
    )
    .addActionRowComponents(new ActionRowBuilder().addComponents(queueSelect))
    .addActionRowComponents(new ActionRowBuilder().addComponents(analystQueueSelect))
    .addActionRowComponents(new ActionRowBuilder().addComponents(matchThreadsSelect))
    .addActionRowComponents(new ActionRowBuilder().addComponents(rankingSelect))
    .addActionRowComponents(
      new ActionRowBuilder().addComponents(
        completed ? [backButton] : [backButton, finishButton]
      )
    );

  return {
    components: [container],
    flags: MessageFlags.IsComponentsV2,
  };
}

function buildCompleted(guildId) {
  const config = getIniciarConfig(guildId);

  const container = new ContainerBuilder()
    .setAccentColor(config.color)
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `# Configuração concluída com sucesso!\n\n` +
        `### 🎨 Aparência\n` +
        `• **Cor das embeds:** ${config.colorName || 'Azul'}\n` +
        `• **Cor central do QR Code:** ${config.qrCenterColor || 'Preto'}\n` +
        `• **Cor da borda do QR Code:** ${config.qrBorderColor || 'Branco'}\n\n` +
        `### 💰 Valores e Taxa\n` +
        `• **Taxa:** ${feeText(config)}\n` +
        `• **Preços:** ${pricesText(config)}\n\n` +
        `### 🛡️ Cargos Definidos\n` +
        `• **Admin:** ${roleLabel(config.adminRoleId)}\n` +
        `• **Mediador:** ${roleLabel(config.mediatorRoleId)}\n` +
        `• **Analista:** ${roleLabel(config.analystRoleId)}\n\n` +
        `### 📢 Canais e Painéis Públicos\n` +
        `• **Canal Fila Mediador (/fila mediador):** ${channelLabel(config.mediatorQueueChannelId)}\n` +
        `• **Canal Fila Analista (/fila analista):** ${channelLabel(config.analystQueueChannelId)}\n` +
        `• **Canal de Tópicos (Abertura de Partidas):** ${channelLabel(config.matchThreadsChannelId)}\n` +
        `• **Canal de Ranking:** ${channelLabel(config.rankingChannelId)}`
      )
    );

  return {
    components: [container],
    flags: MessageFlags.IsComponentsV2,
  };
}

// ─── Modais ───────────────────────────────────────────────────────────────────

function modalAddPrices() {
  const modal = new ModalBuilder()
    .setCustomId('iniciar:modal:precos')
    .setTitle('Adicionar preços');

  const input = new TextInputBuilder()
    .setCustomId('valores')
    .setLabel('Preços')
    .setPlaceholder('Ex.: 5, 10, 25 ou um valor por linha')
    .setStyle(TextInputStyle.Paragraph)
    .setMinLength(1)
    .setMaxLength(500)
    .setRequired(true);

  modal.addComponents(new ActionRowBuilder().addComponents(input));
  return modal;
}

function modalFee(currentFee = '') {
  const modal = new ModalBuilder()
    .setCustomId('iniciar:modal:taxa')
    .setTitle('Configurar taxa');

  const input = new TextInputBuilder()
    .setCustomId('taxa')
    .setLabel('Taxa')
    .setPlaceholder('Ex.: 5%')
    .setStyle(TextInputStyle.Short)
    .setMinLength(1)
    .setMaxLength(8)
    .setRequired(true);

  if (currentFee && currentFee !== '0') {
    input.setValue(currentFee);
  }

  modal.addComponents(new ActionRowBuilder().addComponents(input));
  return modal;
}

// ─── Handler Principal ────────────────────────────────────────────────────────

async function handleIniciar(interaction, client) {
  const guildId = interaction.guildId;

  // ── Comando /iniciar ───────────────────────────────────────────────────────
  if (interaction.isChatInputCommand() && interaction.commandName === 'iniciar') {
    if (!guildId) {
      await interaction.reply({
        content: '⚠️ Este comando só pode ser usado dentro de um servidor.',
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    const hasPermission =
      interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild) ||
      interaction.memberPermissions?.has(PermissionFlagsBits.Administrator);

    if (!hasPermission) {
      await interaction.reply({
        content: '🔒 Você precisa da permissão **Gerenciar Servidor** para usar este comando.',
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    const config = getIniciarConfig(guildId);
    config.stage = 1;
    config.completed = false;
    salvarIniciar(guildId);

    await interaction.reply({
      ephemeral: true,
      ...buildStage1(guildId),
    });
    return true;
  }

  const customId = interaction.customId || '';
  if (!customId.startsWith('iniciar:')) return false;

  if (!guildId) return false;

  const hasPermission =
    interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild) ||
    interaction.memberPermissions?.has(PermissionFlagsBits.Administrator);

  if (!hasPermission) {
    await interaction.reply({
      content: '🔒 Você precisa da permissão **Gerenciar Servidor** para alterar estas configurações.',
      flags: MessageFlags.Ephemeral,
    });
    return true;
  }

  const config = getIniciarConfig(guildId);

  // ── Etapa 1: Selecionar Cor ───────────────────────────────────────────────
  if (interaction.isStringSelectMenu() && customId === 'iniciar:cor') {
    const key = interaction.values[0]?.toLowerCase();
    const colorEntry = COLORS[key];
    if (colorEntry) {
      config.colorName = colorEntry.label;
      config.color = colorEntry.hex;
      salvarIniciar(guildId);
    }
    if (interaction.isRepliable()) {
      await interaction.update(buildStage1(guildId)).catch(async () => {
        await interaction.editReply(buildStage1(guildId)).catch(() => {});
      });
    }
    return true;
  }

  // ── Etapa 1: Selecionar Cor Central do QR Code ───────────────────────────
  if (interaction.isStringSelectMenu() && customId === 'iniciar:qr:central') {
    const val = interaction.values[0];
    if (val) {
      config.qrCenterColor = val;
      salvarIniciar(guildId);
    }
    if (interaction.isRepliable()) {
      await interaction.update(buildStage1(guildId)).catch(async () => {
        await interaction.editReply(buildStage1(guildId)).catch(() => {});
      });
    }
    return true;
  }

  // ── Etapa 1: Selecionar Cor da Borda do QR Code ──────────────────────────
  if (interaction.isStringSelectMenu() && customId === 'iniciar:qr:borda') {
    const val = interaction.values[0];
    if (val) {
      config.qrBorderColor = val;
      salvarIniciar(guildId);
    }
    if (interaction.isRepliable()) {
      await interaction.update(buildStage1(guildId)).catch(async () => {
        await interaction.editReply(buildStage1(guildId)).catch(() => {});
      });
    }
    return true;
  }

  // ── Etapa 1: Próximo ──────────────────────────────────────────────────────
  if (interaction.isButton() && customId === 'iniciar:etapa1:proximo') {
    config.stage = 2;
    salvarIniciar(guildId);
    if (interaction.isRepliable()) {
      await interaction.update(buildStage2(guildId)).catch(async () => {
        await interaction.editReply(buildStage2(guildId)).catch(() => {});
      });
    }
    return true;
  }

  // ── Etapa 2: Adicionar Preços (Abrir Modal) ───────────────────────────────
  if (interaction.isButton() && customId === 'iniciar:precos:adicionar') {
    await interaction.showModal(modalAddPrices());
    return true;
  }

  // ── Etapa 2: Modal Adicionar Preços Submit ─────────────────────────────────
  if (interaction.isModalSubmit() && customId === 'iniciar:modal:precos') {
    const raw = interaction.fields.getTextInputValue('valores');
    try {
      const newPrices = parsePrices(raw);
      const combined = [...new Set([...config.prices, ...newPrices])].sort(
        (a, b) => Number.parseFloat(a) - Number.parseFloat(b)
      );
      config.prices = combined;
      salvarIniciar(guildId);
      if (interaction.isRepliable()) {
        await interaction.update(buildStage2(guildId)).catch(async () => {
          await interaction.editReply(buildStage2(guildId)).catch(() => {});
        });
      }
    } catch (err) {
      await interaction.reply({
        content: err.message || 'Erro ao processar preços.',
        flags: MessageFlags.Ephemeral,
      });
    }
    return true;
  }

  // ── Etapa 2: Remover Preços (Select Menu) ──────────────────────────────────
  if (interaction.isStringSelectMenu() && customId === 'iniciar:precos:remover') {
    const selected = new Set(interaction.values);
    const oldPrices = new Set(config.prices);
    config.prices = config.prices.filter((p) => !selected.has(p));
    salvarIniciar(guildId);
    if (interaction.isRepliable()) {
      await interaction.update(buildStage2(guildId)).catch(async () => {
        await interaction.editReply(buildStage2(guildId)).catch(() => {});
      });
    }

    const intersection = [...selected].some((p) => oldPrices.has(p));
    if (!intersection) {
      await interaction.followUp({
        content: 'ℹ️ Nenhum dos valores selecionados estava cadastrado.',
        flags: MessageFlags.Ephemeral,
      }).catch(() => {});
    }
    return true;
  }

  // ── Etapa 2: Configurar Taxa (Abrir Modal) ─────────────────────────────────
  if (interaction.isButton() && customId === 'iniciar:taxa') {
    const currentVal = config.fee !== '0' ? (config.feeIsPercentage ? `${config.fee}%` : config.fee) : '';
    await interaction.showModal(modalFee(currentVal));
    return true;
  }

  // ── Etapa 2: Modal Taxa Submit ────────────────────────────────────────────
  if (interaction.isModalSubmit() && customId === 'iniciar:modal:taxa') {
    const raw = interaction.fields.getTextInputValue('taxa');
    try {
      const { fee, isPercentage } = parseFee(raw);
      config.fee = fee;
      config.feeIsPercentage = isPercentage;
      salvarIniciar(guildId);
      if (interaction.isRepliable()) {
        await interaction.update(buildStage2(guildId)).catch(async () => {
          await interaction.editReply(buildStage2(guildId)).catch(() => {});
        });
      }
    } catch (err) {
      await interaction.reply({
        content: err.message || 'Erro ao processar taxa.',
        flags: MessageFlags.Ephemeral,
      });
    }
    return true;
  }

  // ── Etapa 2: Voltar para Etapa 1 ──────────────────────────────────────────
  if (interaction.isButton() && customId === 'iniciar:etapa2:voltar') {
    config.stage = 1;
    config.completed = false;
    salvarIniciar(guildId);
    if (interaction.isRepliable()) {
      await interaction.update(buildStage1(guildId)).catch(async () => {
        await interaction.editReply(buildStage1(guildId)).catch(() => {});
      });
    }
    return true;
  }

  // ── Etapa 2: Próximo para Etapa 3 ─────────────────────────────────────────
  if (interaction.isButton() && customId === 'iniciar:etapa2:proximo') {
    config.stage = 3;
    config.completed = false;
    salvarIniciar(guildId);
    if (interaction.isRepliable()) {
      await interaction.update(buildStage3(guildId)).catch(async () => {
        await interaction.editReply(buildStage3(guildId)).catch(() => {});
      });
    }
    return true;
  }

  // ── Etapa 3: Selecionar Cargo Admin ──────────────────────────────────────
  if (interaction.isRoleSelectMenu() && customId === 'iniciar:cargo:admin') {
    const roleId = interaction.values[0];
    config.adminRoleId = roleId;
    salvarIniciar(guildId);
    if (interaction.isRepliable()) {
      await interaction.update(buildStage3(guildId)).catch(async () => {
        await interaction.editReply(buildStage3(guildId)).catch(() => {});
      });
    }
    return true;
  }

  // ── Etapa 3: Selecionar Cargo Mediador ────────────────────────────────────
  if (interaction.isRoleSelectMenu() && customId === 'iniciar:cargo:mediador') {
    const roleId = interaction.values[0];
    config.mediatorRoleId = roleId;
    salvarIniciar(guildId);
    if (interaction.isRepliable()) {
      await interaction.update(buildStage3(guildId)).catch(async () => {
        await interaction.editReply(buildStage3(guildId)).catch(() => {});
      });
    }
    return true;
  }

  // ── Etapa 3: Selecionar Cargo Analista ────────────────────────────────────
  if (interaction.isRoleSelectMenu() && customId === 'iniciar:cargo:analista') {
    const roleId = interaction.values[0];
    config.analystRoleId = roleId;
    salvarIniciar(guildId);
    if (interaction.isRepliable()) {
      await interaction.update(buildStage3(guildId)).catch(async () => {
        await interaction.editReply(buildStage3(guildId)).catch(() => {});
      });
    }
    return true;
  }

  // ── Etapa 3: Voltar para Etapa 2 ──────────────────────────────────────────
  if (interaction.isButton() && customId === 'iniciar:etapa3:voltar') {
    config.stage = 2;
    config.completed = false;
    salvarIniciar(guildId);
    if (interaction.isRepliable()) {
      await interaction.update(buildStage2(guildId)).catch(async () => {
        await interaction.editReply(buildStage2(guildId)).catch(() => {});
      });
    }
    return true;
  }

  // ── Etapa 3: Próximo para Etapa 4 ─────────────────────────────────────────
  if (interaction.isButton() && customId === 'iniciar:etapa3:proximo') {
    config.stage = 4;
    config.completed = false;
    salvarIniciar(guildId);
    if (interaction.isRepliable()) {
      await interaction.update(buildStage4(guildId)).catch(async () => {
        await interaction.editReply(buildStage4(guildId)).catch(() => {});
      });
    }
    return true;
  }

  // ── Etapa 4: Selecionar Canal da Fila de Mediadores ───────────────────────
  if (interaction.isChannelSelectMenu() && customId === 'iniciar:canal:fila') {
    const channelId = interaction.values[0];
    config.mediatorQueueChannelId = channelId;
    salvarIniciar(guildId);
    if (interaction.isRepliable()) {
      await interaction.update(buildStage4(guildId)).catch(async () => {
        await interaction.editReply(buildStage4(guildId)).catch(() => {});
      });
    }
    return true;
  }

  // ── Etapa 4: Selecionar Canal da Fila de Analistas ────────────────────────
  if (interaction.isChannelSelectMenu() && (customId === 'iniciar:canal:fila_analista' || customId === 'iniciar:canal:registro')) {
    const channelId = interaction.values[0];
    config.analystQueueChannelId = channelId;
    salvarIniciar(guildId);
    if (interaction.isRepliable()) {
      await interaction.update(buildStage4(guildId)).catch(async () => {
        await interaction.editReply(buildStage4(guildId)).catch(() => {});
      });
    }
    return true;
  }

  // ── Etapa 4: Selecionar Canal de Tópicos de Partidas ─────────────────────
  if (interaction.isChannelSelectMenu() && customId === 'iniciar:canal:topicos') {
    const channelId = interaction.values[0];
    config.matchThreadsChannelId = channelId;
    salvarIniciar(guildId);
    if (interaction.isRepliable()) {
      await interaction.update(buildStage4(guildId)).catch(async () => {
        await interaction.editReply(buildStage4(guildId)).catch(() => {});
      });
    }
    return true;
  }

  // ── Etapa 4: Selecionar Canal de Ranking ──────────────────────────────────
  if (interaction.isChannelSelectMenu() && customId === 'iniciar:canal:ranking') {
    const channelId = interaction.values[0];
    config.rankingChannelId = channelId;
    salvarIniciar(guildId);
    if (interaction.isRepliable()) {
      await interaction.update(buildStage4(guildId)).catch(async () => {
        await interaction.editReply(buildStage4(guildId)).catch(() => {});
      });
    }
    return true;
  }

  // ── Etapa 4: Voltar para Etapa 3 ──────────────────────────────────────────
  if (interaction.isButton() && customId === 'iniciar:etapa4:voltar') {
    config.stage = 3;
    config.completed = false;
    salvarIniciar(guildId);
    if (interaction.isRepliable()) {
      await interaction.update(buildStage3(guildId)).catch(async () => {
        await interaction.editReply(buildStage3(guildId)).catch(() => {});
      });
    }
    return true;
  }

  // ── Etapa 4: Finalizar ────────────────────────────────────────────────────
  if (interaction.isButton() && customId === 'iniciar:finalizar') {
    if (!config.mediatorQueueChannelId || !config.analystQueueChannelId || !config.matchThreadsChannelId || !config.rankingChannelId) {
      await interaction.reply({
        content: '⚠️ Selecione todos os canais (Fila de Mediadores, Fila de Analistas, Tópicos de Partidas e Ranking) antes de finalizar.',
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }

    config.stage = 4;
    config.completed = true;
    salvarIniciar(guildId);

    // Enviar/publicar os painéis públicos nos canais selecionados
    if (interaction.guild) {
      if (config.mediatorQueueChannelId) {
        const chMed = await interaction.guild.channels.fetch(config.mediatorQueueChannelId).catch(() => null);
        if (chMed) {
          try {
            await require('./fila_mediador').publicarPainelMediador(interaction.guild, chMed);
          } catch (e) {
            console.error('[INICIAR] Erro ao publicar painel de mediador:', e.message);
          }
        }
      }
      if (config.analystQueueChannelId) {
        const chAna = await interaction.guild.channels.fetch(config.analystQueueChannelId).catch(() => null);
        if (chAna) {
          try {
            await require('./fila_analista').publicarPainelFilaAnalista(interaction.guild, chAna);
          } catch (e) {
            console.error('[INICIAR] Erro ao publicar painel de analista:', e.message);
          }
        }
      }
      if (config.rankingChannelId) {
        const chRank = await interaction.guild.channels.fetch(config.rankingChannelId).catch(() => null);
        if (chRank) {
          try {
            await require('./ranking').publicarPainelRanking(interaction.guild, chRank);
          } catch (e) {
            console.error('[INICIAR] Erro ao publicar painel de ranking:', e.message);
          }
        }
      }
    }

    if (interaction.isRepliable()) {
      await interaction.update(buildCompleted(guildId)).catch(async () => {
        await interaction.editReply(buildCompleted(guildId)).catch(() => {});
      });
    }
    return true;
  }

  return false;
}

module.exports = {
  handleIniciar,
  getIniciarConfig,
  buildStage1,
  buildStage2,
  buildStage3,
  buildStage4,
  buildCompleted,
  COLORS,
  PREDEFINED_PRICES,
};
