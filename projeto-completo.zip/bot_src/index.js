'use strict';

try { require('dotenv').config(); } catch (_) {}

const fs = require('fs');
const path = require('path');

// Carregar credenciais salvas em data/app_config.json
try {
  const appConfigPath = path.join(__dirname, '..', 'data', 'app_config.json');
  if (fs.existsSync(appConfigPath)) {
    const rawConfig = fs.readFileSync(appConfigPath, 'utf8').trim();
    if (rawConfig) {
      const cfg = JSON.parse(rawConfig);
      if (cfg.token) {
        process.env.DISCORD_BOT_TOKEN = cfg.token;
      }
      if (cfg.guildId) {
        process.env.DISCORD_GUILD_ID = cfg.guildId;
        process.env.GUILD_ID = cfg.guildId;
      }
      if (cfg.ownerRoleId) {
        process.env.BOT_OWNER_ROLE_ID = cfg.ownerRoleId;
        process.env.CARGO_OWNER_ID = cfg.ownerRoleId;
      }
      if (cfg.sessionSecret) {
        process.env.SESSION_SECRET = cfg.sessionSecret;
      }
      if (cfg.mercadoPagoToken) {
        process.env.MERCADOPAGO_ACCESS_TOKEN = cfg.mercadoPagoToken;
      }
      if (cfg.tryzeApiKey) {
        process.env.TRYZE_CALLS_API_KEY = cfg.tryzeApiKey;
      }
    }
  }
} catch (e) {
  console.warn('[CONFIG] Aviso ao ler data/app_config.json:', e.message);
}

// Mantém compatibilidade com a configuração antiga numerada: o primeiro token
// vira o bot controlador e os demais são importados pelo painel `.bots`.
const numberedTokenKeys = Object.keys(process.env)
  .filter((key) => /^DISCORD_BOT_TOKEN_\d+$/.test(key) && process.env[key])
  .sort((a, b) => Number(a.split('_').pop()) - Number(b.split('_').pop()));
const IS_WORKER = process.argv.includes('--worker');
if (!IS_WORKER && numberedTokenKeys.length > 0 && !process.env.DISCORD_BOT_TOKEN) {
  process.env.DISCORD_BOT_TOKEN = process.env[numberedTokenKeys[0]];
  process.env.BOT_DATA_DIR = process.env.BOT_DATA_DIR || path.join(__dirname, '..', 'data');
}

const {
  Client,
  GatewayIntentBits,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
  ContainerBuilder,
  TextDisplayBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  UserSelectMenuBuilder,
  REST,
  Routes,
  Events,
  MessageFlags,
  PermissionFlagsBits,
} = require('discord.js');

const { handleConfigurar, getConfig }    = require('./configurar');
const { handleIniciar }                  = require('./iniciar');
const { handleAjuda }                    = require('./ajuda');
const {
  verificarPlanoAtivo,
  responderSemPlano,
  isBotOwnerUser,
}                                        = require('./plano_check');
const {
  handleDevMessage,
  handleDevCentral,
  restorePanels: restaurarDevCentral,
}                                        = require('./dev_central');
const {
  handleFilas,
  restaurarPaineis,
  removerPainelPorMsgId,
  removerPaineisDoCanal,
} = require('./filas');
const { handleFilaMediador, restaurarPainelMediador } = require('./fila_mediador');
const { handleFilaAnalista, restaurarPainelFilaAnalista } = require('./fila_analista');
const { handlePartida, handlePartidaMessage, handleAux, restaurarPartidas } = require('./partida');
const { handleFilaStreamer, restaurarPaineisStreamer } = require('./fila_streamer');
const { handlePerfil } = require('./perfil');
const { handleTickets, restaurarPaineisTickets } = require('./tickets');
const { handleAvisos, restaurarAvisos }          = require('./avisos');
const { handleLimpar }                           = require('./limpar');
const {
  handleSorteios,
  restorePanels: restaurarPaineisSorteios,
} = require('./sorteios');
const {
  handleLoja,
  handleLicenseMessage,
  restorePanels: restaurarPaineisLoja,
} = require('./loja');
const { handleRanking, restaurarPainelRanking } = require('./ranking');
const { handleCoins } = require('./coins');
const {
  handleBlacklist,
  restaurarPainelBlacklist,
  iniciarRotinaVerificacaoDiaria,
} = require('./blacklist');
const { handleRegistrar } = require('./exposed');
const { handlePing, handlePingMessage, handlePingInteraction } = require('./ping');
const { automatizarPaineisGuild } = require('./automacao_paineis');
const { verificarEmojis }                        = require('./avisos_mensagens');
const {
  botManager,
  botsPanelPayload,
  botsModal,
  botsRemoveModal,
  botsRemoveSelectPayload,
  isBotsOwner,
  rememberBotsPanel,
  refreshBotsPanels,
  setControllerClient,
} = require('./bots');

const { carregarBotCache, salvarBotCache } = require('./storage');
const { EMOJI_PAINEL, stripEmoji } = require('./visual');

// ── Token ──────────────────────────────────────────────────────────────────────
const TOKEN = process.env.DISCORD_BOT_TOKEN || process.env.DISCORD_TOKEN;
if (!TOKEN) { console.error('[FATAL] DISCORD_BOT_TOKEN não configurado. Adicione a variável de ambiente DISCORD_BOT_TOKEN.'); process.exit(1); }

// ── Cliente Discord ────────────────────────────────────────────────────────────
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
});

if (process.send) {
  process.on('message', (message) => {
    if (message?.type === 'guild_check') {
      process.send({
        type: 'guild_check_result',
        requestId: message.requestId,
        present: client.guilds.cache.has(String(message.guildId)),
      });
      return;
    }
    if (message?.type === 'leave_guild') {
      client.guilds.cache.get(String(message.guildId))?.leave()
        .then(() => process.send({ type: 'leave_guild_result', requestId: message.requestId, ok: true }))
        .catch((error) => process.send({ type: 'leave_guild_result', requestId: message.requestId, ok: false, error: error.message }));
    }
  });
}

// ── Estado — /config_bot ───────────────────────────────────────────────────────
const painelOrigem = new Map(); // guildId:userId -> interaction original

function chavePainelOrigem(guildId, userId) {
  return `${guildId}:${userId}`;
}

// Cache do perfil do bot — carregado do disco ou preenchido no ready
let cache    = { nome: '', bio: '', avatar: '', banner: '' };
let defaults = { nome: '', bio: '', avatar: '', banner: '' };

const cachedData = carregarBotCache();
if (cachedData) {
  cache    = { ...cache,    ...cachedData };
  defaults = { ...defaults, ...cachedData };
  console.log('[INFO] Cache do bot restaurado do disco.');
}

// ── Flags v2 (Components v2) ───────────────────────────────────────────────────
const V2 = MessageFlags.IsComponentsV2;

// ── Paineis — Components v2 (/config_bot) ─────────────────────────────────────

function containerPrincipal(guildId, ultimaAcao = null) {
  let texto =
    `## Painel de Gerenciamento do Perfil do Bot\n\n` +
    'Utilize este painel para gerenciar o perfil público do bot em tempo real, diretamente pelo Discord. ' +
    'Todas as alterações são aplicadas imediatamente na conta do bot e ficam visíveis para todos os usuários do servidor.\n\n' +
    '**Opções disponíveis**\n' +
    '`Nome` — Altera o nome de usuário exibido pelo bot em todos os servidores\n' +
    '`Bio` — Altera a biografia exibida no perfil do bot (visível ao clicar no avatar)\n' +
    '`Avatar` — Substitui a foto de perfil do bot por uma nova imagem via URL\n' +
    '`Banner` — Substitui o banner do perfil do bot por uma nova imagem via URL\n' +
    '`Status` — Define o status de presença do bot (Online, Ausente, Não Perturbe ou Invisível)\n\n' +
    'Use o menu abaixo para selecionar a opção desejada. ' +
    'O botão **Resetar Perfil** restaura todas as configurações para os valores originais do bot.';

  if (ultimaAcao) texto += `\n\n**Resultado da última alteração**\n${stripEmoji(ultimaAcao)}`;

  return new ContainerBuilder()
    .setAccentColor(getConfig(guildId).embedColor)
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(texto))
    .addActionRowComponents(menuPrincipal())
    .addActionRowComponents(rowResetar());
}

function containerStatus(guildId) {
  const texto =
    `## Configuração de Status de Presença\n\n` +
    'Selecione o tipo de status que deseja aplicar ao bot. ' +
    'O status é exibido ao lado do avatar do bot na lista de membros e no perfil. ' +
    'A alteração é aplicada imediatamente após a seleção no menu abaixo.\n\n' +
    '**Tipos de status disponíveis**\n' +
    '`Online` — O bot aparece como disponível e ativo para todos os usuários\n' +
    '`Ausente` — O bot aparece com o indicador amarelo de ausência (away)\n' +
    '`Não Perturbe` — O bot aparece com o indicador vermelho de não perturbe (DND)\n' +
    '`Invisível` — O bot aparece como offline para todos os usuários, mas continua funcionando normalmente';

  return new ContainerBuilder()
    .setAccentColor(getConfig(guildId).embedColor)
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(texto))
    .addActionRowComponents(menuStatus())
    .addActionRowComponents(rowVoltar());
}

// ── Componentes — /config_bot ─────────────────────────────────────────────────
function menuPrincipal() {
  return new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId('cfg:acao')
      .setPlaceholder('Escolha a ação que deseja executar no perfil')
      .addOptions(
        { label: 'Nome',   value: 'nome',   description: 'Alterar o nome de usuário exibido pelo bot'  },
        { label: 'Bio',    value: 'bio',    description: 'Alterar a biografia do perfil do bot'         },
        { label: 'Avatar', value: 'avatar', description: 'Substituir a foto de perfil do bot'           },
        { label: 'Banner', value: 'banner', description: 'Substituir o banner do perfil do bot'         },
        { label: 'Status', value: 'status', description: 'Definir o status de presença do bot'          }
      )
  );
}

function menuStatus() {
  return new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId('cfg:status_tipo')
      .setPlaceholder('Selecione o tipo de status')
      .addOptions(
        { label: 'Online',       value: 'online',    description: 'Exibe o bot como disponível (indicador verde)'   },
        { label: 'Ausente',      value: 'idle',      description: 'Exibe o bot como ausente (indicador amarelo)'    },
        { label: 'Não Perturbe', value: 'dnd',       description: 'Exibe o bot como não perturbe (indicador vermelho)' },
        { label: 'Invisível',    value: 'invisible', description: 'Exibe o bot como offline para todos'             }
      )
  );
}

function rowVoltar() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('cfg:voltar').setLabel('Voltar').setStyle(ButtonStyle.Secondary)
  );
}

function rowResetar() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('cfg:resetar').setLabel('Resetar Perfil').setStyle(ButtonStyle.Danger)
  );
}

// ── Modais — /config_bot ───────────────────────────────────────────────────────
function modalNome() {
  const modal = new ModalBuilder().setCustomId('cfg:modal_nome').setTitle('Alterar Nome de Usuário do Bot');
  const campo = new TextInputBuilder()
    .setCustomId('novo_nome').setLabel('Novo nome de usuário do bot')
    .setStyle(TextInputStyle.Short).setMinLength(2).setMaxLength(32).setRequired(true)
    .setPlaceholder('Ex: MeuBot, Assistente, ModeradorAutomatico');
  if (cache.nome) campo.setValue(cache.nome);
  modal.addComponents(new ActionRowBuilder().addComponents(campo));
  return modal;
}

function modalBio() {
  const modal = new ModalBuilder().setCustomId('cfg:modal_bio').setTitle('Alterar Biografia do Perfil do Bot');
  const campo = new TextInputBuilder()
    .setCustomId('nova_bio').setLabel('Nova biografia do bot (max. 190 caracteres)')
    .setStyle(TextInputStyle.Paragraph).setMaxLength(190).setRequired(false)
    .setPlaceholder('Descreva o bot em até 190 caracteres. Deixe vazio para remover a biografia atual.');
  if (cache.bio) campo.setValue(cache.bio);
  modal.addComponents(new ActionRowBuilder().addComponents(campo));
  return modal;
}

function modalImagem(tipo) {
  const tipoLabel = tipo === 'avatar' ? 'Foto de Perfil (Avatar)' : 'Banner do Perfil';
  const urlAtual  = tipo === 'avatar' ? cache.avatar : cache.banner;
  const modal = new ModalBuilder()
    .setCustomId(`cfg:modal_img_${tipo}`).setTitle(`Alterar ${tipoLabel}`);
  const campo = new TextInputBuilder()
    .setCustomId('url_imagem').setLabel(`URL da nova imagem para o ${tipo === 'avatar' ? 'avatar' : 'banner'}`)
    .setStyle(TextInputStyle.Short).setRequired(true)
    .setPlaceholder('https://exemplo.com/imagem.png (deve ser uma URL pública e direta para a imagem)');
  if (urlAtual) campo.setValue(urlAtual);
  modal.addComponents(new ActionRowBuilder().addComponents(campo));
  return modal;
}

// ── Auxiliares — /config_bot ──────────────────────────────────────────────────
async function atualizarPainel(guildId, userId, container) {
  const orig = painelOrigem.get(chavePainelOrigem(guildId, userId));
  if (!orig) return;
  try {
    await orig.editReply({ flags: V2, components: [container] });
  } catch (err) {
    console.error('[ERRO] Falha ao atualizar painel:', err.message);
  }
}

async function ackModal(interaction) {
  await interaction.reply({ content: '\u200b', flags: MessageFlags.Ephemeral });
}

function atualizarCargoBot(novoNome, nomeAnterior = cache.nome) {
  const tarefas = [];
  for (const guild of client.guilds.cache.values()) {
    const membro = guild.members.me;
    if (!membro) continue;
    // Integration-managed roles cannot be renamed. Only update an editable
    // regular role that was created for the previous bot name.
    const cargo = membro.roles.cache.find(
      (role) => !role.managed && role.name === nomeAnterior && role.editable,
    );
    if (!cargo) continue;
    tarefas.push(
      cargo.setName(novoNome)
        .then(() => console.log(`[INFO] Cargo atualizado em "${guild.name}": ${novoNome}`))
        .catch((err) => console.warn(`[AVISO] Cargo em "${guild.name}": ${err.message}`))
    );
  }
  return Promise.all(tarefas);
}

// ── Lista Oficial de Comandos Slash ──────────────────────────────────────────
const COMANDOS_SLASH = [
  {
    name: 'ping',
    description: 'Exibe o painel com as informações de latência, conexão e status do bot',
  },
  {
    name: 'ajuda',
    description: 'Exibe a central de ajuda com a lista de comandos disponíveis',
  },
  {
    name: 'config',
    description: 'Comandos de configuração do bot',
    default_member_permissions: String(PermissionFlagsBits.Administrator),
    options: [
      {
        type: 1, // SUB_COMMAND
        name: 'bot',
        description: 'Abre o painel de gerenciamento do perfil do bot (nome, bio, avatar, banner, status)',
      },
    ],
  },
  {
    name: 'configurar',
    description: 'Abre o painel de configurações do servidor (cargos, canais, taxa, QR Code, etc.)',
    default_member_permissions: '8', // ADMINISTRATOR
  },
  {
    name: 'iniciar',
    description: 'Configura as filas, os valores, a taxa e os canais do sistema.',
    default_member_permissions: String(PermissionFlagsBits.ManageGuild),
  },
  {
    name: 'filas',
    description: 'Abre o painel de configuração e envio de filas Free Fire',
    default_member_permissions: '8', // ADMINISTRATOR
    options: [
      {
        type: 1, // SUB_COMMAND
        name: 'gerenciar',
        description: 'Abre o painel de gerenciamento e envio de filas',
      },
    ],
  },
  {
    name: 'fila',
    description: 'Comandos de gerenciamento e consulta de filas',
    options: [
      {
        type: 1, // SUB_COMMAND
        name: 'mediador',
        description: 'Abre o painel de fila de mediadores',
      },
      {
        type: 1, // SUB_COMMAND
        name: 'streamer',
        description: 'Abre o painel de configuração e envio de filas de streamers',
      },
      {
        type: 1, // SUB_COMMAND
        name: 'analista',
        description: 'Abre o painel público de fila de analistas',
      },
    ],
  },
  {
    name: 'loja',
    description: 'Gerencia a Loja de Coins',
    default_member_permissions: '8', // ADMINISTRATOR
    options: [
      {
        type: 1, // SUB_COMMAND
        name: 'coins',
        description: 'Abre o painel administrativo da Loja de Coins',
      },
    ],
  },
  {
    name: 'plano',
    description: 'Concede acesso a um bot filho para um membro',
    options: [
      {
        type: 1,
        name: 'dar',
        description: 'Envia por DM um plano de acesso não pago',
        options: [
          {
            type: 3,
            name: 'nome_da_chave',
            description: 'Nome que aparecerá na chave concedida',
            required: true,
            max_length: 100,
          },
          {
            type: 4,
            name: 'duracao',
            description: 'Duração em dias; use 0 para acesso infinito',
            required: true,
            min_value: 0,
          },
          {
            type: 6,
            name: 'membro',
            description: 'Membro que receberá o plano por DM',
            required: true,
          },
        ],
      },
    ],
  },
  {
    name: 'coins',
    description: 'Comandos de gerenciamento de Coins',
    default_member_permissions: '8', // ADMINISTRATOR
    options: [
      {
        type: 1, // SUB_COMMAND
        name: 'gerenciar',
        description: 'Adiciona ou remove Coins de um membro',
        options: [
          {
            type: 3, // STRING
            name: 'acao',
            description: 'Escolha se deseja adicionar ou remover Coins',
            required: true,
            choices: [
              { name: 'Adicionar', value: 'adicionar' },
              { name: 'Remover', value: 'remover' },
            ],
          },
          {
            type: 6, // USER
            name: 'membro',
            description: 'Membro que receberá a movimentação',
            required: true,
          },
          {
            type: 4, // INTEGER
            name: 'quantidade',
            description: 'Quantidade de Coins',
            required: true,
            min_value: 1,
          },
        ],
      },
    ],
  },
  {
    name: 'aux',
    description: 'Abre o painel auxiliar de finalização rápida para mediadores',
  },
  {
    name: 'ranking',
    description: 'Abre o painel de perfil e ranking de vitórias',
    options: [
      {
        type: 1,
        name: 'painel',
        description: 'Abre o painel de perfil e ranking de vitórias',
      },
    ],
  },
  {
    name: 'blacklist',
    description: 'Comandos de consulta e gerenciamento da blacklist Free Fire',
    options: [
      {
        type: 1,
        name: 'painel',
        description: 'Abre o painel público de consulta de blacklist Free Fire',
      },
      {
        type: 1,
        name: 'adicionar',
        description: 'Adiciona um jogador à blacklist do servidor',
      },
      {
        type: 1,
        name: 'remover',
        description: 'Remove um jogador da blacklist do servidor',
      },
    ],
  },
  {
    name: 'sorteio',
    description: 'Gerenciamento, configuração, revogação e reinício de sorteios',
    default_member_permissions: '8',
    options: [
      {
        type: 1, // SUB_COMMAND
        name: 'painel',
        description: 'Abre o painel principal de sorteios',
      },
      {
        type: 1, // SUB_COMMAND
        name: 'revogar',
        description: 'Abre o painel para revogar ou cancelar um sorteio ativo',
      },
      {
        type: 1, // SUB_COMMAND
        name: 'reiniciar',
        description: 'Abre o painel para reiniciar ou re-sortear um sorteio',
      },
    ],
  },
  {
    name: 'tickets',
    description: 'Gerenciamento, configuração e fechamento de tickets',
    default_member_permissions: '8',
    options: [
      {
        type: 1, // SUB_COMMAND
        name: 'painel',
        description: 'Abre o painel de configuração e publicação de tickets',
      },
      {
        type: 1, // SUB_COMMAND
        name: 'fechar',
        description: 'Fecha o ticket atual ou abre o painel para fechar tickets abertos',
      },
    ],
  },
  {
    name: 'avisos',
    description: 'Abre o painel de gerenciamento de avisos automáticos do servidor',
    default_member_permissions: '8',
  },
  {
    name: 'limpar',
    description: 'Apaga mensagens deste canal',
    default_member_permissions: String(PermissionFlagsBits.ManageMessages),
    options: [
      {
        type: 4, // INTEGER
        name: 'quantidade',
        description: 'Quantidade de mensagens para apagar (1 a 1000)',
        required: true,
        min_value: 1,
        max_value: 1000,
      },
    ],
  },
  {
    name: 'exposed',
    description: 'Comandos de exposed e moderação de jogadores',
    default_member_permissions: '8', // ADMINISTRATOR
    options: [
      {
        type: 1, // SUB_COMMAND
        name: 'registrar',
        description: 'Abre o painel para registrar exposed e banir um jogador suspeito',
      },
      {
        type: 1, // SUB_COMMAND
        name: 'historico',
        description: 'Exibe o histórico de exposeds com filtro por analista',
        options: [
          {
            type: 6, // USER
            name: 'analista',
            description: 'Filtrar histórico por um analista específico',
            required: false,
          },
        ],
      },
    ],
  },
];

// ── Registro de Comandos ───────────────────────────────────────────────────────
async function registrarComandos(appId, clientInstance, tokenCustom) {
  const tokenToUse = tokenCustom || TOKEN;
  if (!tokenToUse || !appId) return;
  const rest = new REST({ version: '10' }).setToken(tokenToUse);
  try {
    console.log(`[INFO] Registrando comandos slash globais para app ${appId}...`);
    await rest.put(Routes.applicationCommands(appId), {
      body: COMANDOS_SLASH,
    });
    console.log('[INFO] Comandos registrados com sucesso (escopo global único).');

    // Limpar comandos locais de guildas para evitar duplicidade com os comandos globais
    if (clientInstance?.guilds?.cache?.size) {
      for (const guild of clientInstance.guilds.cache.values()) {
        try {
          await rest.put(Routes.applicationGuildCommands(appId, guild.id), {
            body: [],
          });
        } catch (gErr) {
          // Silencioso se não tiver permissão na guilda
        }
      }
      console.log('[INFO] Limpeza de comandos de guilda concluída (sem duplicatas).');
    }
  } catch (err) {
    console.error('[ERRO] Falha ao registrar comandos:', err.message);
  }
}

// ── ClientReady ────────────────────────────────────────────────────────────────
client.once(Events.ClientReady, async (c) => {
  console.log(`[INFO] Bot online como ${c.user.tag}`);
  if (process.send) {
    process.send({
      type: 'ready',
      tag: c.user.tag,
      id: c.user.id,
      guildCount: c.guilds.cache.size,
    });
  }
  if (IS_WORKER) {
    // Workers registram seus comandos e ficam prontos para atender interações
    await registrarComandos(c.application.id, c, process.env.DISCORD_TOKEN);
    return;
  }
  try {
    const invite = await c.generateInvite({
      scopes: ['bot', 'applications.commands'],
      permissions: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ReadMessageHistory,
        PermissionFlagsBits.ManageMessages,
        PermissionFlagsBits.ManageChannels,
        PermissionFlagsBits.ManageThreads,
        PermissionFlagsBits.CreatePublicThreads,
        PermissionFlagsBits.SendMessagesInThreads,
        PermissionFlagsBits.ManageRoles,
        PermissionFlagsBits.AttachFiles,
        PermissionFlagsBits.EmbedLinks,
      ],
    });
    console.log(`[INFO] Link de convite do bot: ${invite}`);
  } catch (error) {
    console.warn('[AVISO] Não foi possível gerar o link de convite:', error.message);
  }
  setControllerClient(c);

  await registrarComandos(c.application.id, c);
  await verificarEmojis(c);

  // Se já temos cache do disco, não precisamos buscar novamente (economiza requisições)
  if (!cachedData) {
    cache.nome   = defaults.nome   = c.user.username ?? '';
    cache.avatar = defaults.avatar = c.user.avatarURL({ extension: 'png', size: 4096 }) ?? '';
    cache.banner = defaults.banner = c.user.bannerURL?.({ extension: 'png', size: 4096 }) ?? '';
    try {
      const app   = await c.application.fetch();
      cache.bio   = defaults.bio = app.description ?? '';
    } catch (_) { cache.bio = defaults.bio = ''; }
    salvarBotCache(cache);
    console.log('[INFO] Cache de perfil inicializado e salvo no disco.');
  } else {
    console.log('[INFO] Cache de perfil restaurado do disco — ignorando fetch da API.');
  }

  if (!IS_WORKER) {
    try {
      botManager.importNumberedEnvironment();
      const result = await botManager.startAll();
      if (!result.ok && result.message !== 'Nenhum token cadastrado.') {
        console.error(`[MULTI] ${result.message}`);
      } else if (result.ok) {
        console.log('[MULTI] Workers cadastrados no cofre iniciados automaticamente.');
      }
    } catch (error) {
      console.error('[MULTI] Falha ao iniciar bots numerados:', error.message);
    }
  }

  // Restaurar painéis de filas e mediadores após reinício
  const restaurarTodosOsPaineis = async () => {
    try {
      await restaurarPaineis(client);
      await restaurarPainelMediador(client);
      await restaurarPainelFilaAnalista(client);
      await restaurarPainelRanking(client);
      await restaurarPaineisStreamer(client);
      await restaurarPartidas(client);
      await restaurarPaineisTickets(client);
      await restaurarAvisos(client);
      await restaurarPaineisLoja(client);
      await restaurarPaineisSorteios(client);
      await restaurarPainelBlacklist(client);
      iniciarRotinaVerificacaoDiaria(client);
    } catch (e) {
      console.error('[INFO] Erro ao restaurar/atualizar painéis:', e.message);
    }
  };

  setTimeout(async () => {
    await restaurarTodosOsPaineis();

    // Loop infinito de 30 minutos para atualizar URLs de imagens e manter todos os painéis renovados
    setInterval(async () => {
      console.log('[AUTO-REFRESH] Executando renovação de 30 minutos em todos os painéis e URLs de imagens...');
      await restaurarTodosOsPaineis();
    }, 30 * 60 * 1000);
  }, 3000); // aguarda guilds serem cacheadas
});

client.on(Events.GuildCreate, async (guild) => {
  console.log(`[AUTO] Bot adicionado à guild ${guild.id} (${guild.name}). Sincronizando comandos e procurando canais dos painéis.`);
  try {
    const rest = new REST({ version: '10' }).setToken(TOKEN);
    await rest.put(Routes.applicationGuildCommands(client.application.id, guild.id), {
      body: COMANDOS_SLASH,
    }).catch(() => null);
  } catch (_) {}
  await automatizarPaineisGuild(guild);

  // Logo após entrar, o Discord ainda pode estar sincronizando o membro do
  // bot e as permissões dos canais. Repetir a descoberta evita que um evento
  // GuildCreate momentaneamente incompleto impeça a publicação automática.
  for (const atraso of [5000, 20000]) {
    setTimeout(() => {
      automatizarPaineisGuild(guild).catch((error) => {
        console.error(`[AUTO] Falha na nova tentativa da guild ${guild.id}:`, error.message);
      });
    }, atraso);
  }
});

// ── Dispatcher de Alta Performance para Interações ───────────────────────────
async function dispatchInteraction(interaction, client) {
  // Comandos slash
  if (interaction.isChatInputCommand()) {
    const cmd = interaction.commandName;

    // Verificar se o servidor possui plano ativo para os comandos protegidos
    if (interaction.guildId) {
      const plano = verificarPlanoAtivo(interaction.guildId, interaction.member);
      if (!plano.ativo) {
        await responderSemPlano(interaction);
        return true;
      }
    }

    if (cmd === 'ping') return handlePing(interaction, client);
    if (cmd === 'ajuda') return handleAjuda(interaction);
    if (cmd === 'p') return handlePerfil(interaction, client);
    if (cmd === 'iniciar') return handleIniciar(interaction, client);
    if (cmd === 'filas') return handleFilas(interaction, client);
    if (cmd === 'coins') return handleCoins(interaction, client);
    if (cmd === 'loja' || cmd === 'plano' || cmd === 'dar') return handleLoja(interaction, client);
    if (cmd === 'sorteios' || cmd === 'sorteio') return handleSorteios(interaction, client);
    if (cmd === 'ranking') return handleRanking(interaction);
    if (cmd === 'blacklist') return handleBlacklist(interaction);
    if (cmd === 'streamer') return handleFilaStreamer(interaction, client);
    if (cmd === 'fila') {
      const sub = interaction.options?.getSubcommand?.(false);
      if (sub === 'mediador') return handleFilaMediador(interaction, client);
      if (sub === 'streamer') return handleFilaStreamer(interaction, client);
      if (sub === 'analista') return handleFilaAnalista(interaction, client);
      return handleFilas(interaction, client);
    }
    if (cmd === 'mediador') return handleFilaMediador(interaction, client);
    if (cmd === 'analista') return handleFilaAnalista(interaction, client);
    if (cmd === 'aux') return handleAux(interaction, client);
    if (cmd === 'tickets' || cmd === 'ticket') return handleTickets(interaction, client);
    if (cmd === 'avisos') return handleAvisos(interaction, client);
    if (cmd === 'limpar') return handleLimpar(interaction);
    if (cmd === 'configurar' || cmd === 'configurar_servidor' || cmd === 'painel_config') return handleConfigurar(interaction);
    if (cmd === 'exposed' || cmd === 'registrar') return handleRegistrar(interaction, client);
    return false;
  }

  const id = interaction.customId || '';
  if (!id) return false;

  // Interações da Central de Desenvolvedor (devem funcionar para resgate e compras de planos)
  if (id.startsWith('dev:') || id.startsWith('dev_')) {
    return handleDevCentral(interaction, client);
  }

  // Interações de Ajuda
  if (id.startsWith('ajuda:')) {
    if (interaction.guildId) {
      const plano = verificarPlanoAtivo(interaction.guildId, interaction.member);
      if (!plano.ativo) {
        await responderSemPlano(interaction);
        return true;
      }
    }
    return handleAjuda(interaction);
  }

  // Roteamento instantâneo por prefixo do customId
  if (id.startsWith('exposed:')) {
    return handleRegistrar(interaction, client);
  }
  if (id.startsWith('fq:') || id.startsWith('filas:') || id.startsWith('filas_')) {
    return handleFilas(interaction, client);
  }
  if (id.startsWith('ticket:') || id.startsWith('tickets:')) {
    return handleTickets(interaction, client);
  }
  if (id.startsWith('partida:')) {
    return handlePartida(interaction, client);
  }
  if (id.startsWith('aux:') || id.startsWith('aux_')) {
    return handleAux(interaction, client);
  }
  if (id.startsWith('fmed:') || id.startsWith('fila_med:')) {
    return handleFilaMediador(interaction, client);
  }
  if (id.startsWith('fstr:') || id.startsWith('fila_str:')) {
    return handleFilaStreamer(interaction, client);
  }
  if (id.startsWith('fana:') || id.startsWith('fila_ana:')) {
    return handleFilaAnalista(interaction, client);
  }
  if (id.startsWith('sorteio:') || id.startsWith('sorteios:')) {
    return handleSorteios(interaction, client);
  }
  if (id.startsWith('ranking:') || id.startsWith('rank:')) {
    return handleRanking(interaction);
  }
  if (id.startsWith('bl:') || id.startsWith('blacklist:')) {
    return handleBlacklist(interaction);
  }
  if (id.startsWith('conf:') || id.startsWith('config:')) {
    return handleConfigurar(interaction);
  }
  if (id.startsWith('lic:') || id.startsWith('loja:')) {
    return handleLoja(interaction, client);
  }
  if (id.startsWith('avisos:') || id.startsWith('aviso:')) {
    return handleAvisos(interaction, client);
  }
  if (id.startsWith('iniciar:') || id.startsWith('init:')) {
    return handleIniciar(interaction, client);
  }
  if (id.startsWith('ping:')) {
    return handlePingInteraction(interaction, client);
  }
  if (id.startsWith('p:')) {
    return handlePerfil(interaction, client);
  }

  return false;
}

// ── Interacoes ─────────────────────────────────────────────────────────────────
client.on(Events.InteractionCreate, async (interaction) => {
  try {
    // ── Roteamento rápido direto por comando ou prefixo ─────────────────────
    if (await dispatchInteraction(interaction, client)) return;

    // ── /config bot ou /config_bot ──────────────────────────────────────────
    if (interaction.isChatInputCommand() && (interaction.commandName === 'config_bot' || (interaction.commandName === 'config' && interaction.options.getSubcommand(false) === 'bot'))) {
      if (interaction.guildId) {
        const plano = verificarPlanoAtivo(interaction.guildId, interaction.member);
        if (!plano.ativo) {
          await responderSemPlano(interaction);
          return;
        }
      }

      const isAdministrator = interaction.memberPermissions?.has(PermissionFlagsBits.Administrator);
      if (!isAdministrator && !isBotsOwner(interaction.member)) {
        await interaction.reply({
          content: 'Apenas administradores ou o cargo de dono configurado podem alterar o perfil do bot.',
          flags: MessageFlags.Ephemeral,
        });
        return;
      }
      const painelKey = chavePainelOrigem(interaction.guildId, interaction.user.id);
      const anterior = painelOrigem.get(painelKey);
      if (anterior) anterior.deleteReply().catch(() => {});

      await interaction.reply({
        ephemeral: true,
        flags: V2,
          components: [containerPrincipal(interaction.guildId)],
      });
      painelOrigem.set(painelKey, interaction);
      return;
    }

    // ── Botão: Voltar (config_bot) ─────────────────────────────────────────
    if (interaction.isButton() && interaction.customId === 'cfg:voltar') {
      await interaction.deferUpdate();
      await atualizarPainel(interaction.guildId, interaction.user.id, containerPrincipal(interaction.guildId));
      return;
    }

    // ── Botão: Resetar ─────────────────────────────────────────────────────
    if (interaction.isButton() && interaction.customId === 'cfg:resetar') {
      await interaction.deferUpdate();
      const erros = [];
      const nomeAnterior = cache.nome;

      const [nomeErr, bioErr] = await Promise.all([
        client.user.setUsername(defaults.nome)
          .then(() => { cache.nome = defaults.nome; return null; })
          .catch((e) => e.message),
        client.rest.patch(Routes.currentApplication(), { body: { description: defaults.bio } })
          .then(() => { cache.bio = defaults.bio; return null; })
          .catch((e) => e.message),
      ]);
      if (nomeErr) erros.push(`Nome: ${nomeErr}`);
      if (bioErr)  erros.push(`Bio: ${bioErr}`);

      const avatarErr = await client.user.setAvatar(defaults.avatar || null)
        .then(() => { cache.avatar = defaults.avatar; return null; })
        .catch((e) => e.message);
      if (avatarErr) erros.push(`Avatar: ${avatarErr}`);

      const bannerErr = await client.user.setBanner(defaults.banner || null)
        .then(() => { cache.banner = defaults.banner; return null; })
        .catch((e) => e.message);
      if (bannerErr) erros.push(`Banner: ${bannerErr}`);

      try { client.user.setPresence({ status: 'online', activities: [] }); }
      catch (e) { erros.push(`Status: ${e.message}`); }

      salvarBotCache(cache);

      const msg = erros.length === 0
        ? 'O perfil do bot foi resetado com sucesso para todos os valores originais. Nome, bio, avatar, banner e status foram restaurados.'
        : `Reset concluído com alguns avisos em ${erros.length} item(ns). Consulte os logs do bot para obter detalhes.`;

      await atualizarPainel(interaction.guildId, interaction.user.id, containerPrincipal(interaction.guildId, msg));
      if (!nomeErr) atualizarCargoBot(defaults.nome, nomeAnterior);
      return;
    }

    // ── Select Menu Principal ─────────────────────────────────────────────
    if (interaction.isStringSelectMenu() && interaction.customId === 'cfg:acao') {
      const escolha = interaction.values[0];

      if (escolha === 'nome')   { await interaction.showModal(modalNome());           return; }
      if (escolha === 'bio')    { await interaction.showModal(modalBio());            return; }
      if (escolha === 'avatar') { await interaction.showModal(modalImagem('avatar')); return; }
      if (escolha === 'banner') { await interaction.showModal(modalImagem('banner')); return; }

      if (escolha === 'status') {
        await interaction.deferUpdate();
        await atualizarPainel(interaction.guildId, interaction.user.id, containerStatus(interaction.guildId));
        return;
      }
    }

    // ── Select Menu Status ────────────────────────────────────────────────
    if (interaction.isStringSelectMenu() && interaction.customId === 'cfg:status_tipo') {
      await interaction.deferUpdate();
      const tipo        = interaction.values[0];
      const statusLabel = { online: 'Online', idle: 'Ausente', dnd: 'Não Perturbe', invisible: 'Invisível' }[tipo] ?? tipo;
      try {
        client.user.setPresence({ status: tipo, activities: [] });
        await atualizarPainel(interaction.guildId, interaction.user.id,
           containerPrincipal(
             interaction.guildId,
            `Status alterado com sucesso para **${statusLabel}**.\n` +
            `O novo status já é visível na lista de membros do servidor.`
          )
        );
      } catch (err) {
        console.error('[ERRO] Status:', err.message);
        await atualizarPainel(interaction.guildId, interaction.user.id,
           containerPrincipal(interaction.guildId, 'Não foi possível alterar o status. Tente novamente mais tarde.')
        );
      }
      return;
    }

    // ── Modal: Nome ───────────────────────────────────────────────────────
    if (interaction.isModalSubmit() && interaction.customId === 'cfg:modal_nome') {
      await ackModal(interaction);
      const novoNome = interaction.fields.getTextInputValue('novo_nome');
      const nomeAnterior = cache.nome;
      try {
        await client.user.setUsername(novoNome);
        cache.nome = novoNome;
        salvarBotCache(cache);
        await atualizarPainel(interaction.guildId, interaction.user.id,
           containerPrincipal(
             interaction.guildId,
            `Nome de usuário alterado com sucesso para **${novoNome}**.\n` +
            `A mudança já é visível em todos os servidores onde o bot está presente.`
          )
        );
        atualizarCargoBot(novoNome, nomeAnterior);
      } catch (err) {
        console.error('[ERRO] Nome:', err.message);
        await atualizarPainel(interaction.guildId, interaction.user.id,
           containerPrincipal(
             interaction.guildId,
            'Não foi possível alterar o nome. Verifique o limite de alterações do Discord e tente novamente mais tarde.'
          )
        );
      }
      return;
    }

    // ── Modal: Bio ────────────────────────────────────────────────────────
    if (interaction.isModalSubmit() && interaction.customId === 'cfg:modal_bio') {
      await ackModal(interaction);
      const novaBio = interaction.fields.getTextInputValue('nova_bio');
      try {
        await client.rest.patch(Routes.currentApplication(), { body: { description: novaBio } });
        cache.bio = novaBio;
        salvarBotCache(cache);
        const msg = novaBio
          ? `A biografia foi atualizada com sucesso.\nNova bio: **${novaBio}**\nEla será exibida ao clicar no perfil do bot.`
          : 'A biografia foi removida com sucesso. O perfil do bot agora não exibe nenhuma biografia.';
         await atualizarPainel(interaction.guildId, interaction.user.id, containerPrincipal(interaction.guildId, msg));
      } catch (err) {
        console.error('[ERRO] Bio:', err.message);
        await atualizarPainel(interaction.guildId, interaction.user.id,
           containerPrincipal(interaction.guildId, 'Não foi possível alterar a biografia. Tente novamente mais tarde.')
        );
      }
      return;
    }

    // ── Modal: Avatar ─────────────────────────────────────────────────────
    if (interaction.isModalSubmit() && interaction.customId === 'cfg:modal_img_avatar') {
      await ackModal(interaction);
      const url = interaction.fields.getTextInputValue('url_imagem').trim();
      try {
        await client.user.setAvatar(url);
        cache.avatar = url;
        salvarBotCache(cache);
        await atualizarPainel(interaction.guildId, interaction.user.id,
           containerPrincipal(
             interaction.guildId,
            'O avatar foi atualizado com sucesso.\n' +
            'A nova foto de perfil já é exibida em todos os servidores onde o bot está presente. ' +
            'Pode levar alguns segundos para o cache do Discord ser atualizado.'
          )
        );
      } catch (err) {
        console.error('[ERRO] Avatar:', err.message);
         await atualizarPainel(interaction.guildId, interaction.user.id,
           containerPrincipal(interaction.guildId, 'Não foi possível alterar o avatar. Verifique se a URL é pública e aponta diretamente para uma imagem válida.')
        );
      }
      return;
    }

    // ── Modal: Banner ─────────────────────────────────────────────────────
    if (interaction.isModalSubmit() && interaction.customId === 'cfg:modal_img_banner') {
      await ackModal(interaction);
      const url = interaction.fields.getTextInputValue('url_imagem').trim();
      try {
        await client.user.setBanner(url);
        cache.banner = url;
        salvarBotCache(cache);
        await atualizarPainel(interaction.guildId, interaction.user.id,
           containerPrincipal(
             interaction.guildId,
            'O banner de perfil foi atualizado com sucesso.\n' +
            'A nova imagem já é exibida ao acessar o perfil completo do bot. ' +
            'Obs.: banners de perfil são visíveis apenas para contas com Nitro ou bots verificados.'
          )
        );
      } catch (err) {
        console.error('[ERRO] Banner:', err.message);
         await atualizarPainel(interaction.guildId, interaction.user.id,
           containerPrincipal(interaction.guildId, 'Não foi possível alterar o banner. Verifique se a URL é pública e aponta diretamente para uma imagem válida.')
        );
      }
      return;
    }

  } catch (err) {
    if (err?.code === 10062 || err?.code === 40060 || err?.message?.includes('Unknown interaction')) return;
    console.error('[ERRO] InteractionCreate:', err.message, err.code ?? '', err.stack ?? '');
    const reply = {
      content: 'Ocorreu um erro ao processar esta interação.',
      flags: MessageFlags.Ephemeral,
    };
    if (interaction.replied) {
      await interaction.followUp(reply).catch(() => {});
    } else if (interaction.deferred) {
      await interaction.editReply(reply).catch(() => {});
    } else {
      await interaction.reply(reply).catch(() => {});
    }
  }
});

// ── Remoção automática de filas ao apagar mensagem ou canal ─────────────────
client.on(Events.MessageDelete, (message) => {
  try {
    if (!message?.id) return;
    removerPainelPorMsgId(message.id, message.guildId ?? null);
  } catch (err) {
    console.error('[ERRO] MessageDelete:', err.message);
  }
});

client.on(Events.MessageBulkDelete, (messages) => {
  try {
    for (const [id, msg] of messages) {
      removerPainelPorMsgId(id, msg?.guildId ?? null);
    }
  } catch (err) {
    console.error('[ERRO] MessageBulkDelete:', err.message);
  }
});

client.on(Events.ChannelDelete, (channel) => {
  try {
    if (!channel?.id) return;
    removerPaineisDoCanal(channel.id, channel.guildId ?? null);
  } catch (err) {
    console.error('[ERRO] ChannelDelete:', err.message);
  }
});

// ── Comando por prefixo (.p, .dev central, .bots) ──────────────────────────────
client.on(Events.MessageCreate, async (message) => {
  try {
    if (message.author.bot || !message.guild) return;
    if (await handleDevMessage(message, client)) return;
    if (await handleLicenseMessage(message, client)) return;
    if (await handlePartidaMessage(message, client)) return;
    const texto = typeof message.content === 'string' ? message.content.trim() : '';
    if (!texto) return;
    const [command] = texto.split(/\s+/);

    // Comando de Sincronização e Auto-Update Remoto (.atualizar ou .sync)
    if (['.atualizar', '.sync', '.update'].includes(command.toLowerCase())) {
      if (!isBotsOwner(message.member)) {
        await message.reply('❌ Apenas o dono ou membros com cargo de dono configurado podem executar atualizações.');
        return;
      }

      const statusMsg = await message.reply('🔄 **Buscando atualizações no Google AI Studio...**\nConectando à API de sincronização remota...');
      try {
        const { executeSync, getSyncUrl } = require('../sync');
        const syncUrl = getSyncUrl();
        const res = await executeSync({
          url: syncUrl,
          onProgress: (log) => {
            console.log(`[SYNC] ${log}`);
          },
        });

        await statusMsg.edit(
          `✅ **Bot Atualizado com Sucesso!**\n` +
          `• 📦 **Arquivos sincronizados:** ${res.updatedCount}\n` +
          `• 🕒 **Versão:** \`${res.version || res.timestamp}\`\n` +
          `• 🌐 **Origem:** \`${res.sourceUrl || syncUrl}\`\n\n` +
          `🚀 **Reiniciando o bot em 3 segundos para aplicar as alterações...**`
        );

        setTimeout(() => {
          console.log('[SYNC] Reiniciando processo após auto-update via Discord...');
          process.exit(0);
        }, 3000);
      } catch (syncErr) {
        console.error('[SYNC] Erro no comando .atualizar:', syncErr.message);
        await statusMsg.edit(`❌ **Falha ao atualizar o bot:** \`${syncErr.message}\`\nVerifique se o painel web de desenvolvimento está ativo.`);
      }
      return;
    }

    if (command.toLowerCase() === '.ping') {
      await handlePingMessage(message, client);
      return;
    }

    if (command.toLowerCase() === '.bots') {
      if (!isBotsOwner(message.member)) {
        await message.reply('Apenas membros com o cargo de dono configurado podem abrir o painel de bots.');
        return;
      }
      const panel = await message.reply(botsPanelPayload());
      rememberBotsPanel(message.guildId, message.author.id, panel);
      refreshBotsPanels();
      return;
    }
    if (command.toLowerCase() !== '.p') return;

    // Verificar se o servidor possui plano ativo para o comando .p
    const plano = verificarPlanoAtivo(message.guildId, message.member);
    if (!plano.ativo) {
      await message.reply('❌ Este servidor não possui um plano ativo para utilizar os comandos do bot.').catch(() => {});
      return;
    }

    console.log(`[PERFIL] Comando .p recebido — guild=${message.guildId} canal=${message.channelId} usuário=${message.author.id}`);
    await require('./perfil').handlePerfilMessage(message, client);
  } catch (err) {
    console.error('[ERRO] MessageCreate:', err.message, err.stack ?? '');
  }
});

// ── Painel `.bots` ─────────────────────────────────────────────────────────────
client.on(Events.InteractionCreate, async (interaction) => {
  if (!interaction.isButton() && !interaction.isModalSubmit() && !interaction.isStringSelectMenu()) return;
  const id = interaction.customId ?? '';
  if (!id.startsWith('bots:')) return;

  try {
    if (!isBotsOwner(interaction.member)) {
      await interaction.reply({ content: 'Apenas membros com o cargo de dono configurado podem usar este painel.', flags: MessageFlags.Ephemeral });
      return;
    }

    const panelKey = `${interaction.guildId}:${interaction.user.id}`;
    if (interaction.isButton() && id === 'bots:cadastrar') {
      await interaction.showModal(botsModal());
      return;
    }

    if (interaction.isButton() && id === 'bots:remover') {
      await interaction.reply(botsRemoveSelectPayload());
      return;
    }

    if (interaction.isStringSelectMenu() && id === 'bots:remover:select') {
      const slot = Number(interaction.values[0]);
      if (!Number.isInteger(slot) || slot < 1) {
        await interaction.reply({
          content: 'Token inválido. Atualize o painel e tente novamente.',
          flags: MessageFlags.Ephemeral,
        });
        return;
      }
      await interaction.showModal(botsRemoveModal(slot));
      return;
    }

    if (interaction.isModalSubmit() && id.startsWith('bots:modal_remover_token:')) {
      const slot = Number(id.split(':').pop());
      const confirmation = interaction.fields.getTextInputValue('confirmation').trim().toUpperCase();
      if (confirmation !== 'REMOVER') {
        await interaction.reply({
          content: 'Remoção cancelada. Digite exatamente `REMOVER` para confirmar.',
          flags: MessageFlags.Ephemeral,
        });
        return;
      }
      const result = await botManager.removeToken(slot);
      if (!result.ok) {
        await interaction.reply({ content: result.message, flags: MessageFlags.Ephemeral });
        return;
      }
      await interaction.reply({
        content: `O token do **Bot ${result.slot}** foi removido e os workers foram atualizados. O TEAM RYZE não foi alterado.`,
        flags: MessageFlags.Ephemeral,
      });
      await refreshBotsPanels();
      return;
    }

    if (interaction.isModalSubmit() && id === 'bots:modal_tokens') {
      const raw = interaction.fields.getTextInputValue('tokens');
      const result = await botManager.replaceTokens(raw);
      if (!result.ok) {
        await interaction.reply({ content: result.message, flags: MessageFlags.Ephemeral });
        return;
      }
      const ignored = result.ignored
        ? ` Foram ignorados **${result.ignored}** trecho(s) que não formavam um token válido.`
        : '';
      await interaction.reply({ content: `Tokens cadastrados com segurança: **${result.count}**.${ignored} Clique em **Iniciar** para ligar os bots.`, flags: MessageFlags.Ephemeral });
      await refreshBotsPanels();
      return;
    }

    if (interaction.isButton() && id === 'bots:iniciar') {
      await interaction.deferUpdate();
      const result = await botManager.startAll();
      await interaction.message.edit(botsPanelPayload(result.message));
      rememberBotsPanel(interaction.guildId, interaction.user.id, interaction.message);
      return;
    }

    if (interaction.isButton() && id === 'bots:parar') {
      await interaction.deferUpdate();
      await botManager.stopAll();
      await interaction.message.edit(botsPanelPayload('Bots gerenciados foram desligados.'));
      rememberBotsPanel(interaction.guildId, interaction.user.id, interaction.message);
      return;
    }

    if (interaction.isButton() && id === 'bots:atualizar') {
      await interaction.deferUpdate();
      await interaction.message.edit(botsPanelPayload());
      rememberBotsPanel(interaction.guildId, interaction.user.id, interaction.message);
    }
  } catch (error) {
    console.error(`[INTERAÇÃO ERRO] Falha ao processar interação (tipo: ${interaction.type}, id: ${interaction.customId || interaction.commandName}):`, error?.stack || error?.message || error);
    const reply = { content: 'Ocorreu um erro ao processar esta ação. Verifique as permissões do bot ou os logs.', flags: MessageFlags.Ephemeral };
    try {
      if (interaction.replied) await interaction.followUp(reply).catch(() => {});
      else if (interaction.deferred) await interaction.editReply(reply).catch(() => {});
      else await interaction.reply(reply).catch(() => {});
    } catch (_) {}
  }
});

// ── Login ──────────────────────────────────────────────────────────────────────
client.login(TOKEN).catch((err) => {
  const detail = String(err?.message ?? '');
  const reason = /invalid token/i.test(detail)
    ? 'token rejeitado pelo Discord'
    : /disallowed intents/i.test(detail)
      ? 'intents privilegiadas não permitidas para esta aplicação'
      : 'falha de login no Discord';
  console.error(`[FATAL] ${reason}:`, detail);
  if (process.send) process.send({ type: 'error', message: reason, code: err?.code ?? null });
  process.exit(1);
});

process.on('unhandledRejection', (error) => {
  console.error('[ERRO] Promise rejeitada sem tratamento:', error?.stack ?? error?.message ?? error);
});

process.on('uncaughtException', (error) => {
  console.error('[ERRO] Exceção não capturada:', error?.stack ?? error?.message ?? error);
  if (IS_WORKER) {
    if (process.send) process.send({ type: 'error', message: 'erro interno do worker' });
    process.exit(1);
  }
});
