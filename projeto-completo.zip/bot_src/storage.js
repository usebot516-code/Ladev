'use strict';

/**
 * storage.js — Persistência de dados em JSON local.
 *
 * Os arquivos ficam em data/ e sobrevivem
 * a reinicializações e trocas de processo.
 *
 * Estratégia de escrita:
 *   1. Escreve em arquivo temporário (.tmp).
 *   2. Mantém cópia de backup (.bak).
 *   3. Renomeia atomicamente para o destino final.
 */

const fs   = require('fs');
const path = require('path');
const { dataPath } = require('./data-path');

const DATA_DIR          = path.dirname(dataPath('guild_configs.json'));
const GUILD_CONFIG_FILE = dataPath('guild_configs.json');
const BOT_CACHE_FILE    = dataPath('bot_cache.json');

// Garante que o diretório de dados exista ao importar o módulo.
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  console.log('[STORAGE] Diretório de dados criado:', DATA_DIR);
}

// ── Escrita atômica segura ────────────────────────────────────────────────────

function salvarJSON(filePath, data) {
  const tmp = filePath + '.tmp';
  const bak = filePath + '.bak';
  try {
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

    const content = JSON.stringify(data, null, 2);
    fs.writeFileSync(tmp, content, 'utf8');

    // Se o arquivo original já existir, cria backup antes de sobrescrever
    if (fs.existsSync(filePath)) {
      try { fs.copyFileSync(filePath, bak); } catch (_) {}
    }

    fs.renameSync(tmp, filePath);
  } catch (err) {
    console.error(`[STORAGE] Falha ao salvar ${path.basename(filePath)}:`, err.message);
  }
}

function lerJSON(filePath, defaultValue = null) {
  const bak = filePath + '.bak';
  try {
    if (fs.existsSync(filePath)) {
      const raw = fs.readFileSync(filePath, 'utf8').trim();
      if (raw) return JSON.parse(raw);
    }
  } catch (err) {
    console.error(`[STORAGE] Erro ao ler ${path.basename(filePath)}, tentando backup:`, err.message);
  }

  // Tenta recuperar do backup se o original falhou ou não existe
  try {
    if (fs.existsSync(bak)) {
      const raw = fs.readFileSync(bak, 'utf8').trim();
      if (raw) {
        console.log(`[STORAGE] Recuperado do backup: ${path.basename(bak)}`);
        return JSON.parse(raw);
      }
    }
  } catch (bakErr) {
    console.error(`[STORAGE] Falha também no backup de ${path.basename(filePath)}:`, bakErr.message);
  }

  return defaultValue;
}

// ── Configurações de Servidor (guildConfig) ───────────────────────────────────

/**
 * Carrega o Map de configurações de servidor a partir do JSON persistido.
 * Retorna um Map vazio se o arquivo não existir ou estiver corrompido.
 */
function carregarGuildConfigs() {
  const data = lerJSON(GUILD_CONFIG_FILE, null);
  if (data && typeof data === 'object') {
    const map = new Map(Object.entries(data));
    console.log(`[STORAGE] guild_configs.json carregado — ${map.size} servidor(es).`);
    return map;
  }
  return new Map();
}

/**
 * Persiste o Map de configurações de servidor em JSON.
 * @param {Map<string, object>} map
 */
function salvarGuildConfigs(map) {
  if (!map || !(map instanceof Map)) return;
  salvarJSON(GUILD_CONFIG_FILE, Object.fromEntries(map));
}

// ── Cache do Perfil do Bot (botCache) ─────────────────────────────────────────

/**
 * Carrega o cache de perfil do bot a partir do JSON persistido.
 * Retorna null se o arquivo não existir ou estiver corrompido.
 */
function carregarBotCache() {
  return lerJSON(BOT_CACHE_FILE, null);
}

/**
 * Persiste o cache de perfil do bot em JSON.
 * @param {object} cache
 */
function salvarBotCache(cache) {
  salvarJSON(BOT_CACHE_FILE, cache);
}

module.exports = {
  salvarJSON,
  lerJSON,
  carregarGuildConfigs,
  salvarGuildConfigs,
  carregarBotCache,
  salvarBotCache,
};
