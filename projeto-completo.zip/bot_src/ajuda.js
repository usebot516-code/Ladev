'use strict';

const {
  ContainerBuilder,
  TextDisplayBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  MessageFlags,
} = require('discord.js');

function construirPainelAjuda(tipo = 'slash') {
  let corpo = '';
  let botaoAlternar;

  if (tipo === 'prefixo') {
    corpo =
      '# CENTRAL DE AJUDA — COMANDOS DE PREFIXO\n' +
      'Lista de comandos acionados por texto no chat.\n\n' +
      '**Comandos Disponíveis**\n' +
      '`.p` ou `.p @membro`\n' +
      'Exibe o perfil do jogador com saldo de coins, vitórias, estatísticas e link de convite.\n\n' +
      '`pg <nome e sobrenome>` ou `pago <nome e sobrenome>`\n' +
      'Notifica e vincula o pagamento da partida em andamento (informando nome e sobrenome do titular do Pix) para conferência rápida pelo mediador.';

    botaoAlternar = new ButtonBuilder()
      .setCustomId('ajuda:toggle:slash')
      .setLabel('Comandos Slash')
      .setStyle(ButtonStyle.Primary);
  } else {
    corpo =
      '# CENTRAL DE AJUDA — COMANDOS SLASH\n' +
      'Lista de todos os comandos de barra disponíveis no servidor na ordem oficial:\n\n' +
      '`/iniciar` — Configura as filas, os valores, a taxa e os canais do sistema\n' +
      '`/limpar` — Apaga mensagens deste canal (1 a 1000)\n' +
      '`/ajuda` — Exibe a central de ajuda com a lista de comandos disponíveis\n' +
      '`/avisos` — Abre o painel de gerenciamento de avisos automáticos do servidor\n' +
      '`/aux` — Abre o painel auxiliar de finalização rápida para mediadores\n' +
      '`/blacklist painel` — Abre o painel público de consulta de blacklist Free Fire\n' +
      '`/blacklist adicionar` — Adiciona um jogador à blacklist do servidor\n' +
      '`/blacklist remover` — Remove um jogador da blacklist do servidor\n' +
      '`/configurar` — Abre o painel de configurações do servidor (cargos, canais, taxa, QR Code)\n' +
      '`/config bot` — Abre o painel de gerenciamento do perfil do bot (nome, bio, avatar, banner, status)\n' +
      '`/coins gerenciar` — Adiciona ou remove Coins de um membro\n' +
      '`/loja coins` — Abre o painel de gerenciamento e catálogo da Loja de Coins (troca por recompensas)\n' +
      '`/exposed registrar` — Abre o painel para registrar exposed e banir jogador suspeito\n' +
      '`/exposed historico` — Exibe o histórico de exposeds com filtro por analista\n' +
      '`/filas gerenciar` — Abre o painel de configuração e envio de filas Free Fire\n' +
      '`/fila mediador` — Abre o painel de fila de mediadores\n' +
      '`/fila analista` — Abre o painel público de fila de analistas\n' +
      '`/fila streamer` — Abre o painel de configuração e envio de filas de streamers\n' +
      '`/ranking painel` — Abre o painel de perfil e ranking de vitórias\n' +
      '`/sorteio painel` — Abre o painel principal de sorteios\n' +
      '`/sorteio reiniciar` — Abre o painel para reiniciar ou re-sortear um sorteio\n' +
      '`/sorteio revogar` — Abre o painel para revogar ou cancelar um sorteio ativo\n' +
      '`/tickets painel` — Abre o painel de configuração e publicação de tickets\n' +
      '`/tickets fechar` — Fecha o ticket atual ou abre o painel de fechamento';

    botaoAlternar = new ButtonBuilder()
      .setCustomId('ajuda:toggle:prefixo')
      .setLabel('Comandos de Prefixo')
      .setStyle(ButtonStyle.Primary);
  }

  const container = new ContainerBuilder()
    .setAccentColor(0x5865F2)
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(corpo))
    .addActionRowComponents(
      new ActionRowBuilder().addComponents(botaoAlternar)
    );

  return {
    components: [container],
    flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
  };
}

async function handleAjuda(interaction) {
  if (interaction.isChatInputCommand() && interaction.commandName === 'ajuda') {
    const payload = construirPainelAjuda('slash');
    await interaction.reply(payload);
    return true;
  }

  const customId = interaction.customId || '';
  if (!customId.startsWith('ajuda:')) return false;

  if (interaction.isButton()) {
    if (customId === 'ajuda:toggle:prefixo') {
      await interaction.deferUpdate();
      const payload = construirPainelAjuda('prefixo');
      await interaction.editReply(payload);
      return true;
    }

    if (customId === 'ajuda:toggle:slash') {
      await interaction.deferUpdate();
      const payload = construirPainelAjuda('slash');
      await interaction.editReply(payload);
      return true;
    }
  }

  return false;
}

module.exports = {
  construirPainelAjuda,
  handleAjuda,
};
