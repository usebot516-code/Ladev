BOAS-VINDAS
# boas-vindas
# regras
# anúncios
# sorteios

INFORMAÇÕES
# como-funciona
# ranking
# blacklist
# exposed-mob

ATENDIMENTO
# abrir-ticket
# duvidas

FILAS APOSTAS 1X1
# 1x1-mob
# 1x1-emulador
# 1x1-misto

FILAS APOSTAS 2X2
# 2x2-mob
# 2x2-emulador
# 2x2-misto

FILAS APOSTAS 4X4
# 4x4-mob
# 4x4-emulador
# 4x4-misto

SALAS PERSONALIZADAS
# sala-personalizada
# fila-rapida

MEDIAÇÃO
# fila-mediador
# ponto-mediador
# painel-mediacao

ANÁLISES
# fila-analista
# logs-analises
🔊 analise-tela-1
🔊 analise-tela-2
🔊 analise-tela-3
🔊 analise-tela-4

STREAMERS
# live-on
# fila-streamers
# transmissoes

COMUNIDADE
# chat-geral
# comandos-bot
# midia
# clipes

SALAS DE VOZ
🔊 Call 01
🔊 Call 02
🔊 Call 03
🔊 Call 04
🔊 Call 05
🔊 Call 06
🔊 Call 07
🔊 Call 08

GERÊNCIA
# chat-staff
# comandos-staff
# financeiro
🔊 reuniao-staff

SUPORTE
# chat-suporte
# fila-atendimento

LOGS DE PARTIDAS
# log-partidas
# log-confirmadas
# logs-finalizadas

LOGS DO SISTEMA
# log-ticket
# log-punicoes
# log-transacoes
# log-auditoria
