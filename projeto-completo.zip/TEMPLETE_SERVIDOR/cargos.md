# chat-staff — DONO: visualizar, ler histórico, enviar, gerenciar mensagens
# chat-staff — GERENTE: visualizar, ler histórico, enviar, gerenciar mensagens
# comandos-staff — DONO: visualizar, ler histórico, enviar, gerenciar mensagens
# comandos-staff — GERENTE: visualizar, ler histórico, enviar, gerenciar mensagens
# financeiro — DONO: visualizar, ler histórico, enviar, gerenciar mensagens
# financeiro — GERENTE: visualizar, ler histórico, enviar
🔊 reuniao-staff — DONO: visualizar, conectar, falar
🔊 reuniao-staff — GERENTE: visualizar, conectar, falar
🔊 reuniao-staff — ANALISTA: visualizar, conectar, falar
🔊 reuniao-staff — MEDIADOR: visualizar, conectar, falar
🔊 reuniao-staff — SUPORTE: visualizar, conectar, falar

# chat-suporte — DONO: visualizar, ler histórico, enviar, gerenciar mensagens
# chat-suporte — GERENTE: visualizar, ler histórico, enviar, gerenciar mensagens
# chat-suporte — SUPORTE: visualizar, ler histórico, enviar, gerenciar mensagens
# fila-atendimento — SUPORTE: visualizar, ler histórico, enviar

# fila-mediador — MEDIADOR: visualizar, ler histórico, enviar
# fila-mediador — GERENTE: visualizar, ler histórico, enviar, gerenciar mensagens
# fila-mediador — DONO: visualizar, ler histórico, enviar, gerenciar mensagens
# ponto-mediador — MEDIADOR: visualizar, ler histórico, enviar
# painel-mediacao — MEDIADOR: visualizar, ler histórico, enviar

# fila-analista — ANALISTA: visualizar, ler histórico, enviar
# fila-analista — GERENTE: visualizar, ler histórico, enviar, gerenciar mensagens
# fila-analista — DONO: visualizar, ler histórico, enviar, gerenciar mensagens
# logs-analises — ANALISTA: visualizar, ler histórico, enviar
🔊 analise-tela-1 — ANALISTA: visualizar, conectar, falar
🔊 analise-tela-2 — ANALISTA: visualizar, conectar, falar
🔊 analise-tela-3 — ANALISTA: visualizar, conectar, falar
🔊 analise-tela-4 — ANALISTA: visualizar, conectar, falar

# live-on — INFLUENCIADOR: visualizar, ler histórico, enviar
# fila-streamers — INFLUENCIADOR: visualizar, ler histórico, enviar

# log-partidas — DONO: visualizar, ler histórico
# log-partidas — GERENTE: visualizar, ler histórico
# log-confirmadas — DONO: visualizar, ler histórico
# log-confirmadas — GERENTE: visualizar, ler histórico
# logs-finalizadas — DONO: visualizar, ler histórico
# logs-finalizadas — GERENTE: visualizar, ler histórico
# log-ticket — DONO: visualizar, ler histórico
# log-ticket — GERENTE: visualizar, ler histórico
# log-ticket — SUPORTE: visualizar, ler histórico
# log-punicoes — DONO: visualizar, ler histórico
# log-punicoes — GERENTE: visualizar, ler histórico
# log-transacoes — DONO: visualizar, ler histórico
# log-transacoes — GERENTE: visualizar, ler histórico
# log-auditoria — DONO: visualizar, ler histórico
