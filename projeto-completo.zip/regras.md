REGRAS GERAIS DO PROJETO

1. API E TECNOLOGIA

- Utilizar sempre a versão mais recente e estável da API do Discord disponível no momento da implementação.
- Utilizar Discord Components V2 em TODOS os painéis, botões, modais e sistemas do projeto.
- Select Menus, botões e controles DEVEM estar obrigatoriamente dentro da estrutura do painel (Container V2), nunca soltos ou fora do painel.
- Não utilizar tecnologias ou versões antigas quando existir uma alternativa atual e compatível.

2. AUTO-REFRESH OBRIGATÓRIO EM TODOS OS PAINÉIS

- Todo tipo de painel público, administrativo ou de gerenciamento DEVE possuir sistema de Auto-Refresh integrado.
- Qualquer alteração de estado (inclusão, remoção, alteração de status ou configuração) deve acionar imediatamente a atualização in-place da mensagem original do painel.
- O Auto-Refresh deve atualizar as informações do painel sem exigir que o usuário execute o comando novamente.
- Atualizações devem ocorrer de forma controlada, sem criar mensagens ou painéis duplicados.

3. PAINÉIS, PROIBIÇÃO TOTAL DE EMOJIS E PROIBIÇÃO DE RODAPÉS

- TODO tipo de painel tem que ser feito ESTRITAMENTE SEM USO DE EMOJIS.
- PROIBIDO o uso de qualquer tipo de rodapé (footer) em painéis, embeds ou mensagens.
- Não utilizar emojis em títulos de painéis, descrições, campos (fields) ou mensagens.
- Não utilizar emojis em botões (labels) ou Select Menus (placeholders e labels).
- Não utilizar emojis em modais ou mensagens de resposta.
- Os textos dos painéis devem ser profissionais, claros, técnicos e bem organizados.
- Evitar criar painéis iguais ou desnecessários.
- Sempre que possível, editar o painel existente em vez de enviar outro painel.
- Cada painel deve possuir uma finalidade clara com descrição bem elaborada.

4. SELECT MENUS E COMPONENTES DENTRO DO PAINEL

- Select Menus DEVEM estar estritamente dentro do Container V2 do painel.
- Select Menus devem possuir nomes, descrições e placeholders bem elaborados e sem emojis.
- O placeholder deve explicar claramente o que o usuário deve selecionar.
- Cada Select Menu deve possuir uma finalidade específica.
- Não criar Select Menus desnecessários.
- Os componentes devem possuir comportamento previsível e consistente.
- Os nomes definidos na especificação de cada sistema devem ser respeitados exatamente.

5. BOTÕES

- Botões devem possuir nomes claros, diretos e objetivos.
- PROIBIDO utilizar emojis em qualquer botão.
- Cada botão deve executar somente a função para a qual foi criado.
- Botões de navegação e paginação devem editar o painel atual (in-place) sempre que possível.

6. ATUALIZAÇÕES DO PROJETO E EXPORTAÇÃO ZIP

- Sempre que o bot ou qualquer parte do projeto for atualizada, gerar um novo arquivo ".zip" limpo e sincronizado.
- O ".zip" deve ser disponibilizado no painel web para download.
- Nunca incluir "node_modules", ".git", "venv", ".venv", "__pycache__", ".cache" ou arquivos temporários no ".zip".
- O arquivo ".zip" deve conter somente os arquivos necessários para executar, configurar e manter o projeto.

7. REGRA PRINCIPAL

- Estas regras são ESTRITAMENTE OBRIGATÓRIAS para TODO o projeto.
- Todo e qualquer tipo de painel criado ou modificado deve seguir impreterivelmente:
  1. SEM EMOJIS
  2. COM AUTO-REFRESH
  3. DISCORD COMPONENTS V2 (com Select Menus e botões dentro do container)
  4. ZERO RODAPÉ (sem nenhum footer)
- Nenhum sistema deve ignorar estas regras.