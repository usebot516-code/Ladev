from __future__ import annotations

from dataclasses import asdict, dataclass, field
from decimal import Decimal
from typing import Any


PREDEFINED_PRICES = (
    "0.30",
    "0.50",
    "0.70",
    "1.00",
    "2.00",
    "3.00",
    "4.00",
    "5.00",
    "10.00",
    "20.00",
    "30.00",
)


def _default_prices() -> list[str]:
    return list(PREDEFINED_PRICES)


@dataclass(slots=True)
class GuildConfig:
    guild_id: int
    color: int = 0x5865F2
    color_name: str = "Azul"
    queue_title: str = "Filas de Atendimento"
    banner_url: str | None = None
    thumbnail_url: str | None = None
    prices: list[str] = field(default_factory=_default_prices)
    predefined_prices_seeded: bool = True
    fee: str = "0"
    fee_is_percentage: bool = False
    mediator_queue_channel_id: int | None = None
    mediator_log_channel_id: int | None = None
    stage: int = 1
    completed: bool = False

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> GuildConfig:
        prices = [str(value) for value in payload.get("prices", [])]
        prices_seeded = "predefined_prices_seeded" in payload
        if not prices_seeded:
            prices = list(dict.fromkeys([*prices, *PREDEFINED_PRICES]))
            prices_seeded = True
        return cls(
            guild_id=int(payload["guild_id"]),
            color=int(payload.get("color", 0x5865F2)),
            color_name=str(payload.get("color_name", "Azul")),
            queue_title=str(payload.get("queue_title", "Filas de Atendimento")),
            banner_url=str(payload.get("banner_url")) if payload.get("banner_url") else None,
            thumbnail_url=str(payload.get("thumbnail_url")) if payload.get("thumbnail_url") else None,
            prices=prices,
            predefined_prices_seeded=bool(
                payload.get("predefined_prices_seeded", prices_seeded)
            ),
            fee=str(payload.get("fee", "0")),
            fee_is_percentage=bool(payload.get("fee_is_percentage", False)),
            mediator_queue_channel_id=_optional_int(
                payload.get("mediator_queue_channel_id")
            ),
            mediator_log_channel_id=_optional_int(
                payload.get("mediator_log_channel_id")
            ),
            stage=min(max(int(payload.get("stage", 1)), 1), 3),
            completed=bool(payload.get("completed", False)),
        )

    @property
    def formatted_fee(self) -> str:
        amount = Decimal(self.fee)
        suffix = "%" if self.fee_is_percentage else ""
        return f"{amount.normalize():f}{suffix}"


def _optional_int(value: object) -> int | None:
    if value in (None, ""):
        return None
    return int(value)


@dataclass(slots=True)
class QueuePlayer:
    user_id: int
    user_name: str
    user_mention: str
    sub_mode: str = "padrao"
    joined_at: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> QueuePlayer:
        return cls(
            user_id=int(payload["user_id"]),
            user_name=str(payload.get("user_name", "Jogador")),
            user_mention=str(payload.get("user_mention", f"<@{payload['user_id']}>")),
            sub_mode=str(payload.get("sub_mode", "padrao")),
            joined_at=str(payload.get("joined_at", "")),
        )


@dataclass(slots=True)
class QueueModel:
    id: str
    guild_id: int
    title: str
    mode: str  # "1v1", "2v2", "3v3", "4v4"
    type: str  # "Mobile", "Emulador", "Misto"
    price: str  # e.g. "5.00"
    banner_url: str | None = None
    thumbnail_url: str | None = None
    channel_id: int | None = None
    message_id: int | None = None
    created_at: str = ""
    players: list[QueuePlayer] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["players"] = [p.to_dict() for p in self.players]
        return data

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> QueueModel:
        raw_players = payload.get("players", [])
        players = [
            QueuePlayer.from_dict(p)
            for p in raw_players
            if isinstance(p, dict)
        ]
        return cls(
            id=str(payload["id"]),
            guild_id=int(payload["guild_id"]),
            title=str(payload.get("title", "Filas de Atendimento")),
            mode=str(payload.get("mode", "1v1")),
            type=str(payload.get("type", "Mobile")),
            price=str(payload.get("price", "5.00")),
            banner_url=str(payload.get("banner_url")) if payload.get("banner_url") else None,
            thumbnail_url=str(payload.get("thumbnail_url")) if payload.get("thumbnail_url") else None,
            channel_id=_optional_int(payload.get("channel_id")),
            message_id=_optional_int(payload.get("message_id")),
            created_at=str(payload.get("created_at", "")),
            players=players,
        )

    def get_players_for_sub_mode(self, sub_mode: str) -> list[QueuePlayer]:
        return [p for p in self.players if p.sub_mode == sub_mode]

    def has_player(self, user_id: int) -> bool:
        return any(p.user_id == user_id for p in self.players)

    def remove_player(self, user_id: int) -> bool:
        initial_len = len(self.players)
        self.players = [p for p in self.players if p.user_id != user_id]
        return len(self.players) < initial_len


@dataclass(slots=True)
class MatchModel:
    id: str
    guild_id: int
    queue_id: str
    player1_id: int
    player1_name: str
    player2_id: int
    player2_name: str
    mode: str
    type: str
    sub_mode: str
    price: str
    fee: str
    channel_id: int | None = None
    created_at: str = ""
    status: str = "active"  # "active", "completed", "cancelled"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> MatchModel:
        return cls(
            id=str(payload["id"]),
            guild_id=int(payload["guild_id"]),
            queue_id=str(payload.get("queue_id", "")),
            player1_id=int(payload["player1_id"]),
            player1_name=str(payload.get("player1_name", "")),
            player2_id=int(payload["player2_id"]),
            player2_name=str(payload.get("player2_name", "")),
            mode=str(payload.get("mode", "1v1")),
            type=str(payload.get("type", "Mobile")),
            sub_mode=str(payload.get("sub_mode", "padrao")),
            price=str(payload.get("price", "0.00")),
            fee=str(payload.get("fee", "0")),
            channel_id=_optional_int(payload.get("channel_id")),
            created_at=str(payload.get("created_at", "")),
            status=str(payload.get("status", "active")),
        )
