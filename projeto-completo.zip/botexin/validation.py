from __future__ import annotations

import re
from decimal import Decimal, InvalidOperation


PRICE_PATTERN = re.compile(r"^\d+(?:[.,]\d{1,2})?$")
FEE_PATTERN = re.compile(r"^\d+(?:[.,]\d{1,2})?%?$")

COLORS: dict[str, tuple[str, int]] = {
    "azul": ("Azul", 0x5865F2),
    "verde": ("Verde", 0x57F287),
    "amarelo": ("Amarelo", 0xFEE75C),
    "laranja": ("Laranja", 0xE67E22),
    "vermelho": ("Vermelho", 0xED4245),
    "roxo": ("Roxo", 0x9B59B6),
    "rosa": ("Rosa", 0xEB459E),
    "ciano": ("Ciano", 0x1ABC9C),
    "turquesa": ("Turquesa", 0x00CED1),
    "esmeralda": ("Esmeralda", 0x2ECC71),
    "dourado": ("Dourado", 0xD4AF37),
    "magenta": ("Magenta", 0xE91E63),
    "coral": ("Coral", 0xFF6F61),
    "escarlate": ("Escarlate", 0xC0392B),
    "azul_celeste": ("Azul Celeste", 0x3498DB),
    "lavanda": ("Lavanda", 0xB57EDC),
    "grafite": ("Grafite", 0x2C2F33),
    "preto": ("Preto", 0x23272A),
    "branco": ("Branco", 0xF8F9FA),
    "prata": ("Prata", 0x95A5A6),
}


def parse_prices(raw: str) -> list[str]:
    values: list[Decimal] = []
    pieces = [piece.strip() for piece in re.split(r"[,;\n]+", raw) if piece.strip()]
    if not pieces:
        raise ValueError("Informe pelo menos um preço.")

    for piece in pieces:
        normalized = piece.replace(",", ".")
        if not PRICE_PATTERN.fullmatch(piece):
            raise ValueError(
                f"Preço inválido: {piece}. Use valores positivos com até duas casas."
            )
        try:
            value = Decimal(normalized)
        except InvalidOperation as error:
            raise ValueError(f"Preço inválido: {piece}.") from error
        if value <= 0:
            raise ValueError("Os preços precisam ser maiores que zero.")
        values.append(value.quantize(Decimal("0.01")))

    unique = sorted(set(values))
    return [format(value, "f").rstrip("0").rstrip(".") for value in unique]


def parse_fee(raw: str) -> tuple[str, bool]:
    normalized = raw.strip()
    if not FEE_PATTERN.fullmatch(normalized):
        raise ValueError(
            "Informe um número válido, com ou sem o sinal de porcentagem."
        )
    is_percentage = normalized.endswith("%")
    if is_percentage:
        normalized = normalized[:-1]
    normalized = normalized.replace(",", ".")
    try:
        value = Decimal(normalized)
    except InvalidOperation as error:
        raise ValueError("Informe uma taxa numérica válida entre 0 e 100.") from error
    if value < 0 or value > 100:
        raise ValueError("A taxa deve estar entre 0 e 100.")
    formatted = (
        format(value.quantize(Decimal("0.01")), "f")
        .rstrip("0")
        .rstrip(".")
        or "0"
    )
    return formatted, is_percentage


def color_from_value(value: str) -> tuple[str, int]:
    key = value.strip().lower()
    try:
        return COLORS[key]
    except KeyError as error:
        raise ValueError("Selecione uma cor válida no menu.") from error