from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True, slots=True)
class Settings:
    discord_token: str
    data_path: Path


def load_settings() -> Settings:
    token = os.getenv("DISCORD_TOKEN", "").strip()
    if not token:
        # Fallback to local stored token file if present
        token_file = Path(__file__).resolve().parents[1] / "data" / ".token"
        if token_file.exists():
            try:
                token = token_file.read_text(encoding="utf-8").strip()
            except Exception:
                token = ""

    if not token:
        raise RuntimeError(
            "DISCORD_TOKEN não configurado. Adicione o token como segredo "
            "ou variável de ambiente antes de iniciar o bot."
        )

    configured_path = os.getenv("BOTEXIN_DATA_PATH", "data/config.json").strip()
    data_path = Path(configured_path)
    if not data_path.is_absolute():
        data_path = Path(__file__).resolve().parents[1] / data_path

    return Settings(discord_token=token, data_path=data_path)