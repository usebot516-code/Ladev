from __future__ import annotations

import discord


def can_manage_guild(interaction: discord.Interaction, guild_id: int) -> bool:
    member = interaction.user
    return (
        interaction.guild_id == guild_id
        and isinstance(member, discord.Member)
        and (
            member.guild_permissions.manage_guild
            or member.guild_permissions.administrator
        )
    )


async def edit_panel(
    interaction: discord.Interaction,
    view: discord.ui.LayoutView,
    *,
    message_id: int | None = None,
    channel_id: int | None = None,
    original_interaction: discord.Interaction | None = None,
) -> bool:
    """Edit the existing panel whenever possible, including after a modal."""
    message = None if message_id and channel_id else interaction.message

    if message is not None and not interaction.response.is_done():
        try:
            await interaction.response.edit_message(
                content=None,
                embeds=[],
                attachments=[],
                view=view,
            )
            return True
        except discord.DiscordException:
            return False

    if original_interaction is not None:
        try:
            await original_interaction.edit_original_response(
                content=None,
                embeds=[],
                attachments=[],
                view=view,
            )
            if not interaction.response.is_done():
                await interaction.response.defer(ephemeral=True)
            return True
        except discord.DiscordException:
            pass

    if message is None and message_id and channel_id and interaction.client:
        channel = interaction.client.get_channel(channel_id)
        if channel is None:
            try:
                channel = await interaction.client.fetch_channel(channel_id)
            except (discord.DiscordException, TypeError):
                channel = None
        if channel is not None and hasattr(channel, "fetch_message"):
            try:
                message = await channel.fetch_message(message_id)
            except discord.DiscordException:
                message = None

    if message is None:
        return False

    try:
        await message.edit(
            content=None,
            embeds=[],
            attachments=[],
            view=view,
        )
        return True
    except discord.DiscordException:
        return False


async def respond_error(interaction: discord.Interaction, message: str) -> None:
    if interaction.response.is_done():
        await interaction.followup.send(message, ephemeral=True)
    else:
        await interaction.response.send_message(message, ephemeral=True)