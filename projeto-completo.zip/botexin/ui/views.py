from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
import logging

import discord

from botexin.models import PREDEFINED_PRICES, GuildConfig
from botexin.storage.repository import ConfigStore
from botexin.ui.helpers import can_manage_guild, edit_panel, respond_error
from botexin.validation import COLORS, color_from_value


logger = logging.getLogger("botexin.ui")
PREDEFINED_REMOVE_PRICES = PREDEFINED_PRICES


@dataclass(slots=True)
class PanelReference:
    message_id: int
    channel_id: int


def _reference(interaction: discord.Interaction) -> PanelReference:
    if interaction.message is None or interaction.channel_id is None:
        raise RuntimeError("Não foi possível localizar o painel atual.")
    return PanelReference(
        message_id=interaction.message.id,
        channel_id=interaction.channel_id,
    )


def _prices_text(config: GuildConfig) -> str:
    if not config.prices:
        return "Nenhum preço cadastrado."
    return ", ".join(config.prices)


class PanelView(discord.ui.LayoutView):
    def __init__(self, store: ConfigStore, guild_id: int) -> None:
        super().__init__(timeout=None)
        self.store = store
        self.guild_id = guild_id

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.guild_id != self.guild_id:
            await respond_error(interaction, "Este painel pertence a outro servidor.")
            return False
        if not can_manage_guild(interaction, self.guild_id):
            await respond_error(
                interaction,
                "Você precisa da permissão Gerenciar Servidor para alterar estas configurações.",
            )
            return False
        return True

    async def on_error(
        self,
        interaction: discord.Interaction,
        error: Exception,
        item: discord.ui.Item[object],
    ) -> None:
        logger.error("Erro em componente do /iniciar.", exc_info=error)
        await respond_error(
            interaction,
            "Não foi possível concluir esta ação. Tente novamente.",
        )


class Stage1View(PanelView):
    def __init__(self, store: ConfigStore, guild_id: int) -> None:
        super().__init__(store, guild_id)
        config = store.get(guild_id)
        color_options = [
            discord.SelectOption(
                label=label,
                value=key,
                default=key == config.color_name.lower(),
            )
            for key, (label, _) in COLORS.items()
        ]
        color_select = ColorMenu(store, guild_id, color_options)
        next_button = Stage1NextButton(store, guild_id)

        self.add_item(
            discord.ui.Container(
                discord.ui.TextDisplay(
                    "# Aparência das filas\n"
                    f"**Cor atual**\n{config.color_name}"
                ),
                discord.ui.ActionRow(color_select),
                discord.ui.ActionRow(next_button),
                accent_color=config.color,
            )
        )


class ColorMenu(discord.ui.Select):
    def __init__(
        self,
        store: ConfigStore,
        guild_id: int,
        options: list[discord.SelectOption],
    ) -> None:
        super().__init__(
            custom_id="botexin:iniciar:cor",
            placeholder="Selecionar uma cor",
            min_values=1,
            max_values=1,
            options=options,
        )
        self.store = store
        self.guild_id = guild_id

    async def callback(self, interaction: discord.Interaction) -> None:
        try:
            label, color = color_from_value(self.values[0])
            config = self.store.get(self.guild_id)
            config.color_name = label
            config.color = color
            self.store.save(config)
            updated = await edit_panel(
                interaction,
                Stage1View(self.store, self.guild_id),
            )
            if not updated:
                await respond_error(interaction, "A cor foi salva, mas o painel não pôde ser atualizado.")
        except ValueError as error:
            await respond_error(interaction, str(error))


class Stage1NextButton(discord.ui.Button):
    def __init__(self, store: ConfigStore, guild_id: int) -> None:
        super().__init__(
            label="Próximo",
            style=discord.ButtonStyle.primary,
            custom_id="botexin:iniciar:etapa1:proximo",
        )
        self.store = store
        self.guild_id = guild_id

    async def callback(self, interaction: discord.Interaction) -> None:
        config = self.store.get(self.guild_id)
        config.stage = 2
        self.store.save(config)
        if not await edit_panel(interaction, Stage2View(self.store, self.guild_id)):
            await respond_error(
                interaction,
                "Configuração salva, mas o painel não pôde ser atualizado.",
            )


class Stage2View(PanelView):
    def __init__(self, store: ConfigStore, guild_id: int) -> None:
        super().__init__(store, guild_id)
        config = store.get(guild_id)
        self.add_item(
            discord.ui.Container(
                discord.ui.TextDisplay(
                    "# Valores e taxa\n"
                    f"**Exibição dos valores**\n{_prices_text(config)}"
                ),
                discord.ui.ActionRow(PricesButton(store, guild_id)),
                discord.ui.ActionRow(RemovePresetPricesSelect(store, guild_id)),
                discord.ui.ActionRow(FeeButton(store, guild_id)),
                discord.ui.ActionRow(Stage2BackButton(store, guild_id)),
                discord.ui.ActionRow(Stage2NextButton(store, guild_id)),
                accent_color=config.color,
            )
        )


class PricesButton(discord.ui.Button):
    def __init__(self, store: ConfigStore, guild_id: int) -> None:
        super().__init__(
            label="Adicionar preços",
            style=discord.ButtonStyle.secondary,
            custom_id="botexin:iniciar:precos:adicionar",
        )
        self.store = store
        self.guild_id = guild_id

    async def callback(self, interaction: discord.Interaction) -> None:
        from botexin.ui.modals import AddPricesModal

        try:
            ref = _reference(interaction)
            await interaction.response.send_modal(
                AddPricesModal(
                    store=self.store,
                    guild_id=self.guild_id,
                    message_id=ref.message_id,
                    channel_id=ref.channel_id,
                    original_interaction=interaction,
                )
            )
        except RuntimeError as error:
            await respond_error(interaction, str(error))


class RemovePresetPricesSelect(discord.ui.Select):
    def __init__(self, store: ConfigStore, guild_id: int) -> None:
        super().__init__(
            custom_id="botexin:iniciar:precos:remover",
            placeholder="Remover preços",
            min_values=1,
            max_values=len(PREDEFINED_REMOVE_PRICES),
            options=[
                discord.SelectOption(
                    label=price,
                    value=price,
                )
                for price in PREDEFINED_REMOVE_PRICES
            ],
        )
        self.store = store
        self.guild_id = guild_id

    async def callback(self, interaction: discord.Interaction) -> None:
        config = self.store.get(self.guild_id)
        selected = {Decimal(value) for value in self.values}
        old_prices = {Decimal(value) for value in config.prices}
        config.prices = [
            price
            for price in config.prices
            if Decimal(price) not in selected
        ]
        self.store.save(config)
        updated = await edit_panel(
            interaction,
            Stage2View(self.store, self.guild_id),
        )
        if updated and not old_prices.intersection(selected):
            await interaction.followup.send(
                "Nenhum dos valores selecionados estava cadastrado.",
                ephemeral=True,
            )


class FeeButton(discord.ui.Button):
    def __init__(self, store: ConfigStore, guild_id: int) -> None:
        super().__init__(
            label="Configurar taxa",
            style=discord.ButtonStyle.secondary,
            custom_id="botexin:iniciar:taxa",
        )
        self.store = store
        self.guild_id = guild_id

    async def callback(self, interaction: discord.Interaction) -> None:
        from botexin.ui.modals import FeeModal

        try:
            ref = _reference(interaction)
            await interaction.response.send_modal(
                FeeModal(
                    store=self.store,
                    guild_id=self.guild_id,
                    message_id=ref.message_id,
                    channel_id=ref.channel_id,
                    original_interaction=interaction,
                )
            )
        except RuntimeError as error:
            await respond_error(interaction, str(error))


class Stage2BackButton(discord.ui.Button):
    def __init__(self, store: ConfigStore, guild_id: int) -> None:
        super().__init__(
            label="Voltar",
            style=discord.ButtonStyle.secondary,
            custom_id="botexin:iniciar:etapa2:voltar",
        )
        self.store = store
        self.guild_id = guild_id

    async def callback(self, interaction: discord.Interaction) -> None:
        config = self.store.get(self.guild_id)
        config.stage = 1
        config.completed = False
        self.store.save(config)
        if not await edit_panel(
            interaction,
            Stage1View(self.store, self.guild_id),
        ):
            await respond_error(
                interaction,
                "O painel anterior não pôde ser carregado.",
            )


class Stage2NextButton(discord.ui.Button):
    def __init__(self, store: ConfigStore, guild_id: int) -> None:
        super().__init__(
            label="Próximo",
            style=discord.ButtonStyle.primary,
            custom_id="botexin:iniciar:etapa2:proximo",
        )
        self.store = store
        self.guild_id = guild_id

    async def callback(self, interaction: discord.Interaction) -> None:
        config = self.store.get(self.guild_id)
        config.stage = 3
        config.completed = False
        self.store.save(config)
        if not await edit_panel(interaction, Stage3View(self.store, self.guild_id)):
            await respond_error(
                interaction,
                "Configuração salva, mas o painel não pôde ser atualizado.",
            )


class Stage3View(PanelView):
    def __init__(
        self,
        store: ConfigStore,
        guild_id: int,
        *,
        completed: bool = False,
    ) -> None:
        super().__init__(store, guild_id)
        config = store.get(guild_id)
        queue_name = _channel_label(config.mediator_queue_channel_id)
        log_name = _channel_label(config.mediator_log_channel_id)
        channel_types = [discord.ChannelType.text, discord.ChannelType.news]
        status_text = (
            "\n\n**Status**\nConfiguração finalizada."
            if completed
            else ""
        )
        container_children: list[discord.ui.Item[object]] = [
            discord.ui.TextDisplay(
                "# Canais\n"
                "**Selecionar canal da fila de mediadores**\n"
                f"{queue_name}\n\n"
                "**Selecionar canal de registro do mediador**\n"
                f"{log_name}"
                f"{status_text}"
            ),
            discord.ui.ActionRow(
                QueueChannelSelect(
                    self.store,
                    self.guild_id,
                    channel_types=channel_types,
                    default_channel_id=config.mediator_queue_channel_id,
                )
            ),
            discord.ui.ActionRow(
                LogChannelSelect(
                    self.store,
                    self.guild_id,
                    channel_types=channel_types,
                    default_channel_id=config.mediator_log_channel_id,
                )
            ),
        ]
        if not completed:
            container_children.append(
                discord.ui.ActionRow(Stage3BackButton(self.store, self.guild_id))
            )
            container_children.append(
                discord.ui.ActionRow(FinishButton(self.store, self.guild_id))
            )
        else:
            container_children.append(
                discord.ui.ActionRow(Stage3BackButton(self.store, self.guild_id))
            )
        self.add_item(
            discord.ui.Container(
                *container_children,
                accent_color=config.color,
            )
        )


def _channel_label(channel_id: int | None) -> str:
    return f"<#{channel_id}>" if channel_id else "Nenhum canal selecionado."


class BaseChannelSelect(discord.ui.ChannelSelect):
    def __init__(
        self,
        store: ConfigStore,
        guild_id: int,
        *,
        custom_id: str,
        placeholder: str,
        channel_types: list[discord.ChannelType],
        default_channel_id: int | None,
    ) -> None:
        default_values: list[discord.SelectDefaultValue] = []
        if default_channel_id:
            default_values.append(
                discord.SelectDefaultValue(
                    id=default_channel_id,
                    type=discord.SelectDefaultValueType.channel,
                )
            )
        super().__init__(
            custom_id=custom_id,
            channel_types=channel_types,
            placeholder=placeholder,
            default_values=default_values,
        )
        self.store = store
        self.guild_id = guild_id


class QueueChannelSelect(BaseChannelSelect):
    def __init__(
        self,
        store: ConfigStore,
        guild_id: int,
        *,
        channel_types: list[discord.ChannelType],
        default_channel_id: int | None,
    ) -> None:
        super().__init__(
            store,
            guild_id,
            custom_id="botexin:iniciar:canal:fila",
            placeholder="Selecionar canal da fila de mediadores",
            channel_types=channel_types,
            default_channel_id=default_channel_id,
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        config = self.store.get(self.guild_id)
        config.mediator_queue_channel_id = self.values[0].id
        self.store.save(config)
        if not await edit_panel(interaction, Stage3View(self.store, self.guild_id)):
            await respond_error(interaction, "Canal salvo, mas o painel não pôde ser atualizado.")


class LogChannelSelect(BaseChannelSelect):
    def __init__(
        self,
        store: ConfigStore,
        guild_id: int,
        *,
        channel_types: list[discord.ChannelType],
        default_channel_id: int | None,
    ) -> None:
        super().__init__(
            store,
            guild_id,
            custom_id="botexin:iniciar:canal:registro",
            placeholder="Selecionar canal de registro do mediador",
            channel_types=channel_types,
            default_channel_id=default_channel_id,
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        config = self.store.get(self.guild_id)
        config.mediator_log_channel_id = self.values[0].id
        self.store.save(config)
        if not await edit_panel(interaction, Stage3View(self.store, self.guild_id)):
            await respond_error(interaction, "Canal salvo, mas o painel não pôde ser atualizado.")


class Stage3BackButton(discord.ui.Button):
    def __init__(self, store: ConfigStore, guild_id: int) -> None:
        super().__init__(
            label="Voltar",
            style=discord.ButtonStyle.secondary,
            custom_id="botexin:iniciar:etapa3:voltar",
        )
        self.store = store
        self.guild_id = guild_id

    async def callback(self, interaction: discord.Interaction) -> None:
        config = self.store.get(self.guild_id)
        config.stage = 2
        config.completed = False
        self.store.save(config)
        if not await edit_panel(
            interaction,
            Stage2View(self.store, self.guild_id),
        ):
            await respond_error(
                interaction,
                "O painel anterior não pôde ser carregado.",
            )


class CompletedView(PanelView):
    def __init__(self, store: ConfigStore, guild_id: int) -> None:
        super().__init__(store, guild_id)
        config = store.get(guild_id)
        self.add_item(
            discord.ui.Container(
                discord.ui.TextDisplay(
                    "# CONFIGURAÇÕES BASES FEITAS\n"
                    "Essas configurações são a base do sistema em seu servidor."
                ),
                accent_color=config.color,
            )
        )


class FinishButton(discord.ui.Button):
    def __init__(self, store: ConfigStore, guild_id: int) -> None:
        super().__init__(
            label="Finalizar",
            style=discord.ButtonStyle.success,
            custom_id="botexin:iniciar:finalizar",
        )
        self.store = store
        self.guild_id = guild_id

    async def callback(self, interaction: discord.Interaction) -> None:
        config = self.store.get(self.guild_id)
        if not config.mediator_queue_channel_id or not config.mediator_log_channel_id:
            await respond_error(
                interaction,
                "Selecione os dois canais antes de finalizar.",
            )
            return
        config.stage = 3
        config.completed = True
        self.store.save(config)
        if not await edit_panel(
            interaction,
            CompletedView(self.store, self.guild_id),
        ):
            await respond_error(
                interaction,
                "Configuração salva, mas o painel não pôde ser atualizado.",
            )