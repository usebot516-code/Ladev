from __future__ import annotations

import logging

import discord

from botexin.storage.repository import ConfigStore
from botexin.ui.helpers import can_manage_guild, edit_panel, respond_error
from botexin.ui.views import Stage2View
from botexin.validation import parse_fee, parse_prices


logger = logging.getLogger("botexin.ui")


class PanelModal(discord.ui.Modal):
    def __init__(
        self,
        *,
        title: str,
        store: ConfigStore,
        guild_id: int,
        message_id: int,
        channel_id: int,
        original_interaction: discord.Interaction,
    ) -> None:
        super().__init__(title=title, timeout=300)
        self.store = store
        self.guild_id = guild_id
        self.message_id = message_id
        self.channel_id = channel_id
        self.original_interaction = original_interaction

    async def on_error(
        self,
        interaction: discord.Interaction,
        error: Exception,
    ) -> None:
        logger.error("Erro em modal do /iniciar.", exc_info=error)
        await respond_error(
            interaction,
            "Não foi possível concluir esta alteração. Tente novamente.",
        )


class AddPricesModal(PanelModal):
    values = discord.ui.TextInput(
        label="Preços",
        placeholder="Ex.: 5, 10, 25 ou um valor por linha",
        min_length=1,
        max_length=500,
        required=True,
    )

    def __init__(self, **kwargs: object) -> None:
        super().__init__(title="Adicionar preços", **kwargs)

    async def on_submit(self, interaction: discord.Interaction) -> None:
        if not can_manage_guild(interaction, self.guild_id):
            await respond_error(
                interaction,
                "Você não tem permissão para alterar esta configuração.",
            )
            return
        try:
            new_prices = parse_prices(str(self.values.value))
            config = self.store.get(self.guild_id)
            config.prices = sorted(
                set(config.prices).union(new_prices),
                key=lambda value: float(value),
            )
            self.store.save(config)
            panel = Stage2View(self.store, self.guild_id)
            updated = await edit_panel(
                interaction,
                panel,
                message_id=self.message_id,
                channel_id=self.channel_id,
                original_interaction=self.original_interaction,
            )
            if interaction.response.is_done():
                if not updated:
                    await interaction.followup.send(
                        "Preços salvos, mas o painel não pôde ser atualizado.",
                        ephemeral=True,
                    )
            else:
                if not updated:
                    await interaction.response.send_message(
                        "Preços salvos, mas o painel não pôde ser atualizado.",
                        ephemeral=True,
                    )
        except ValueError as error:
            await respond_error(interaction, str(error))


class FeeModal(PanelModal):
    value = discord.ui.TextInput(
        label="Taxa",
        placeholder="Ex.: 5%",
        min_length=1,
        max_length=8,
        required=True,
    )

    def __init__(self, **kwargs: object) -> None:
        super().__init__(title="Configurar taxa", **kwargs)

    async def on_submit(self, interaction: discord.Interaction) -> None:
        if not can_manage_guild(interaction, self.guild_id):
            await respond_error(
                interaction,
                "Você não tem permissão para alterar esta configuração.",
            )
            return
        try:
            config = self.store.get(self.guild_id)
            config.fee, config.fee_is_percentage = parse_fee(str(self.value.value))
            self.store.save(config)
            panel = Stage2View(self.store, self.guild_id)
            updated = await edit_panel(
                interaction,
                panel,
                message_id=self.message_id,
                channel_id=self.channel_id,
                original_interaction=self.original_interaction,
            )
            if not updated:
                message = "Taxa salva, mas o painel não pôde ser atualizado."
                if interaction.response.is_done():
                    await interaction.followup.send(message, ephemeral=True)
                else:
                    await interaction.response.send_message(message, ephemeral=True)
        except ValueError as error:
            await respond_error(interaction, str(error))