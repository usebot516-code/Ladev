from __future__ import annotations

import asyncio
import logging

import discord
from discord.ext import commands

from botexin.config import load_settings
from botexin.cogs.iniciar import IniciarCog
from botexin.cogs.filas import FilasCog
from botexin.storage.repository import ConfigStore


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
logger = logging.getLogger("botexin")


class Botexin(commands.Bot):
    def __init__(self, store: ConfigStore) -> None:
        intents = discord.Intents.none()
        intents.guilds = True
        super().__init__(
            command_prefix=commands.when_mentioned,
            intents=intents,
        )
        self.store = store
        self._command_sync_started = False

    async def setup_hook(self) -> None:
        await self.add_cog(IniciarCog(self, self.store))
        await self.add_cog(FilasCog(self, self.store))

        # Persistent views let existing panels continue working after a restart.
        for guild_id in self.store.guild_ids():
            config = self.store.get(guild_id)
            if config.stage == 1:
                from botexin.ui.views import Stage1View

                self.add_view(Stage1View(self.store, guild_id))
            elif config.stage == 2:
                from botexin.ui.views import Stage2View

                self.add_view(Stage2View(self.store, guild_id))
            elif config.completed:
                from botexin.ui.views import CompletedView

                self.add_view(CompletedView(self.store, guild_id))
            else:
                from botexin.ui.views import Stage3View

                self.add_view(
                    Stage3View(
                        self.store,
                        guild_id,
                        completed=False,
                    )
                )

        # Register persistent published queue views
        from botexin.ui.queue_views import PublishedQueueView

        for queue in self.store.get_all_queues():
            self.add_view(
                PublishedQueueView(
                    self.store,
                    queue.id,
                    queue.mode,
                    queue.type,
                )
            )

    async def on_ready(self) -> None:
        if self.user is not None:
            logger.info("Bot conectado como %s (%s).", self.user, self.user.id)
        if not self._command_sync_started:
            self._command_sync_started = True
            asyncio.create_task(self._sync_commands())

    async def _sync_commands(self) -> None:
        try:
            await self.tree.sync()
            logger.info("Comandos /iniciar e /filas sincronizados.")
        except discord.DiscordException:
            self._command_sync_started = False
            logger.exception("Falha ao sincronizar comandos.")



async def run() -> None:
    settings = load_settings()
    store = ConfigStore(settings.data_path)
    bot = Botexin(store)
    try:
        await bot.start(settings.discord_token)
    finally:
        await bot.close()


if __name__ == "__main__":
    try:
        asyncio.run(run())
    except KeyboardInterrupt:
        logger.info("Bot encerrado.")