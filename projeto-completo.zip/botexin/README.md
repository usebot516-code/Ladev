# Botexin

Bot Discord em Python para configurar o sistema de filas com o comando
`/iniciar`.

## O que está incluído

- Exatamente três etapas no `/iniciar`.
- Painel único editado durante a configuração.
- Discord Components V2 com `LayoutView`.
- Configuração persistida em `data/config.json`.
- Controle de permissão por `Gerenciar Servidor`.
- Adição de vários preços em uma única operação.
- Select Menu direto para remover preços, com valores pré-definidos de 0.30 a
  30.00, já cadastrados na configuração inicial.
- Botões organizados verticalmente, sem botões lado a lado.
- Taxa aceita entre 0 e 100, como número normal ou com o sinal `%` para percentual.
- Seleção dos dois canais por Channel Select Menu.
- Views persistentes registradas após reiniciar o bot.
- Nenhuma IA, polling ou chamada paga.

## Como executar

1. Crie um bot no Discord Developer Portal e habilite os escopos `bot` e
   `applications.commands`.
2. Instale as dependências:

   ```bash
   python -m pip install -r requirements.txt
   ```

3. Configure o token apenas como variável de ambiente ou segredo:

   ```bash
   export DISCORD_TOKEN="seu_token"
   ```

4. Inicie:

   ```bash
   python -m botexin.main
   ```

O bot usa somente a API do Discord para responder às interações. As
configurações ficam no arquivo JSON local e são gravadas de forma atômica.

## Regras respeitadas

Os nomes e a estrutura do `/iniciar` seguem `regras.md` e `iniciar.md` da
especificação enviada. Não há escolha de jogo, HEX manual, criação automática
de canais, indicador de progresso, quarta etapa ou emojis nos painéis.