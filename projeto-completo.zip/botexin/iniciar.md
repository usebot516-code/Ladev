# Especificação do `/iniciar`

O fluxo possui exatamente três etapas:

1. **Aparência das filas:** `Cor atual`, `Selecionar uma cor`, `Próximo`.
2. **Valores e taxa:** `Exibição dos valores`, botão `Adicionar preços`,
   Select Menu `Remover preços`, botão `Configurar taxa`, `Voltar`, `Próximo`.
3. **Canais:** `Selecionar canal da fila de mediadores`,
   `Selecionar canal de registro do mediador`, `Voltar`, `Finalizar`.

Os nomes acima são mantidos exatamente no painel. Não há escolha de jogo,
campo HEX, indicador de progresso, criação automática de canais ou etapa
adicional.

O Select Menu `Remover preços` contém os valores pré-definidos:
`0.30`, `0.50`, `0.70`, `1.00`, `2.00`, `3.00`, `4.00`, `5.00`, `10.00`,
`20.00` e `30.00`. Cada botão aparece em sua própria linha.