from __future__ import annotations

import logging

import discord
from discord import app_commands
from discord.ext import commands

from botexin.storage.repository import ConfigStore
from botexin.ui.helpers import can_manage_guild
from botexin.ui.views import Stage1View


logger = logging.getLogger("botexin.iniciar")


class IniciarCog(commands.Cog):
    """The /iniciar flow, kept independent from future bot commands."""

    def __init__(self, bot: commands.Bot, store: ConfigStore) -> None:
        self.bot = bot
        self.store = store

    @app_commands.command(
        name="iniciar",
        description="Configura as filas, os valores, a taxa e os canais do sistema.",
    )
    @app_commands.default_permissions(manage_guild=True)
    async def iniciar(self, interaction: discord.Interaction) -> None:
        if interaction.guild is None:
            await interaction.response.send_message(
                "Este comando só pode ser usado dentro de um servidor.",
                ephemeral=True,
            )
            return

        if not can_manage_guild(interaction, interaction.guild.id):
            await interaction.response.send_message(
                "Você precisa da permissão Gerenciar Servidor para usar este comando.",
                ephemeral=True,
            )
            return

        config = self.store.get(interaction.guild.id)
        config.stage = 1
        config.completed = False
        self.store.save(config)
        try:
            await interaction.response.send_message(
                view=Stage1View(self.store, interaction.guild.id),
                ephemeral=True,
            )
        except discord.DiscordException:
            logger.exception("Falha ao abrir o assistente /iniciar.")
            if interaction.response.is_done():
                await interaction.followup.send(
                    "Não foi possível abrir a configuração agora.",
                    ephemeral=True,
                )
            else:
                await interaction.response.send_message(
                    "Não foi possível abrir a configuração agora.",
                    ephemeral=True,
                )