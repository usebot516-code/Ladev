from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path

from botexin.models import GuildConfig, MatchModel, QueueModel


class ConfigStore:
    """Small JSON store with atomic writes and records for guilds, queues and matches."""

    def __init__(self, path: Path) -> None:
        self.path = path
        self._configs: dict[int, GuildConfig] = {}
        self._queues: dict[str, QueueModel] = {}
        self._matches: dict[str, MatchModel] = {}
        self._load()

    def guild_ids(self) -> list[int]:
        return list(self._configs)

    def get(self, guild_id: int) -> GuildConfig:
        if guild_id not in self._configs:
            self._configs[guild_id] = GuildConfig(guild_id=guild_id)
        return self._configs[guild_id]

    def save(self, config: GuildConfig) -> None:
        config.stage = min(max(config.stage, 1), 3)
        self._configs[config.guild_id] = config
        self._write()

    # Queue management
    def get_queues(self, guild_id: int) -> list[QueueModel]:
        return [q for q in self._queues.values() if q.guild_id == guild_id]

    def get_all_queues(self) -> list[QueueModel]:
        return list(self._queues.values())

    def get_queue(self, queue_id: str) -> QueueModel | None:
        return self._queues.get(queue_id)

    def save_queue(self, queue: QueueModel) -> None:
        self._queues[queue.id] = queue
        self._write()

    def delete_queue(self, queue_id: str) -> bool:
        if queue_id in self._queues:
            del self._queues[queue_id]
            self._write()
            return True
        return False

    def get_player_queues(self, guild_id: int, user_id: int) -> list[QueueModel]:
        return [
            q for q in self.get_queues(guild_id)
            if q.has_player(user_id)
        ]

    def remove_player_from_all_queues(self, guild_id: int, user_id: int) -> list[QueueModel]:
        affected: list[QueueModel] = []
        for q in self.get_queues(guild_id):
            if q.remove_player(user_id):
                affected.append(q)
        if affected:
            self._write()
        return affected

    # Match management
    def save_match(self, match: MatchModel) -> None:
        self._matches[match.id] = match
        self._write()

    def get_matches(self, guild_id: int) -> list[MatchModel]:
        return [m for m in self._matches.values() if m.guild_id == guild_id]

    def _load(self) -> None:
        if not self.path.exists():
            return
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            if not isinstance(raw, dict):
                return
            records = raw.get("guilds", {})
            self._configs = {
                int(guild_id): GuildConfig.from_dict(payload)
                for guild_id, payload in records.items()
                if isinstance(payload, dict)
            }
            raw_queues = raw.get("queues", {})
            self._queues = {
                str(qid): QueueModel.from_dict(payload)
                for qid, payload in raw_queues.items()
                if isinstance(payload, dict)
            }
            raw_matches = raw.get("matches", {})
            self._matches = {
                str(mid): MatchModel.from_dict(payload)
                for mid, payload in raw_matches.items()
                if isinstance(payload, dict)
            }
        except (OSError, ValueError, TypeError, KeyError):
            # A malformed file should not take the bot offline.
            self._configs = {}
            self._queues = {}
            self._matches = {}

    def _write(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "version": 1,
            "guilds": {
                str(guild_id): config.to_dict()
                for guild_id, config in self._configs.items()
            },
            "queues": {
                str(qid): queue.to_dict()
                for qid, queue in self._queues.items()
            },
            "matches": {
                str(mid): match.to_dict()
                for mid, match in self._matches.items()
            },
        }
        fd, temporary_name = tempfile.mkstemp(
            prefix=f"{self.path.name}.",
            suffix=".tmp",
            dir=self.path.parent,
        )
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as temporary:
                json.dump(payload, temporary, ensure_ascii=False, indent=2)
                temporary.write("\n")
                temporary.flush()
                os.fsync(temporary.fileno())
            os.replace(temporary_name, self.path)
        finally:
            if os.path.exists(temporary_name):
                os.unlink(temporary_name)