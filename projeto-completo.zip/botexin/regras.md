REGRAS GERAIS DO PROJETO

1. API E TECNOLOGIA

- Utilizar sempre a versão mais recente e estável da API do Discord disponível no momento da implementação.
- Utilizar Discord Components V2 em todos os sistemas compatíveis.
- O projeto deve ser desenvolvido em Python.
- Utilizar uma biblioteca Python para Discord que seja compatível com a versão atual da API e com os recursos utilizados pelo projeto.
- Não utilizar tecnologias ou versões antigas quando existir uma alternativa atual e compatível.

2. AUTO-REFRESH

- Implementar sistema de Auto-Refresh nos painéis que precisarem permanecer atualizados.
- O Auto-Refresh deve atualizar as informações do painel sem exigir que o usuário execute o comando novamente.
- Atualizações devem ocorrer de forma controlada, evitando consumo desnecessário de recursos.
- O Auto-Refresh não deve criar mensagens ou painéis duplicados.

3. PAINÉIS

- Evitar criar painéis iguais ou desnecessários.
- Sempre que possível, editar o painel existente em vez de enviar outro painel.
- Não enviar várias mensagens para representar uma única atualização.
- Cada painel deve possuir uma finalidade clara.
- Os painéis devem ter descrição bem elaborada e explicar de forma objetiva sua função.
- Manter padrão visual consistente em todo o bot.
- Não utilizar emojis em painéis.
- Não utilizar emojis em botões.
- Não utilizar emojis em embeds.
- Os textos dos painéis devem ser profissionais, claros e bem organizados.

4. SELECT MENUS E COMPONENTES

- Select Menus devem possuir nomes, descrições e placeholders bem elaborados.
- O placeholder deve explicar claramente o que o usuário deve selecionar.
- Cada Select Menu deve possuir uma finalidade específica.
- Não criar Select Menus desnecessários.
- Não utilizar um componente para executar uma função que deveria pertencer a outro sistema.
- Os componentes devem possuir comportamento previsível e consistente.
- Os nomes definidos na especificação de cada sistema devem ser respeitados exatamente.
- Não alterar nomes de botões, Select Menus ou outros componentes sem solicitação explícita.

5. BOTÕES

- Botões devem possuir nomes claros e objetivos.
- Não utilizar emojis em nenhum botão.
- Cada botão deve executar somente a função para a qual foi criado.
- Evitar criar botões duplicados ou com funções semelhantes sem necessidade.
- Botões de navegação devem editar o painel atual sempre que possível.

6. ATUALIZAÇÕES DO PROJETO

- Sempre que o bot ou qualquer parte do projeto for atualizada, gerar um novo arquivo ".zip" contendo o projeto atualizado.
- O ".zip" deve ser enviado junto com a atualização.
- Nunca incluir a pasta "node_modules" no ".zip".
- Como o projeto utiliza Python, também não incluir ambientes virtuais ou arquivos temporários desnecessários, como "venv", ".venv", "__pycache__" e arquivos ".pyc".
- O arquivo ".zip" deve conter somente os arquivos necessários para executar, configurar e manter o projeto.

7. REGRA PRINCIPAL

- Estas regras são obrigatórias para todo o projeto.
- Novos comandos, sistemas, painéis e componentes devem seguir estas regras.
- Nenhum sistema deve ignorar estas regras sem uma solicitação explícita.