import { spawn, ChildProcess } from 'child_process';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';

export interface LogEntry {
  id: string;
  timestamp: string;
  type: 'stdout' | 'stderr' | 'system' | 'error' | 'ready';
  message: string;
}

export interface BotState {
  status: 'offline' | 'starting' | 'online' | 'error';
  tag?: string;
  id?: string;
  avatar?: string;
  guildCount: number;
  uptimeSeconds: number;
  startedAt?: number;
  lastError?: string;
  workers: Array<{ slot: number; state: string; tag?: string; id?: string }>;
  memoryUsageMb: number;
}

class DiscordBotManager {
  private child: ChildProcess | null = null;
  private logs: LogEntry[] = [];
  private maxLogs = 500;
  private state: BotState = {
    status: 'offline',
    guildCount: 0,
    uptimeSeconds: 0,
    workers: [],
    memoryUsageMb: 0,
  };
  private logIdCounter = 0;
  private startedTime: number | null = null;
  private configFilePath: string;

  constructor() {
    const dataDir = path.join(process.cwd(), 'data');
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    this.configFilePath = path.join(dataDir, 'app_config.json');
    this.loadAppConfig();
    this.ensureDefaultSessionSecret();
  }

  public loadAppConfig() {
    try {
      if (fs.existsSync(this.configFilePath)) {
        const raw = fs.readFileSync(this.configFilePath, 'utf8').trim();
        if (raw) {
          const cfg = JSON.parse(raw);
          if (cfg.token && !process.env.DISCORD_BOT_TOKEN) {
            process.env.DISCORD_BOT_TOKEN = cfg.token;
          }
          if (cfg.guildId && !process.env.DISCORD_GUILD_ID) {
            process.env.DISCORD_GUILD_ID = cfg.guildId;
          }
          if (cfg.ownerRoleId && !process.env.BOT_OWNER_ROLE_ID) {
            process.env.BOT_OWNER_ROLE_ID = cfg.ownerRoleId;
          }
          if (cfg.sessionSecret && !process.env.SESSION_SECRET) {
            process.env.SESSION_SECRET = cfg.sessionSecret;
          }
          if (cfg.mercadoPagoToken && !process.env.MERCADOPAGO_ACCESS_TOKEN) {
            process.env.MERCADOPAGO_ACCESS_TOKEN = cfg.mercadoPagoToken;
          }
          if (cfg.tryzeApiKey && !process.env.TRYZE_CALLS_API_KEY) {
            process.env.TRYZE_CALLS_API_KEY = cfg.tryzeApiKey;
          }
          if (cfg.tryzeApiUrl && !process.env.TRYZE_API_URL) {
            process.env.TRYZE_API_URL = cfg.tryzeApiUrl;
          }
          console.log('[CONFIG] Configurações persistentes carregadas de data/app_config.json');
        }
      }
    } catch (err: any) {
      console.error('[CONFIG] Erro ao carregar app_config.json:', err.message);
    }
  }

  public saveAppConfig(updates?: {
    token?: string;
    guildId?: string;
    ownerRoleId?: string;
    sessionSecret?: string;
    mercadoPagoToken?: string;
    tryzeApiKey?: string;
    tryzeApiUrl?: string;
  }) {
    try {
      let current: Record<string, any> = {};
      if (fs.existsSync(this.configFilePath)) {
        try {
          const raw = fs.readFileSync(this.configFilePath, 'utf8').trim();
          if (raw) current = JSON.parse(raw);
        } catch (_) {}
      }

      if (updates?.token !== undefined) current.token = updates.token;
      else if (process.env.DISCORD_BOT_TOKEN) current.token = process.env.DISCORD_BOT_TOKEN;

      if (updates?.guildId !== undefined) current.guildId = updates.guildId;
      else if (process.env.DISCORD_GUILD_ID) current.guildId = process.env.DISCORD_GUILD_ID;

      if (updates?.ownerRoleId !== undefined) current.ownerRoleId = updates.ownerRoleId;
      else if (process.env.BOT_OWNER_ROLE_ID) current.ownerRoleId = process.env.BOT_OWNER_ROLE_ID;

      if (updates?.sessionSecret !== undefined) current.sessionSecret = updates.sessionSecret;
      else if (process.env.SESSION_SECRET) current.sessionSecret = process.env.SESSION_SECRET;

      if (updates?.mercadoPagoToken !== undefined) current.mercadoPagoToken = updates.mercadoPagoToken;
      else if (process.env.MERCADOPAGO_ACCESS_TOKEN) current.mercadoPagoToken = process.env.MERCADOPAGO_ACCESS_TOKEN;

      if (updates?.tryzeApiKey !== undefined) current.tryzeApiKey = updates.tryzeApiKey;
      else if (process.env.TRYZE_CALLS_API_KEY) current.tryzeApiKey = process.env.TRYZE_CALLS_API_KEY;

      if (updates?.tryzeApiUrl !== undefined) current.tryzeApiUrl = updates.tryzeApiUrl;
      else if (process.env.TRYZE_API_URL) current.tryzeApiUrl = process.env.TRYZE_API_URL;

      const tmp = this.configFilePath + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify(current, null, 2), 'utf8');
      fs.renameSync(tmp, this.configFilePath);
      console.log('[CONFIG] Configurações persistidas com sucesso em data/app_config.json');

      // Atualizar também o arquivo .env para que o zip e qualquer subprocesso estejam sempre sincronizados
      try {
        const envPath = path.join(process.cwd(), '.env');
        const envLines = [
          '# Discord Bot Configuration',
          `DISCORD_BOT_TOKEN=${current.token || process.env.DISCORD_BOT_TOKEN || ''}`,
          `DISCORD_GUILD_ID=${current.guildId || process.env.DISCORD_GUILD_ID || ''}`,
          `GUILD_ID=${current.guildId || process.env.GUILD_ID || ''}`,
          `BOT_OWNER_ROLE_ID=${current.ownerRoleId || process.env.BOT_OWNER_ROLE_ID || ''}`,
          `CARGO_OWNER_ID=${current.ownerRoleId || process.env.CARGO_OWNER_ID || ''}`,
          `SESSION_SECRET=${current.sessionSecret || process.env.SESSION_SECRET || ''}`,
        ];
        if (current.mercadoPagoToken || process.env.MERCADOPAGO_ACCESS_TOKEN) {
          envLines.push(`MERCADOPAGO_ACCESS_TOKEN=${current.mercadoPagoToken || process.env.MERCADOPAGO_ACCESS_TOKEN}`);
        }
        if (current.tryzeApiKey || process.env.TRYZE_CALLS_API_KEY) {
          envLines.push(`TRYZE_CALLS_API_KEY=${current.tryzeApiKey || process.env.TRYZE_CALLS_API_KEY}`);
        }
        if (current.tryzeApiUrl || process.env.TRYZE_API_URL) {
          envLines.push(`TRYZE_API_URL=${current.tryzeApiUrl || process.env.TRYZE_API_URL}`);
        }
        fs.writeFileSync(envPath, envLines.join('\n') + '\n', 'utf8');
      } catch (envErr: any) {
        console.warn('[CONFIG] Erro ao sincronizar .env:', envErr.message);
      }
    } catch (err: any) {
      console.error('[CONFIG] Erro ao salvar app_config.json:', err.message);
    }
  }

  private ensureDefaultSessionSecret() {
    if (!process.env.SESSION_SECRET) {
      process.env.SESSION_SECRET = 'ryze_secret_' + crypto.randomBytes(16).toString('hex');
      this.saveAppConfig();
    }
  }

  public addLog(type: LogEntry['type'], message: string) {
    const entry: LogEntry = {
      id: `log-${Date.now()}-${++this.logIdCounter}`,
      timestamp: new Date().toLocaleTimeString('pt-BR', { hour12: false }),
      type,
      message: message.trim(),
    };
    this.logs.push(entry);
    if (this.logs.length > this.maxLogs) {
      this.logs.shift();
    }
    // Also output to console for node log visibility
    if (type === 'error' || type === 'stderr') {
      console.error(`[DISCORD-BOT] ${message}`);
    } else {
      console.log(`[DISCORD-BOT] ${message}`);
    }
  }

  public getLogs(): LogEntry[] {
    return this.logs;
  }

  public clearLogs() {
    this.logs = [];
  }

  public getState(): BotState {
    const uptime = this.startedTime ? Math.floor((Date.now() - this.startedTime) / 1000) : 0;
    return {
      ...this.state,
      uptimeSeconds: uptime,
    };
  }

  public start(customToken?: string): Promise<{ success: boolean; message: string }> {
    if (this.child && !this.child.killed) {
      return Promise.resolve({ success: false, message: 'O bot já está em execução.' });
    }

    const token = customToken || process.env.DISCORD_BOT_TOKEN || process.env.DISCORD_TOKEN;
    if (!token) {
      this.addLog('error', 'Token do Discord não informado. Configure a variável DISCORD_BOT_TOKEN ou insira no painel.');
      this.state.status = 'error';
      this.state.lastError = 'Token do Discord ausente';
      return Promise.resolve({ success: false, message: 'Token do Discord não configurado.' });
    }

    // Save token to environment
    process.env.DISCORD_BOT_TOKEN = token;
    this.ensureDefaultSessionSecret();

    this.state.status = 'starting';
    this.state.lastError = undefined;
    this.addLog('system', `Iniciando Ryze Discord Bot...`);

    const botIndexPath = path.join(process.cwd(), 'bot_src', 'index.js');
    const dataDir = path.join(process.cwd(), 'data');

    const env = {
      ...process.env,
      DISCORD_BOT_TOKEN: token,
      GUILD_ID: process.env.DISCORD_GUILD_ID || process.env.GUILD_ID || '',
      DISCORD_GUILD_ID: process.env.DISCORD_GUILD_ID || process.env.GUILD_ID || '',
      BOT_DATA_DIR: dataDir,
      NODE_ENV: 'production',
    };

    try {
      this.child = spawn(process.execPath, [botIndexPath], {
        env,
        cwd: process.cwd(),
        stdio: ['ignore', 'pipe', 'pipe', 'ipc'],
      });

      this.startedTime = Date.now();

      this.child.stdout?.on('data', (data) => {
        const text = data.toString('utf8');
        const lines = text.split('\n').filter((l: string) => l.trim().length > 0);
        for (const line of lines) {
          this.addLog('stdout', line);

          // Detect ready or user tag from output
          if (line.includes('Online como') || line.includes('Logado como') || line.includes('ready')) {
            this.state.status = 'online';
            const match = line.match(/(?:Online como|Logado como)\s+([^!\n\r]+)/i);
            if (match && match[1]) {
              this.state.tag = match[1].trim();
            }
          }
          if (line.includes('[ERRO]') || line.includes('[FATAL]')) {
            this.state.lastError = line;
          }
        }
      });

      this.child.stderr?.on('data', (data) => {
        const text = data.toString('utf8');
        const lines = text.split('\n').filter((l: string) => l.trim().length > 0);
        for (const line of lines) {
          this.addLog('stderr', line);
          if (line.toLowerCase().includes('token') && line.toLowerCase().includes('invalid')) {
            this.state.status = 'error';
            this.state.lastError = 'Token inválido do Discord';
          }
        }
      });

      this.child.on('message', (message: any) => {
        if (message?.type === 'ready') {
          this.state.status = 'online';
          this.state.tag = message.tag || this.state.tag;
          this.state.id = message.id || this.state.id;
          this.addLog('ready', `[READY] Bot autenticado com sucesso! ID: ${message.id} | Tag: ${message.tag}`);
        }
        if (message?.type === 'stats') {
          this.state.guildCount = message.guildCount || this.state.guildCount;
        }
      });

      this.child.on('error', (err) => {
        this.addLog('error', `Falha no processo do bot: ${err.message}`);
        this.state.status = 'error';
        this.state.lastError = err.message;
      });

      this.child.on('exit', (code, signal) => {
        this.addLog('system', `Processo do bot encerrado (código: ${code}, sinal: ${signal})`);
        this.state.status = 'offline';
        this.startedTime = null;
        this.child = null;
      });

      // If the bot hasn't sent ready event within 15s, check process
      setTimeout(() => {
        if (this.child && !this.child.killed && this.state.status === 'starting') {
          // If still starting and not ready, warn
          this.addLog('system', 'Aguardando confirmação de login no Discord Gateway...');
        }
      }, 10000);

      return Promise.resolve({ success: true, message: 'Bot iniciado com sucesso.' });
    } catch (err: any) {
      this.state.status = 'error';
      this.state.lastError = err.message;
      this.addLog('error', `Erro ao criar processo: ${err.message}`);
      return Promise.resolve({ success: false, message: `Erro ao iniciar: ${err.message}` });
    }
  }

  public stop(): Promise<{ success: boolean; message: string }> {
    if (!this.child || this.child.killed) {
      this.state.status = 'offline';
      this.startedTime = null;
      this.child = null;
      return Promise.resolve({ success: true, message: 'O bot já está parado.' });
    }

    const currentChild = this.child;
    this.child = null;
    this.addLog('system', 'Solicitando desligamento do bot...');

    return new Promise((resolve) => {
      let resolved = false;
      const finish = () => {
        if (!resolved) {
          resolved = true;
          this.state.status = 'offline';
          this.startedTime = null;
          resolve({ success: true, message: 'Bot parado com sucesso.' });
        }
      };

      currentChild.once('exit', finish);
      try {
        currentChild.kill('SIGTERM');
      } catch (_) {}

      setTimeout(() => {
        if (!currentChild.killed) {
          try {
            currentChild.kill('SIGKILL');
          } catch (_) {}
        }
        finish();
      }, 1500);
    });
  }

  public async restart(customToken?: string): Promise<{ success: boolean; message: string }> {
    await this.stop();
    await new Promise((r) => setTimeout(r, 1000));
    return this.start(customToken);
  }
}

export const botManagerInstance = new DiscordBotManager();
